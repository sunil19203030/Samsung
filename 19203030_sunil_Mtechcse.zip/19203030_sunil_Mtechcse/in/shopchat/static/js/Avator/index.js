import React from "react";
import {
    connect
} from 'react-redux';
import samsungIcon from "../assets/samsungavator.png";
import membersIcon from "../assets/membersavatar.svg";
import Constants from '../Resources/Constants';
import './style.css';



class Avator extends React.Component {
        constructor(props) {
            super(props);
            this.state = {
                node: this.getImage(props)
            };

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }

        getImage(props) {
            if (props.agentProfilePhoto) {
                return props.agentProfilePhoto;
            } else if (props.originatorInfo && props.originatorInfo.agentName && props.originatorInfo.agentName !== "Product Expert") {

                let agentName = props.originatorInfo.agentName.trim().split(" ");
                agentName = (agentName.length > 1 ? agentName[0].charAt(0) + agentName[1].charAt(0) : agentName.length === 1 ? agentName[0].charAt(0) : "");
                if (agentName) {
                    const theme = this.props.theme ? this.props.theme : ''
                    return <div data - letters = {
                        agentName.toUpperCase()
                    }
                    className = {
                        `agent_name_style agent_name_style${theme}`
                    } > < /div>;
                } else {
                    return samsungIcon;
                }

            } else if (props.originatorInfo && (props.originatorInfo.userFullName || props.originatorInfo.userNickName)) {

                let agentUserName = props.originatorInfo.userFullName ? props.originatorInfo.userFullName.trim().split(" ") : props.originatorInfo.userNickName ? props.originatorInfo.userNickName.trim().split(" ") : "";
                agentUserName = (Array.isArray(agentUserName) && agentUserName.length > 1 ? agentUserName[0].charAt(0) + agentUserName[1].charAt(0) : (Array.isArray(agentUserName) && agentUserName.length === 1) ? agentUserName[0].charAt(0) : "");
                if (agentUserName) {
                    const theme = this.props.theme ? this.props.theme : ''
                    return <div data - letters = {
                        agentUserName.toUpperCase()
                    }
                    className = {
                        `agent_name_style agent_name_style${theme}`
                    } > < /div>;
                } else {
                    return samsungIcon;
                }

            } else if ((props.appType === 'shopsamsung' || (props.userObj && props.userObj["app-type"] === 'samsung.com')) && props.originatorInfo === "shopbot") {

                return samsungIcon;

            } else if (props.originatorInfo === "supportbot" && (props.appType.toLowerCase() === "splus" || props.appType.toLowerCase() === "iossplus" || props.appType === 'shopsamsung' || props.appType === 'samsung.com')) {

                return membersIcon;

            } else if ((props.appType === 'shopsamsung' || props.appType === 'samsung.com')) {

                return samsungIcon;

            } else if (props.appType.toLowerCase() === "splus" || props.appType.toLowerCase() === "iossplus") {
                return membersIcon;
            } else {
                return samsungIcon;
            }

        }
        render() {
                return ((this.state.node && this.state.node.type ? this.state.node : < img src = {
                            this.state.node
                        }
                        className = "loader-image agent-avator"
                        alt = {
                            ""
                        }
                        />))
                    }
                }

                const mapStateToProps = (state) => {
                    return {
                        theme: state.theme
                    }
                }

                export default connect(mapStateToProps)(Avator)