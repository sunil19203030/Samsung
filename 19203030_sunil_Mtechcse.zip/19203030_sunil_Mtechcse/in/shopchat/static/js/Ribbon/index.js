import React from 'react';
import ReactDOM from 'react-dom';
import {
    connect
} from 'react-redux';
import './style.css';
import * as Utils from '../Util/Util'
import Constants from '../Resources/Constants';


class Ribbon extends React.Component {
        constructor(props) {
            super(props);
            this.escalation_node_array = [];

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
                this.notification = require('../assets/icon_notifications.svg')
            } else {
                this.notification = require('../assets/notification_new.png')
            }
        }
        componentDidMount() {
            if (this.props.hideLoader) {
                this.props.hideLoader();
            }
            if (this.props.escalation_status === "show_agent_helpful") {
                Utils.setCustomerFirstMessageNeedToSend(true);
            }
            ReactDOM.findDOMNode(this.Ribbon).scrollIntoView(false);
        }
        render() {
                const theme = this.props.theme ? this.props.theme : ''
                return ( < div style = {
                            {
                                clear: "both"
                            }
                        }
                        className = {
                            this.props.escalation_status ? this.props.escalation_status + "_parent_div" : ""
                        } > {
                            (this.props.escalation_status && this.props.escalation_status === "initiated" ?
                                <
                                div >
                                <
                                div className = {
                                    `escalationInitDiv escalationInitDiv${theme} initalDiv`
                                } >
                                <
                                div className = 'sweet-loading' >
                                <
                                div className = {
                                    `css-1ibav57 css-1ibav57${theme}`
                                } > < /div> <
                                div className = {
                                    `css-1ibav57 css-1ibav57${theme}`
                                } > < /div> <
                                div className = {
                                    `css-1ibav57 css-1ibav57${theme}`
                                } > < /div> <
                                div className = {
                                    `css-1ibav57 css-1ibav57${theme}`
                                } > < /div> <
                                /div><p>{(this.props.escalatin_status_message?this.props.escalatin_status_message:"")}</p > < /div>


                                <
                                /div> : null)}

                                {
                                    (this.props.escalation_status && this.props.escalation_status === "connected" ? < div >
                                        <
                                        div className = {
                                            `escalationConnectedDiv escalationConnectedDiv${theme}`
                                        } >
                                        <
                                        div className = "notification" >
                                        <
                                        div className = {
                                            `circle circle${theme}`
                                        } >
                                        <
                                        img src = {
                                            this.notification
                                        }
                                        alt = {
                                            "Notification"
                                        }
                                        /> <
                                        /div> <
                                        /div> <
                                        p > {
                                            (this.props.escalatin_status_message ? this.props.escalatin_status_message : "")
                                        } < /p> <
                                        /div> <
                                        /div> : null)}

                                        {
                                            (this.props.escalation_status && this.props.escalation_status === "show_agent_helpful" ?
                                                <
                                                div className = {
                                                    `showagentInfo showagentInfo${theme}`
                                                } > {
                                                    (this.props.escalatin_status_message ? this.props.escalatin_status_message : "")
                                                } < /div> : null)} {

                                                    (this.props.escalation_status && (this.props.escalation_status === "agent_closed_conversation" || this.props.escalation_status === "conversation_closed" || this.props.escalation_status === "expert_markasresolved" || this.props.escalation_status === "closed" || this.props.escalation_status === "rerouted") ? < div className = "agentConnectionNotification" >
                                                        <
                                                        div className = {
                                                            `agent_connection_notification_child_div agent_connection_notification_child_div${theme}`
                                                        } >
                                                        <
                                                        p > {
                                                            (this.props.escalatin_status_message ? this.props.escalatin_status_message : "")
                                                        } < /p> <
                                                        /div> <
                                                        /div> : null)
                                                    } {

                                                        (this.props.escalation_status && this.props.escalation_status === "close_status" ? < div className = "header_close_notification_div" >
                                                            <
                                                            div className = "header_close_notification_div_child_div" >
                                                            <
                                                            p > {
                                                                (this.props.escalatin_status_message ? this.props.escalatin_status_message : "")
                                                            } < /p> <
                                                            /div> <
                                                            /div> : null)
                                                        }

                                                        {
                                                            (this.props.escalation_status && this.props.escalation_status === "resume" ? < div className = "agentConnectionNotification" >
                                                                <
                                                                div className = {
                                                                    `agent_connection_notification_child_div agent_connection_notification_child_div${theme}`
                                                                } >
                                                                <
                                                                p > {
                                                                    (this.props.escalatin_status_message ? this.props.escalatin_status_message : "")
                                                                } < /p> <
                                                                /div> <
                                                                /div> : null)
                                                            } <
                                                            div ref = {
                                                                    (refs) => {
                                                                        this.Ribbon = refs
                                                                    }
                                                                } > < /div> <
                                                                /div>);



                                                        }
                                                    }

                                                    const mapStateToProps = (state) => {
                                                        return {
                                                            theme: state.theme
                                                        }
                                                    }

                                                    export default connect(mapStateToProps)(Ribbon)