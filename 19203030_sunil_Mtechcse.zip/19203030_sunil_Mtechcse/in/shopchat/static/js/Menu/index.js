import React from 'react';
import leftArrow from '../assets/leftArrow.png';
import rightArrow from '../assets/rightArrow.png';
import * as utils from '../Util/Util';
import * as NetworkHelper from '../Util/NetworkHelper';
import PopupModal from '../PopupModal/index';
import Constants from '../Resources/Constants';
import {
    connect
} from 'react-redux';
import {
    closeChat
} from '../actions/action';
import './style.css';

class Menu extends React.Component {
        constructor(props) {
            super(props);
            this.previousMenuMap = {};
            this.menu = [];
            if (this.props.drawerMenus && this.props.drawerMenus.menu && this.props.drawerMenus.menu.params) {
                if (this.props.drawerMenus.menu.params && utils.getisConnectedWithAgent() && this.props.drawerMenus.menu.params["agent_escalation_call_to_actions"]) {
                    this.menu = this.props.drawerMenus.menu.params["agent_escalation_call_to_actions"];
                } else if (this.props.drawerMenus.menu.params["call_to_actions"]) {
                    this.menu = this.props.drawerMenus.menu.params["call_to_actions"];
                }

            }
            this.state = {
                drawerMenus: "",
                level: 0,
                menu: {
                    "menu": this.menu
                },
                isShowMenu: false,
                isShowParentMenu: false,
                parentMenuLabel: "",
                menuHeight: "70%",
                isShowPopup: false
            };

            if (props.state && props.state.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }


        componentDidMount() {
            this.props.hideLoader(true);
        }

        getHeightForMessageDiv = () => {
            let height = document.getElementsByClassName("widget-container")[0].offsetHeight -
                document.getElementsByClassName("senderMainDiv")[0].offsetHeight;
            if (document.getElementsByClassName("header").length > 0) {
                height = height - document.getElementsByClassName("header")[0].offsetHeight;
            }
            if (document.getElementsByClassName("error-snackbar-parentdiv") && document.getElementsByClassName("error-snackbar-parentdiv").length > 0) {
                height = height - document.getElementsByClassName("error-snackbar-parentdiv")[0].offsetHeight;
            }
            return height;
        }


        showDrawerMenu = () => {
                if (this.props.drawerMenus != null) {
                    if (!this.state.isShowMenu) {
                        const theme = this.props.state && this.props.state.theme ? this.props.state.theme : ''
                        return this.state.menu.menu.map((value, index) => {
                                if (utils.getisConnectedWithAgent() && value["active_during_agent_conversation"] && value["active_during_agent_conversation"].toString() === "true") {
                                    return <div key = {
                                        index
                                    }
                                    className = {
                                        `menuNode menuNode${theme}`
                                    }
                                    onClick = {
                                        this.drawMenuEventHandling.bind(this, value)
                                    } > {
                                        value["title"]
                                    } {
                                        value["type"] === "nested" ? < img className = "rightArrow"
                                        alt = {
                                            "Arrow"
                                        }
                                        src = {
                                            rightArrow
                                        }
                                        /> : null}</div >
                                    } else if (value["title"] != 'Start Over' && (value["active_during_agent_conversation"] === undefined || value["active_during_agent_conversation"].toString() === "false")) {

                                        return <div key = {
                                            index
                                        }
                                        className = {
                                            `menuNode menuNode${theme}`
                                        }
                                        onClick = {
                                            this.drawMenuEventHandling.bind(this, value)
                                        } > {
                                            value["title"]
                                        } {
                                            value["type"] === "nested" ? < img className = "rightArrow"
                                            alt = {
                                                "Arrow"
                                            }
                                            src = {
                                                rightArrow
                                            }
                                            /> : null}</div >
                                        }
                                        return null;
                                    })
                            } else {
                                let messageHeight = this.getHeightForMessageDiv();
                                utils.getMessagerNodeRef().style.height = messageHeight + "px"
                            }
                        }
                    }

                    drawMenuEventHandling = (eventObj) => {
                        let menuEventObj = eventObj;
                        /*when menu event is postback just send back to bot else need to draw the next level menu */
                        if (menuEventObj.type === "postback") {
                            this.props.userSubmitValueToServer(menuEventObj.title)
                            let messageHeight = this.getHeightForMessageDiv();
                            utils.getMessagerNodeRef().style.height = messageHeight + "px"
                            NetworkHelper.buildRequestToSend('event', menuEventObj.payload, NetworkHelper.getUserInfo(), {
                                text: menuEventObj.title,
                                optionsSelection: true,
                                drawerMenu: true
                            });
                            this.setState({
                                isShowMenu: false,
                                isShowParentMenu: false
                            });
                        } else if (menuEventObj.type === "popup") {
                            this.popupObj = menuEventObj;

                            this.setState({
                                isShowPopup: true
                            });
                            /*while drawing popup just checking web or mobile and drawing
                            if(!this.props.drawerMenus.menu.params.ui_style||(this.props.drawerMenus.menu.params.ui_style&&this.props.drawerMenus.menu.params.ui_style!=="web"))
                            {
                               this.setState({ isShowPopup: true });
                              
                            }else
                            {
                                    this.props.closeChat(menuEventObj);
                                    utils.getMessagerNodeRef().style.height = "90%";
                                    this.props.userSubmitValueToServer();
                                
                                    (document.getElementsByClassName("endChatDiv")[0]?document.getElementsByClassName("endChatDiv")[0].style.display = "block":null);
                                    (document.getElementsByClassName("senderMainDiv")[0]?document.getElementsByClassName("senderMainDiv")[0].style.display = "none":null);
                                
                            }
                            */



                        } else {
                            this.setState({
                                "drawerMenus": "",
                                isShowMenu: false
                            })
                            /*let drawerMenus = menuEventObj.call_to_actions.map((value, key) => {
                                return <div className="menuNode" onClick={this.drawMenuEventHandling.bind(this, value)}>{value["title"]}{value["type"] === "nested" ? <img className="rightArrow" src={rightArrow} alt={"Arrow"} /> : null}</div>
                            })*/
                            this.previousMenuMap[this.state.level] = this.state.menu;
                            this.setState({
                                "menu": {
                                    menu: menuEventObj.call_to_actions,
                                    menuObj: menuEventObj
                                },
                                level: this.state.level + 1,
                                isShowMenu: false,
                                isShowParentMenu: true,
                                menuHeight: "50%",
                                parentMenuLabel: menuEventObj.title
                            })
                            setTimeout(() => {
                                let messageHeight = this.getHeightForMessageDiv();
                                if (messageHeight > 0) {
                                    utils.getMessagerNodeRef().style.height = messageHeight + "px"
                                }
                            }, 100)
                        }
                    }

                    showParentMenu() {
                        if (this.state.level - 1 === 0) {
                            this.setState({
                                isShowParentMenu: false,
                                level: this.state.level - 1,
                                "menu": this.previousMenuMap[this.state.level - 1]
                            }, () => {
                                this.showDrawerMenu()
                            });
                        } else if (this.state.level > 0) {
                            let previousMenuObj = this.previousMenuMap[this.state.level - 1];
                            this.setState({
                                isShowParentMenu: true,
                                level: this.state.level - 1,
                                parentMenuLabel: previousMenuObj.menuObj.title,
                                "menu": previousMenuObj
                            }, () => {
                                this.showDrawerMenu()
                            });
                        }

                    }
                    onPopupClose = () => {
                        this.setState({
                            isShowPopup: false,
                            isShowMenu: false
                        }, () => {
                            this.props.userSubmitValueToServer();
                            setTimeout(() => {
                                let messageHeight = this.getHeightForMessageDiv();
                                utils.getMessagerNodeRef().style.height = messageHeight + "px"
                            }, 500)

                        });

                    }
                    onPopupSubmit = (postbackUrl) => {
                        this.setState({
                            isShowPopup: false,
                            isShowMenu: false
                        }, () => {
                            this.props.userSubmitValueToServer();
                            setTimeout(() => {
                                let messageHeight = this.getHeightForMessageDiv();
                                utils.getMessagerNodeRef().style.height = messageHeight + "px"
                            }, 500)
                            NetworkHelper.onPopupEvnetHandler(postbackUrl, {
                                drawerMenu: true
                            });
                        });


                    }


                    render() {
                            return ( < div > {
                                        (this.state.isShowParentMenu ? < div className = "menuNodeParent"
                                            onClick = {
                                                () => this.showParentMenu()
                                            } > < img className = "leftArrow"
                                            alt = {
                                                "Arrow"
                                            }
                                            src = {
                                                leftArrow
                                            }
                                            />{this.state.parentMenuLabel}</div > : null)
                                    } {
                                        (this.props.drawerMenus ? this.showDrawerMenu() : null)
                                    } {
                                        (this.state.isShowMenu ? < div className = "menuContainer"
                                            style = {
                                                {
                                                    maxHeight: this.state.menuHeight
                                                }
                                            }
                                            ref = {
                                                (ref) => {
                                                    this.drawerMenuNode = ref
                                                }
                                            } > {
                                                this.state.drawerMenus
                                            } < /div> : null)} {
                                                (this.state.isShowPopup ? < PopupModal popupObj = {
                                                        this.popupObj
                                                    }
                                                    onClose = {
                                                        this.onPopupClose
                                                    }
                                                    onPopupSubmit = {
                                                        this.onPopupSubmit
                                                    } > < /PopupModal> : null)}</div > );
                                            }
                                        }


                                        const mapDispatchToProps = dispatch => ({
                                            closeChat: (data) => dispatch(closeChat(data))
                                        })

                                        const mapStateToProps = (state) => {
                                            return {
                                                state
                                            }
                                        }

                                        export default connect(mapStateToProps, mapDispatchToProps)(Menu)