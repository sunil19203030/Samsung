import React from 'react';
import {
    connect
} from 'react-redux';
import PropTypes from 'prop-types';
import './style.css';
import closeIcon from '../assets/closeIcon.png';
import * as utils from '../Util/Util';
import Constants from '../Resources/Constants';

class Modal extends React.Component {


        constructor(props) {
            super(props);
            this.state = {
                "isShowDialog": true
            };

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }

        closeDialog() {
            this.setState({
                "isShowDialog": false
            });
            document.getElementById("MessageDiv").classList.remove("containerOverlay");
            if (utils.getisSurveyIsRequired()) {
                utils.setisSurveyIsRequired(false);
                utils.postMessageToParent("closeChat");
                if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                    window.frames.location.reload(true);
                }
            }
        }

        handleClick() {
            this.props.onClose()
        }

        render() {

            if (!this.props.show) {
                return null;
            }

            const theme = this.props.theme ? this.props.theme : ''
            return (
                (this.state.isShowDialog ? < div className = "backdropStyle" >
                    <
                    div className = {
                        `modalStyle modalStyle${theme}`
                    } >
                    <
                    div className = {
                        `headerModal headerModal${theme}`
                    } >
                    <
                    img src = {
                        closeIcon
                    }
                    alt = {
                        ""
                    }
                    onClick = {
                        () => {
                            this.closeDialog()
                        }
                    }
                    /> <
                    /div> <
                    div className = "modal-content" > {
                        this.props.children
                    } <
                    /div>

                    <
                    div className = {
                        `footer footer${theme}`
                    } >
                    <
                    div className = {
                        `footer-content footer-content${theme}`
                    }
                    onClick = {
                        this.handleClick.bind(this)
                    } > {
                        this.props.cta_text
                    } <
                    /div> <
                    /div> <
                    /div> <
                    /div> : null)
                );
            }
        }

        Modal.propTypes = {
            onClose: PropTypes.func.isRequired,
            show: PropTypes.bool,
            children: PropTypes.node
        };

        const mapStateToProps = (state) => {
            return {
                theme: state.theme
            }
        }

        export default connect(mapStateToProps)(Modal)