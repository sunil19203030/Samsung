import React from 'react'
import {
    connect
} from 'react-redux';
import Constants from '../Resources/Constants';

import './style.css';



class ChatClientCallback extends React.Component {

        constructor(props) {
            super(props)
        }

        render() {
                return ( <
                        div >
                        <
                        div className = "conversation-container-header" > {
                            Constants.HEADER
                        } < /div> <
                        div className = "conversation-container-secondary-header" > {
                            Constants.SECONDARY_HEADER_CALLBACK
                        } < /div>             {
                            !this.props.iscallbackSelected ? < div className = "conversation-container-third-header" > {
                                Constants.THIRD_HEADER_CALLBACK
                            } < /div> : null } {
                                !this.props.iscallbackSelected ?
                                    <
                                    div className = "input-field-form" >
                                    <
                                    div className = "input-field-container-time"
                                onClick = {
                                        this.props.callbackEight
                                    } >
                                    8 AM - 10 AM <
                                    /div> <
                                    div className = "input-field-container-time"
                                onClick = {
                                        this.props.callbackTen
                                    } >
                                    10 AM - 12 Noon <
                                    /div> <
                                    div className = "input-field-container-time"
                                onClick = {
                                        this.props.callbackTwelve
                                    } >
                                    12 Noon - 2 PM <
                                    /div> <
                                    div className = "input-field-container-time"
                                onClick = {
                                        this.props.callbackTwo
                                    } >
                                    2 PM - 4 PM <
                                    /div> <
                                    div className = "input-field-container-time"
                                onClick = {
                                        this.props.callbackFour
                                    } >
                                    4 PM - 6 PM <
                                    /div> <
                                    div className = "input-field-container-time"
                                onClick = {
                                        this.props.callbackSix
                                    } >
                                    6 PM - 8 PM <
                                    /div> <
                                    /div> : null } {
                                        this.props.iscallbackSelected ? < div className = "conversation-container-callback-ack" > Thank you
                                        for the input.Our product expert will
                                        try to get in touch with you within the desired timeslot.({
                                                this.props.selectedSlot
                                            }) < /div> : null}     <
                                            /div>

                                    );
                            }

                        }



                        const mapStateToprops = (state) => ({
                            state
                        })

                        export default connect(mapStateToprops)(ChatClientCallback);