import React from 'react';
import icon_no_signal from '../assets/ic_no_signal.png';
import './style.css';
import * as utils from '../Util/Util';

export default class ErrorSnackbar extends React.Component {

        componentDidMount() {
            let messageHeight = this.getHeightForMessageDiv();
            if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > -1) {
                messageHeight = messageHeight - 10;
            }
            utils.getMessagerNodeRef().style.height = messageHeight + "px"
        }
        getHeightForMessageDiv = () => {
            let height = document.getElementsByClassName("widget-container")[0].offsetHeight -
                document.getElementsByClassName("senderMainDiv")[0].offsetHeight;
            if (document.getElementsByClassName("header").length > 0) {
                height = height - document.getElementsByClassName("header")[0].offsetHeight;
            }
            if (document.getElementsByClassName("error-snackbar-parentdiv") && document.getElementsByClassName("error-snackbar-parentdiv").length > 0) {
                height = height - document.getElementsByClassName("error-snackbar-parentdiv")[0].offsetHeight;
            }
            return height;
        }

        render() {
            return ( < div className = "error-snackbar-parentdiv" >
                <
                div className = "icon-no-signal" > < img src = {
                    icon_no_signal
                }
                alt = {
                    ""
                }
                /></div >
                <
                div className = "error-snackbar-messageinfo" > {
                    "Network error, please check your network connection"
                } < /div> <
                div className = "error-snackbar-eventhandlemessage"
                onClick = {
                    this.props.handleReconnect
                } > {
                    "RETRY"
                } < /div> <
                /div>);
            }


        }