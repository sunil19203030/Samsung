import React from "react";
import {
    connect
} from 'react-redux';
import PropTypes from 'prop-types';
import Constants from '../Resources/Constants';
import './style.css';

class ProgressBar extends React.Component {
    constructor(props) {
        super(props);

        if (props.theme === Constants.THEME_MEMBERS) {
            require('./style_members.css')
        }
    }

    render() {
        const theme = this.props.theme ? this.props.theme : ''
        return ( <
            div className = {
                `track track${theme} ${this.props.trackStyle}`
            } >
            <
            div className = {
                `progress progress${theme} ${this.props.progressStyle}`
            }
            style = {
                {
                    width: this.props.percent + '%'
                }
            } > < /div> <
            /div>
        )
    }
}

ProgressBar.defaultProps = {
    trackStyle: '',
    progressStyle: '',
};

ProgressBar.propTypes = {
    trackStyle: PropTypes.string,
    progressStyle: PropTypes.string,
};

const mapStateToProps = (state) => {
    return {
        theme: state.theme
    }
}

export default connect(mapStateToProps)(ProgressBar)