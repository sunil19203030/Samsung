import React from 'react';
import './style.css';
import {
    Store
} from '../store/store';
import * as utils from '../Util/Util';
import * as NetworkLib from '../Util/NetworkLib';
import * as NetworkHelper from '../Util/NetworkHelper';

import {
    connect
} from 'react-redux';
import {
    closeChat,
    showEndChatConfirmation,
    clearMessagerDiv
} from '../actions/action';

import Constants from '../Resources/Constants';




class Header extends React.Component {
        constructor(props) {
            super(props);

            if (props.state && props.state.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
                this.close = require('../assets/icon_close.svg')
                this.minimize = require('../assets/icon_minimize.svg')
            } else {
                this.close = require('../assets/close.png')
                this.minimize = require('../assets/minimize.png')
            }
        }

        closeChat = () => {
            /* if(window.parent && window.parent.document &&  window.parent.document.getElementsByTagName("body")[0])
             {
                 window.parent.document.getElementsByTagName("body")[0].style="position:static";
             }*/
            if (NetworkLib.getSocketRef()) {

                if (this.props.state && this.props.state.menus && this.props.state.menus.menu && this.props.state.menus.menu.params && this.props.state.menus.menu.params.ui_style === "web" && !document.getElementsByClassName("endChatDiv")[0] && !document.getElementsByClassName("end_chat_confirmation")[0]) {
                    //this.props.closeChat((this.props.state.menus.menu.params.end_chat ? this.props.state.menus.menu.params.end_chat : null));
                    if (Store.getState().callback_time) {
                        NetworkHelper.submitSurvey(true);
                        NetworkLib.closeSocketConnection();
                        this.triggerTaggingForClose();
                        utils.postMessageToParent("closeChat");
                        let Payload = {
                            "isEndChatConfirmation": false,
                            "EndChatConfirmationData": null
                        }
                        this.props.showEndChatConfirmation(Payload);
                        if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                            window.frames.location.reload(true);
                        }
                    } else if (this.props.state.menus.menu.params.end_chat) {
                        this.props.closeChat(this.props.state.menus.menu.params.end_chat);
                    } else {
                        NetworkHelper.submitSurvey(true);
                        NetworkLib.closeSocketConnection();
                        this.triggerTaggingForClose();
                        utils.postMessageToParent("closeChat");
                        let Payload = {
                            "isEndChatConfirmation": false,
                            "EndChatConfirmationData": null
                        }
                        this.props.showEndChatConfirmation(Payload);
                        if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                            window.frames.location.reload(true);
                        }
                    }
                } else {
                    if (this.props.state && this.props.state.menus && this.props.state.menus.menu && this.props.state.menus.menu.params && this.props.state.menus.menu.params.end_chat && document.getElementsByClassName("endChatDiv")[0] && !document.getElementsByClassName("end_chat_confirmation")[0]) {
                        let obj = this.props.state.menus.menu.params.end_chat;
                        if (obj.popup_cta) {
                            let popup_cta = obj.popup_cta;
                            for (var prop in popup_cta) {
                                if (popup_cta[prop]["client_action"] === "end_chat") {
                                    if (popup_cta[prop]["payload"]) {
                                        NetworkHelper.buildRequestToSend('event', popup_cta[prop]["payload"], NetworkHelper.getUserInfo(), {
                                            text: "close_chat"
                                        });
                                    }
                                    this.triggerTaggingForClose();
                                    utils.postMessageToParent("closeChat");
                                    setTimeout(() => {
                                        NetworkHelper.submitSurvey(true);
                                        NetworkLib.closeSocketConnection();
                                        if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                                            window.frames.location.reload(true);
                                        }
                                    }, 1000)
                                }
                            }
                        }
                    } else if (this.props.state && this.props.state.menus && this.props.state.menus.menu && this.props.state.menus.menu.params && this.props.state.menus.menu.params.end_chat && !document.getElementsByClassName("end_chat_confirmation")[0] && !document.getElementsByClassName("endChatDiv")[0]) {
                        let obj = this.props.state.menus.menu.params.end_chat;
                        if (obj.popup_cta) {
                            let popup_cta = obj.popup_cta;
                            for (var propkey in popup_cta) {
                                if (popup_cta[propkey]["client_action"] === "end_chat" && popup_cta[propkey]["payload"]) {
                                    NetworkHelper.buildRequestToSend('event', popup_cta[propkey]["payload"], NetworkHelper.getUserInfo(), {
                                        text: "close_chat"
                                    });
                                    setTimeout(() => {
                                        NetworkHelper.submitSurvey(true);
                                        NetworkLib.closeSocketConnection();
                                        this.triggerTaggingForClose();
                                        utils.postMessageToParent("closeChat");
                                        if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                                            window.frames.location.reload(true);
                                        }
                                    }, 1000)
                                }
                            }
                        }

                    } else {

                        NetworkHelper.submitSurvey(true);
                        NetworkLib.closeSocketConnection();
                        this.triggerTaggingForClose();
                        utils.postMessageToParent("closeChat");
                        let Payload = {
                            "isEndChatConfirmation": false,
                            "EndChatConfirmationData": null
                        }
                        this.props.showEndChatConfirmation(Payload);
                        if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                            window.frames.location.reload(true);
                        }
                    }


                }

            } else {
                this.triggerTaggingForClose();
                utils.postMessageToParent("closeChat");
                let Payload = {
                    "isEndChatConfirmation": false,
                    "EndChatConfirmationData": null
                }
                this.props.showEndChatConfirmation(Payload);
                if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                    window.frames.location.reload(true);
                }
            }

        }

        triggerTaggingForClose = () => {
            let tag_params = {
                "tag_event": "click",
                "tag_action": "close"
            }
            utils.postMessageToParent("tag", tag_params);
        }

        minimizeChat = () => {
            let Payload = {
                "isEndChatConfirmation": false,
                "EndChatConfirmationData": null
            }
            this.props.showEndChatConfirmation(Payload);

            /*if isoutage clear the dom*/
            if (NetworkHelper.getisOutageMessage()) {
                this.props.clearMessagerDiv(true);
            }
            utils.postMessageToParent("minimizeChat");
        }
        render() {
            const theme = this.props.state && this.props.state.theme ? this.props.state.theme : ''
            return ( < div className = {
                    `header header${theme}`
                } > < div style = {
                    {
                        height: "30px"
                    }
                } >
                <
                div className = {
                    `headerContent headerContent${theme}`
                } >

                <
                div className = {
                    `textDisplay textDisplay${theme}`
                } > {
                    this.props.headerTitle ? this.props.headerTitle : "CHAT"
                } < /div> <
                div className = 'rightImage' > {
                    this.props.isMinimizeRequired === true || this.props.isMinimizeRequired === "true" || this.props.isMinimizeRequired == null ? < img src = {
                        this.minimize
                    }
                    onClick = {
                        () => this.minimizeChat()
                    }
                    className = {
                        `minimizeChat minimizeChat${theme}`
                    }
                    alt = "minimizeChat" / > : null
                } {
                    this.props.isCloseRequired === true || this.props.isCloseRequired === "true" || this.props.isCloseRequired == null ? < img src = {
                        this.close
                    }
                    onClick = {
                        () => this.closeChat()
                    }
                    className = {
                        `closeIcon closeIcon${theme}`
                    }
                    alt = "close" / >: null
                } <
                /div> <
                /div>

                <
                /div> <
                /div>)

            }
        }


        const mapDispatchToProps = dispatch => ({
            closeChat: (data) => dispatch(closeChat(data)),
            showEndChatConfirmation: (data) => dispatch(showEndChatConfirmation(data)),
            clearMessagerDiv: (data) => dispatch(clearMessagerDiv(data))

        })

        const mapStateToProps = (state) => {
            return {
                state
            }
        }

        export default connect(mapStateToProps, mapDispatchToProps)(Header)