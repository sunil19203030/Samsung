import React from 'react';
import {
    connect
} from 'react-redux';
import * as utils from '../Util/Util';
import './style.css';
import * as NetworkHelper from '../Util/NetworkHelper';
import ReactDOM from 'react-dom';
import Parser from 'html-react-parser';
import Avator from '../Avator';
import {
    Store
} from '../store/store';
import Constants from '../Resources/Constants';

class CardMenu extends React.Component {
        constructor(props) {
            super(props);
            this.changeHandler = this.changeHandler.bind(this);
            this.paragraghNodeHeight = 0;
            this.buttonNodeHeight = 0;
            this.isContainerValueWeb = (Store.getState().chatbotparams.containerValue ? Store.getState().chatbotparams.containerValue.toLowerCase() === 'web' : false)

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }

        componentDidMount() {
            document.addEventListener("fullscreenchange", this.changeHandler, false);
            document.addEventListener("webkitfullscreenchange", this.changeHandler, false);
            document.addEventListener("mozfullscreenchange", this.changeHandler, false);
            /*itreate the card after render and update the height 
            dynamicaaly for all the card*/
            ReactDOM.findDOMNode(this.bottomDiv).scrollIntoView(false);
            if (this.props.hideLoader) {
                this.props.hideLoader();
            }
            let thisobj = this;
            Array.prototype.map.call(this.cardContainer.childNodes, function(value) {
                let containerNode = value.childNodes[0];
                if (containerNode.getElementsByClassName("card-notification-paragraph-container-text").length > 0 && containerNode.getElementsByClassName("card-notification-paragraph-container-text")[0]) {
                    let domParagraphHeight = containerNode.getElementsByClassName("card-notification-paragraph-container-text")[0].offsetHeight;
                    if (thisobj.paragraghNodeHeight === 0) {
                        thisobj.paragraghNodeHeight = domParagraphHeight;
                    } else if (thisobj.paragraghNodeHeight < domParagraphHeight) {
                        thisobj.paragraghNodeHeight = domParagraphHeight;
                    }
                }
            });

            Array.prototype.map.call(this.cardContainer.childNodes, function(value) {
                let containerNode = value.childNodes[0];
                if (containerNode.getElementsByClassName("card-link-parent-div").length > 0 && containerNode.getElementsByClassName("card-link-parent-div")[0]) {
                    let dombuttonNodeHeight = containerNode.getElementsByClassName("card-link-parent-div")[0].offsetHeight;
                    if (thisobj.buttonNodeHeight === 0) {
                        thisobj.buttonNodeHeight = dombuttonNodeHeight;
                    } else if (thisobj.buttonNodeHeight < dombuttonNodeHeight) {
                        thisobj.buttonNodeHeight = dombuttonNodeHeight;
                    }
                }
            });

            Array.prototype.map.call(this.cardContainer.childNodes, function(value) {
                let containerNode = value.childNodes[0];
                if (containerNode.getElementsByClassName("card-link-parent-div").length > 0 && containerNode.getElementsByClassName("card-link-parent-div")[0]) {
                    if (thisobj.paragraghNodeHeight !== 0) {
                        containerNode.getElementsByClassName("card-link-parent-div")[0].style.height = thisobj.buttonNodeHeight + "px";
                    }
                }
            });


            Array.prototype.map.call(this.cardContainer.childNodes, function(value) {
                let containerNode = value.childNodes[0];
                if (containerNode.getElementsByClassName("card-notification-paragraph-container-text").length > 0 && containerNode.getElementsByClassName("card-notification-paragraph-container-text")[0]) {
                    if (thisobj.paragraghNodeHeight !== 0) {
                        containerNode.getElementsByClassName("card-notification-paragraph-container-text")[0].style.height = thisobj.paragraghNodeHeight + "px";
                    }
                }
            });

            /* if (this.props.cardMenuArray.message && Array.isArray(this.props.cardMenuArray.message) && this.props.cardMenuArray.message.length === 1) {
                 this.imageref.childNodes[0].style.bottom = "0px";
             } else {
                 this.imageref.childNodes[0].style.bottom = "20px";
             }*/
            var elmnt = this.cardContainer;
            if (elmnt && elmnt.scrollLeft === 0) {
                if (this.leftArrow) {
                    this.leftArrow.style.display = "none"
                }
            }
            /*when no scroll for card just hiding the element*/
            if (elmnt && elmnt.offsetWidth >= elmnt.scrollWidth) {
                if (this.leftArrow) {
                    this.leftArrow.style.display = "none"
                }
                if (this.rightArrow) {
                    this.rightArrow.style.display = "none"
                }
            }
        }

        componentWillUnmount() {
            document.removeEventListener("fullscreenchange", this.changeHandler, false);
            document.removeEventListener("webkitfullscreenchange", this.changeHandler, false);
            document.removeEventListener("mozfullscreenchange", this.changeHandler, false);
        }
        /*when video is render fullscreen while closing moving to current node*/
        changeHandler(event) {

            if (document.webkitIsFullScreen === false) {
                ReactDOM.findDOMNode(event.target.parentElement).scrollIntoView();
            } else if (document.mozFullScreen === false) {
                ReactDOM.findDOMNode(event.target.parentElement).scrollIntoView();
            } else if (document.msFullscreenElement === false) {
                ReactDOM.findDOMNode(event.target.parentElement).scrollIntoView();

            }

        }
        onSend(cardObj) {
            if (cardObj.type !== "orderstatus" && cardObj.postback) {
                NetworkHelper.buildRequestToSend('event', (cardObj.postback ? cardObj.postback : (cardObj.cta_postback ? cardObj.cta_postback : "")), NetworkHelper.getUserInfo(), {
                    text: (cardObj.label ? cardObj.label : ""),
                    optionsSelection: true
                })
                this.props.onHandleClick(cardObj.type !== "orderstatus" ? (cardObj.label ? cardObj.label : "") : (cardObj.cta_text ? cardObj.cta_text : ""));
            } else if (cardObj.type === "orderstatus" && cardObj.cta_page) {
                utils.postMessageToParent(cardObj.cta_page);
            } else {
                if (cardObj.cta_url) {
                    cardObj.url = cardObj.cta_url;
                }
                if (utils.getUrlRedirectAppTypes(NetworkHelper.getUserInfo()["app-type"].toLowerCase()) !== -1 && cardObj.url) {
                    window.open(cardObj.url, "_blank");
                } else if (cardObj.cta_page) {
                    utils.postMessageToParent(cardObj.cta_page);
                }
            }
        }


        handleCardScrollEvent(event) {
            /*Added this for when card scrolling avator image will go back no scroll avator image will come front*/
            if (event.currentTarget.scrollLeft > 0) {

                this.cardContainer.style.marginLeft = "0px";
                this.cardContainer.style.width = "98%";
                this.imageref.style.zIndex = "-1";

                if (this.leftArrow) {
                    this.leftArrow.style.display = "table";
                    var elmnt = this.cardContainer;
                    var newScrollLeft = elmnt.scrollLeft,
                        width = elmnt.offsetWidth,
                        scrollWidth = elmnt.scrollWidth;

                    if (scrollWidth - newScrollLeft - width <= 50) {
                        this.rightArrow.style.display = "none";
                    } else {
                        this.rightArrow.style.display = "table";
                    }

                }

            } else {

                this.cardContainer.style.marginLeft = "50px";
                this.cardContainer.style.width = "87%";
                this.imageref.style.zIndex = "666";
                if (this.leftArrow) {
                    this.leftArrow.style.display = "none";
                }
            }

        }


        moveLeft() {
            var elmnt = this.cardContainer;
            elmnt.scrollLeft = elmnt.scrollLeft - 100;
            var newScrollLeft = elmnt.scrollLeft,
                width = elmnt.offsetWidth,
                scrollWidth = elmnt.scrollWidth;
            if (elmnt.scrollLeft === 0) {
                this.leftArrow.style.display = "none";
            }

            if (scrollWidth - newScrollLeft - width > 50) {
                this.rightArrow.style.display = "table";
            }
        }

        moveRight() {
            var elmnt = this.cardContainer;
            elmnt.scrollLeft = elmnt.scrollLeft + 100;
            var newScrollLeft = elmnt.scrollLeft,
                width = elmnt.offsetWidth,
                scrollWidth = elmnt.scrollWidth;

            if (scrollWidth - newScrollLeft - width <= 50) {
                this.rightArrow.style.display = "none";
            }

            if (elmnt.scrollLeft > 0) {
                this.leftArrow.style.display = "table";
            }


        }

        render() {
                const theme = this.props.theme ? this.props.theme : ''
                /*update avator position height when card render so delayed and updating height of avatar image*/
                return ( <
                    div >
                    <
                    div className = "cardMainContainer"
                    ref = {
                        (refs) => {
                            this.cardMainContainer = refs
                        }
                    } > {
                        this.props.appType === "samsung.com" || this.isContainerValueWeb ? < div > < div className = "left-icon-parentNode"
                        onClick = {
                            this.moveLeft.bind(this)
                        }
                        ref = {
                            (refs) => {
                                this.leftArrow = refs
                            }
                        } > < div className = "left-icon" > < span className = "icon-left-carat slick-arrow__icon" > < /span></div > < /div> <
                        div className = "right-icon-parentNode"
                        onClick = {
                            this.moveRight.bind(this)
                        }
                        ref = {
                            (refs) => {
                                this.rightArrow = refs
                            }
                        } > < div className = "right-icon" > < span className = "icon-right-carat slick-arrow__icon" > < /span></div > < /div></div > : null
                    } <
                    div ref = {
                        (ref) => {
                            this.imageref = ref
                        }
                    } > < Avator appType = {
                        this.props.appType
                    }
                    originatorInfo = {
                        this.props.originatorInfo
                    }
                    /></div >
                    <
                    div className = "cardContainer"
                    ref = {
                        (ref) => {
                            this.cardContainer = ref
                        }
                    }
                    onScroll = {
                        this.handleCardScrollEvent.bind(this)
                    } > {
                        this.props.cardMenuArray["message"].map((cardObj, index) => {
                                return <div className = "cardDiv"
                                key = {
                                        index
                                    } >
                                    <
                                    div className = "cardContentContainer"
                                ref = {
                                    (ref) => {
                                        this.cardContentContainer = ref
                                    }
                                } > {
                                    (cardObj.videoUrl ? < iframe title = "cardVideo"
                                        src = {
                                            cardObj.videoUrl
                                        }
                                        webkitallowfullscreen = {
                                            "true"
                                        }
                                        mozallowfullscreen = {
                                            "true"
                                        }
                                        allowFullScreen = {
                                            "true"
                                        } > < /iframe> : <div className="cardimage-parent-container" onClick={this.onSend.bind(this, cardObj)}><img className="cardImage" src={cardObj["imageUrl"]} alt={""} > <
                                        /img></div > )
                                }

                                {
                                    cardObj.type === "orderstatus" ?
                                        <
                                        div className = {
                                            "card-notification-container-div"
                                        } > {
                                            cardObj["label"] && cardObj["label"].length ?
                                            <
                                            div className = {
                                                `card-notification-container-title-label card-notification-container-title-label${theme}`
                                            } > {
                                                cardObj["label"].length > 24 ? `${cardObj["label"].substring(0, 24)}...` : cardObj["label"]
                                            } <
                                            /div> :
                                                null
                                        } <
                                        div className = {
                                            "card-notification-container-text"
                                        } > < div className = "card-notification-container-text-label" > {
                                            "ORDER #: "
                                        } < /div><div className="card-notification-container-text-content">{cardObj["order_number"] ? Parser(cardObj["order_number"]) : ""}</div > < /div> <
                                        div className = {
                                            "card-notification-container-text"
                                        } > < div className = "card-notification-container-text-label" > {
                                            "STATUS: "
                                        } < /div> <div className="card-notification-container-text-content">{cardObj["order_status"] ? Parser(cardObj["order_status"]) : ""}</div > < /div> {
                                            cardObj["tracking_number"] ? < div className = {
                                                    "card-notification-container-text"
                                                } >
                                                <
                                                div className = "card-notification-container-text-label" > {
                                                    "TRACKING: "
                                                } < /div> <
                                                div className = "card-notification-container-text-content" > {
                                                    Parser(cardObj["tracking_number"])
                                                } < /div> <
                                                /div> : <div className={"card-notification-container-text"}><div className={"card-notification-no-tracking"}></div > < /div>} <
                                                /div> : cardObj["text"] ? <
                                                div className = {
                                                    "card-notification-container-div"
                                                } >
                                                <
                                                div className = {
                                                    `card-notification-container-title-label card-notification-container-title-label${theme}`
                                                } > {
                                                    cardObj["label"] ? (cardObj["label"].length > 29 ? `${cardObj["label"].substring(0, 29)}...` : cardObj["label"]) : null
                                                } < /div> <
                                                div className = {
                                                    `card-notification-paragraph-container-text card-notification-paragraph-container-text${theme}`
                                                } > {
                                                    cardObj["text"] ? cardObj["text"].length > 50 ? `${cardObj['text'].substring(0, 50)}...` : Parser(cardObj["text"]) : null
                                                } < /div> <
                                                /div> : null} <
                                                div className = "card-link-parent-div" > {
                                                    (cardObj["buttons"] ?
                                                        cardObj.buttons.map((value, index) => {
                                                            value["label"] = (value["cta_text"] ? value["cta_text"] : "");
                                                            value["type"] = "CARD";
                                                            if (value["cta_postback"]) {
                                                                value["postback"] = value["cta_postback"];
                                                            }
                                                            return <div key = {
                                                                index
                                                            }
                                                            className = {
                                                                `cardLink cardLink{$theme}`
                                                            }
                                                            onClick = {
                                                                    this.onSend.bind(this, value)
                                                                } > {
                                                                    (value["cta_text"] ? value["cta_text"] : (value["label"] ? value["label"] : null))
                                                                } <
                                                                /div>
                                                        })

                                                        :
                                                        cardObj["postback"] || cardObj["cta_page"] ?
                                                        <
                                                        div className = {
                                                            `cardLink cardLink${theme}`
                                                        }
                                                        onClick = {
                                                            this.onSend.bind(this, cardObj)
                                                        } > {
                                                            (cardObj["cta_text"] ? (cardObj["cta_text"].length > 18 ? `${cardObj["cta_text"].substring(0, 18)}...` : cardObj["cta_text"]) : (cardObj["label"] ? (cardObj["label"].length > 18 ? `${cardObj["label"].substring(0, 18)}...` : cardObj["label"]) : null))
                                                        } <
                                                        /div> : null
                                                    )
                                                } <
                                                /div> <
                                                /div> <
                                                /div>

                                        })
                            } < /div> <
                            /div> <
                            div style = {
                                {
                                    clear: "both",
                                    paddingBottom: "1px"
                                }
                            }
                            ref = {
                                (refs) => {
                                    this.bottomDiv = refs
                                }
                            } > < /div> <
                            /div>
                        );
                    }
                }

                const mapStateToProps = (state) => {
                    return {
                        theme: state.theme
                    }
                }

                export default connect(mapStateToProps)(CardMenu)