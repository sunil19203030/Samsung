import * as NetworkLib from '../Util/NetworkLib'
import {
    Store
} from '../store/store';
import * as utils from '../Util/Util';
import Parser from 'html-react-parser';
import {
    receivedResponse,
    drawCardMenu,
    drawOption,
    showKeyboard,
    updateMenu,
    escalationStatusMessage,
    drawSurvey,
    updateTextBoxStatus,
    setHistoryData,
    showLoader,
    setIntialStateValue,
    drawRatingStar,
    drawThankyouPage,
    closeStatusMessage,
    hideLoader,
    setInfoCardValue,
    typingMessage
} from '../actions/action';
import * as moment from "moment";

/* imported for Test Run: Starts */
// import Chatmock from './../mocks/Chatmock';
/* imported for Test Run: Ends */


export let isOutageMessage = false;
export let ChatOptionsProp = null
export let survey_id = "";
export const defaultHistoryMsgCount = 50 // Default Message Count to be fetched from History
// increment on each request sent to bt platform
export let conversationReqSeqId = 0 // eslint-disable-line import/no-mutable-exports
// Session Id for each Chat Messages
export let Session = '' // eslint-disable-line import/no-mutable-exports
// Message Id of each message
export let MessageId = 0 // eslint-disable-line import/no-mutable-exports
// Message Id of last message of retrieved chat history
export let MessageHistoryId = '' // eslint-disable-line import/no-mutable-exports
// `Bot` object
export let MessageBot = {} // eslint-disable-line import/no-mutable-exports
// `Bot` object of last message of retrieved chat history
export let MessageHistoryBot = {} // eslint-disable-line import/no-mutable-exports
// chat | event | message
export let MessageRequestMethod = '' // eslint-disable-line import/no-mutable-exports
// (MessageRequestMethod = event) event deeplink at 'msg' key
export let EventMessage = '' // eslint-disable-line import/no-mutable-exports
// (MessageRequestMethod = chat) message user types at 'text' key
export let ChatText = '' // eslint-disable-line import/no-mutable-exports
// `user` object in request.params
export let UserInfo = {} // eslint-disable-line import/no-mutable-exports
export let submit_id = 0;

let lastMessageParam = {};
export let isDrawerMenuScoketCalled = false;
export let startOverCompleted = false;

export const getMoreHistory = (user) => {
    console.log(user) // eslint-disable-line
    // TODO
}

export const getMessageRequestMethod = () => (
    MessageRequestMethod
)

function checkIsRenderDataexceptHistory(data) {
    return (!(data instanceof Object) && JSON.parse(data)["params"] !== undefined && JSON.parse(data)["type"] !== "ack")
}

function getCookie(name) {
    var match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
    if (match) return match[2];
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return false;
}

export const onReceiveCb = (data, isHistoryAvailable) => {
    //Store.dispatch(showLoader())
    /*show loader bottom on the ui except history*/
    if (!Array.isArray(data) && JSON.parse(data)["type"] !== "ack") {
        Store.dispatch(setIntialStateValue());
    } else if (Array.isArray(data) && data.length === 0) {
        Store.dispatch(setIntialStateValue());
    }

    if (isHistoryAvailable && Array.isArray(data)) {
        /*to print the history data for the user*/
        let historyData = data.reverse();
        utils.setisHistory(true);

        /*grouping the history for chatbot */
        let tempHistoryData = [];
        for (var i = 0; i < historyData.length; i++) {
            if ((historyData[i]["method"] === "message" || historyData[i]["method"] === "chat") && historyData[i]["text"] && historyData[i]["text"].indexOf("href") === -1 && !historyData[i]["card"] && !historyData[i]["buttons"]) {
                if (tempHistoryData[tempHistoryData.length - 1] && !tempHistoryData[tempHistoryData.length - 1]["card"] && !tempHistoryData[tempHistoryData.length - 1]["buttons"] && (tempHistoryData[tempHistoryData.length - 1]["method"] === "message" || tempHistoryData[tempHistoryData.length - 1]["method"] === "chat")) {
                    let PreviousHistoryObj = tempHistoryData[tempHistoryData.length - 1];
                    if (utils.formatAMPM(PreviousHistoryObj["createdAt"]) === utils.formatAMPM(historyData[i]["createdAt"]) && PreviousHistoryObj["method"] === historyData[i]["method"]) {
                        PreviousHistoryObj["text"] = PreviousHistoryObj["text"] + (historyData[i]["text"].indexOf("<p>") === -1 ? "<p>" + historyData[i]["text"] + "</p>" : historyData[i]["text"]);
                        tempHistoryData[tempHistoryData.length - 1] = PreviousHistoryObj;
                    } else {
                        if (historyData[i]["text"] && historyData[i]["text"] && historyData[i]["text"].indexOf("<p>") === -1) {
                            historyData[i]["text"] = "<p>" + historyData[i]["text"] + "</p>";
                            tempHistoryData.push(historyData[i])
                        } else {
                            tempHistoryData.push(historyData[i]);
                        }
                    }
                } else {
                    if (historyData[i]["text"] && historyData[i]["text"] && historyData[i]["text"].indexOf("<p>") === -1) {
                        historyData[i]["text"] = "<p>" + historyData[i]["text"] + "</p>";
                        tempHistoryData.push(historyData[i])
                    } else {
                        tempHistoryData.push(historyData[i]);
                    }
                }
            } else {
                tempHistoryData.push(historyData[i])
            }

        }

        Store.dispatch(setHistoryData(tempHistoryData));
    } else if (checkIsRenderDataexceptHistory(data)) {
        utils.setisHistory(false);
        console.log("Response reveived from cloud chatbot");
        console.log(JSON.parse(data));
        data = JSON.parse(data);
        let message = data["params"]["data"];
        let BubbleText = "";
        /*handling message to print on the ui*/
        if (message !== undefined && message !== "") {
            if (readCookie("cbEvents") && getCookie("cbEvents") === 'minimized' && message.text !== '') {
                var existingCount = 1;
                if (readCookie("cbMessageCount")) {
                    existingCount = parseInt(getCookie("cbMessageCount")) + 1;
                }
                utils.createCookie("cbMessageCount", existingCount, 0.001, showMessageCountEvent)
            }
            var isNativeApp = utils.isNativeApp()
            if (message.text !== '' && !isNativeApp && utils.getisConnectedWithAgent()) {
                sendNotification()
            }
            /*Added if outage just disable below text box*/
            if (message.isOutageMessage === true || message.isOutageMessage === "true") {
                document.getElementsByClassName("senderMainDiv")[0].style.display = "none";
                setisOutageMessage(true);
            } else {
                if (document.getElementsByClassName("senderMainDiv") && document.getElementsByClassName("senderMainDiv")[0]) {
                    document.getElementsByClassName("senderMainDiv")[0].style.display = "block";
                }
                setisOutageMessage(false);
            }

            let text = (message.menu ? (message.menu[0].text !== undefined ? message.menu[0].text.replace("<card></card>", "") : (message.text ? message.text.replace("<card></card>", "") : "")) : message["text"]);
            if (text) {
                text = utils.unescapeHtmlEntities(text);
            }
            if (data.params.originator && data.params.originator !== "shopbot" && data.params.originator !== "supportbot") {
                utils.setisConnectedWithAgent(true);
                utils.setOriginatorInfo((data.params.originator_info ? data.params.originator_info : {}));
            } else {
                utils.setCustomerFirstMessageNeedToSend(false);
                utils.setisConnectedWithAgent(false);
                utils.setOriginatorInfo(data.params.originator);
            }

            if (text !== "" && text !== undefined) {
                Store.dispatch(showLoader());
                BubbleText = utils.splitTag(text);
                if (message && message.buttons && Array.isArray(message.buttons) && message.buttons.length > 0) {
                    let infoCarddata = {
                        text: text,
                        buttons: message.buttons
                    }
                    Store.dispatch(setInfoCardValue(infoCarddata))
                } else if (BubbleText && BubbleText !== "") {
                    Store.dispatch(receivedResponse(BubbleText, new Date(), message.action));
                    Store.dispatch(showLoader());
                }

            }

            if (message.menu || message.card) {
                text = (text !== undefined ? text.replace("<card></card>", "") : null);
                let card = (message.menu ? message.menu[0].card : message.card);
                Store.dispatch(showLoader());
                Store.dispatch(drawCardMenu(card));
            }
            if (message["option"] !== undefined) {
                Store.dispatch(showLoader());
                /*Fix for CBAU-5 3rd bubble is rendered after pill and no scrolling happens*/
                if (BubbleText && Array.isArray(BubbleText) && BubbleText.length > 0) {
                    setTimeout(() => {
                        Store.dispatch(drawOption(message["option"]));
                    }, (BubbleText.length * 700))
                } else {
                    Store.dispatch(drawOption(message["option"]));
                }
                /*Fix for CBAU-5 END*/

            }
        }

        /*to handle survey this method will execute*/
        if (data.type && data.type === "survey") {
            if (data.params && data.params.survey_info && Object.keys(data.params.survey_info).length !== 0) {
                let survey_info = data.params.survey_info;
                Store.dispatch(drawSurvey(survey_info));
            }
        }

        /*to handle menu this method will execute*/
        if (data.type && data.type === "menu") {
            Store.dispatch(updateMenu(data));
        }

        /*handle client actions*/
        if (message !== undefined && message.action !== undefined) {
            let actions = message["action"];
            for (let key in actions) {
                actionCommandHandler(actions[key]);
            }
        }

    }

    /*to get menu this  code is calling when menu is empty*/
    if (!isDrawerMenuScoketCalled && (NetworkLib.isBotEntryEqual())) {
        prepareAndCallgetMenu(Store.getState().chatbotparams.chatbotInitParams["entry"]);
    }
}
const sendNotification = () => {
    Notification && Notification.requestPermission().then(function(permission) {
        // If the user accepts, let's create a notification
        if (permission === "granted") {
            var notification = new Notification('You’ve a message from Samsung Product Expert.', {});
        }
    });
}
export const showMessageCountEvent = () => {
    utils.postMessageToParent("showmessagecount");
}

export const prepareAndCallgetMenu = (entry) => {
    console.log(entry)
    let params = {
        "app_type": Store.getState().chatbotparams.userobj["app-type"],
        session: getSession(),
        "entry": entry
    };
    getMenu(params);
    /* setTimeout(() => {
            // let params = { "app_type": Store.getState().chatbotparams.userobj["app-type"],"survey_id":"talisma_feedback.js" ,"entry": Store.getState().chatbotparams.chatbotInitParams["entry"] };
            // getSurvey(params);
           Store.dispatch(drawSurvey(survey_info));
          }, 3000)*/
    isDrawerMenuScoketCalled = true;
}
const actionCommandHandler = (actionObject) => {
    switch (actionObject["command"]) {
        case "escalation_status":
            {
                Store.dispatch(escalationStatusMessage(actionObject));
                break;
            }
        case "typing_status":
            {
                Store.dispatch(typingMessage(actionObject));
                break;
            }
        case "show_keyboard":
            {

                Store.dispatch(showKeyboard(true));
                utils.postMessageToParent(actionObject["command"]);
                Store.dispatch(showLoader());
                break;
            }
        case "close_status":
            {
                actionObject["status"] = actionObject["command"];
                Store.dispatch(closeStatusMessage(actionObject));
                utils.eraseCookie('cbMessageCount')
                break;
            }
        case "delay":
            {
                setTimeout(function() {
                    buildRequestToSend("event", actionObject["postback"], getUserInfo(), {
                        text: "",
                        loaderRequire: false,
                        optionsSelection: true
                    })
                }, actionObject["ms"])
                break;
            }
        case "show_survey":
            {
                survey_id = actionObject["survey_id"];
                let params = {
                    "app_type": Store.getState().chatbotparams.userobj["app-type"],
                    session: getSession(),
                    "survey_id": actionObject["survey_id"],
                    "bot": getMessageBot(),
                    "user": getUserInfo(),
                    "entry": Store.getState().chatbotparams.chatbotInitParams["entry"]
                };
                getSurvey(params);
                //Store.dispatch(drawRatingStar(actionObject));
                break;
            }
        case "disable_text_input":
            {
                Store.dispatch(showLoader());
                Store.dispatch(updateTextBoxStatus());
                if (isOutageMessage) {
                    Store.dispatch(hideLoader(true));
                }

                break;
            }
        case "hide_keyboard":
            {
                utils.postMessageToParent(actionObject["command"]);
                break;
            }
        case "external_redirect":
            {
                setTimeout(() => {
                    if (utils.getUrlRedirectAppTypes(getUserInfo()["app-type"].toLowerCase()) && actionObject["url"]) {
                        window.open(actionObject["url"], "_blank");
                    } else {
                        if (actionObject["page"]) {
                            (isValidURL(actionObject["page"]) ? utils.postMessageToParent(actionObject["command"], {
                                "URL": actionObject["page"]
                            }) : utils.postMessageToParent(actionObject["page"]))
                        } else if (actionObject["cta_page"]) {
                            (isValidURL(actionObject["cta_page"]) ? utils.postMessageToParent(actionObject["command"], {
                                "URL": actionObject["cta_page"]
                            }) : utils.postMessageToParent(actionObject["cta_page"]))
                        } else {
                            console.log("param is not getting")
                        }

                    }
                }, 2500);
                break;
            }
        case "end_survey":
            {
                console.log("survey is ended")
                break;
            }
        case "rate_our_app":
            {
                console.log("rate our app");
                break;
            }
        case "require_login":
            {
                utils.postMessageToParent(actionObject["command"]);
                break;
            }
        case "end_session":
            {
                Store.dispatch(receivedResponse([actionObject["message"]]));
                break;
            }
        case "status_text":
            {
                Store.dispatch(receivedResponse([actionObject["message"]]));
                break;
            }
        case "rating":
            {
                setTimeout(() => {
                    Store.dispatch(drawRatingStar([actionObject]));
                }, 500);
                break;
            }
        case "tag":
            {
                let tag_event = actionObject["tag_event"];
                let tag_action = actionObject["tag_action"];
                let tag_mdata = actionObject["tag_mdata"];
                let tag_params = {};
                if (tag_event) {
                    tag_params["tag_event"] = tag_event;
                }
                if (tag_action) {
                    tag_params["tag_action"] = tag_action;
                }
                if (tag_mdata) {
                    tag_params["tag_mdata"] = tag_mdata;
                }
                utils.postMessageToParent("tag", tag_params);
                break;
            }
        default:
            break;
    }
}


export const isValidURL = (str) => {
    var a = document.createElement('a');
    a.href = str;
    return (a.host && a.host !== window.location.host);
}

export const setMessageRequestMethod = (reqMethod) => {
    MessageRequestMethod = reqMethod
}

export const getEventMessage = () => (
    EventMessage
)

export const setEventMessage = (evtMsg) => {
    EventMessage = evtMsg
}

export const getChatText = () => (
    EventMessage
)

export const setChatText = (chatTxt) => {
    ChatText = chatTxt
}

export const getSession = () => (
    Session
)

export const setSession = (sess) => {
    Session = sess
}

export const getId = () => (
    conversationReqSeqId
)

export const setId = (id) => {
    conversationReqSeqId = id
}

export const getMessageId = () => (
    MessageId
)

export const setMessageId = (msgId) => {
    MessageId = msgId
}

export const getMessageHistoryId = () => (
    MessageHistoryId
)

export const setMessageHistoryId = (msgHistoryId) => {
    MessageHistoryId = msgHistoryId
}

export const getMessageBot = () => (
    MessageBot
)

export const setMessageBot = (msgBot) => {
    MessageBot = msgBot
}

export const getMessageHistoryBot = () => (
    MessageHistoryBot
)

export const setMessageHistoryBot = (msgHistoryBot) => {
    MessageHistoryBot = msgHistoryBot
}

export const getUserInfo = () => (
    UserInfo
)

export const getDefaultHistoryMsgCount = () => {
    return defaultHistoryMsgCount;
}

export const setUserInfo = (usrInfo) => {
    UserInfo = usrInfo
}



export const setisOutageMessage = (isOutageMessageflag) => {
    isOutageMessage = isOutageMessageflag
}

export const getisOutageMessage = () => (
    isOutageMessage
)

export const mapMessage = (isMsgOrTxt) => {
    const msgReqMethod = getMessageRequestMethod()
    let params = {}
    let msgOrTxt = isMsgOrTxt;
    if (msgReqMethod) {
        setEventMessage(isMsgOrTxt)
        switch (isMsgOrTxt) {
            case "initiate_chat":
                {
                    msgOrTxt = Store.getState().chatbotparams.chatbotInitParams["entry"];
                    break;
                }
            default:
                break;
        }
        params = {
            ...params,
            msg: msgOrTxt,
        }
    }
    return params;
}

const getMessageIdForMethods = (methods) => {
    if (methods === 'get_message') {
        return getMessageHistoryId()
    }
    return getMessageId()
}

/*before send to server just build the params previous bot and previous message id*/
export const buildParams = (msgType, msg, additional = {}) => {
    const msgBot = getMessageBot()
    const userInfo = getUserInfo()
    const originator = 'user'
    const show = false
    // const tt = new Date().toISOString()
    const params = mapMessage(msg)
    let chatbotparams = Store.getState().chatbotparams.chatbotInitParams;

    const firstParam = {
        bot: msgBot,
        msg: getEventMessage(),
        originator,
        show,
        text: Store.getState().callback_time || getChatText(),
        tt: moment(new Date()).format("YYYY-MM-DDTHH:mm:ss"),
        user: userInfo,
        msg_id: getMessageIdForMethods(getMessageRequestMethod()),
        reference_msg_id: getMessageId(),
        timestamp: Date.now(),
        count: defaultHistoryMsgCount,
        country: chatbotparams["country"],
        chatVersion: chatbotparams["chatVersion"],
        isChatsessionExists: (readCookie('cbEvents') == 'open' && (sessionStorage.getItem('cbSession') != 'open' || sessionStorage.getItem('cbSession') == null))
    }
    const mergedParams = { ...firstParam,
        ...params,
        ...additional
    }
    console.log(mergedParams)
    return mergedParams
}

/*const storeResponseParametersForFutureRequest = (incomingResponse) => {
  setSession(lastMsg.session)
  setMessageId(lastMsg.params.msg_id)
  setMessageBot(lastMsg.params.bot)
}

/*every time update bot object here and accessing bot object while sending this method will call 
during response get from chabot onMessage*/
export const processIncomingResponse = (incomingResponse) => {
    if (incomingResponse.type && incomingResponse.type === 'history') {
        if (incomingResponse.params.history && incomingResponse.params.history.length) {
            const totalItems = incomingResponse.params.history.length

            const lastMsgHistory = incomingResponse.params.history[totalItems - 1]
            let lastMsg = incomingResponse.params.history[0];
            setMessageHistoryBot(lastMsgHistory.params.bot)
            const lastMsgId = lastMsgHistory.params.bot.last_msg_id
            setMessageHistoryId(lastMsgId)

            if (totalItems > 0) {

                if (lastMsg) {
                    setSession(lastMsg.session)
                    setMessageId(lastMsg.params.msg_id)
                    console.log(lastMsg.params.bot)
                    setMessageBot(lastMsg.params.bot)
                    if (lastMessageParam.params && lastMsg.params.timestamp > lastMessageParam.params.timestamp) {
                        setMessageBot(lastMsg.params.bot)
                    } else {
                        if (lastMessageParam.params === undefined) {
                            setMessageBot(lastMsg.params.bot)
                        }
                        lastMessageParam = lastMsg;
                    }
                } else {
                    setSession("");
                    setMessageId("");
                    setMessageBot({});
                }
            }
        }
    } else if (Array.isArray(incomingResponse) && incomingResponse[0].type === 'nested' && incomingResponse[0].title === "Menu") {
        console.log(incomingResponse);
    } else if (incomingResponse.params !== undefined && incomingResponse.params.bot !== undefined) {
        if (incomingResponse.type !== "ack" && incomingResponse.type !== "menu") {
            Store.dispatch(showLoader())
        }
        const {
            session
        } = incomingResponse
        const msgId = incomingResponse.params.msg_id
        setSession(session)
        setMessageId(msgId)
        setMessageBot(incomingResponse.params.bot)
    }

}

/*
 * `conversationMethod` can be one of these (chat|event|message)
 * msgType :
 * -if(conversationMethod == `event`) `msgType` will be the `event` to be sent
 * -if(conversationMethod == `chat`) `msgType` will be the `message` to be sent
 * user can be `user` object from device.
 */

export const buildRequestToSend = (msgRequestMethod, msgType, user, additionalParams = {}) => {


    setMessageRequestMethod(msgRequestMethod)
    // This sets event.msg or chat.text
    mapMessage(msgType)
    // This sets the user information at params
    setUserInfo(user)
    const session = getSession()
    let id = getId()
    const msgReqMethod = getMessageRequestMethod()
    const params = buildParams({}, msgType, additionalParams)
    const req = {
        session,
        id: (++id), // eslint-disable-line
        method: msgReqMethod,
        params,
    }
    setId(id)
    if (msgReqMethod === "submit_survey") {
        submit_id = id;
    }
    NetworkLib.doSend(JSON.stringify(req))

}

const doStartOver = (user) => {
    //TCA.gatherTCAnalytics(TCA.TCAnalytics.TextChat, { action: TCA.TCAction.START, agent: 'Directly / Samsung', value: 1 }
    if (!startOverCompleted) {
        startOverCompleted = true
        buildRequestToSend('event', 'initiate_chat', user);

        /*login success just for us pass param to user Obj to packend*/
        if (user.loginstatus) {
            let loginPostbackObj = utils.getLoginPostbackObj();
            if (user.loginstatus.toLowerCase() === "success" && Object.keys(loginPostbackObj).length > 0) {
                buildRequestToSend('event', loginPostbackObj["login_success_postback"], user)
            } else if (user.loginstatus.toLowerCase() === "failure" && Object.keys(loginPostbackObj).length > 0) {
                buildRequestToSend('event', loginPostbackObj["login_failure_postback"], user);
            }
        }
        /*login success end */

    }
}

/*first call the history when socket open*/
export const doGetHistory = (user) => {
    if (utils.getMessagerNodeRef() && utils.getMessagerNodeRef().children[1].children.length === 0) {
        Store.dispatch(showLoader())
    }
    buildRequestToSend('get_message', '', user, {
        count: defaultHistoryMsgCount
    })
}



export const connectionSuccessCb = () => {
    if (!startOverCompleted) {
        doGetHistory(getUserInfo())
    }
}

//refresh chat on tab change fetch history and show it


export const resetNetwork = () => {
    setMessageRequestMethod('get_message')
    // This sets event.msg or chat.text
    mapMessage('')
    // This sets the user information at params
    //setUserInfo(user)
    const session = "";
    let id = 0;
    const msgReqMethod = getMessageRequestMethod()
    const params = {
        bot: {},
        msg: "",
        originator: "user",
        show: false,
        text: "",
        tt: "2020-01-30T18:18:08",
        user: getUserInfo(),
        msg_id: "",
        reference_msg_id: 0,
        timestamp: new Date().getTime(),
        count: 50,
        country: "IN",
        chatVersion: "2.0",
        isChatsessionExists: false
    }
    const req = {
        session,
        id: (++id), // eslint-disable-line
        method: msgReqMethod,
        params,
    }
    setId(id);
    NetworkLib.doSend(JSON.stringify(req))
}

export const initValues = () => {
    conversationReqSeqId = 0
    Session = ''
    MessageId = 0
    MessageHistoryId = ''
    MessageBot = {}
    MessageHistoryBot = {}
    MessageRequestMethod = ''
    EventMessage = ''
    ChatText = ''
    UserInfo = {}
    startOverCompleted = false
}

export const connectionFailureCb = () => {
    console.log('Connection Failure .. ') // eslint-disable-line 
}

/*if no history call init chat */
export const historySucessfulyRetrieved = (historyData) => {
    doStartOver(getUserInfo());
}

export const fetchHistoryDuringScroll = () => {
    const user = getUserInfo();
    buildRequestToSend('get_message', '', user, {
        count: defaultHistoryMsgCount
    })
}

export const getSurvey = (params) => {
    const user = getUserInfo();
    buildRequestToSend('get_survey', '', user, params)
}
export const getMenu = (params) => {
    const user = getUserInfo();
    buildRequestToSend('get_menu', '', user, params)
}

export const onPopupEvnetHandler = (postbackUrl, params) => {
    const user = getUserInfo();
    var result = postbackUrl;
    if (postbackUrl.indexOf("/") !== -1) {
        var str = postbackUrl;
        var n = str.lastIndexOf('/');
        result = str.substring(n + 1);
    }
    params['text'] = result;
    buildRequestToSend('event', postbackUrl, user, params)
}

export const setStarOverCompleted = (flag) => {
    startOverCompleted = flag;
}

export const submitSurvey = (isPageClsoe) => {
    const user = getUserInfo();
    let questioninfo = [];
    let survey_info = utils.getSurveyObj();
    if (survey_info) {
        let survey_info_questions = utils.getSurveyObj().questions;
        for (let prop in survey_info_questions) {
            if (typeof survey_info_questions[prop].answer !== "undefined") {
                let tempQuestionInfo = {
                    "questionId": survey_info_questions[prop]["id"],
                    "question": survey_info_questions[prop]["label"],
                    "answer": survey_info_questions[prop]["answer"]
                };
                // questioninfo.push({ "questionId": survey_info_questions[prop]["id"], "answer": survey_info_questions[prop]["answer"] }) // by Ganesan.
                if (survey_info_questions[prop]["type"]) {
                    tempQuestionInfo["type"] = survey_info_questions[prop]["type"];
                }

                questioninfo.push(tempQuestionInfo);
            }
            survey_info["questions"] = questioninfo;
        }
        if (questioninfo.length > 0) {
            let chatbotparams = Store.getState().chatbotparams.chatbotInitParams;
            let params = {
                "app_type": Store.getState().chatbotparams.userobj["app-type"],
                session: getSession(),
                "survey_id": survey_id,
                "survey_info": survey_info,
                "entry": chatbotparams["entry"]
            };
            buildRequestToSend('submit_survey', '', user, params)
        }
    }
    if (isPageClsoe) {
        Store.dispatch(drawThankyouPage(false));
        if (document.getElementsByClassName("survey") && document.getElementsByClassName("survey").length > 0) {
            document.getElementsByClassName("survey")[0].style.display = "none";
        }
    }


}