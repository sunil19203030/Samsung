import * as NetworkHelper from './NetworkHelper'

import {
    updateTextBoxStatus,
    onNetworkError,
    drawThankyouPage,
    showContextChangeConfirmation,
    resetHistoryStore
} from '../actions/action';
import {
    Store
} from '../store/store';
import * as utils from '../Util/Util';

let wsTunnel
let user
let chatBotMessages = []
let previousId = 0;
let socketReference = "";
let receivedResponse = [];
let timerInterval = null;
let isFirstLoad = false;

const processRecievedMessageActions = (recievedMessageObject, profile) => {
    let actionProcessed = false
    if (recievedMessageObject.params.data && recievedMessageObject.params.data.action) {
        const actions = recievedMessageObject.params.data.action
        actions.map((action) => {
            if ((action.command && action.command === 'escalation_status') || action.command === 'rating' || action.command === 'close_status') { // action commands to be processed
                actionProcessed = true
                const profileMerge = { ...profile,
                    user: {
                        _id: 5
                    }
                };
                if (action.command === 'close_status') {
                    action["status"] = action.command
                }
                const appendableMessage = {
                    ...action,
                    _id: Math.round(Math.random() * 1000000),
                    params: recievedMessageObject.params,
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    ...profileMerge,
                }
                chatBotMessages.push(appendableMessage)
            }
            return "";
        })
    }
    return actionProcessed
}

const processChatText = (recievedMessageObject, userProfile) => {

    const createdDate = new Date(recievedMessageObject.params.timestamp)
    let displayText = ''
    if (recievedMessageObject.method === 'event' && recievedMessageObject.params.optionsSelection) {
        displayText = recievedMessageObject.params.text
    } else {
        displayText = recievedMessageObject.params.msg
    }


    if (displayText) {
        chatBotMessages.push({
            _id: Math.round(Math.random() * 1000000),
            text: displayText,
            method: recievedMessageObject.method,
            params: recievedMessageObject.params,
            createdAt: createdDate,
            user: {
                ...recievedMessageObject.user,
                ...userProfile,
            },
        })
    }
}


/*itreate the history data append in chatbot render in the ui*/
export const onMessageProcesser = (text) => {
    if (!user) {
        user = NetworkHelper.getUserInfo()
    }
    const recievedMessageObject = JSON.parse(text)
    if (recievedMessageObject.method === 'chat' || (recievedMessageObject.method === 'event' && recievedMessageObject.params.optionsSelection)) {
        return (
            processChatText(recievedMessageObject, user)
        )
    }
    const baseParams = {};
    if (recievedMessageObject.params.data && recievedMessageObject.params.data.text && recievedMessageObject.params.data.buttons) {
        return (
            chatBotMessages.push({
                _id: Math.round(Math.random() * 1000000),
                text: recievedMessageObject.params.data.text,
                buttons: recievedMessageObject.params.data.buttons,
                params: recievedMessageObject.params,
                action: (recievedMessageObject.params.data.action ? recievedMessageObject.params.data.action : null),
                method: recievedMessageObject.method,
                createdAt: new Date(recievedMessageObject.params.timestamp),
                user: {
                    ...user,
                },
            })
        )
    }

    if (recievedMessageObject.params.data && recievedMessageObject.params.data.option) {
        if (!recievedMessageObject.params.data.text) {
            return (
                chatBotMessages.push({
                    text: null,
                    option: recievedMessageObject.params.data.option,
                    method: recievedMessageObject.method,
                    params: recievedMessageObject.params,
                    _id: Math.round(Math.random() * 1000000),
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    user: {
                        ...user,
                    },
                })
            )
        }

        chatBotMessages.push({
            text: recievedMessageObject.params.data.text,
            method: recievedMessageObject.method,
            params: recievedMessageObject.params,
            _id: Math.round(Math.random() * 1000000),
            createdAt: new Date(recievedMessageObject.params.timestamp),
            ...baseParams,
        })

        chatBotMessages.push({
            text: null,
            option: recievedMessageObject.params.data.option,
            method: recievedMessageObject.method,
            params: recievedMessageObject.params,
            _id: Math.round(Math.random() * 1000000),
            createdAt: new Date(recievedMessageObject.params.timestamp),
            user: {
                ...user
            }
        })


    }




    if (recievedMessageObject.params.data && recievedMessageObject.params.data.menu) {
        if (recievedMessageObject.params.data.menu[0].card[0].reference) {
            return (
                chatBotMessages.push({
                    _id: Math.round(Math.random() * 1000000),
                    text: null,
                    menu: recievedMessageObject.params.data.menu[0].card,
                    params: recievedMessageObject.params,
                    reference: true,
                    method: recievedMessageObject.method,
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    user: {
                        ...user,
                    },
                })
            )
        }
        if (!recievedMessageObject.params.data.menu[0].text) {
            return (
                chatBotMessages.push({
                    text: null,
                    card: recievedMessageObject.params.data.menu[0].card,
                    method: recievedMessageObject.method,
                    params: recievedMessageObject.params,
                    _id: Math.round(Math.random() * 1000000),
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    user: {
                        ...user,
                    },
                })
            )
        } else if (recievedMessageObject.params.data && recievedMessageObject.params.data.menu[0] && recievedMessageObject.params.data.menu[0].text) {
            let Bubbletext = recievedMessageObject.params.data.menu[0].text.replace("<card></card>", "");
            return (
                chatBotMessages.push({
                    text: (Bubbletext && Bubbletext.length > 0 ? Bubbletext : ""),
                    card: recievedMessageObject.params.data.menu[0].card,
                    method: recievedMessageObject.method,
                    params: recievedMessageObject.params,
                    _id: Math.round(Math.random() * 1000000),
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    user: {
                        ...user,
                    },
                })
            )
        }

        chatBotMessages.push({
            text: recievedMessageObject.params.data.text,
            method: recievedMessageObject.method,
            params: recievedMessageObject.params,
            _id: Math.round(Math.random() * 1000000),
            createdAt: new Date(recievedMessageObject.params.timestamp),
            ...baseParams,
        })

        return (
            chatBotMessages.push({
                text: null,
                menu: recievedMessageObject.params.data.menu[0].card,
                method: recievedMessageObject.method,
                params: recievedMessageObject.params,
                _id: Math.round(Math.random() * 1000000),
                createdAt: new Date(recievedMessageObject.params.timestamp),
                user: {
                    ...user,
                },
            })
        )

    }

    if (recievedMessageObject.params.data && recievedMessageObject.params.data.action && recievedMessageObject.params.data.text) {
        const convertedArray = recievedMessageObject.params.data.text.match(/<p collapsible='true'>(.*?)<\/p>/g)
        if (convertedArray) {
            return (
                chatBotMessages.push({
                    _id: Math.round(Math.random() * 1000000),
                    text: recievedMessageObject.params.data.text,
                    params: recievedMessageObject.params,
                    action: recievedMessageObject.params.data.action,
                    method: recievedMessageObject.method,
                    card: (recievedMessageObject.params.data.card ? recievedMessageObject.params.data.card : null),
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    user: {
                        ...user,
                    },
                })
            )

        }
    }

    if (recievedMessageObject.params.data && recievedMessageObject.params.data.action && recievedMessageObject.params.data.action[0] && recievedMessageObject.params.data.action[0].text) {
        chatBotMessages.push({
            _id: Math.round(Math.random() * 1000000),
            text: recievedMessageObject.params.data.action[0].text,
            method: recievedMessageObject.method,
            params: recievedMessageObject.params,
            createdAt: new Date(recievedMessageObject.params.timestamp),
            ...baseParams,
        })

        if (recievedMessageObject.params.data.action[0].option) {
            return (
                chatBotMessages.push({
                    _id: Math.round(Math.random() * 1000000),
                    text: null,
                    option: recievedMessageObject.params.data.action[0].option,
                    stars: true,
                    method: recievedMessageObject.method,
                    params: recievedMessageObject.params,
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    user: {
                        ...user,
                    },
                })
            )
        }
        return null
    }

    if (recievedMessageObject.params.data && recievedMessageObject.params.data.text && !recievedMessageObject.params.data.option) {
        const convertedArray = recievedMessageObject.params.data.text.match(/<p>(.*?)<\/p>/g)
        if (convertedArray) {
            return (
                chatBotMessages.push({
                    text: recievedMessageObject.params.data.text,
                    method: recievedMessageObject.method,
                    _id: Math.round(Math.random() * 1000000),
                    params: recievedMessageObject.params,
                    card: (recievedMessageObject.params.data.card ? recievedMessageObject.params.data.card : null),
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    ...baseParams,
                })
            )

        } else {
            const removeHtmlStartTag = recievedMessageObject.params.data.text.replace('<p>', '')
            const removeHtmlEndTag = removeHtmlStartTag.replace('</p>', '')
            if (removeHtmlEndTag) {
                chatBotMessages.push({
                    text: recievedMessageObject.params.data.text,
                    method: recievedMessageObject.method,
                    params: recievedMessageObject.params,
                    _id: Math.round(Math.random() * 1000000),
                    card: (recievedMessageObject.params.data.card ? recievedMessageObject.params.data.card : null),
                    createdAt: new Date(recievedMessageObject.params.timestamp),
                    ...baseParams,
                })
            }
        }
    }
    processRecievedMessageActions(recievedMessageObject, baseParams)
}

/*just delete the previous option and pill buttons from history*/
const processHistoryDataForRender = (history, modified) => {


    /*take loginobj and kept in cahce for furture trequest*/

    if (history.params && history.params.data && history.params.data.option) {
        let options = history.params.data.option;
        for (var i = 0; i < options.length; i++) {
            if (options[i]["command"] && options[i]["command"] === "require_login") {
                utils.setLoginPostbackObj(options[i]);
                break;
            }
        }

    }
    /*end*/

    if (((history.params && history.params.data && history.params.data.option && !modified) || (historyDraw && history.params && history.params.data && history.params.data.option))) {
        const modifiedHistory = {
            ...history,
        }
        if (modifiedHistory && modifiedHistory.params && modifiedHistory.params.data && modifiedHistory.params.data.option) {
            modifiedHistory.params.data.option = null
        }
        return modifiedHistory
    }
    if ((history.params && history.params.data && history.params.data.action && !modified) || (historyDraw && history.params && history.params.data && history.params.data.action)) {
        const modifiedHistory = {
            ...history,
        }
        if (modifiedHistory && modifiedHistory.params && modifiedHistory.params.data && modifiedHistory.params.data.action && modifiedHistory.params.data.action.length > 0 && modifiedHistory.params.data.action[0].option) {
            modifiedHistory.params.data.action[0].option = null
        }
        return modifiedHistory
    }
    return history
}

/*process chat history and start init chat*/
let temphistoryData = [];
let historyDraw = false;
export const sendSequentialHistoryMessages = (responseMessage) => {
    let originalHistoryData = JSON.parse(JSON.stringify(responseMessage.params.history));
    let historyData = responseMessage.params.history.reverse()
    temphistoryData = temphistoryData.concat(historyData);
    //const rowLen = historyData.length
    const filterHistoryData = []
    /*read previous entry from user obj and set it to gloabl variable and compare*/
    let chatbotinitParamsFromState = Store.getState().chatbotparams;
    if (chatbotinitParamsFromState.validateContextChange === true && historyData && Array.isArray(historyData) && historyData.length > 0 && !utils.getPreviousEntry()) {
        for (var i = 0; i < originalHistoryData.length; i++) {
            let userObj = originalHistoryData[i].params.user;
            if (userObj && userObj.reporting && userObj["reporting"][userObj["app-type"]] && userObj["reporting"][userObj["app-type"]]["bot_entry"]) {
                console.log(originalHistoryData[i])
                utils.setPreviousEntry(userObj["reporting"][userObj["app-type"]]["bot_entry"]);
                break;
            }
        }
    }

    historyData.map((history) => {
        if ((history.method === 'event' && history.params.text === 'initiate_chat') || (history.method === 'event' && history.params.text === "close_chat") || (history.method === 'event' && history.params.text === 'end_chat') || history.method === 'submit_survey' || (history.params.data && Object.keys(history.params.data).length === 0) || (history.params.data && history.params.data.isOutageMessage && (history.params.data.isOutageMessage === true || history.params.data.isOutageMessage === "true"))) {
            return null
        }
        return filterHistoryData.push(history)
    })

    filterHistoryData.map((history, historyIndex) => {
        if (utils.getMessagerNodeRef() && utils.getMessagerNodeRef().childNodes[1].childNodes.length > 1) {
            onMessageProcesser(JSON.stringify(processHistoryDataForRender(history, false)))
        } else {
            onMessageProcesser(JSON.stringify(processHistoryDataForRender(history, filterHistoryData.length === historyIndex + 1)))
        }
        if (filterHistoryData.length === historyIndex + 1) {
            NetworkHelper.historySucessfulyRetrieved(temphistoryData)

        } else if (filterHistoryData.length - 1 === historyIndex) {
            //NetworkHelper.buildRequestToSend('get_message', '', user, { count: NetworkHelper.getDefaultHistoryMsgCount() })
            NetworkHelper.doGetHistory(NetworkHelper.getUserInfo());
        }
        return null
    })
    /*"*remove the last bubble when cData is success"*/
    if (chatBotMessages && chatBotMessages.length > 0) {
        let data = chatBotMessages[chatBotMessages.length - 1];
        let user = NetworkHelper.getUserInfo();
        if (user.loginstatus && (user.loginstatus.toLowerCase() === "success" || user.loginstatus.toLowerCase() === "failure")) {
            if (Object.keys(utils.getLoginPostbackObj()).length > 0 && data.option) {
                chatBotMessages[chatBotMessages.length - 1].option = null;
            }
        }
    }
    /*end last bubble removed*/

    NetworkHelper.onReceiveCb(chatBotMessages.reverse(), true)
    if (chatBotMessages && chatBotMessages.length > 0) {
        let data = chatBotMessages[chatBotMessages.length - 1];
        if (data.params && data.params && data.params.data && data.params.data.action) {
            let actions = data.params.data.action;
            actions.map((action) => {
                if ((action.command && action.command === 'disable_text_input')) { // action commands to be processed
                    Store.dispatch(updateTextBoxStatus());
                }
                return "";
            })
        }
    }
    if (!chatBotMessages.length) {
        NetworkHelper.historySucessfulyRetrieved(historyData)
    }
    chatBotMessages = []
}

export const onOpen = (wsRef) => {
    wsTunnel = wsRef.state.ws;
    socketReference = wsRef;
    NetworkHelper.connectionSuccessCb();
}

/*once response came from server remove from array failure message*/
export const deleteSubmitTextMessageFromArray = (responseMessage) => {
    let updateArray = [];
    let SubmitTextMessageBeforeSend = utils.getSubmitTextMessageBeforeSend();
    for (var i = 0; i < SubmitTextMessageBeforeSend.length; i++) {
        if (SubmitTextMessageBeforeSend[i]["id"] !== responseMessage.id) {
            updateArray.push(SubmitTextMessageBeforeSend[i])
        }
    }

    utils.setSubmitTextMessageBeforeSend(updateArray)
}

export const onMessage = (data) => {
    let responseMessage = JSON.parse(data)
    let storeHistory = JSON.parse(Store.getState().chat_initiate_history)
    console.log('responseMessage', responseMessage)
    console.log('Store.getState().chat_initiate_history', storeHistory)
    //Store.getState().chat_initiate_history;
    if (responseMessage && responseMessage.type == "history" && storeHistory && storeHistory.type == "history") {
        if (responseMessage.params && responseMessage.params.history && responseMessage.params.history > 0) {} else {
            responseMessage = storeHistory
            Store.dispatch(resetHistoryStore())
            console.log('Store.getState()', Store.getState().chat_initiate_history)
        }
    }
    console.log('responseMessage after', responseMessage)

    /*when submit survey is success draw thank you page*/
    if (responseMessage.id && responseMessage.id === NetworkHelper.submit_id) {
        Store.dispatch(drawThankyouPage(true));
        utils.setSurveyObj(null);
    }
    if (responseMessage.reply) {
        utils.postMessageToParent("toast_message", {
            "message": responseMessage.reply.msg
        })
    }
    /*just history fail send call init chat again*/
    if (responseMessage.error && Object.keys(NetworkHelper.getMessageBot()).length === 0 && Object.keys(NetworkHelper.getMessageHistoryBot()).length === 0) {
        NetworkHelper.historySucessfulyRetrieved([]);

    }

    NetworkHelper.processIncomingResponse(responseMessage)
    if (responseMessage.type && responseMessage.type === 'history') {
        sendSequentialHistoryMessages(responseMessage)
    } else if ((responseMessage.type && (responseMessage.type === "menu" || responseMessage.type === "survey")) || (responseMessage.params && responseMessage.params.data && Object.keys(responseMessage.params.data).length > 0)) {
        if (responseMessage.type !== "ack" && (utils.getMessagerNodeRef() && utils.getMessagerNodeRef().children[1].children.length === 0 || !isFirstLoad)) {
            NetworkHelper.onReceiveCb(data);
            isFirstLoad = true;
        } else {
            receivedResponse.push(data);
            if (timerInterval == null) {
                timerInterval = setInterval(function() {
                    NetworkHelper.onReceiveCb(receivedResponse[0]);
                    receivedResponse.shift();
                    if (receivedResponse.length === 0) {
                        clearInterval(timerInterval);
                        timerInterval = null;
                    }
                }, 1500)
            }
        }

    }

}

/*
function checkJSNetConnection(){
  var xhr = new XMLHttpRequest();
  var file = "favicon.ico";
  var r = Math.round(Math.random() * 10000);
  xhr.open('HEAD', file + "?subins=" + r, false);
  try {
   xhr.send();
   if (xhr.status >= 200 && xhr.status < 304) {
    return true;
   } else {
    return false;
   }
  } catch (e) {
   return false;
  }
 }*/

export const isBotEntryEqual = () => {
    let previousEntry = utils.getPreviousEntry();
    let chatbotinitParamsFromState = Store.getState().chatbotparams;
    if (chatbotinitParamsFromState && chatbotinitParamsFromState.validateContextChange === true && chatbotinitParamsFromState.chatbotInitParams && chatbotinitParamsFromState.chatbotInitParams["entry"]) {
        if (!previousEntry || previousEntry === chatbotinitParamsFromState.chatbotInitParams["entry"]) {
            return true;
        }
    } else {
        return true;
    }
    return false;
}

export const doSend = (data) => {
    try {

        /*if network is offline when user typing imeditely show the alert bar*/

        if (!utils.getisNetworkConnected()) {
            utils.updateSubmitTextMessageBeforeSend(data);
            socketReference.closeSocket("onClose");
        } else if (wsTunnel.readyState !== 1) {
            utils.updateSubmitTextMessageBeforeSend(data);
            socketReference.reconnectSocket();
            let timerInterval = setInterval(() => {
                if (socketReference.state.ws.readyState === 1) {
                    socketReference.setupWebsocket();
                    updateSocketRef(socketReference.state.ws);
                    clearInterval(timerInterval);
                    doSend(data);
                }
            }, 1000);
        } else if (wsTunnel.readyState === 1) {

            /*compare the  bot and show confirmation popup*/

            if (!isBotEntryEqual()) {
                let datasObj = {
                    "requestData": data,
                    "isContextChangeConfirmation": true
                }
                Store.dispatch(showContextChangeConfirmation(datasObj));
                return false;
            }
            wsTunnel.send(data);
        }

    } catch (e) {
        console.log('ws Client Tunnel Error ', e) // eslint-disable-line
        NetworkHelper.connectionFailureCb()
    }
}

export const onClose = (event) => {
    if (event === undefined || (event && event.code !== 1000)) {
        utils.setisSocketConnected(false);
        let messages = [];
        let submitMessageArray = utils.getSubmitTextMessageBeforeSend();
        for (let i = 0; i < submitMessageArray.length; i++) {
            let data = submitMessageArray[i];
            if (data != null && data.msg) {
                let msg = JSON.parse(data.msg).params.text;
                messages.push(msg);

            }
        }
        Store.dispatch(updateTextBoxStatus());
        if (messages.length > 0) {
            Store.dispatch(onNetworkError(messages));
        }
    }

    console.log('Connection Closed...') // eslint-disable-line
}


export const updateSocketRef = (socketRef) => {
    wsTunnel = socketRef;
}


export const getSocketRef = (socketRef) => {
    return wsTunnel;
}


export const closeSocketConnection = () => {
    socketReference.closeSocket();
    // updateSocketRef(null);
}


/*send failure message one buy one to bot don't allow multiple request 
for same id so using previous id param updating and checking*/
export const sendFailureMessage = () => {
    let submitMessageArrayFullObject = utils.getSubmitTextMessageBeforeSend();
    if (submitMessageArrayFullObject.length > 0) {
        let timeInterval = setInterval(() => {
            if (submitMessageArrayFullObject.length > 0) {
                let submitMessageArray = submitMessageArrayFullObject[0];
                if (submitMessageArray !== undefined && submitMessageArray["id"] !== previousId) {
                    let data = submitMessageArray;
                    if (data != null && data.msg) {
                        doSend(data.msg);
                    }
                    previousId = submitMessageArray["id"];
                }
                submitMessageArrayFullObject.shift();
            } else {
                clearInterval(timeInterval);
            }
        }, 500)
    }
}

export const onError = (evt) => {
    console.log('Connection error...') // eslint-disable-line
}