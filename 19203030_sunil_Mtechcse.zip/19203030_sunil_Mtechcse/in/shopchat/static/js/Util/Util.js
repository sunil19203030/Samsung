let messageNodeRef = "";
let surveyObj = "";
let escalationDOMNodeReference = [];
let isConnectedWithAgent = false;
let originatorInfo;
let submitTextBeforeSend = [];
let isSocketConnected = true;
let isAgentActive = false;
let isHistory = false;
let isNetworkConnected = false;
let speechBubbleRightTime = "";
let speechBubbleLeftTime = "";
let regexEscape = /["&'<>`]/g;
let loginPostbackObj = {};
let CustomerFirstMessageNeedToSend = false;
let previous_entry = "";
let isEndChatWhileConnectingWithAgent = false;
let isSurveyRequiredDuringCloseChat = false;
const encodeMap = {
    '"': '&quot;',
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '`': '&#x60;',
    '\'': '&#8217;'
};

export function setCustomerFirstMessageNeedToSend(flag) {
    CustomerFirstMessageNeedToSend = flag;
}

export function getCustomerFirstMessageNeedToSend() {
    return CustomerFirstMessageNeedToSend;
}

/*Added app types here for all like orders,etc url need to open as a seperate new window */
let urlRedirectAppTypes = ["samsung.com"];
export function getUuid() {
    if (readCookie("uuid")) {
        return readCookie("uuid");
    } else {
        let uuid = generateGuid();
        createCookie("uuid", uuid, 366);
        return uuid;
    }
}


export function createCookie(name, value, days, cb) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        document.cookie = name + "=" + value + ";expires=" + date.toUTCString() + ";path=/";
        if (cb) {
            cb();
        }
    } else {
        console.log("ERROR: set cookie require ttl.");
    }
}

export function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return false;
}

export function eraseCookie(name, cb) {
    createCookie(name, "", -1, cb);
}
export function generateGuid() {
    var result, i, j;
    result = '';
    for (j = 0; j < 32; j++) {
        if (j === 8 || j === 12 || j === 16 || j === 20)
            result = result + '-';
        i = Math.floor(Math.random() * 16).toString(16).toUpperCase();
        result = result + i;
    }

    return result;
}


export function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0' + minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}

export function replaceAll(str, find, replace) {
    return str.replace(new RegExp(find, 'g'), replace);
}


export function splitTag(htmlTags) {
    let html = htmlTags;
    let isValidYoutubeRenderLink = false;
    //html=replaceAll(html,"&gt;",">");
    //html=replaceAll(html,"&lt;","<");
    html = html.replace(/<style [^>]*?>[\s\S]*?<\/style>/g, "").trim();
    html = html.replace(/<font [^>]*?>/g, "").trim();
    html = html.replace(/<\/font>/g, "").trim();
    html = html.replace(/<span [^>]*?>/g, "").trim();
    html = html.replace(/<\/span>/g, "").trim();
    html = html.replace(/<br>/g, " ");
    html = replaceAll(html, "<div> </div>", "");
    html = replaceAll(html, "<div></div>", "");
    html = html.replace(/<p>\s*<\/p>/g, "");
    html = html.replace(/<p style='.*?'/g, "<p").trim();
    html = html.replace(/<p style=".*?"/g, "<p").trim();
    html = html.replace(/<div>\s*<\/div>/g, "");
    html = html.replace(/(<div)/igm, '<p').replace(/<\/div>/igm, '</p>'); //to replace all div to p
    /*modifiying text if anchor tag having youtube url*/
    let anchorTag = html.match(/<a[^>]*>([^<]+)<\/a>/g);
    if (anchorTag && Array.isArray(anchorTag) && anchorTag.length > 0) {
        let anchorTagString = anchorTag[0];
        let href = anchorTagString.match(/href=("|')(.*?)("|')/g)
        if (href && Array.isArray(href) && href.length > 0) {
            href = href[0].replace("href=\"", "").trim();
            href = href.replace("href='", "").replace("'", "").trim();
            href = replaceAll(href, "\"", "");
            let formattedStr = "";
            let startAtag = "<a";
            let endATag = "</a>";
            if (isValidYoutubeUrl(href)) {
                html = replaceAll(html, "<p>", "");
                html = replaceAll(html, "</p>", "");
                let startStr = html.substring(0, html.indexOf(startAtag));
                let endStr = html.substring(html.length, (html.indexOf(endATag) + endATag.length));
                if (startStr) {
                    formattedStr = "<p>" + startStr + "</p>";
                }
                if (href.split("//")[0]) {
                    let hrefurl = href.split("//")[0] + "//" + extractHostname(href);
                    let embedYoutubeurl = hrefurl + "/embed/";

                    if (getParameterByName("list", href)) {
                        embedYoutubeurl = embedYoutubeurl + "&listType=playlist&list=" + getParameterByName("list", href);
                        if (getParameterByName("index", href)) {
                            embedYoutubeurl = embedYoutubeurl + "&index=" + (getParameterByName("index", href) - 1);
                        }
                        if (getParameterByName("t", href)) {
                            embedYoutubeurl = embedYoutubeurl + "&start=" + getParameterByName("t", href);
                        }
                        isValidYoutubeRenderLink = true;
                    } else if (getParameterByName("v", href)) {
                        embedYoutubeurl = embedYoutubeurl + getParameterByName("v", href);
                        isValidYoutubeRenderLink = true;
                    }


                    if (isValidYoutubeRenderLink) {
                        embedYoutubeurl = embedYoutubeurl + "&modestbranding=1&rel=0";
                        embedYoutubeurl = embedYoutubeurl.replace("&", "?");
                        console.log("embedYoutubeurl : " + embedYoutubeurl);
                        formattedStr = formattedStr + "<p>" + embedYoutubeurl + "</p>";
                        if (endStr) {
                            formattedStr = formattedStr + "<p>" + endStr + "</p>";
                        }
                        html = formattedStr;
                    }
                }

            }
        }

    }
    let arr = html.match(/(.*?)<p>(.*?)<\/p>/g);
    if (arr == null) {
        arr = html.match(/<p collapsible='true'>(.*?)<\/p>/g);
        if (html.match(/<img (.*?)>/g) != null && arr != null) {
            arr.push(html.match(/<img (.*?)>/g)[0])
        }
        if (arr == null)
            return [html];
        else
            return arr;
    } else {
        html = html.replace(/(<\/?(?:p)[^>]*>)|<[^>]+>/ig, '$1'); //to replace all the tag except p
        let htmlArray = [];
        for (let htmlValue in arr) {
            let trimmedValue = arr[htmlValue].replace(/\t/g, '').replace(/<br>/g, '');
            if (trimmedValue !== "<p></p>") {
                htmlArray.push(arr[htmlValue].replace(/\t/g, '').replace(/<br>/g, ''));
            }

        }
        return htmlArray;
    }
}


export function smooth_scroll_to(element, target, duration) {
    target = Math.round(target);
    duration = Math.round(duration);
    if (duration < 0) {
        return Promise.reject("bad duration");
    }
    if (duration === 0) {
        element.scrollTop = target;
        return Promise.resolve();
    }

    var start_time = Date.now();
    var end_time = start_time + duration;

    var start_top = element.scrollTop;
    var distance = target - start_top;


    var smooth_step = function(start, end, point) {
        if (point <= start) {
            return 0;
        }
        if (point >= end) {
            return 1;
        }
        var x = (point - start) / (end - start);
        return x * x * (3 - 2 * x);
    }

    return new Promise(function(resolve, reject) {
        // This is to keep track of where the element's scrollTop is
        // supposed to be, based on what we're doing
        var previous_top = element.scrollTop;


        var scroll_frame = function() {

            // set the scrollTop for this frame
            var now = Date.now();
            var point = smooth_step(start_time, end_time, now);
            var frameTop = Math.round(start_top + (distance * point));
            element.scrollTop = frameTop;

            // check if we're done!
            if (now >= end_time) {
                resolve();
                return;
            }

            // If we were supposed to scroll but didn't, then we
            // probably hit the limit, so consider it done; not
            // interrupted.
            if (element.scrollTop === previous_top &&
                element.scrollTop !== frameTop) {
                resolve();
                return;
            }
            previous_top = element.scrollTop;

            // schedule next frame for execution
            setTimeout(scroll_frame, 0);
        }

        // boostrap the animation process
        setTimeout(scroll_frame, 0);
    });
}

export function postMessageToParent(message, params) {
    let postMessage = {
        command: "launch_deeplink",
        metadata: {
            "deeplink": message
        }
    }

    if (params) {
        postMessage.metadata["params"] = params;
    }
    if (isNativeIos() && window && window.webkit) {
        window.webkit.messageHandlers.dismissChatbot.postMessage(message);
    } else {
        window.parent.postMessage({
            cData: JSON.stringify(postMessage),
            target: "chatbot"
        }, "*");
    }
}

export function validateParams(userObj) {
    let ValidateKey = ["chatbot_api_server", "chatbot_api_port", "chatbot_api_path", "entry", "country", "chatVersion"];
    let ValidationObject = {};
    for (let keys in ValidateKey) {
        if (userObj[ValidateKey[keys]] === undefined) {
            ValidationObject["isValid"] = false;
            ValidationObject["message"] = "Missing " + ValidateKey[keys] + " Params for chatbot";
            break;
        } else {
            ValidationObject["isValid"] = true;
            ValidationObject["message"] = "";
        }
    }
    return ValidationObject;
}

export function setMessagerNodeRef(node) {
    messageNodeRef = node;
}

export function getMessagerNodeRef() {
    return messageNodeRef;
}

export function setSurveyObj(obj) {
    surveyObj = obj;
}

export function getSurveyObj() {
    return surveyObj;
}

export function setEscalationDOMNodeReference(escalationDomNodeArray) {
    escalationDOMNodeReference = escalationDomNodeArray;
}

export function getEscalationDOMNodeReference() {
    return escalationDOMNodeReference;
}

export function setisConnectedWithAgent(flag) {
    isConnectedWithAgent = flag;
}

export function getisConnectedWithAgent() {
    return isConnectedWithAgent;
}

export function setOriginatorInfo(originator_info) {
    originatorInfo = originator_info;
}

export function getOriginatorInfo() {
    return originatorInfo;
}
export function getUrlRedirectAppTypes(appType) {
    if (urlRedirectAppTypes.indexOf(appType) !== -1) {
        return true;
    } else {
        return false;
    }
}

export function updateSubmitTextMessageBeforeSend(msg) {
    let isMsgPresent = false;
    for (var i = 0; i < submitTextBeforeSend.length; i++) {
        if (submitTextBeforeSend[i]["id"] === JSON.parse(msg).id) {
            submitTextBeforeSend[i]["msg"] = msg;
            isMsgPresent = true;
            break;
        }
    }
    if (!isMsgPresent) {
        submitTextBeforeSend.push({
            id: JSON.parse(msg).id,
            msg: msg
        });
    }
}

export function setSubmitTextMessageBeforeSend(msgArray) {
    submitTextBeforeSend = msgArray;
}

export function getSubmitTextMessageBeforeSend() {
    return submitTextBeforeSend;
}

export function isValidURL(str) {
    var regex = /(http|https):\/\/(\w+:{0,1}\w*)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%!]))?/;
    if (!regex.test(str)) {
        return false;
    } else {
        return true;
    }
}

export function setisNetworkConnected(networkStatus) {
    isNetworkConnected = networkStatus;
}

export function getisNetworkConnected() {
    return isNetworkConnected;
}

export function setisSocketConnected(socketStatus) {
    isSocketConnected = socketStatus;
}

export function setActiveLiveAgentStatus(agentStatus) {
    isAgentActive = agentStatus;
}

export function getActiveLiveAgentStatus() {
    return isAgentActive;
}

export function getisSocketConnected() {
    return isSocketConnected;
}

export function setisHistory(flag) {
    isHistory = flag;
}

export function getisHistory() {
    return isHistory;
}

export function unescapeHtmlEntities(htmlStirng) {
    return htmlStirng.replace(/&gt;/g, '>').replace(/&lt;/g, '<').replace(/ x60;/g, '`').replace(/ x60/g, '`').replace(/&amp;/g, '&').replace(/&quot;/g, '`').replace(/&#8217;/g, '`').replace(/&#x60;/g, '`');
}

export function escapeHtmlEntities(string) {
    return string.replace(regexEscape, function($0) {
        // Note: there is no need to check `has(escapeMap, $0)` here.
        return encodeMap[$0];
    });
}

export function setSpeechBubbleRightTime(rightbubbleTime) {
    speechBubbleRightTime = rightbubbleTime;
}

export function getSpeechBubbleRightTime() {
    return speechBubbleRightTime;
}


export function setSpeechBubbleLeftTime(bubbleTime) {
    speechBubbleLeftTime = bubbleTime;
}

export function getSpeechBubbleLeftTime() {
    return speechBubbleLeftTime;
}

export function setLoginPostbackObj(loginobj) {
    loginPostbackObj = loginobj;
}

export function getLoginPostbackObj() {
    return loginPostbackObj;
}

export function isValidYoutubeUrl(url) {
    var valid = /^(http(s)?:\/\/)?((w){3}.)?youtu(be|.be)?(\.com)?\/.+/
    return valid.test(url);
}

export function extractHostname(url) {
    var hostname;
    //find & remove protocol (http, ftp, etc.) and get hostname

    if (url.indexOf("//") > -1) {
        hostname = url.split('/')[2];
    } else {
        hostname = url.split('/')[0];
    }

    //find & remove port number
    hostname = hostname.split(':')[0];
    //find & remove "?"
    hostname = hostname.split('?')[0];

    return hostname;
}

export function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

export function setPreviousEntry(entry) {
    previous_entry = entry;
}

export function getPreviousEntry() {
    return previous_entry;
}

export function setisEndChatWhileConnectedWithAgent(flag) {
    isEndChatWhileConnectingWithAgent = flag;
}

export function getisEndChatWhileConnectedWithAgent() {
    return isEndChatWhileConnectingWithAgent;
}


export function setisSurveyIsRequired(flag) {
    isSurveyRequiredDuringCloseChat = flag;
}

export function getisSurveyIsRequired() {
    return isSurveyRequiredDuringCloseChat;
}
export function checkInitiateIsRequiredDuringMaximizeChat() {
    let InitiateIsRequired = true;
    eraseCookie('cbMessageCount', hideMessageCountEvent)
    if (getMessagerNodeRef() && getMessagerNodeRef().children && getMessagerNodeRef().children.length > 0 && getMessagerNodeRef().children[1] && getMessagerNodeRef().children[1].children && getMessagerNodeRef().children[1].children.length > 0) {
        let domNode = getMessagerNodeRef().children[1].children[getMessagerNodeRef().children[1].children.length - 1];
        if (domNode && domNode.className === "initiated_parent_div") {
            InitiateIsRequired = false;
        }
    }
    return InitiateIsRequired;
}
export function hideMessageCountEvent() {
    postMessageToParent("hidemessagecount");
}
export function isNativeApp() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent)
}
export function isNativeIos() {
    return ['iPhone', 'iPad', 'iPod', 'iPad Simulator', 'iPhone Simulator', 'iPod Simulator', ].includes(navigator.platform);
}