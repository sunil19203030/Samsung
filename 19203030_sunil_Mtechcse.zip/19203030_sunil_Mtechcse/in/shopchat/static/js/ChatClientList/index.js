import React from 'react'
import {
    connect
} from 'react-redux';
import Constants from '../Resources/Constants';

import './style.css';



class ChatClientList extends React.Component {

    constructor(props) {
        super(props)
    }

    onPurchaseClick = (e) => {
        this.props.onPurchaseClicked();
    }

    onOrdersClick() {
        let url = 'https://www.samsung.com/in/web/my-orders'
        if (window && window.EcommAndroidClient && window.EcommAndroidClient['openExternalBrowser']) {
            window.EcommAndroidClient['openExternalBrowser'](url);
        } else {
            window.open(url, '_blank')
        }
    }

    onServiceClick() {
        let url = 'https://chatbot.samsungcs-support.com/?source=dotcom'
        if (window && window.EcommAndroidClient && window.EcommAndroidClient['openExternalBrowser']) {
            window.EcommAndroidClient['openExternalBrowser'](url);
        } else {
            window.open(url, '_blank ')
        }
    }

    render() {
        return (

            <
            div >
            <
            div className = "conversation-container-header" > {
                Constants.HEADER
            } < /div> <
            div className = "conversation-container-secondary-header" > {
                Constants.SECONDARY_HEADER
            } < /div> <
            div className = "conversation-container-list" >
            <
            div className = "conversation-container-list-card"
            onClick = {
                this.onPurchaseClick
            } >
            <
            div className = "conversation-container-list-card-header" > {
                Constants.CARD_ONE_HEADER
            } <
            /div> <
            div className = "conversation-container-list-card-content" > {
                Constants.CARD_ONE_CONTENT
            } <
            /div> <
            /div> <
            div className = "conversation-container-list-card"
            onClick = {
                this.onOrdersClick
            } >
            <
            div className = "conversation-container-list-card-header" > {
                Constants.CARD_TWO_HEADER
            } <
            /div> <
            div className = "conversation-container-list-card-content" > {
                Constants.CARD_TWO_CONTENT
            } <
            /div> <
            /div> <
            div className = "conversation-container-list-card"
            onClick = {
                this.onServiceClick
            } >
            <
            div className = "conversation-container-list-card-header" > {
                Constants.CARD_THREE_HEADER
            } <
            /div> <
            div className = "conversation-container-list-card-content" > {
                Constants.CARD_THREE_CONTENT
            } <
            /div> <
            /div> <
            /div> <
            /div>

        );
    }

}



const mapStateToprops = (state) => ({
    state
})

export default connect(mapStateToprops)(ChatClientList);