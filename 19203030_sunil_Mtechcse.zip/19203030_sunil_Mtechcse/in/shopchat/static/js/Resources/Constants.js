const constants = {
    THEME_MEMBERS: '_members', // theme for Chat v2.0 client conforms with Members design spec
    HEADER: 'Samsung Live Chat',
    SECONDARY_HEADER: 'Need Help? Select your enquiry type',
    SECONDARY_HEADER_LIST: 'Please enter your details below',
    SECONDARY_HEADER_CALLBACK: 'Arranging Call Back',
    THIRD_HEADER_CALLBACK: 'Please suggest a preferred time slot. Our product expert will get in touch with you as soon as possible',
    CARD_ONE_HEADER: 'Purchase & Offers',
    CARD_ONE_CONTENT: 'Product specification, purchase related, pricing & offers',
    CARD_TWO_HEADER: 'Orders',
    CARD_TWO_CONTENT: 'Questions about the orders you placed',
    CARD_THREE_HEADER: 'Service',
    CARD_THREE_CONTENT: 'Support for existing products',
    CALLBACK_ACTION: 'bot://shop.samsung.com/shop_custom/request_callback',
    EMPTY_USER_ACTION: 'bot://shop.samsung.com/shop_custom/empty_user_callback',
    INITIATE_ACTION: 'bot://shop.samsung.com/shop_custom/initiate_chat',
    PARTNER_CHAT: ['in_flipkart', 'in_tatacliq', 'in_amazon', 'in_mygalaxy', 'in_finance-plus']
}

export default constants