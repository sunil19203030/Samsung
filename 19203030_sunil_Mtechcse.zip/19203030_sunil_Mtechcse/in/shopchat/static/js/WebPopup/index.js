import React from "react";
import * as NetworkHelper from '../Util/NetworkHelper';
import * as NetworkLib from '../Util/NetworkLib';
import * as utils from '../Util/Util';
import {
    connect
} from 'react-redux';
import {
    setIntialStateValue,
    closeChat,
    showEndChatConfirmation,
    showOverLay
} from '../actions/action';
import './style.css';


class WebPopup extends React.Component {
        constructor(props) {
            super(props)
            this.chatpotParams = this.props.popupParams;
            this.state = {
                endChatConfirmationScreen: false,
                endChatConfirmationObject: null
            };

        }

        componentDidMount() {
            if (document.getElementsByClassName("endChatDiv")[0]) {
                document.getElementsByClassName("endChatDiv")[0].style.display = "block";
            }
            this.props.hideLoader();
        }

        buttonClick(value) {

            if (value["payload"]) {
                NetworkHelper.buildRequestToSend('event', value.payload, NetworkHelper.getUserInfo(), {
                    text: "close_chat"
                });
            }
            /*this code will work for keep chating an end chating*/
            if (value["tag"]) {
                let tag_params = {
                    "tag_event": value["tag"]["tag_event"],
                    "tag_action": value["tag"]["tag_action"],
                }
                utils.postMessageToParent("tag", tag_params);
            }
            this.props.closeChat();
            /*if end chat option is present and if style web then draw the end chat confirmation screen*/
            if (value['client_action'] === "end_chat") {
                utils.setisSurveyIsRequired(true);
                this.props.showOverLay(true);
            }
            document.getElementsByClassName("endChatDiv")[0].style.display = "none"
            /*document.getElementsByClassName("senderMainDiv")[0].style.display = "block";*/

            if (typeof value.end_chat_confirmation === "undefined" && value['client_action'] === "end_chat") {
                utils.postMessageToParent("closeChat");
                NetworkHelper.submitSurvey(true);
                NetworkLib.closeSocketConnection();
                if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                    window.frames.location.reload(true);
                }
            }

        }
        render() {
            return (this.chatpotParams != null && !this.state.endChatConfirmationScreen ? < div style = {
                    {
                        textAlign: "center",
                        marginTop: 120
                    }
                } >
                <
                div className = {
                    "endChatTitle"
                } > {
                    this.chatpotParams.popup_title
                } < /div> <
                div className = {
                    "endChatDescription"
                } > {
                    this.chatpotParams.popup_desc
                } < /div> <
                div > {
                    this.chatpotParams.popup_cta.map((value, key) => {
                        return <div className = {
                            "endChatbutton"
                        }
                        key = {
                            key
                        }
                        onClick = {
                            this.buttonClick.bind(this, value)
                        } > {
                            value.cta_text
                        } < /div>
                    })
                } < /div>

                <
                /div> :null)
            }
        }

        const mapDispatchToProps = dispatch => ({
            closeChat: () => dispatch(closeChat()),
            setIntialStateValue: () => dispatch(setIntialStateValue()),
            showEndChatConfirmation: (data) => dispatch(showEndChatConfirmation(data)),
            showOverLay: (data) => dispatch(showOverLay(data))
        })

        const mapStateToProps = (state) => {
            return {
                state
            }
        }

        export default connect(mapStateToProps, mapDispatchToProps)(WebPopup)