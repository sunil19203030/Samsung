import React from 'react';
import './style.css';
import startIcon from '../assets/starIcon.png';
import selectedStartIcon from '../assets/selected_star_icon.png';
import * as NetworkHelper from '../Util/NetworkHelper';


export default class Rating extends React.Component {
        constructor(props) {
            super(props);

            this.state = {
                "selectedStar": -1,
                "starSelected": false
            }
        }

        handleRatingClick(value) {
            if (!this.state.starSelected) {
                NetworkHelper.buildRequestToSend('event', (value.postback ? value.postback : ""), NetworkHelper.getUserInfo(), {})
                this.setState({
                    selectedStar: value["index"],
                    starSelected: true
                });
            }
        }
        render() {
            return ( < div className = "rating-start-containerdiv" > {
                    this.props.option.map((value, index) => {
                        let objValue = {
                            index: index,
                            postback: value["postback"]
                        }
                        if (index <= this.state.selectedStar) {
                            return <div className = "rating-star"
                            key = {
                                index
                            } > < img src = {
                                selectedStartIcon
                            }
                            alt = "img is missing" / > < /div>
                        } else {
                            return <div className = "rating-star"
                            key = {
                                index
                            } > < img src = {
                                startIcon
                            }
                            onClick = {
                                this.handleRatingClick.bind(this, objValue)
                            }
                            alt = "img is missing" / > < /div>
                        }


                    })
                } < /div>);
            }


        }