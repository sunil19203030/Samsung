import React from 'react'
import Footer from '../Footer';
import Header from '../Header';
import Websocket from '../Websocket';
import ChatClientList from '../ChatClientList';
import ChatClientDetailsForm from '../ChatClientDetailsForm';
import ChatClientCallback from '../ChatClientCallback';
import Messager from '../Messager';
import {
    connect
} from 'react-redux';
import {
    updatechatbotparams,
    callbackTime,
    storeChatHistory
} from '../actions/action';
import Constants from '../Resources/Constants';
import * as NetworkLib from '../Util/NetworkLib';
import * as NetworkHelper from '../Util/NetworkHelper';
import * as utils from '../Util/Util';

import './style.css';



class ChatClientWidget extends React.Component {

        constructor(props) {
            super(props)
            this.state = {
                chatparam: this.props.params,
                listView: true,
                detailsView: false,
                callbackView: false,
                phone: '',
                email: '',
                name: '',
                isPhoneValid: false,
                isEmailValid: false,
                startChat: false,
                isCallbackSelected: false,
                time: '',
                isPartnerChat: false,
                isAgentCheck: false,
                emailExists: '',
                phoneExists: ''
            };

            if (props.state && props.state.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }

        componentDidMount() {
            this.props.updatechatbotparams(this.props.params);
            let userInfo = NetworkHelper.getUserInfo();
            let appType = userInfo['app-type']
            let isPartner = Constants.PARTNER_CHAT.includes(appType)
            this.setState({
                isPartnerChat: isPartner
            })
            let updatedState = { ...this.state.chatparam
            }
            if (updatedState.chatbotInitParams) {
                updatedState.chatbotInitParams.entry = ''
            }
            this.setState({
                chatparam: updatedState,
                isAgentCheck: true
            }, () => {
                this.props.updatechatbotparams(this.state.chatparam);
            })
        }

        componentWillReceiveProps(nextProps) {
            this.setState({
                userObj: nextProps.params.userobj
            });
        }

        handlePurchaseFlow = (e) => {
            this.setState({
                listView: false,
                detailsView: true,
                callbackView: false,
                startChat: false
            })
        }

        showCallbackView = (e) => {
            this.setState({
                listView: false,
                detailsView: false,
                callbackView: true
            })
        }

        handlePhoneInput = (e) => {
            let regexp = /^[0-9\b]+$/
            let telephone = e.target.value;
            if (telephone === '' || regexp.test(telephone)) {
                this.setState({
                    phone: e.target.value
                }, () => {
                    let MOBILEREGX = /^[1-9][0-9]{9}$/
                    if (MOBILEREGX.test(this.state.phone)) {
                        this.setState({
                            isPhoneValid: true
                        })
                    } else {
                        this.setState({
                            isPhoneValid: false
                        })
                    }
                })
            } else {
                e.preventDefault();
            }


        }

        handleEmailInput = (e) => {
            let emailRegex = /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i
            this.setState({
                email: e.target.value
            }, () => {
                if (emailRegex.test(this.state.email)) {
                    this.setState({
                        isEmailValid: true
                    })
                } else {
                    this.setState({
                        isEmailValid: false
                    })
                }
            })
        }

        handleNameInput = (e) => {
            this.setState({
                name: e.target.value
            })
        }

        onFormSubmit = (e) => {
            let user = {}
            for (var prop in this.props.params.userobj) {
                user[prop] = this.props.params.userobj[prop];
            }
            if (this.state.email) {
                user['email'] = this.state.email
            }
            if (this.state.name) {
                user['full-name'] = this.state.name
            }
            if (this.state.phone) {
                user['phone-number'] = this.state.phone
            }
            NetworkHelper.setUserInfo(user)
            this.setState({
                startChat: true
            })
        }

        renderCheckWebSocket = () => {

            return ( <
                Websocket ref = {
                    (ref) => {
                        this.ws = ref
                    }
                }
                url = {
                    this.props.socketUrl
                }
                onOpen = {
                    () => {
                        NetworkLib.onOpen(this.ws)
                    }
                }
                onMessage = {
                    (data) => {
                        this.onMessage(data)
                    }
                }
                onError = {
                    (evt) => NetworkLib.onError(evt)
                }
                onClose = {
                    (evt) => NetworkLib.onClose(evt)
                }
                reconnect = {
                    true
                }
                />
            )
        }

        renderWebSocket = () => {

            return ( <
                Websocket ref = {
                    (ref) => {
                        this.ws = ref
                    }
                }
                url = {
                    this.props.socketUrl
                }
                onOpen = {
                    () => {
                        NetworkLib.onOpen(this.ws)
                    }
                }
                onMessage = {
                    (data) => {
                        NetworkLib.onMessage(data)
                    }
                }
                onError = {
                    (evt) => NetworkLib.onError(evt)
                }
                onClose = {
                    (evt) => NetworkLib.onClose(evt)
                }
                reconnect = {
                    true
                }
                />
            )
        }

        onMessage = (data) => {
            let responseMessage = JSON.parse(data);
            let validUser, validPhone, validName;
            if (data) {
                this.props.storeChatHistory(data)
            }
            NetworkHelper.processIncomingResponse(responseMessage)
            if (responseMessage.type && responseMessage.type === 'history') {
                if (responseMessage && responseMessage.params && responseMessage.params.history && responseMessage.params.history[0]) {
                    const lastMsgHistory = responseMessage.params.history[0]
                    let originalHistoryData = JSON.parse(JSON.stringify(lastMsgHistory));
                    console.log('originalHistoryData', originalHistoryData)
                    let botObj = originalHistoryData && originalHistoryData.params && originalHistoryData.params.bot;
                    if (botObj && botObj.active_agent_session) {
                        utils.setActiveLiveAgentStatus(true)
                    }
                    let userData = originalHistoryData && originalHistoryData.params && originalHistoryData.params.user
                    validUser = userData && userData['email'] && userData['email'] != 'tempuser@temp.com' ? userData['email'] : ''
                    validPhone = userData && userData['phone-number']
                    validName = userData && userData['full-name']
                    if (validUser) {
                        this.setState({
                            emailExists: userData['email']
                        })
                    }
                    if (validPhone) {
                        this.setState({
                            phoneExists: userData['phone-number']
                        })
                    }
                }
                console.log('utils.getActiveLiveAgentStatus()', utils.getActiveLiveAgentStatus())
            }
            if (utils.getActiveLiveAgentStatus() && validUser && validPhone) {
                let userInformation = {}
                for (var prop in this.props.params.userobj) {
                    userInformation[prop] = this.props.params.userobj[prop];
                }
                if (validUser) {
                    userInformation['email'] = validUser
                }
                if (validName) {
                    userInformation['full-name'] = validName
                }
                if (validPhone) {
                    userInformation['phone-number'] = validPhone
                }
                NetworkHelper.setUserInfo(userInformation)
                let updatedState = { ...this.state.chatparam
                }
                if (updatedState.chatbotInitParams) {
                    updatedState.chatbotInitParams.entry = Constants.INITIATE_ACTION
                }
                NetworkHelper.setStarOverCompleted(false)
                this.setState({
                    chatparam: updatedState,
                    startChat: true,
                    isAgentCheck: false,
                    listView: false,
                }, () => {
                    this.props.updatechatbotparams(this.state.chatparam);
                })
            } else {
                let updatedState = { ...this.state.chatparam
                }
                if (updatedState.chatbotInitParams) {
                    updatedState.chatbotInitParams.entry = Constants.INITIATE_ACTION
                }
                NetworkHelper.setStarOverCompleted(false)
                this.setState({
                    chatparam: updatedState,
                    startChat: false,
                    isAgentCheck: false
                }, () => {
                    this.props.updatechatbotparams(this.state.chatparam);
                })
            }
        }


        schedulingCallback(timeSlot) {
            let user = {}
            for (var prop in this.props.params.userobj) {
                user[prop] = this.props.params.userobj[prop];
            }
            if (this.state.email) {
                user['email'] = this.state.email
            }
            if (this.state.name) {
                user['full-name'] = this.state.name
            }
            if (this.state.phone) {
                user['phone-number'] = this.state.phone
            }
            NetworkHelper.setUserInfo(user)
            let updatedState = { ...this.state.chatparam
            }
            if (updatedState.chatbotInitParams) {
                updatedState.chatbotInitParams.entry = Constants.CALLBACK_ACTION
            }
            this.setState({
                chatparam: updatedState,
                isCallbackSelected: true,
                time: timeSlot
            }, () => {
                this.props.updatechatbotparams(this.state.chatparam);
                this.props.callbackTime(this.state.time);
            })
        }

        callbackEight = (e) => {
            this.schedulingCallback('8AM-10AM')
        }

        callbackTen = () => {
            this.schedulingCallback('10AM-12Noon')
        }

        callbackTwelve = () => {
            this.schedulingCallback('12Noon-2PM')
        }

        callbackTwo = () => {
            this.schedulingCallback('2PM-4PM')
        }

        callbackFour = () => {
            this.schedulingCallback('4PM-6PM')
        }

        callbackSix = () => {
            this.schedulingCallback('6PM-8PM')
        }

        callbackFromChat = () => {
            NetworkHelper.setStarOverCompleted(false)
            this.setState({
                listView: false,
                detailsView: false,
                callbackView: true,
                startChat: false
            })
        }

        callbackFromEmptyChat = () => {
            NetworkHelper.setStarOverCompleted(false)
            this.setState({
                listView: false,
                detailsView: true,
                callbackView: false,
                startChat: false
            })
        }

        render() {
                const theme = this.props.state && this.props.state.theme ? this.props.state.theme : ''
                let userInfo = {}
                let data = this.state;
                if (data.phone && data.isPhoneValid) {
                    userInfo.phone = data.phone
                }
                if (data.email && data.isEmailValid) {
                    userInfo.email = data.email
                }
                if (data.name) {
                    userInfo.name = data.name
                }
                let userInfoAvailable = (data.phoneExists || userInfo.phone) && (data.emailExists || userInfo.email)
                return (

                        <
                        div className = {
                            `widget-container widget-container${theme}`
                        } >
                        <
                        div className = "conversation-container" >

                        {
                            this.props.isHeaderRequired === "true" || this.props.isHeaderRequired === true ? < Header isMinimizeRequired = {
                                this.props.isMinimizeRequired
                            }
                            isCloseRequired = {
                                this.props.isCloseRequired
                            }
                            headerTitle = {
                                this.props.headerTitle
                            }
                            /> : null} {
                                this.state.startChat && userInfoAvailable ? < Messager params = {
                                    this.state.chatparam
                                }
                                userData = {
                                    userInfo
                                }
                                isHeaderRequired = {
                                    this.props.isHeaderRequired
                                }
                                chatCallback = {
                                    this.callbackFromChat
                                }
                                emptyUserCallback = {
                                    this.callbackFromEmptyChat
                                }
                                socketUrl = {
                                    this.props.socketUrl
                                }
                                /> : null } {
                                    this.state.startChat && userInfoAvailable ? < Footer
                                    sendMessage = {
                                        this.props.sendMessage
                                    }
                                    placeholder = {
                                        "Message Samsung"
                                    }
                                    disabledInput = {
                                        this.props.disabledInput
                                    }
                                    /> : null } {
                                        (this.state.startChat && !userInfoAvailable) || (!this.state.startChat && !this.state.isPartnerChat && this.state.listView) ? < ChatClientList onPurchaseClicked = {
                                            this.handlePurchaseFlow
                                        }
                                        /> : null }  {
                                            !this.state.startChat && (this.state.detailsView || this.state.isPartnerChat) ?
                                                <
                                                ChatClientDetailsForm
                                            phone = {
                                                this.state.phone
                                            }
                                            email = {
                                                this.state.email
                                            }
                                            name = {
                                                this.state.name
                                            }
                                            isPhoneValid = {
                                                this.state.isPhoneValid
                                            }
                                            isEmailValid = {
                                                this.state.isEmailValid
                                            }
                                            handlePhoneChange = {
                                                this.handlePhoneInput
                                            }
                                            handleEmailChange = {
                                                this.handleEmailInput
                                            }
                                            handleNameChange = {
                                                this.handleNameInput
                                            }
                                            handleSubmit = {
                                                this.onFormSubmit
                                            }
                                            showCallback = {
                                                this.showCallbackView
                                            }
                                            isPartner = {
                                                this.state.isPartnerChat
                                            }
                                            /> : null }  {
                                                !this.state.startChat && this.state.callbackView ?
                                                    <
                                                    ChatClientCallback
                                                callbackEight = {
                                                    this.callbackEight
                                                }
                                                callbackTen = {
                                                    this.callbackTen
                                                }
                                                iscallbackSelected = {
                                                    this.state.isCallbackSelected
                                                }
                                                selectedSlot = {
                                                    this.state.time
                                                }
                                                callbackTwelve = {
                                                    this.callbackTwelve
                                                }
                                                callbackTwo = {
                                                    this.callbackTwo
                                                }
                                                callbackFour = {
                                                    this.callbackFour
                                                }
                                                callbackSix = {
                                                    this.callbackSix
                                                }
                                                /> : null } {
                                                    this.state.isCallbackSelected ? < div ref = {
                                                        (ref) => {
                                                            this.socketParentNode = ref
                                                        }
                                                    } > {
                                                        this.renderWebSocket()
                                                    } < /div> : null } {
                                                        this.state.isAgentCheck ? < div ref = {
                                                                (ref) => {
                                                                    this.socketCheckParentNode = ref
                                                                }
                                                            } > {
                                                                this.renderCheckWebSocket()
                                                            } < /div> : null } <
                                                            /div> <
                                                            /div>

                                                    );
                                                }

                                            }



                                            const mapStateToprops = (state) => ({
                                                state
                                            })

                                            const mapDispatchToProps = dispatch => ({
                                                updatechatbotparams: (chatbotparam) => dispatch(updatechatbotparams(chatbotparam)),
                                                callbackTime: (time) => dispatch(callbackTime(time)),
                                                storeChatHistory: (data) => dispatch(storeChatHistory(data))

                                            })

                                            export default connect(mapStateToprops, mapDispatchToProps)(ChatClientWidget);