import React from "react";
import * as NetworkHelper from '../Util/NetworkHelper';
import * as NetworkLib from '../Util/NetworkLib';
import * as utils from '../Util/Util';
import {
    connect
} from 'react-redux';
import {
    showContextChangeConfirmation,
    updatechatbotparams
} from '../actions/action';
import './style.css';


class ContextChangeConfirmation extends React.Component {
        constructor(props) {
            super(props)
            console.log(props)

        }

        componentDidMount() {
            this.props.hideLoader(true);
        }
        buttonClick(event) {
            if (event.target && event.target.innerHTML && event.target.innerHTML.toLowerCase().trim() === "continue") {
                let previousEntry = utils.getPreviousEntry();
                let requestData = JSON.parse(this.props.requestData);
                let userInfo = NetworkHelper.getUserInfo();

                let chatbotparams = this.props.chatbotparams;
                if (userInfo && userInfo["app-type"] && userInfo["reporting"]) {
                    userInfo.reporting[userInfo["app-type"]]["bot_entry"] = previousEntry;
                    NetworkHelper.setUserInfo(userInfo);
                }
                chatbotparams.chatbotInitParams["entry"] = previousEntry;
                chatbotparams.userobj.reporting[chatbotparams.userobj["app-type"]]["bot_entry"] = previousEntry;
                this.props.updatechatbotparams(chatbotparams);
                if (requestData && requestData.params && requestData.params.msg) {
                    requestData.params.msg = previousEntry;
                }
                if (requestData && requestData.params && requestData.params.user && requestData.params.user["app-type"] && requestData.params.user.reporting) {
                    requestData.params.user.reporting[requestData.params.user["app-type"]]["bot_entry"] = previousEntry;
                }
                NetworkHelper.prepareAndCallgetMenu(previousEntry);
                NetworkLib.getSocketRef().send(JSON.stringify(requestData));
            } else {
                utils.setPreviousEntry(this.props.chatbotparams.chatbotInitParams["entry"]);
                let newBot = {};
                newBot["session_ended"] = true;
                NetworkHelper.setMessageBot(newBot);
                NetworkHelper.buildRequestToSend('event', 'initiate_chat', NetworkHelper.getUserInfo());
                NetworkHelper.prepareAndCallgetMenu(utils.getPreviousEntry());
            }
            let data = {
                "requestData": {},
                "isContiueChatConfirmation": false
            }
            this.props.showContextChangeConfirmation(data);

        }


        render() {
            return ( < div className = "context-continue-chat-backdropStyle" >
                <
                div className = "context-continue-chat-modalStyle" >

                <
                div className = "context-continue-chat-content" >
                <
                div className = "context-continue-chat-modal-message" > {
                    "Would you like to continue where we left off or start over?"
                } < /div> <
                /div>

                <
                div className = "context-continue-chat-footer" >
                <
                div className = "context-continue-chat-footer-content"
                onClick = {
                    this.buttonClick.bind(this)
                } >
                <
                div className = "context-continue-chat-startover" > {
                    "START OVER"
                } < /div> <
                div className = "context-continue-chat-continue" > {
                    "CONTINUE"
                } < /div>

                <
                /div> <
                /div> <
                /div> <
                /div>)
            }
        }




        const mapDispatchToProps = dispatch => ({
            showContextChangeConfirmation: (data) => dispatch(showContextChangeConfirmation(data)),
            updatechatbotparams: (data) => dispatch(updatechatbotparams(data))
        })

        const mapStateToProps = (state) => {
            return {
                requestData: state.requestData,
                chatbotparams: state.chatbotparams
            }
        }

        export default connect(mapStateToProps, mapDispatchToProps)(ContextChangeConfirmation)