import React from 'react';
import {
    connect
} from 'react-redux';
import './style.css';
import Constants from '../Resources/Constants';

class PopupModal extends React.Component {
    constructor(props) {
        super(props);

        if (props.theme === Constants.THEME_MEMBERS) {
            require('./style_members.css')
        }
    }

    handleClick() {
        this.props.onPopupSubmit(this.props.popupObj.popup_cta[1].payload);
    }

    render() {
        const theme = this.props.theme ? this.props.theme : ''
        return ( <
            div className = "popupBackdropStyle" >
            <
            div className = {
                `popupModalStyle popupModalStyle${theme}`
            } >
            <
            div className = {
                `popupHeaderModal popupHeaderModal${theme}`
            } > {
                this.props.popupObj.popup_title
            } <
            /div> <
            div className = {
                `popupModal-content popupModal-content${theme}`
            } > {
                this.props.popupObj.popup_desc
            } <
            /div>

            <
            div className = "popupFooter" >
            <
            div className = {
                `popupFooter-content popupFooter-content${theme}`
            } >
            <
            div className = {
                `button1 button1${theme}`
            }
            onClick = {
                this.props.onClose
            } > {
                (this.props.popupObj && this.props.popupObj.popup_cta && this.props.popupObj.popup_cta[0] ? this.props.popupObj.popup_cta[0].cta_text : "")
            } < /div><div className={`button2 button2${theme}`} onClick={this.handleClick.bind(this)}>{this.props.popupObj&&this.props.popupObj.popup_cta&&this.props.popupObj.popup_cta[1]?this.props.popupObj.popup_cta[1].cta_text:""}</div >
            <
            /div> <
            /div> <
            /div> <
            /div>
        );
    }
}


const mapStateToProps = (state) => {
    return {
        theme: state.theme
    }
}

export default connect(mapStateToProps)(PopupModal)