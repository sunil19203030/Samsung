import React from 'react';
import ReactDOM from 'react-dom';
import Websocket from '../Websocket';
import Parser from 'html-react-parser';

import {
    connect,
    Provider
} from 'react-redux';
import {
    buttonSend,
    onNetworkErrorSuccess,
    setSurveyStatus,
    setIntialStateValue,
    showLoader
} from '../actions/action';



import * as utils from '../Util/Util';

import * as NetworkLib from '../Util/NetworkLib';
import * as NetworkHelper from '../Util/NetworkHelper';


import InforCard from '../InfoCard/index';
import Modal from '../Modal';
import Overlay from '../Overlay'
import Survey from '../Survey';
import Bubble from '../Bubble';
import PillButtons from '../PillButtons';
import CardMenu from '../CardMenu';
import Ribbon from '../Ribbon';
import ErrorSnackbar from '../ErrorSnackbar';
import DateRibbon from '../DateRibbon';
import * as moment from "moment";
import Rating from '../Rating';
import Avator from '../Avator';
import Delay from '../Delay';
import WebPopup from '../WebPopup';
import EndChatConfirmation from '../EndChatConfirmation';
import ContextChangeConfirmation from '../ContextChangeConfirmation';
import {
    Store
} from '../store/store';
import Constants from '../Resources/Constants';





import './style.css';



let user = {

}

/* for smooth scrolling we need to use this*/
let scrollTimeDealy = 500;



class Messager extends React.Component {
        constructor(props) {
            super(props)
            this.state = {
                userObj: this.props.params.userobj,
                isError: false,
                errorMessage: "",
                escalation_status: "",
                escalatin_status_message: "",
                isDialogOpen: true,
                isShowArticleContent: false,
                renderSocket: true,
                tabSwitch: false
            }
            this.renderTagsHTML = [];
            this.historyDomNode = [];
            this.escalationDivRendered = false;
            this.isConnectedWithAgent = false;
            this.isSurveyPage = false;
            this.isSurveyDialog = false;
            this.isLoaderShown = false;
            this.article_Url = "";
            this.articleContent = "";
            this.isforceUpdate = false;
            this.NetworkFailureSubmitMessage = "";
            this.onScroll = false;
            this.isHistoryPresent = false;
            this.topMessage = "";
            this.historyDate = "";
            this.historyDateIndex = -1;
            this.componentCleanup = this.componentCleanup.bind(this);
            this.onScrollMethod = this.onScrollMethod.bind(this);
            this.historyDateObj = {};
            this.showloader = false;
            this.renderDomNode = null;
            this.isEnableLaoder = false;

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }
        componentCleanup() {
            NetworkHelper.submitSurvey(true);
            this.ws.state.ws.close();
            this.ws.state.ws.onclose = () => {
                console.log("forcefully socket closing")
            }

        }
        componentDidMount() {
            window.addEventListener('beforeunload', this.componentCleanup);
            let timerInterval = setInterval(() => {
                if (document.getElementById('MessageDiv')) {
                    var messagesElement = document.getElementById('MessageDiv');
                    var menuElement = document.getElementsByClassName('menuunsel-icon');
                    var senderMainDiv = document.getElementsByClassName('senderMainDiv')[0];
                    var menuClick = false,
                        delayParam = 0;
                    window.onresize = (event) => {
                        if (document.getElementsByClassName("survey_main_div").length === 0) {
                            this.addSpace(messagesElement, senderMainDiv);
                        }
                    }
                    menuElement[0].onclick = e => {
                        menuClick = menuClick ? false : true;
                        delayParam = menuClick ? null : 300;
                        window.setTimeout(() => {
                            this.addSpace(messagesElement, senderMainDiv);
                            delayParam = 0;
                        }, delayParam);
                    }

                    const scroller = this.getScroller()
                    scroller.addEventListener('wheel', this.onScrollMethod)

                    clearInterval(timerInterval)
                }

            }, 1000)
        }

        chatCallback = () => {
            this.props.chatCallback()
        }

        emptyUserCallback = () => {
            this.props.emptyUserCallback()
        }

        componentWillUnmount() {
            this.componentCleanup();
            window.removeEventListener('beforeunload', this.componentCleanup); // remove the event handler for normal unmounting
            window.removeEventListener("resize", this.handleResize);

            const scroller = this.getScroller()
            scroller.removeEventListener('wheel', this.onScrollMethod)
        }
        componentWillReceiveProps(props) {
            if (props.params) {
                /* let validateResponse = utils.validateParams(props.params.chatbotInitParams);
                 if (!validateResponse["isValid"]) {
                     this.setState({ isError: true, errorMessage: validateResponse["message"] });
                 }*/
            }

            if (props.history_data && props.history_data.length > 0 && this.messagerList && this.messagerList.childNodes[1] && this.messagerList.childNodes[1].childNodes[1]) {
                this.topMessage = this.messagerList.childNodes[1].childNodes[1];
            } else {
                this.topMessage = "";
            }
            /*
            if (props.chatbotparams != null && props.chatbotparams.chatbotInitParams != null && props.chatbotparams.chatbotInitParams.isChatsessionExists === true) {
                document.getElementsByClassName("senderMainDiv")[0].style.display = "none";
            }*/
            if ((props.message && props.chatbotparams && props.message.length > 0) || (props.close_chatdata != null || props.isEndChatConfirmation) || (props.options != null) || (props.escalation_status) || (props.surveyinfo) || (props.history_data && props.history_data.length > 0) || (props.isShowoverlay)) {
                let renderDom = this.handleMessagerUpdate(props);
                if (renderDom != null) {
                    this.renderTagsHTML.push(renderDom)
                }
            }
            if ((props.message && props.chatbotparams && props.message.length > 0) || (props.close_chatdata != null || props.isEndChatConfirmation) || (props.options != null) || (props.escalation_status) || (props.surveyinfo)) {
                this.isEnableLaoder = true;
            }
            if (props.isHideLoader && !props.show_loader) {
                this.isEnableLaoder = false;
            } else if (props.show_loader) {
                this.isEnableLaoder = true;
            } else {
                this.hideLoader();
            }

            if (this.props.isCloseChatWindow || this.props.isClearDomNode) {
                this.renderTagsHTML = [];

            }


        }


        componentDidUpdate(props) {


            //this code is commiting because each component scroll to bottom is doing*/
            /*if (props.message && props.chatbotparams && props.message.length > 0 || props.options != null || props.escalation_status) {
                if (props.options != null) {
                    setTimeout(() => {
                       //utils.smooth_scroll_to(this.messagerList, this.messagerList.scrollHeight, scrollTimeDealy)
                        //let messageList = utils.getMessagerNodeRef().childNodes[1];
                        //(this.messagerList.childNodes[1].childNodes.length > 1 ? ReactDOM.findDOMNode(messageList.childNodes[messageList.childNodes.length - 1]).scrollIntoView() : null);
                    }, 1500)
                } if (props.message[0] && props.message[0]["component"] === "Card") {
                    setTimeout(() => {
                    // utils.smooth_scroll_to(this.messagerList, this.messagerList.scrollHeight, scrollTimeDealy)
                        //let messageList = utils.getMessagerNodeRef().childNodes[1];
                        //(this.messagerList.childNodes[1].childNodes.length > 1 ? ReactDOM.findDOMNode(messageList.childNodes[messageList.childNodes.length - 1]).scrollIntoView() : null);
                    }, 2000)
                } else {

                  //utils.smooth_scroll_to(this.messagerList, this.messagerList.scrollHeight, scrollTimeDealy)
                    // let messageList = utils.getMessagerNodeRef().childNodes[1];
                    //(this.messagerList.childNodes[1].childNodes.length > 1 ? ReactDOM.findDOMNode(messageList.childNodes[messageList.childNodes.length - 1]).scrollIntoView() : null);
                }
            } else*/
            if (this.isHistoryPresent && this.topMessage !== "" && this.topMessage != null && !this.props.show_loader) {
                ReactDOM.findDOMNode(this.topMessage).scrollIntoView(false);
            }

            utils.setMessagerNodeRef(this.messagerList);
            let messageHeight = this.getHeightForMessageDiv();
            if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > -1) {
                messageHeight = messageHeight - 10;
            }
            utils.getMessagerNodeRef().style.height = messageHeight + "px";
            /*when history is not present showloader in bottom*/
            if (this.props.show_loader && this.props.history_data == null) {
                if (document.getElementsByClassName("loader-container-messageLoader").length > 0) {
                    ReactDOM.findDOMNode(document.getElementsByClassName("loader-container-messageLoader")[0].childNodes[2]).scrollIntoView(false)
                }
            } else if ((props.message && props.chatbotparams && props.message.length > 0) || props.options != null || props.escalation_status) {
                if (document.getElementsByClassName("loader-container-messageLoader")[0]) {
                    document.getElementsByClassName("loader-container-messageLoader")[0].style.visibility = "hidden"
                }
            } else if (utils.getisHistory() || this.props.isShowKeyboard || typeof this.props.close_chatdata === "undefined") {
                this.hideLoader();
            }

            let messageList = utils.getMessagerNodeRef() && utils.getMessagerNodeRef().childNodes[1];
            if (messageList && messageList.childNodes) {
                let node = messageList.childNodes[messageList.childNodes.length - 1];
                if (node && node.childNodes[0]) {
                    let domNode = node.childNodes[0];
                    if (domNode && domNode.childNodes[0] && domNode.childNodes[0].className) {
                        if (domNode.childNodes[0].className.indexOf("escalationInitDiv") !== -1) {
                            this.hideLoader();
                        } else if (domNode.childNodes[0].className.indexOf("header_close_notification_div_child_div") !== -1) {
                            this.isEnableLaoder = true;
                        }
                    } else if (domNode && domNode.className && domNode.className.indexOf("pillButtons") !== -1) {
                        this.hideLoader();
                    }
                }
            }


        }


        getScroller() {
            return ReactDOM.findDOMNode(this.messagerList)
        }

        onScrollMethod(event) {
            const {
                currentTarget,
                deltaY
            } = event
            const {
                scrollTop,
                scrollHeight
            } = currentTarget
            if ((deltaY < 0 && scrollTop <= 0) || (deltaY > 0 && scrollTop >= scrollHeight - parseInt(getComputedStyle(currentTarget).height, 10))) {
                event.preventDefault()
            }
        }

        addSpace(messagesElement, senderMainDiv) {

            let messageHeight = this.getHeightForMessageDiv();
            if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > -1) {
                messageHeight = messageHeight - 10;
            }
            utils.getMessagerNodeRef().style.height = messageHeight + "px";
            if (document.activeElement.id === "textbox") {
                utils.smooth_scroll_to(this.messagerList, this.messagerList.scrollHeight, scrollTimeDealy)
            }
            if (window.innerHeight < 300) {
                if (document.getElementsByClassName("text-area")[0]) {
                    document.getElementsByClassName("text-area")[0].style.height = "20px"
                }
            } else {
                if (document.getElementsByClassName("text-area")[0]) {
                    document.getElementsByClassName("text-area")[0].style.height = "80px"
                }
            }
        }

        /*render the websocket connect */
        renderWebSocket = () => {

            return ( <
                Websocket ref = {
                    (ref) => {
                        this.ws = ref
                    }
                }
                url = {
                    this.props.socketUrl
                }
                onOpen = {
                    () => {
                        NetworkLib.onOpen(this.ws)
                    }
                }
                onMessage = {
                    (data) => {
                        NetworkLib.onMessage(data)
                    }
                }
                onError = {
                    (evt) => NetworkLib.onError(evt)
                }
                onClose = {
                    (evt) => NetworkLib.onClose(evt)
                }
                reconnect = {
                    true
                }
                />
            )


        }

        submitChatText(value) {
            this.props.buttonSend(value);
        }

        hideLoader() {
            if (document.getElementsByClassName("loader-container-messageLoader").length > 0) {
                document.getElementsByClassName("loader-container-messageLoader")[0].style.height = "0";
                document.getElementsByClassName("loader-container-messageLoader")[0].style.overflow = "hidden";
                document.getElementsByClassName("loader-container-messageLoader")[0].style.padding = "0";
            }

        }
        /*return true or false for show loader*/
        isShowLoader() {
            return (!utils.getisConnectedWithAgent() && ((this.isEnableLaoder && (this.props.message[0] && this.props.message[0].component !== "NetWorkError" && this.props.message[0].component !== "FromServer")) || ((utils.getisSocketConnected() && this.isEnableLaoder))));
        }

        /*check whether need to show networksnack bar or not*/
        isShowErrorSnackBar() {
            return (this.props.message[0] && this.props.message[0].component === "NetWorkError") || !utils.getisSocketConnected()
        }


        /*it will show the survey page */
        toggleModal = () => {
            this.isSurveyDialog = false;
            this.surveyDOM.style.display = "block";
            this.props.setSurveyStatus(true)
            document.getElementById("MessageDiv").classList.remove("containerOverlay")
            document.getElementsByClassName("backdropStyle")[0].parentNode.removeChild(document.getElementsByClassName("backdropStyle")[0]);
            setTimeout(() => {
                ReactDOM.render( < Provider store = {
                        Store
                    } > < Survey key = {
                        Math.round(Math.random() * 1000000)
                    }
                    passChatbotInitParams = {
                        this.props.params.chatbotInitParams
                    }
                    callSocket = {
                        this.socketReconnect.bind(this)
                    }
                    /></Provider > , this.surveyDOM);
            }, 500);
        }






        checkSocketStateSendFailureMessage = () => {
            this.timerInterval = setInterval(() => {
                if (this.ws.state.ws.readyState === 1) {
                    this.ws.setupWebsocket();
                    NetworkLib.updateSocketRef(this.ws.state.ws);
                    clearInterval(this.timerInterval);
                    NetworkLib.sendFailureMessage();

                }
            }, 1000);

        }

        /*callcaluate height for message div*/
        getHeightForMessageDiv = () => {
            let height = document.getElementsByClassName("widget-container")[0].offsetHeight -
                document.getElementsByClassName("senderMainDiv")[0].offsetHeight;
            if (document.getElementsByClassName("header").length > 0) {
                height = height - document.getElementsByClassName("header")[0].offsetHeight;
            }
            if (document.getElementsByClassName("error-snackbar-parentdiv") && document.getElementsByClassName("error-snackbar-parentdiv").length > 0) {
                height = height - document.getElementsByClassName("error-snackbar-parentdiv")[0].offsetHeight;
            }
            return height;
        }


        /*when click reconnect socket is ready state this method will call*/
        socketReconnect = () => {
            if (utils.getisNetworkConnected()) {
                this.ws.reconnectSocket();
                let submitMessageArray = utils.getSubmitTextMessageBeforeSend();
                utils.setisSocketConnected(true);
                let messages = [];
                NetworkLib.updateSocketRef(this.ws.state.ws);
                for (let i = 0; i < submitMessageArray.length; i++) {
                    let data = submitMessageArray[i];
                    if (data != null && data.msg) {
                        let msg = JSON.parse(data.msg).params.text;
                        if (!JSON.parse(data.msg).params.drawerMenu && msg !== "initiate_chat" && msg.length > 0) {
                            messages.push(msg);
                        }

                    }
                }
                this.props.onNetworkErrorSuccess(messages);
                this.checkSocketStateSendFailureMessage();
                setTimeout(() => {
                    let messageHeight = this.getHeightForMessageDiv();
                    if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > -1) {
                        messageHeight = messageHeight - 10;
                    }
                    utils.getMessagerNodeRef().style.height = messageHeight + "px";

                }, 100);
            } else {
                document.getElementsByClassName("speech-bubblefailure")[0].parentElement.style.display = "none";
                setTimeout(() => {
                    document.getElementsByClassName("speech-bubblefailure")[0].parentElement.style.display = "block";
                }, 500)
            }
        }


        /*when user click like pillbutton card it will draw the bubble*/
        renderUserSelection(selectedText, isPillButton) {
                let message = [{
                    message: [selectedText],
                    component: "sender"
                }];
                if (isPillButton) {
                    this.renderTagsHTML.pop();
                }
                this.removeExistingNode();
                this.isEnableLaoder = true;
                this.renderTagsHTML.push( < Bubble key = {
                        Math.round(Math.random() * 1000000)
                    }
                    messageArray = {
                        message
                    }
                    msgType = {
                        message[0]["component"]
                    }
                    appType = {
                        this.props.chatbotparams.userobj["app-type"]
                    }
                    />);
                    this.forceUpdate(() => {
                        this.props.showLoader();
                    });

                }

                /*remove Existing Node*/
                removeExistingNode() {
                    if (this.renderTagsHTML[this.renderTagsHTML.length - 1] && this.renderTagsHTML[this.renderTagsHTML.length - 1].props && this.renderTagsHTML[this.renderTagsHTML.length - 1].props.buttonOptions) {
                        this.renderTagsHTML.pop();
                    }
                    if (this.renderTagsHTML[this.renderTagsHTML.length - 1] && this.renderTagsHTML[this.renderTagsHTML.length - 1].props.children && this.renderTagsHTML[this.renderTagsHTML.length - 1].props.children.props && this.renderTagsHTML[this.renderTagsHTML.length - 1].props.children.props.buttonOptions) {
                        this.renderTagsHTML.pop();
                    }
                    if (this.renderTagsHTML[this.renderTagsHTML.length - 1] && this.renderTagsHTML[this.renderTagsHTML.length - 1].props && this.renderTagsHTML[this.renderTagsHTML.length - 1].props.escalation_status === "initiated") {
                        this.renderTagsHTML.pop();
                    }

                }


                /*it will draw all the componenet based the type*/
                handleMessagerUpdate(props) {

                        // if chat open in other tab then show refresh button
                        if (props.escalation_status === "agent_on_new_window") {
                            //console.log(props.escalatin_status_message);
                            this.setState({
                                tabSwitch: true,
                                escalatin_status_message: props.escalatin_status_message
                            }, () => {
                                setTimeout(() => {
                                    this.refreshButtonRef.scrollIntoView();
                                }, 500);
                            })
                        }

                        let originatorInfo = utils.getOriginatorInfo();
                        if (props.message && props.chatbotparams && props.message.length > 0) {
                            if (props.message[0] && props.message[0].message[0] && props.message[0].message[0].length > 0) {
                                this.removeExistingNode();
                            }
                            if (props.message[0]["component"] === "Card") {
                                this.removeExistingNode();
                                return <Delay key = {
                                    Math.round(Math.random() * 1000000)
                                }
                                wait = {
                                    2000
                                } > < CardMenu key = {
                                    Math.round(Math.random() * 1000000)
                                }
                                hideLoader = {
                                    this.hideLoader.bind(this)
                                }
                                cardMenuArray = {
                                    props.message[0]
                                }
                                onHandleClick = {
                                    this.submitChatText.bind(this)
                                }
                                originatorInfo = {
                                    originatorInfo
                                }
                                appType = {
                                    props.chatbotparams.userobj["app-type"]
                                }
                                /></Delay >
                            } else if (props.message[0]["component"] === "InforCard") {
                                this.removeExistingNode();
                                return <Delay key = {
                                    Math.round(Math.random() * 1000000)
                                }
                                wait = {
                                    1000
                                } > < InforCard cardObj = {
                                    props.message[0]
                                }
                                hideLoader = {
                                    this.hideLoader.bind(this)
                                }
                                originatorInfo = {
                                    originatorInfo
                                }
                                appType = {
                                    props.chatbotparams.userobj["app-type"]
                                } > < /InforCard></Delay >
                            } else {
                                if (props.message[0]["component"] === "NetWorkError") {
                                    /*remove early rendered sender message draw the Error footer*/
                                    if (props.message[0].length > 0 && props.message[0].message[0].length > 0) {
                                        let arrayLength = this.renderTagsHTML.length;
                                        let messageLength = props.message[0].message.length;
                                        let startPositon = arrayLength - messageLength;
                                        for (let i = 0; i < props.message[0].message.length; i++) {
                                            let message = [{
                                                message: [props.message[0].message[i]],
                                                "component": props.message[0]["component"]
                                            }];
                                            this.renderTagsHTML[startPositon + i] = ( < Bubble key = {
                                                    Math.round(Math.random() * 1000000)
                                                }
                                                messageArray = {
                                                    message
                                                }
                                                msgType = {
                                                    props.message[0]["component"]
                                                }
                                                originatorInfo = {
                                                    originatorInfo
                                                }
                                                appType = {
                                                    props.chatbotparams.userobj["app-type"]
                                                }
                                                />);
                                            }
                                        }

                                        return null;
                                    }

                                    if (props.message[0]["component"] === "NetWorkSuccess") {
                                        /*remove early rendered sender message draw the Error footer*/
                                        if (props.message[0].message.length > 0 && props.message[0].message[0].length > 0) {
                                            let arrayLength = this.renderTagsHTML.length;
                                            let messageLength = props.message[0].message.length;
                                            let startPositon = arrayLength - messageLength;
                                            for (let i = 0; i < props.message[0].message.length; i++) {
                                                let message = [{
                                                    message: [props.message[0].message[i]],
                                                    "component": props.message[0]["component"]
                                                }];
                                                this.renderTagsHTML[startPositon + i] = ( < Bubble key = {
                                                        Math.round(Math.random() * 1000000)
                                                    }
                                                    messageArray = {
                                                        message
                                                    }
                                                    msgType = {
                                                        props.message[0]["component"]
                                                    }
                                                    originatorInfo = {
                                                        originatorInfo
                                                    }
                                                    appType = {
                                                        props.chatbotparams.userobj["app-type"]
                                                    }
                                                    />);
                                                }
                                            }

                                            return null;
                                        }

                                        return <Bubble key = {
                                            Math.round(Math.random() * 1000000)
                                        }
                                        hideLoader = {
                                            this.hideLoader.bind(this)
                                        }
                                        messageArray = {
                                            props.message
                                        }
                                        msgType = {
                                            props.message[0]["component"]
                                        }
                                        originatorInfo = {
                                            originatorInfo
                                        }
                                        appType = {
                                            props.chatbotparams.userobj["app-type"]
                                        }
                                        />
                                    }

                                }
                                /*just hide footer div during end chat ui showin
                                if (props.close_chatdata != null || props.isEndChatConfirmation) {
                                    document.getElementsByClassName("senderMainDiv")[0].style.display = "none";
                                }*/

                                if (props.options != null) {
                                    this.removeExistingNode();
                                    return <Delay key = {
                                        Math.round(Math.random() * 1000000)
                                    }
                                    wait = {
                                        1000
                                    } > < PillButtons key = {
                                        Math.round(Math.random() * 1000000)
                                    }
                                    hideLoader = {
                                        this.hideLoader.bind(this)
                                    }
                                    callbackFromChat = {
                                        this.chatCallback
                                    }
                                    emptyUserFromChat = {
                                        this.emptyUserCallback
                                    }
                                    buttonOptions = {
                                        props.options
                                    }
                                    ref = {
                                        (refs) => {
                                            this.pillbuttonNode = refs
                                        }
                                    }
                                    onHandleClick = {
                                        this.renderUserSelection.bind(this)
                                    }
                                    /></Delay >
                                }

                                /*once escalation initiated just draw ribbon. ribbon will monitor the all escalation status*/
                                if (props.escalation_status) {
                                    this.removeExistingNode();
                                    (props.escalation_status === "connected" || props.escalation_status === "resume" || props.escalation_status === "show_agent_helpful" ? utils.setisConnectedWithAgent(true) : utils.setisConnectedWithAgent(false));
                                    return <Ribbon key = {
                                        Math.round(Math.random() * 1000000)
                                    }
                                    hideLoader = {
                                        this.hideLoader.bind(this)
                                    }
                                    escalation_status = {
                                        props.escalation_status
                                    }
                                    escalatin_status_message = {
                                        props.escalatin_status_message
                                    }
                                    />
                                }

                                if (props.isShowoverlay) {
                                    if (this.renderTagsHTML[this.renderTagsHTML.length - 1] && this.renderTagsHTML[this.renderTagsHTML.length - 1].props && this.renderTagsHTML[this.renderTagsHTML.length - 1].props["className"] !== "Overlay_div") {
                                        this.renderTagsHTML.push( < div className = "Overlay_div" > < Overlay show = {
                                                true
                                            }
                                            /></div > );
                                    }
                                }

                                if (props.surveyinfo) {
                                    this.removeExistingNode();
                                    this.renderTagsHTML = this.renderTagsHTML.map((node, key) => {
                                        if ((node && node.props && node.props.show && node.props.children.props && node.props.children.props.show) || (node && node.props && node.props.className && node.props.className === "Overlay_div")) {
                                            return null;
                                        } else {
                                            return node;
                                        }
                                    });
                                    if (!Store.getState().survey_status) {
                                        this.isSurveyDialog = true;
                                        this.isSurveyPage = true;
                                        const theme = this.props.theme ? this.props.theme : ''
                                        this.renderTagsHTML.push( <
                                            Modal show = {
                                                this.isSurveyDialog
                                            }
                                            cta_text = {
                                                props.surveyinfo.cta_text ? props.surveyinfo.cta_text : "OKAY"
                                            }
                                            onClose = {
                                                this.toggleModal.bind(this)
                                            } >
                                            <
                                            div className = {
                                                `modal-message-header modal-message-header${theme}`
                                            } > {
                                                props.surveyinfo.title ? Parser(props.surveyinfo.title) : ""
                                            } < /div> <
                                            div className = {
                                                `modal-message modal-message${theme}`
                                            } > {
                                                props.surveyinfo.description ? Parser(props.surveyinfo.description) : ""
                                            } < /div> <
                                            /Modal>);
                                            document.getElementById("MessageDiv").classList.add("containerOverlay") utils.setSurveyObj(props.surveyinfo);
                                        }
                                    }

                                    if (props.rating_data) {
                                        this.removeExistingNode();
                                        let message = [{
                                            message: [props.rating_data[0].text],
                                            component: "FromServer"
                                        }];
                                        this.renderTagsHTML.push( < Bubble key = {
                                                Math.round(Math.random() * 1000000)
                                            }
                                            messageArray = {
                                                message
                                            }
                                            msgType = {
                                                message[0]["component"]
                                            }
                                            appType = {
                                                props.chatbotparams.userobj["app-type"]
                                            }
                                            />);
                                            return <Delay wait = {
                                                1000
                                            } > < Rating key = {
                                                Math.round(Math.random() * 1000000)
                                            }
                                            option = {
                                                props.rating_data[0].option
                                            }
                                            /></Delay >
                                        }

                                        /*itreate history and draw the history componenet*/
                                        if (props.history_data && props.history_data.length > 0) {


                                            let options = {
                                                weekday: 'long',
                                                year: 'numeric',
                                                month: 'long',
                                                day: 'numeric'
                                            };
                                            let messageList = utils.getMessagerNodeRef() && utils.getMessagerNodeRef().childNodes[1];
                                            let historyData = props.history_data;
                                            /* if (messageList && messageList.children.length !== 0) {
                                                historyData = historyData.reverse();
                                            }else if(historyData) {
                                                historyData = historyData.reverse();
                                            } */

                                            let tempHistoryData = [];
                                            for (var i = 0; i < historyData.length; i++) {
                                                let historyObj = historyData[i];
                                                let key = i;
                                                let obj = {};
                                                if (this.historyDate === "") {
                                                    obj["method"] = "Date";
                                                    if (moment(new Date()).isSame(historyObj.createdAt, 'date')) {
                                                        obj["createdAt"] = "TODAY";
                                                    } else {
                                                        obj["createdAt"] = historyObj.createdAt;
                                                    }
                                                    tempHistoryData.push(obj)
                                                    this.historyDate = historyObj.createdAt;
                                                    tempHistoryData.push(historyObj)
                                                } else {
                                                    if (historyData.length - 1 === key && messageList && messageList.children.length !== 0) {
                                                        obj["method"] = "Date";
                                                        if (moment(new Date()).isSame(historyObj.createdAt, 'date')) {
                                                            obj["createdAt"] = "TODAY";
                                                        } else {
                                                            obj["createdAt"] = historyObj.createdAt;
                                                        }
                                                        tempHistoryData.push(historyObj)
                                                        tempHistoryData.push(obj)

                                                        if (moment(historyObj.createdAt).isSame(this.historyDate, 'date')) {
                                                            this.renderTagsHTML.shift();
                                                        }
                                                        this.historyDate = historyObj.createdAt;
                                                    } else {
                                                        if (!moment(historyObj.createdAt).isSame(this.historyDate, 'date')) {
                                                            obj["method"] = "Date";
                                                            if (moment(new Date()).isSame(historyObj.createdAt, 'date')) {
                                                                obj["createdAt"] = "TODAY";
                                                            } else {
                                                                obj["createdAt"] = historyObj.createdAt;
                                                            }
                                                            tempHistoryData.push(obj)
                                                            tempHistoryData.push(historyObj)
                                                            if (moment(historyObj.createdAt).isSame(this.historyDate, 'date')) {
                                                                if (messageList && messageList.children.length !== 0) {
                                                                    this.renderTagsHTML.shift();
                                                                }
                                                            }
                                                            this.historyDate = historyObj.createdAt;
                                                        } else {
                                                            tempHistoryData.push(historyObj);
                                                        }

                                                    }
                                                }
                                            }
                                            tempHistoryData.map((historyObj, key) => {
                                                        let Historydate = historyObj.createdAt;

                                                        let isConnectedWithAgent;

                                                        if (historyObj.params && historyObj.params.originator && historyObj.params.originator !== "shopbot" && historyObj.params.originator !== "supportbot") {
                                                            isConnectedWithAgent = true;
                                                            utils.setisConnectedWithAgent(true);
                                                        } else {
                                                            isConnectedWithAgent = false;
                                                            utils.setisConnectedWithAgent(false);
                                                        }

                                                        if (historyObj["method"] === "Date") {
                                                            let DateHistoryComponent = < div key = {
                                                                Math.round(Math.random() * 1000000)
                                                            } > < DateRibbon key = {
                                                                Math.round(Math.random() * 1000000)
                                                            }
                                                            date = {
                                                                (Historydate !== "TODAY" ? Historydate.toLocaleDateString("en-US", options) : Historydate)
                                                            }
                                                            /></div > ;
                                                            if (messageList && messageList.children.length === 0) {
                                                                this.renderTagsHTML.push(DateHistoryComponent)
                                                            } else {
                                                                this.renderTagsHTML.unshift(DateHistoryComponent)
                                                            }
                                                        } else if (historyObj["buttons"] && historyObj["text"] != null) {
                                                            let bubbleText = historyObj["text"];
                                                            if (bubbleText) {
                                                                bubbleText = utils.unescapeHtmlEntities(bubbleText);
                                                            }
                                                            originatorInfo = (historyObj.params.originator_info ? historyObj.params.originator_info : historyObj.params.originator);
                                                            let message = {
                                                                text: bubbleText,
                                                                buttons: historyObj["buttons"],
                                                                "component": "InforCard",
                                                                "messageTime": historyObj.createdAt
                                                            };
                                                            let HistoryInfoCard = < InforCard cardObj = {
                                                                {
                                                                    message: [message]
                                                                }
                                                            }
                                                            hideLoader = {
                                                                this.hideLoader.bind(this)
                                                            }
                                                            originatorInfo = {
                                                                originatorInfo
                                                            }
                                                            appType = {
                                                                historyObj.params.user["app-type"]
                                                            }
                                                            Historydate = {
                                                                Historydate
                                                            } > < /InforCard>;
                                                            if (messageList && messageList.children.length === 0) {
                                                                this.renderTagsHTML.push(HistoryInfoCard);
                                                            } else {
                                                                this.renderTagsHTML.unshift(HistoryInfoCard)
                                                            }
                                                        } else if (historyObj["method"] === "message" && historyObj["text"] != null) {
                                                            let originatorInfo = "";
                                                            let bubbleText = historyObj["text"];
                                                            originatorInfo = (historyObj.params.originator_info ? historyObj.params.originator_info : historyObj.params.originator);
                                                            /*when live agent sending any tags just replacing lt to < and gt to >*/
                                                            if (bubbleText) {
                                                                bubbleText = utils.unescapeHtmlEntities(bubbleText);
                                                            }
                                                            let message = [{
                                                                message: utils.splitTag(bubbleText),
                                                                "component": "FromServer",
                                                                "messageTime": historyObj.createdAt
                                                            }];
                                                            if (messageList && messageList.children.length === 0) {
                                                                let historyBubble = < Bubble key = {
                                                                    Math.round(Math.random() * 1000000)
                                                                }
                                                                messageArray = {
                                                                    message
                                                                }
                                                                msgType = {
                                                                    message[0]["component"]
                                                                }
                                                                originatorInfo = {
                                                                    originatorInfo
                                                                }
                                                                isConnectedWithAgent = {
                                                                    isConnectedWithAgent
                                                                }
                                                                appType = {
                                                                    historyObj.params.user["app-type"]
                                                                }
                                                                Historydate = {
                                                                    Historydate
                                                                }
                                                                />;
                                                                if (bubbleText) {
                                                                    this.renderTagsHTML.push(historyBubble);
                                                                }
                                                                if (historyObj.card) {
                                                                    let HistorycardMenu = < CardMenu Historydate = {
                                                                        Historydate
                                                                    }
                                                                    key = {
                                                                        Math.round(Math.random() * 1000000)
                                                                    }
                                                                    cardMenuArray = {
                                                                        {
                                                                            "message": historyObj.card
                                                                        }
                                                                    }
                                                                    onHandleClick = {
                                                                        this.submitChatText.bind(this)
                                                                    }
                                                                    isConnectedWithAgent = {
                                                                        isConnectedWithAgent
                                                                    }
                                                                    originatorInfo = {
                                                                        originatorInfo
                                                                    }
                                                                    appType = {
                                                                        historyObj.params.user["app-type"]
                                                                    }
                                                                    />
                                                                    this.renderTagsHTML.push(HistorycardMenu)
                                                                }
                                                            } else {
                                                                if (historyObj.card) {
                                                                    this.renderTagsHTML.unshift( < CardMenu Historydate = {
                                                                            Historydate
                                                                        }
                                                                        key = {
                                                                            Math.round(Math.random() * 1000000)
                                                                        }
                                                                        cardMenuArray = {
                                                                            {
                                                                                "message": historyObj.card
                                                                            }
                                                                        }
                                                                        onHandleClick = {
                                                                            this.submitChatText.bind(this)
                                                                        }
                                                                        isConnectedWithAgent = {
                                                                            isConnectedWithAgent
                                                                        }
                                                                        originatorInfo = {
                                                                            originatorInfo
                                                                        }
                                                                        appType = {
                                                                            historyObj.params.user["app-type"]
                                                                        }
                                                                        />)
                                                                    }
                                                                    if (bubbleText) {
                                                                        this.renderTagsHTML.unshift( < Bubble key = {
                                                                                Math.round(Math.random() * 1000000)
                                                                            }
                                                                            messageArray = {
                                                                                message
                                                                            }
                                                                            msgType = {
                                                                                message[0]["component"]
                                                                            }
                                                                            originatorInfo = {
                                                                                originatorInfo
                                                                            }
                                                                            isConnectedWithAgent = {
                                                                                isConnectedWithAgent
                                                                            }
                                                                            appType = {
                                                                                historyObj.params.user["app-type"]
                                                                            }
                                                                            Historydate = {
                                                                                Historydate
                                                                            }
                                                                            />)
                                                                        }

                                                                    }
                                                                } else if ((historyObj.method === "chat" || historyObj.method === "event") && historyObj["text"] !== null) {
                                                                    let bubbleText = historyObj["text"];
                                                                    bubbleText = utils.unescapeHtmlEntities(bubbleText);
                                                                    let message = [{
                                                                        message: utils.splitTag(bubbleText),
                                                                        "component": "FromChatBot",
                                                                        "messageTime": historyObj.createdAt
                                                                    }];
                                                                    let connectWithAgent = utils.getisConnectedWithAgent();
                                                                    let originatorInfo = "";
                                                                    originatorInfo = (historyObj.params ? historyObj.params.originator_info : null)
                                                                    if (messageList && messageList.children.length === 0) {
                                                                        this.renderTagsHTML.push( < Bubble Historydate = {
                                                                                Historydate
                                                                            }
                                                                            key = {
                                                                                Math.round(Math.random() * 1000000)
                                                                            }
                                                                            messageArray = {
                                                                                message
                                                                            }
                                                                            msgType = {
                                                                                message[0]["component"]
                                                                            }
                                                                            connectedWithAgent = {
                                                                                connectWithAgent
                                                                            }
                                                                            originatorInfo = {
                                                                                originatorInfo
                                                                            }
                                                                            />)
                                                                        }
                                                                        else {
                                                                            this.renderTagsHTML.unshift( < Bubble Historydate = {
                                                                                    Historydate
                                                                                }
                                                                                key = {
                                                                                    Math.round(Math.random() * 1000000)
                                                                                }
                                                                                messageArray = {
                                                                                    message
                                                                                }
                                                                                msgType = {
                                                                                    message[0]["component"]
                                                                                }
                                                                                connectedWithAgent = {
                                                                                    connectWithAgent
                                                                                }
                                                                                originatorInfo = {
                                                                                    originatorInfo
                                                                                }
                                                                                />)
                                                                            }
                                                                        } else if (historyObj.method === "message" && historyObj["option"]) {
                                                                            (messageList && messageList.children.length === 0 ? this.renderTagsHTML.push( < PillButtons Historydate = {
                                                                                    Historydate
                                                                                }
                                                                                key = {
                                                                                    Math.round(Math.random() * 1000000)
                                                                                }
                                                                                callbackFromChat = {
                                                                                    this.chatCallback
                                                                                }
                                                                                emptyUserFromChat = {
                                                                                    this.emptyUserCallback
                                                                                }
                                                                                buttonOptions = {
                                                                                    historyObj["option"]
                                                                                }
                                                                                ref = {
                                                                                    (refs) => {
                                                                                        this.pillbuttonNode = refs
                                                                                    }
                                                                                }
                                                                                onHandleClick = {
                                                                                    this.renderUserSelection.bind(this)
                                                                                }
                                                                                />) : this.renderTagsHTML.unshift(<PillButtons Historydate={Historydate} key={Math.round(Math.random() * 1000000)} callbackFromChat={this.chatCallback} emptyUserFromChat={this.emptyUserCallback} buttonOptions={historyObj["option"]} ref={(refs) => { this.pillbuttonNode = refs }} onHandleClick={this.renderUserSelection.bind(this)} / > ))

                                                                        } else if (historyObj.method === "message" && historyObj["menu"]) {
                                                                            let cardObj = {
                                                                                "message": historyObj["menu"]
                                                                            }
                                                                            let originatorInfo = "";
                                                                            originatorInfo = (historyObj.params.originator_info ? historyObj.params.originator_info : historyObj.params.originator)
                                                                            let isConnectedWithAgent = "";
                                                                            if (historyObj.params.originator_info) {
                                                                                isConnectedWithAgent = true;
                                                                            } else {
                                                                                isConnectedWithAgent = false;
                                                                            }

                                                                            (messageList && messageList.children.length === 0 ? this.renderTagsHTML.push( < CardMenu Historydate = {
                                                                                    Historydate
                                                                                }
                                                                                key = {
                                                                                    Math.round(Math.random() * 1000000)
                                                                                }
                                                                                cardMenuArray = {
                                                                                    cardObj
                                                                                }
                                                                                onHandleClick = {
                                                                                    this.renderUserSelection.bind(this)
                                                                                }
                                                                                isConnectedWithAgent = {
                                                                                    isConnectedWithAgent
                                                                                }
                                                                                originatorInfo = {
                                                                                    originatorInfo
                                                                                }
                                                                                appType = {
                                                                                    historyObj.params.user["app-type"]
                                                                                }
                                                                                />) : this.renderTagsHTML.unshift(<CardMenu Historydate={Historydate} key={Math.round(Math.random() * 1000000)} cardMenuArray={cardObj} onHandleClick={this.renderUserSelection.bind(this)} isConnectedWithAgent={isConnectedWithAgent} originatorInfo={originatorInfo} appType={historyObj.params.user["app-type"]} / > ))
                                                                        } else if (historyObj.command === "escalation_status" || historyObj.command === "close_status") {
                                                                            if ((historyObj.command === "escalation_status" && historyObj.status !== "initiated") || historyObj.command === "close_status") {
                                                                                if (historyObj.status === "close_status" || historyObj.status === "conversation_closed") {
                                                                                    utils.getisConnectedWithAgent(false);
                                                                                }
                                                                                (messageList && messageList.children.length === 0 ? this.renderTagsHTML.push( < Ribbon Historydate = {
                                                                                        Historydate
                                                                                    }
                                                                                    key = {
                                                                                        Math.round(Math.random() * 1000000)
                                                                                    }
                                                                                    escalation_status = {
                                                                                        historyObj.status
                                                                                    }
                                                                                    escalatin_status_message = {
                                                                                        historyObj.message
                                                                                    }
                                                                                    />) : this.renderTagsHTML.unshift(<Ribbon Historydate={Historydate} key={Math.round(Math.random() * 1000000)} escalation_status={historyObj.status} escalatin_status_message={historyObj.message} / > ))
                                                                            }

                                                                        }
                                                                        if (messageList && messageList.children.length === 0 && tempHistoryData.length - 1 === key && historyObj.params) {
                                                                            originatorInfo = (historyObj.params && historyObj.params.originator_info ? historyObj.params.originator_info : historyObj.params.originator);
                                                                            utils.setOriginatorInfo(originatorInfo);

                                                                            if (historyObj.params.bot && historyObj.params.bot["liveagent_agentInfo"] && Object.keys(historyObj.params.bot["liveagent_agentInfo"]).length > 0) {
                                                                                utils.setisConnectedWithAgent(true);
                                                                            }
                                                                        }

                                                                        if (props.history_data.length - 1 === key) {
                                                                            if (this.topMessage === "") {
                                                                                setTimeout(() => {
                                                                                    utils.smooth_scroll_to(this.messagerList, this.messagerList.scrollHeight, scrollTimeDealy)
                                                                                    this.hideLoader();
                                                                                }, 300)
                                                                            }

                                                                            this.isHistoryPresent = true;
                                                                            this.topMessage = this.messagerList.childNodes[1].childNodes[1];
                                                                            this.isEnableLaoder = false;
                                                                            /*if (this.renderTagsHTML.length > NetworkHelper.getDefaultHistoryMsgCount()) {
                                                                                this.isHistoryPresent = true;
                                                                                this.topMessage = this.messagerList.childNodes[1].childNodes[1];
                                                                               
                                                                            } */


                                                                        }
                                                                        return null;
                                                                    })
                                                            }

                                                            return null;
                                                        }

                                                        /*call history when scroll up*/
                                                        Onscrollfunction = (event) => {
                                                            event.preventDefault();
                                                            let scrollTop = this.messagerList.scrollTop;
                                                            /* for ios native app added this css fix*/
                                                            if (!document.getElementById("MessageDiv").style.WebkitOverflowScrolling) {
                                                                document.getElementById("MessageDiv").style.WebkitOverflowScrolling = "touch";
                                                            }
                                                            if (scrollTop === 0 && NetworkHelper.getMessageHistoryId() !== '' && NetworkLib.getSocketRef().readyState === 1) {
                                                                this.isHistoryPresent = false;
                                                                NetworkHelper.doGetHistory(NetworkHelper.getUserInfo());
                                                            }
                                                        }


                                                        closeExisitingChat = () => {
                                                            utils.postMessageToParent("retry");
                                                        }

                                                        handleRefresh = async () => {
                                                            //window.parent.location.reload();
                                                            //await this.socketReconnect();

                                                            setTimeout(async () => {
                                                                this.renderTagsHTML = [];
                                                                await NetworkHelper.resetNetwork();
                                                                await NetworkHelper.buildRequestToSend('event', 'initiate_chat', NetworkHelper.getUserInfo())
                                                                this.setState({
                                                                    tabSwitch: false
                                                                });
                                                            }, 1000)

                                                        }

                                                        render() {
                                                                const theme = this.props.theme ? this.props.theme : ''
                                                                /*if header is present show scroll bar*/
                                                                let MessagerDivclassName = "MessagerDiv";
                                                                MessagerDivclassName = (this.props.chatbotparams != null && this.props.chatbotparams.headerParams && (this.props.chatbotparams.headerParams.isHeaderRequired === true || this.props.chatbotparams.headerParams.isHeaderRequired === "true" || !this.props.chatbotparams.headerParams.isHeaderRequired) ? MessagerDivclassName : MessagerDivclassName + " MessagerDivScroll")
                                                                return (

                                                                        (this.props.chatbotparams != null && this.props.chatbotparams.chatbotInitParams != null && this.props.chatbotparams.chatbotInitParams.isChatsessionExists !== true ?

                                                                            <
                                                                            div ref = {
                                                                                (ref) => {
                                                                                    this.messagerListParrent = ref
                                                                                }
                                                                            }
                                                                            style = {
                                                                                {
                                                                                    overflow: "auto",
                                                                                    position: "relative",
                                                                                    height: "100%"
                                                                                }
                                                                            } >
                                                                            <
                                                                            div className = {
                                                                                MessagerDivclassName
                                                                            }
                                                                            id = "MessageDiv"
                                                                            ref = {
                                                                                (ref) => {
                                                                                    this.messagerList = ref
                                                                                }
                                                                            }
                                                                            onScroll = {
                                                                                this.Onscrollfunction.bind(this)
                                                                            } >
                                                                            <
                                                                            div ref = {
                                                                                (ref) => {
                                                                                    this.socketParentNode = ref
                                                                                }
                                                                            } > {
                                                                                this.renderWebSocket()
                                                                            } < /div> <
                                                                            div style = {
                                                                                {
                                                                                    marginTop: "5%"
                                                                                }
                                                                            } >

                                                                            {
                                                                                this.renderTagsHTML
                                                                            } <
                                                                            /div>

                                                                            <
                                                                            div > {
                                                                                this.renderTagsHTML.length === 0 || this.isShowLoader() ? < div key = {
                                                                                    Math.round(Math.random() * 1000000)
                                                                                }
                                                                                className = "loader-container-messageLoader" >
                                                                                <
                                                                                Avator appType = {
                                                                                    this.props.chatbotparams ? this.props.chatbotparams.userobj["app-type"] : null
                                                                                }
                                                                                originatorInfo = {
                                                                                    utils.getOriginatorInfo()
                                                                                }
                                                                                isConnectedWithAgent = {
                                                                                    utils.getisConnectedWithAgent()
                                                                                }
                                                                                /> <
                                                                                div className = 'loader-image-loading' >
                                                                                <
                                                                                div className = "loading-dots" >
                                                                                <
                                                                                div className = {
                                                                                    `loading-dots--dot loading-dots--dot${theme}`
                                                                                } > < /div> <
                                                                                div className = {
                                                                                    `loading-dots--dot loading-dots--dot${theme}`
                                                                                } > < /div> <
                                                                                div className = {
                                                                                    `loading-dots--dot loading-dots--dot${theme}`
                                                                                } > < /div> <
                                                                                /div> <
                                                                                /div> <
                                                                                div className = {
                                                                                    "loader_bottom_div"
                                                                                } > < /div> <
                                                                                /div> : null} <
                                                                                /div> {
                                                                                    this.state.tabSwitch ?
                                                                                        <
                                                                                        div class = "conversation_closed_parent_div"
                                                                                    style = {
                                                                                            {
                                                                                                clear: "both",
                                                                                                color: "black"
                                                                                            }
                                                                                        } >
                                                                                        <
                                                                                        div class = "agentConnectionNotification" >
                                                                                        <
                                                                                        div class = "agent_connection_notification_child_div agent_connection_notification_child_div_members" >
                                                                                        <
                                                                                        p > {
                                                                                            this.state.escalatin_status_message
                                                                                        } < /p> <
                                                                                        /div> <
                                                                                        /div> <
                                                                                        /div> : null} {
                                                                                            this.state.tabSwitch ? < div style = {
                                                                                                {
                                                                                                    "margin-top": "10px",
                                                                                                    "margin-bottom": "10px",
                                                                                                }
                                                                                            }
                                                                                            ref = {
                                                                                                (ref) => {
                                                                                                    this.refreshButtonRef = ref
                                                                                                }
                                                                                            }
                                                                                            onClick = {
                                                                                                this.handleRefresh
                                                                                            }
                                                                                            class = "pillButtons pillButtons_members pillButtons_center" > Click to resume the conversation here < /div> : null} <
                                                                                                /div> {
                                                                                                    this.isSurveyPage ? < div className = {
                                                                                                        `survey survey${theme}`
                                                                                                    }
                                                                                                    style = {
                                                                                                        {
                                                                                                            display: "none"
                                                                                                        }
                                                                                                    }
                                                                                                    ref = {
                                                                                                        (ref) => {
                                                                                                            this.surveyDOM = ref
                                                                                                        }
                                                                                                    } > < /div> : null} {
                                                                                                        this.isShowErrorSnackBar() ? < ErrorSnackbar ref = {
                                                                                                            (refs) => {
                                                                                                                this.errorSnackBar = refs
                                                                                                            }
                                                                                                        }
                                                                                                        handleReconnect = {
                                                                                                            this.socketReconnect.bind(this)
                                                                                                        }
                                                                                                        /> : null} {
                                                                                                            this.articleContent
                                                                                                        } {
                                                                                                            this.props.close_chatdata ? < div className = {
                                                                                                                "endChatDiv"
                                                                                                            } > < WebPopup popupParams = {
                                                                                                                this.props.close_chatdata
                                                                                                            }
                                                                                                            hideLoader = {
                                                                                                                this.hideLoader.bind(this)
                                                                                                            }
                                                                                                            /></div >: < div > < /div>} {
                                                                                                                    this.props.isEndChatConfirmation ? < div > < EndChatConfirmation EndChatConfirmationparams = {
                                                                                                                        this.props.EndChatConfirmationData
                                                                                                                    }
                                                                                                                    hideLoader = {
                                                                                                                        this.hideLoader.bind(this)
                                                                                                                    }
                                                                                                                    /></div >: null
                                                                                                                } {
                                                                                                                    this.props.isContextChangeConfirmation ? < div > < ContextChangeConfirmation hideLoader = {
                                                                                                                        this.hideLoader.bind(this)
                                                                                                                    }
                                                                                                                    /></div >: null
                                                                                                                } <
                                                                                                                /div> : (this.props.chatbotparams != null && this.props.chatbotparams.chatbotInitParams != null && this.props.chatbotparams.chatbotInitParams.isChatsessionExists === true ? <div><div className="existingchatinfo-text">{"You already have an active chat session open in this browser.Please close the original chat session to continue"}</div > < div className = "existingchatinfo-retry"
                                                                                                            onClick = {
                                                                                                                this.closeExisitingChat.bind(this)
                                                                                                            } > {
                                                                                                                "RETRY"
                                                                                                            } < /div></div >: null))

                                                                                                )

                                                                                        }
                                                                                }


                                                                                const mapDispatchToProps = dispatch => ({
                                                                                    buttonSend: (data) => dispatch(buttonSend(data)),
                                                                                    onNetworkErrorSuccess: (message) => dispatch(onNetworkErrorSuccess(message)),
                                                                                    setIntialStateValue: () => dispatch(setIntialStateValue()),
                                                                                    showLoader: () => dispatch(showLoader()),
                                                                                    setSurveyStatus: (message) => dispatch(setSurveyStatus(message))


                                                                                })

                                                                                const mapStateToProps = (state) => {
                                                                                    return {
                                                                                        theme: state.theme,
                                                                                        chatbotparams: state.chatbotparams,
                                                                                        message: state.message,
                                                                                        history_data: state.history_data,
                                                                                        escalation_status: state.escalation_status,
                                                                                        surveyinfo: state.surveyinfo,
                                                                                        escalatin_status_message: state.escalatin_status_message,
                                                                                        show_loader: state.show_loader,
                                                                                        options: state.options,
                                                                                        rating_data: state.rating_data,
                                                                                        close_chatdata: state.close_chatdata,
                                                                                        isEndChatConfirmation: state.isEndChatConfirmation,
                                                                                        EndChatConfirmationData: state.EndChatConfirmationData,
                                                                                        isShowKeyboard: state.isShowKeyboard,
                                                                                        isHideLoader: state.isHideLoader,
                                                                                        isClearDomNode: state.isClearDomNode,
                                                                                        isContextChangeConfirmation: state.isContextChangeConfirmation,
                                                                                        isShowoverlay: state.isShowoverlay

                                                                                    }
                                                                                }

                                                                                export default connect(mapStateToProps, mapDispatchToProps)(Messager)