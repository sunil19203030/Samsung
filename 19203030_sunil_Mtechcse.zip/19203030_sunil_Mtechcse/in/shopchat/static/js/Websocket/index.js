import React from 'react';
import PropTypes from 'prop-types';

class Websocket extends React.Component {

    constructor(props) {
        super(props);
        try {
            this.state = {
                ws: new WebSocket(this.props.url),
                attempts: 1
            };
        } catch (e) {
            console.log(e);
        }

        this.socketMessageTime = "";
        this.interval = "";
        this.socketMointorInMinute = 15;
    }

    logging(logline) {
        if (this.props.debug === true) {
            console.log(logline);
        }
    }

    reconnectSocket() {
        this.setState({
            attempts: this.state.attempts + 1
        });
        this.setState({
            ws: new WebSocket(this.props.url)
        });
        this.setupWebsocket();
    }

    closeSocket(callback) {
        this.state.ws.close();
        this.state.ws.onclose(() => {
            console.log("forcefully socket closing")
        })
        if (callback)
            this.props.onClose();
    }

    generateInterval(k) {
        if (this.props.reconnectIntervalInMilliSeconds > 0) {
            return this.props.reconnectIntervalInMilliSeconds;
        }
        return Math.min(30, (Math.pow(2, k) - 1)) * 1000;
    }

    /*check socket previous message time and close it */
    checkSocketState() {
        let startDate = new Date();
        startDate.setMinutes(startDate.getMinutes() - this.socketMointorInMinute);
        if (this.socketMessageTime < startDate) {
            this.state.ws.close();
            clearInterval(this.interval);
        }
    }


    setupWebsocket() {
        let websocket = this.state.ws;
        websocket.onopen = () => {
            this.logging('Websocket connected');
            this.interval = setInterval(() => {
                this.checkSocketState()
            }, 500000);
            if (typeof this.props.onOpen === 'function') this.props.onOpen();
        };

        websocket.onmessage = (evt) => {
            this.socketMessageTime = new Date();
            this.props.onMessage(evt.data);
        };

        websocket.onerror = (evt) => {
            console.log("error in socket")
            this.props.onError(evt);
        }

        websocket.onclose = (evt) => {
            console.log("close socket")
        }

    }

    componentDidMount() {
        this.setupWebsocket();
    }

    componentWillUnmount() {
        this.shouldReconnect = false;
        clearTimeout(this.timeoutID);
        let websocket = this.state.ws;
        websocket.close();
    }

    sendMessage(message) {
        let websocket = this.state.ws;
        websocket.send(message);
    }

    render() {
        return ( <
            div > < /div>
        );
    }
}

Websocket.defaultProps = {
    debug: false,
    reconnect: true
};

Websocket.propTypes = {
    url: PropTypes.string.isRequired,
    onMessage: PropTypes.func.isRequired,
    onOpen: PropTypes.func,
    onClose: PropTypes.func,
    onError: PropTypes.func,
    debug: PropTypes.bool,
    reconnect: PropTypes.bool,
    protocol: PropTypes.string,
    reconnectIntervalInMilliSeconds: PropTypes.number
};

export default Websocket;