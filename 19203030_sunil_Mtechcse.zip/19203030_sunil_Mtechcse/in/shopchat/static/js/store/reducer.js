import {
    SEND_DATA,
    RECEIVED_DATA,
    UPDATE_CHATBOT_PARAMS,
    DRAW_CARD,
    DRAW_OPTION,
    SHOW_KEYBOARD,
    GET_MENU,
    ESCALATION_STATUS_MESSAGE,
    DRAW_SURVEY_PAGE,
    DISABLE_TEXT_BOX,
    INITAL_STATE_VALUE,
    SHOW_LOADER,
    NETWORK_ERROR,
    NETWORK_ERROR_SUCCESS,
    HISTORY_DATA,
    DRAW_RATING_STAR,
    CLOSE_CHAT,
    SHOW_END_CHAT_CONFIRMATION,
    DRAW_THANK_TOU_PAGE,
    CLOSE_STATUS,
    HIDE_LOADER,
    CLEAR_MESSAGER_DIV,
    DRAW_INFOCARD,
    SHOW_CONTEXT_CHANGE_CONFIRMATION,
    SHOW_OVERLAY,
    UPDATE_THEME,
    TYPING_STATUS_MESSAGE,
    UPDATE_CALLBACK_TIME,
    SET_SURVEY_STATUS,
    UPDATE_HISTORY_DATA,
    RESET_STORE_HISTORY
} from "../actions/action-type"
const initalState = {
    message: [],
    socket: null,
    sequence: 1,
    chatbotparams: null,
    cardMenu: null,
    options: null,
    isShowKeyboard: false,
    menus: null,
    escalation_status: null,
    escalatin_status_message: "",
    surveyinfo: "",
    disable_text_input: true,
    show_loader: false,
    history_data: null,
    rating_data: "",
    close_chatdata: null,
    isEndChatConfirmation: false,
    EndChatConfirmationData: null,
    drawThankyouPage: false,
    isHideLoader: false,
    isClearDomNode: false,
    isContextChangeConfirmation: false,
    requestData: "",
    isShowoverlay: false,
    typing_status: null,
    typing_status_message: '',
    callback_time: '',
    survey_status: false,
    chat_initiate_history: null
}




export default function reducer(state = initalState, action) {
    switch (action.type) {
        case SEND_DATA:
            return {
                ...state,
                message: [{
                    message: action.payload.componentData,
                    messageTime: action.payload.DataTime,
                    component: "FromChatBot"
                }],
                options: null,
                escalation_status: null,
                escalatin_status_message: "",
                surveyinfo: "",
                show_loader: false,
                history_data: null,
                isHideLoader: false,
                isShowoverlay: false
            }
        case RECEIVED_DATA:
            return {
                ...state,
                message: [{
                    message: action.payload.componentData,
                    messageTime: action.payload.DataTime,
                    action: action.payload.action,
                    component: "FromServer"
                }],
                options: null,
                escalation_status: null,
                escalatin_status_message: "",
                disable_text_input: false,
                surveyinfo: "",
                show_loader: false,
                history_data: "",
                isHideLoader: false,
                isShowoverlay: false
            }
        case NETWORK_ERROR:
            return {
                ...state,
                message: [{
                    message: action.payload.componentData,
                    component: "NetWorkError"
                }],
                options: null,
                escalation_status: null,
                escalatin_status_message: "",
                disable_text_input: true,
                surveyinfo: "",
                show_loader: false,
                history_data: null,
                isShowoverlay: false
            }
        case NETWORK_ERROR_SUCCESS:
            return {
                ...state,
                message: [{
                    message: action.payload.componentData,
                    component: "NetWorkSuccess"
                }],
                options: null,
                escalation_status: null,
                escalatin_status_message: "",
                disable_text_input: false,
                surveyinfo: "",
                show_loader: false,
                history_data: null,
                isShowoverlay: false
            }
        case UPDATE_CHATBOT_PARAMS:
            return {
                ...state,
                chatbotparams: action.params,
                show_loader: false,
                isShowoverlay: false
            }
        case DRAW_CARD:
            return {
                ...state,
                message: [{
                    component: "Card",
                    message: action.payload
                }],
                show_loader: false,
                isShowoverlay: false
            }
        case DRAW_OPTION:
            return {
                ...state,
                options: action.option,
                message: [],
                show_loader: false,
                isShowoverlay: false
            }
        case SHOW_KEYBOARD:
            return {
                ...state,
                isShowKeyboard: action.isShowKeyboardFlag,
                escalation_status: null,
                escalatin_status_message: "",
                message: [],
                disable_text_input: false,
                options: null,
                show_loader: false,
                history_data: null,
                isShowoverlay: false
            }
        case GET_MENU:
            return {
                ...state,
                menus: action.payload,
                options: null,
                message: [],
                show_loader: false,
                escalation_status: null,
                escalatin_status_message: "",
                history_data: null,
                isShowoverlay: false
            }
        case ESCALATION_STATUS_MESSAGE:
            return {
                ...state,
                escalation_status: action.payload["status"],
                escalatin_status_message: action.payload["message"],
                message: [],
                disable_text_input: false,
                show_loader: false,
                surveyinfo: "",
                history_data: null,
                isShowoverlay: false
            }
        case TYPING_STATUS_MESSAGE:
            return {
                ...state,
                typing_status: action.payload["status"],
                typing_status_message: action.payload['message']
            }
        case UPDATE_CALLBACK_TIME:
            return {
                ...state,
                callback_time: action.payload
            }
        case SET_SURVEY_STATUS:
            return {
                ...state,
                survey_status: action.payload
            }
        case UPDATE_HISTORY_DATA:
            return {
                ...state,
                chat_initiate_history: action.params
            }
        case RESET_STORE_HISTORY:
            return {
                ...state,
                chat_initiate_history: null
            }
        case CLOSE_STATUS:
            return {
                ...state,
                escalation_status: action.payload["status"],
                escalatin_status_message: action.payload["message"],
                message: [],
                disable_text_input: true,
                show_loader: false,
                surveyinfo: "",
                history_data: null,
                isShowoverlay: false
            }
        case DRAW_SURVEY_PAGE:
            return {
                ...state,
                surveyinfo: action.payload,
                message: [],
                escalation_status: null,
                escalatin_status_message: "",
                disable_text_input: false,
                show_loader: false,
                history_data: null,
                isShowoverlay: false
            }
        case DISABLE_TEXT_BOX:
            return {
                ...state,
                disable_text_input: action.isDisable,
                options: null,
                escalation_status: null,
                escalatin_status_message: "",
                message: [],
                show_loader: false,
                surveyinfo: "",
                history_data: null,
                isShowoverlay: false
            }
        case SHOW_LOADER:
            return {
                ...state,
                show_loader: true,
                options: null,
                escalation_status: null,
                escalatin_status_message: "",
                message: [],
                surveyinfo: "",
                history_data: null,
                close_chatdata: null,
                rating_data: "",
                isShowoverlay: state.isShowoverlay

            }
        case INITAL_STATE_VALUE:
            return {
                ...state,
                message: [],
                cardMenu: null,
                options: null,
                isShowKeyboard: false,
                show_loader: false,
                escalation_status: null,
                escalatin_status_message: "",
                surveyinfo: "",
                history_data: null,
                close_chatdata: null,
                rating_data: "",
                drawThankyouPage: false,
                isHideLoader: true,
                isClearDomNode: false,
                isShowoverlay: false
            }
        case HISTORY_DATA:
            return {
                ...state,
                message: [],
                cardMenu: null,
                options: null,
                isShowKeyboard: false,
                escalation_status: null,
                escalatin_status_message: "",
                surveyinfo: "",
                disable_text_input: false,
                show_loader: false,
                close_chatdata: null,
                history_data: action.payload.historyData,
                isShowoverlay: false
            }
        case CLOSE_CHAT:
            return {
                ...state,
                close_chatdata: action.payload,
                message: [],
                escalation_status: null,
                escalatin_status_message: "",
                isShowoverlay: false
            }
        case DRAW_RATING_STAR:
            {
                return {
                    ...state,
                    rating_data: action.payload.ratingStartData,
                    isShowoverlay: false
                }
            }
        case SHOW_END_CHAT_CONFIRMATION:
            {
                return {
                    ...state,
                    isEndChatConfirmation: action.payload.isEndChatConfirmation,
                    EndChatConfirmationData: action.payload.EndChatConfirmationData,
                    message: [],
                    escalation_status: null,
                    escalatin_status_message: "",
                    isShowKeyboard: false,
                    isShowoverlay: false

                }
            }
        case HIDE_LOADER:
            {
                return {
                    ...state,
                    isHideLoader: action.payload.isHideLoader,
                    options: null,
                    escalation_status: null,
                    escalatin_status_message: "",
                    message: [],
                    surveyinfo: "",
                    history_data: null,
                    close_chatdata: null,
                    rating_data: "",
                    isShowoverlay: false

                }
            }
        case DRAW_THANK_TOU_PAGE:
            {
                return {
                    ...state,
                    drawThankyouPage: action.payload.drawThankyouPage,
                    isShowoverlay: false
                }
            }
        case CLEAR_MESSAGER_DIV:
            {
                return {
                    ...state,
                    isClearDomNode: action.payload,
                    isShowoverlay: false
                }
            }
        case DRAW_INFOCARD:
            {
                return {
                    ...state,
                    message: [{
                        component: "InforCard",
                        message: [{
                            text: action.payload.text,
                            buttons: action.payload.buttons
                        }]
                    }],
                    show_loader: false,
                    isShowoverlay: false

                }
            }
        case SHOW_CONTEXT_CHANGE_CONFIRMATION:
            {
                return {
                    ...state,
                    requestData: action.payload.requestData,
                    isContextChangeConfirmation: action.payload.isContextChangeConfirmation,
                    history_data: null,
                    isShowoverlay: false

                }
            }
        case SHOW_OVERLAY:
            {
                return {
                    ...state,
                    surveyinfo: null,
                    message: [],
                    escalation_status: null,
                    escalatin_status_message: "",
                    disable_text_input: false,
                    show_loader: false,
                    history_data: null,
                    isShowoverlay: true
                }
            }
        case UPDATE_THEME:
            {
                return {
                    ...state,
                    theme: action.theme
                }
            }
        default:
            return state;
    }
}