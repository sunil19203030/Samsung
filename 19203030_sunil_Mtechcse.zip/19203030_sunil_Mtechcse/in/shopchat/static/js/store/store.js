import {
    createStore,
    applyMiddleware
} from 'redux';
import Reducer from './reducer';
import thunk from 'redux-thunk';


const middleware = applyMiddleware(thunk);
export const Store = createStore(Reducer, middleware);