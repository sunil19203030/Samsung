import 'react-app-polyfill/ie11';
import React from 'react';
import ReactDOM from 'react-dom';
//import registerServiceWorker from './registerServiceWorker';
import {
    unregister
} from './registerServiceWorker'
import ChatClientWidget from './ChatClientWidget';
import {
    Provider
} from 'react-redux';
import {
    Store
} from '../src/store/store';
import * as utils from '../src/Util/Util';
import './style.css';
import * as NetworkHelper from '../src/Util/NetworkHelper';
import * as NetworkLib from '../src/Util/NetworkLib';
import {
    updatechatbotparams,
    setIntialStateValue,
    hideLoader,
    updateTheme
} from './actions/action';

export default class WidgetComponent extends React.Component {

        constructor(props) {
            super(props);
            this.state = {
                "isMessageReceived": false,
                data: "",
                isHeaderRequired: false,
                headerParams: {}
            };
            this.socketUrl = "";
            this.updateNetWorkStatus = this.updateNetWorkStatus.bind(this);
        }

        componentDidMount() {
            utils.setisNetworkConnected(true)
            window.addEventListener('message', this.handlemessage.bind(this));
            window.addEventListener('online', this.updateNetWorkStatus);
            window.addEventListener('offline', this.updateNetWorkStatus);
            this.askUserPermission();
            console.log(this)

        }
        askUserPermission = () => {
            var isNativeApp = utils.isNativeApp()
            console.log('isNativeApp', isNativeApp);
            if (!isNativeApp) {
                return Notification.requestPermission();
            }

        }
        updateNetWorkStatus = (networkStatus) => {
            utils.setisNetworkConnected(navigator.onLine)
        }

        componentWillUnmount() {
            window.removeEventListener('message', this.handlemessage.bind(this));
            window.removeEventListener('online', this.updateNetWorkStatus);
            window.removeEventListener('offline', this.updateNetWorkStatus);
        }

        handlemessage(event) {
            utils.setCustomerFirstMessageNeedToSend(false);
            Store.dispatch(setIntialStateValue());
            let cData = JSON.parse(event.data.cData);
            if (cData["reporting"] && cData["reporting"]["samsung.com"] && cData["reporting"]["samsung.com"]["originating_url"]) {
                let originating_url = cData["reporting"]["samsung.com"]["originating_url"];
                if (originating_url && originating_url.indexOf("microsite") !== -1 && originating_url[originating_url.length - 1] === "/") {
                    originating_url = originating_url.substring(0, originating_url.length - 1);
                    let product_display_name = originating_url.substring(originating_url.lastIndexOf("/") + 1, originating_url.length);
                    if (product_display_name === "galaxy-m") {
                        cData["originating_page"] = "pdp";
                        cData["product_category"] = "smartphone";
                        cData["product_display_name"] = product_display_name;
                    }
                } else if (originating_url && originating_url.indexOf("smartphones") !== -1 && originating_url[originating_url.length - 1] === "/") {
                    originating_url = originating_url.substring(39, originating_url.length);
                    let product_display_name = "";
                    if (originating_url) {
                        product_display_name = originating_url.substring(0, originating_url.indexOf("/"));
                    }
                    if (product_display_name === "galaxy-s10") {
                        cData["originating_page"] = product_display_name;
                        cData["product_category"] = "smartphone";
                        cData["product_display_name"] = product_display_name;
                    } else if (product_display_name && product_display_name.indexOf("-") !== -1) {
                        product_display_name = product_display_name.split("-");
                        cData["originating_page"] = "pdp";
                        cData["product_category"] = "smartphone";
                        cData["product_display_name"] = product_display_name[0] + "-" + product_display_name[1];
                    }
                }
            }
            NetworkHelper.setUserInfo(cData);
            let chatbotInitParams = JSON.parse(event.data.chatbotInitParams);
            /*when socketref is present always when event is there call initae chat*/
            if (NetworkLib.getSocketRef() && NetworkHelper.startOverCompleted && utils.checkInitiateIsRequiredDuringMaximizeChat()) {
                NetworkHelper.buildRequestToSend('event', 'initiate_chat', NetworkHelper.getUserInfo())
                Store.dispatch(hideLoader(true));
            }

            /*First request update previous entry*/
            let validateContextChange = event.data.validateContextChange;
            if (validateContextChange && validateContextChange === true) {
                if (cData.reporting && cData["reporting"][cData["app-type"]]) {
                    cData["reporting"][cData["app-type"]]["bot_entry"] = chatbotInitParams.entry;
                }
            }

            if (chatbotInitParams) {
                this.socketUrl = (chatbotInitParams.chatbot_api_port.toString() === "443" ? "wss" : "ws");
                this.socketUrl += "://" + chatbotInitParams["chatbot_api_server"];
                this.socketUrl += ":" + chatbotInitParams["chatbot_api_port"].toString();
                this.socketUrl += chatbotInitParams["chatbot_api_path"];
                if (chatbotInitParams["theme"]) {
                    Store.dispatch(updateTheme('_' + chatbotInitParams["theme"]));
                }
            }
            let headerParams = "";
            if (event.data.headerParams) {
                headerParams = JSON.parse(event.data.headerParams);
                this.setState({
                    "isHeaderRequired": headerParams.isHeaderRequired,
                    isMinimizeRequired: (headerParams.isMinimizeRequired !== null ? headerParams.isMinimizeRequired : null),
                    isCloseRequired: (headerParams.isCloseRequired !== null ? headerParams.isCloseRequired : null),
                    headerTitle: (headerParams.headerTitle != null && headerParams.headerTitle ? headerParams.headerTitle : null),
                    "headerParams": headerParams,
                    "isMessageReceived": true,
                    data: {
                        userobj: cData,
                        chatbotInitParams: chatbotInitParams,
                        headerParams: headerParams
                    }
                });
            } else {
                this.setState({
                    "isMessageReceived": true,
                    data: {
                        userobj: cData,
                        chatbotInitParams: chatbotInitParams,
                        headerParams: headerParams
                    }
                });
            }
            let containerValue = event.data.container;
            let clientObj = this.state.data;
            clientObj["containerValue"] = containerValue;
            clientObj["validateContextChange"] = validateContextChange;
            Store.dispatch(updatechatbotparams(clientObj));
        }

        render() {
            return (
                (this.state.isMessageReceived ? < ChatClientWidget params = {
                        this.state.data
                    }
                    isHeaderRequired = {
                        this.state.isHeaderRequired
                    }
                    isMinimizeRequired = {
                        this.state.isMinimizeRequired
                    }
                    isCloseRequired = {
                        this.state.isCloseRequired
                    }
                    headerTitle = {
                        this.state.headerTitle
                    }
                    headerParams = {
                        this.state.headerParams
                    }
                    socketUrl = {
                        this.socketUrl
                    }
                    /> : null)

                )
            }

        }


        ReactDOM.render( < Provider store = {
                    Store
                } > < WidgetComponent / > < /Provider>, document.getElementById('root'));
                //registerServiceWorker();
                unregister();