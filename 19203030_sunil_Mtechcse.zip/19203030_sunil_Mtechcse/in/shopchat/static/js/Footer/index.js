import React from 'react';
import {
    buttonSend,
    showKeyboard,
    showLoader,
    hideLoader,
    setIntialStateValue
} from '../actions/action';
import {
    connect
} from 'react-redux';

import './style.css';
import * as utils from '../Util/Util';
import Menu from '../Menu'
import * as NetworkHelper from '../Util/NetworkHelper';
import Constants from '../Resources/Constants';






class Sender extends React.Component {
        constructor(props) {
            super(props)
            this.state = {
                drawerMenus: "",
                isShowMenu: false,
                isShowParentMenu: false,
                parentMenuLabel: "",
                menuHeight: "70%",
                isTextValueReadyToSend: false,
                isShowPopup: false
            };
            this.getMenuCallInitiated = false;
            this.popupObj = "";
            this.showKeyboard = false;

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
                this.send = require('../assets/icon_send.svg')
                this.sendselected = require('../assets/icon_send_enabled.svg')
                this.menuunsel = require('../assets/icon_more.svg')
                this.menusel = require('../assets/icon_more_enabled.svg')
            } else {
                this.send = require('../assets/ic_send_unsel.png')
                this.sendselected = require('../assets/ic_send_sel.png')
                this.menuunsel = require('../assets/ic_menu_unsel.png')
                this.menusel = require('../assets/ic_menu_sel.png')
            }
        }

        componentWillReceiveProps(nextProps) {
            if (nextProps.isShowKeyboard && !nextProps.close_chatdata) {
                console.log("text box focus")
                this.textbox.disabled = false;
                this.textbox.focus();
            }

            if (nextProps.close_chatdata) {
                this.setState({
                    "isShowMenu": false
                });
            }
            /*just adjust the opacity when keyboard is disabled*/
            if (nextProps.disable_text_input) {
                this.textbox.style.opacity = "0.2";
                this.sendIcon.style.opacity = "0.2";
                this.textbox.value = "";
                this.textbox.disabled = true;
            } else {
                this.textbox.style.opacity = "1";
                this.sendIcon.style.opacity = "1";
                this.textbox.disabled = false;
            }
        }

        submitChatTextToCloudBot() {
            if (this.props.escalation_status !== "initiated" && this.textbox.value.trim().length > 0) {
                if (utils.getCustomerFirstMessageNeedToSend()) {
                    let tag_event = "click";
                    let tag_action = "customer first message";
                    let tag_params = {
                        "tag_event": tag_event,
                        "tag_action": tag_action
                    };
                    utils.postMessageToParent('tag', tag_params);
                    utils.setCustomerFirstMessageNeedToSend(false);
                }
                NetworkHelper.buildRequestToSend('chat', utils.escapeHtmlEntities(this.textbox.value), NetworkHelper.getUserInfo());
                this.props.submitChatText(this.textbox.value);
                this.setState({
                    isTextValueReadyToSend: false
                });
                this.textbox.value = "";
                if (utils.getisConnectedWithAgent()) {
                    this.textbox.focus();
                } else {
                    this.textbox.blur();
                }
                // utils.postMessageToParent("hide_keyboard");
            }
        }



        /*It will execute 
        when enter key in the ui*/
        handleKeyPress = (event) => {
            if (event.key === 'Enter' && this.textbox.value.trim().length > 0) {
                this.submitChatTextToCloudBot();
            }
        }

        /*selected Menu event will render in UI this
         method will call from Menu.js*/
        menuEventTextAppendInMessager = (text) => {
            if (text !== undefined) {
                this.props.submitChatText(text);
            }
            this.setState({
                "isShowMenu": false
            });
        }



        getHeightForMessageDiv = () => {
            let height = document.getElementsByClassName("widget-container")[0].offsetHeight -
                document.getElementsByClassName("senderMainDiv")[0].offsetHeight;
            if (document.getElementsByClassName("header").length > 0) {
                height = height - document.getElementsByClassName("header")[0].offsetHeight;
            }
            if (document.getElementsByClassName("error-snackbar-parentdiv") && document.getElementsByClassName("error-snackbar-parentdiv").length > 0) {
                height = height - document.getElementsByClassName("error-snackbar-parentdiv")[0].offsetHeight;
            }
            return height;
        }

        /*update the state to draw the drawer menu*/
        renderDrawerMenu() {
            this.props.setIntialStateValue();
            if (this.state.isShowMenu) {
                this.setState({
                    "isShowMenu": false,
                    isConnectedWithAgent: utils.getisConnectedWithAgent()
                })

            } else {
                this.setState({
                    "isShowMenu": true,
                    isConnectedWithAgent: utils.getisConnectedWithAgent()
                })
            }

            /*to handle messger div programtically doing this when drawer menu open 
                     messager div height automatically will adjust with scrolling*/
            setTimeout(() => {
                let messageHeight = this.getHeightForMessageDiv();
                if (navigator.userAgent.indexOf('MSIE') !== -1 || navigator.appVersion.indexOf('Trident/') > -1) {
                    messageHeight = messageHeight - 10;
                }
                if (messageHeight > 0) {
                    utils.getMessagerNodeRef().style.height = messageHeight + "px"
                }
            }, 500)
        }

        getHeightForMessagerParentDiv() {
            if (utils.getMessagerNodeRef()) {
                let height = document.getElementsByClassName("widget-container")[0].offsetHeight -
                    document.getElementsByClassName("senderMainDiv")[0].offsetHeight;
                if (document.getElementsByClassName("header").length > 0) {
                    height = height - document.getElementsByClassName("header")[0].offsetHeight;
                }
                if (document.getElementsByClassName("error-snackbar-parentdiv") && document.getElementsByClassName("error-snackbar-parentdiv").length > 0) {
                    height = height - document.getElementsByClassName("error-snackbar-parentdiv")[0].offsetHeight;
                }

                utils.getMessagerNodeRef().style.height = height + "px";

            }


        }

        render() {
                const theme = this.props.theme ? this.props.theme : ''

                /*when show keyboard call this function will exceute and focus on the text box*/

                return ( < div className = {
                        `senderMainDiv senderMainDiv${theme}`
                    }
                    ref = {
                        (ref) => {
                            this.footerDiv = ref
                        }
                    } >
                    <
                    div className = {
                        `senderRowdiv senderRowdiv${theme}`
                    } >
                    <
                    img src = {
                        this.state.isShowMenu && this.props.menus && this.props.menus.menu.params && this.props.menus.menu.params.call_to_actions ? this.menusel : this.state.isShowMenu && this.state.isConnectedWithAgent && this.props.menus && this.props.menus.menu && this.props.menus.menu.params && this.props.menus.menu.params.agent_escalation_call_to_actions && this.props.menus.menu.params.agent_escalation_call_to_actions.length > 0 ? this.menusel : this.menuunsel
                    }
                    className = {
                        `menuunsel-icon menuunsel-icon${theme}`
                    }
                    alt = "send"
                    onClick = {
                        () => this.renderDrawerMenu()
                    }
                    /> <
                    input type = "text"
                    className = {
                        `new-message new-message${theme} ${this.props.typing_status && this.props.typing_status=== 'showTyping' ? 'new-message-type' : '' }`
                    }
                    id = "textbox"
                    name = "message"
                    ref = {
                        (ref) => {
                            this.textbox = ref
                        }
                    }
                    onKeyPress = {
                        this.handleKeyPress
                    }
                    onInput = {
                        () => {
                            this.textbox.value.trim().length > 0 ? this.setState({
                                isTextValueReadyToSend: true
                            }) : this.setState({
                                isTextValueReadyToSend: false
                            })
                        }
                    }
                    placeholder = {
                        this.props.typing_status && this.props.typing_status === 'showTyping' ? this.props.typing_status_message : this.props.placeholder
                    }
                    disabled = {
                        this.props.disable_text_input || this.props.escalation_status === "initiated"
                    }
                    autoComplete = "off" / >
                    <
                    div className = {
                        `send-icon-maindiv send-icon-maindiv${theme}`
                    }
                    onClick = {
                        () => this.submitChatTextToCloudBot()
                    } > < img className = {
                        `send-icon send-icon${theme}`
                    }
                    src = {!this.state.isTextValueReadyToSend ? this.send : this.sendselected
                    }
                    ref = {
                        (ref) => {
                            this.sendIcon = ref
                        }
                    }
                    alt = "send" / > < /div> <
                    /div> {
                        this.state.isShowMenu && this.props.menus ? < Menu key = {
                            Math.round(Math.random() * 1000000)
                        }
                        drawerMenus = {
                            this.props.menus
                        }
                        hideLoader = {
                            this.props.hideLoader.bind(this)
                        }
                        userSubmitValueToServer = {
                            this.menuEventTextAppendInMessager
                        }
                        /> : null} <
                        /div>)

                    }
                }


                const mapDispatchToProps = dispatch => ({
                    submitChatText: (data) => dispatch(buttonSend(data)),
                    showKeyboard: (flag) => dispatch(showKeyboard(flag)),
                    showLoader: () => dispatch(showLoader()),
                    hideLoader: (data) => dispatch(hideLoader(data)),
                    setIntialStateValue: () => dispatch(setIntialStateValue())

                })

                const mapStateToProps = (state) => {
                    return {
                        theme: state.theme,
                        isShowKeyboard: state.isShowKeyboard,
                        menus: state.menus,
                        escalation_status: state.escalation_status,
                        disable_text_input: state.disable_text_input,
                        close_chatdata: state.close_chatdata,
                        typing_status: state.typing_status,
                        typing_status_message: state.typing_status_message
                    }
                }

                export default connect(mapStateToProps, mapDispatchToProps)(Sender)