import {
    SEND_DATA,
    RECEIVED_DATA,
    UPDATE_CHATBOT_PARAMS,
    DRAW_CARD,
    DRAW_OPTION,
    SHOW_KEYBOARD,
    GET_MENU,
    ESCALATION_STATUS_MESSAGE,
    DRAW_SURVEY_PAGE,
    DISABLE_TEXT_BOX,
    INITAL_STATE_VALUE,
    SHOW_LOADER,
    NETWORK_ERROR,
    NETWORK_ERROR_SUCCESS,
    HISTORY_DATA,
    DRAW_RATING_STAR,
    CLOSE_CHAT,
    SHOW_END_CHAT_CONFIRMATION,
    DRAW_THANK_TOU_PAGE,
    CLOSE_STATUS,
    HIDE_LOADER,
    SHOW_CONTEXT_CHANGE_CONFIRMATION,
    CLEAR_MESSAGER_DIV,
    DRAW_INFOCARD,
    SHOW_OVERLAY,
    UPDATE_THEME,
    TYPING_STATUS_MESSAGE,
    UPDATE_CALLBACK_TIME,
    SET_SURVEY_STATUS,
    UPDATE_HISTORY_DATA,
    RESET_STORE_HISTORY
} from "./action-type";


function sendData(data, time) {
    return {
        type: SEND_DATA,
        payload: {
            componentData: [data],
            DataTime: time
        }
    }
}

function receivedData(data, time, action) {
    return {
        type: RECEIVED_DATA,
        payload: {
            componentData: data,
            DataTime: time,
            action: action
        }
    }
}


function updatechatbotparamsinstate(param) {
    return {
        type: UPDATE_CHATBOT_PARAMS,
        params: param
    }

}

function storeChatHistoryinstate(param) {
    return {
        type: UPDATE_HISTORY_DATA,
        params: param
    }

}

function updationOptionInState(options) {
    return {
        type: DRAW_OPTION,
        option: options
    }
}




function updateCardMenuState(cardMenu) {
    return {
        type: DRAW_CARD,
        payload: cardMenu
    }
}

function updateShowKeyboardStatus(isShowKeyboard) {
    return {
        type: SHOW_KEYBOARD,
        isShowKeyboardFlag: isShowKeyboard
    }
}


function updateMenuInState(Menu) {
    return {
        type: GET_MENU,
        payload: {
            menu: Menu
        }
    }
}

function updateEscalationStatusInState(data) {
    return {
        type: ESCALATION_STATUS_MESSAGE,
        payload: data
    }
}

function updateTypingStatusMessage(data) {
    return {
        type: TYPING_STATUS_MESSAGE,
        payload: data
    }
}

function updateCallbackTime(data) {
    return {
        type: UPDATE_CALLBACK_TIME,
        payload: data
    }
}

function updateCloseStatusMessageInState(data) {
    return {
        type: CLOSE_STATUS,
        payload: data
    }
}



function UpdateRatingSurveyInState(data) {
    return {
        type: DRAW_SURVEY_PAGE,
        payload: data
    }
}

function updateTextBoxStatusInState() {
    return {
        type: DISABLE_TEXT_BOX,
        isDisable: true
    }
}

function updateShowLoaderStatus() {
    return {
        type: SHOW_LOADER
    }
}

function UpdateMessageInState(data) {

    return {
        type: NETWORK_ERROR,
        payload: {
            componentData: data
        }

    }
}

function UpdateMessageInStateNetworkErrorSuccess(data) {
    return {
        type: NETWORK_ERROR_SUCCESS,
        payload: {
            componentData: data
        }

    }
}

function UpdateSurveyStatus(data) {
    return {
        type: SET_SURVEY_STATUS,
        payload: data
    }
}

function updateInitalStateValue() {
    return {
        type: INITAL_STATE_VALUE
    }
}

function updateHistoryDataInState(data) {
    return {
        type: HISTORY_DATA,
        payload: {
            historyData: data
        }
    }
}

function updateRatingStarInState(data) {
    return {
        type: DRAW_RATING_STAR,
        payload: {
            ratingStartData: data
        }
    }
}

function updateCloseChatInState(data) {
    return {
        type: CLOSE_CHAT,
        payload: data
    }
}

function updateshowEndChatConfirmation(data) {
    return {
        type: SHOW_END_CHAT_CONFIRMATION,
        payload: {
            isEndChatConfirmation: data.isEndChatConfirmation,
            EndChatConfirmationData: data.EndChatConfirmationData
        }

    }
}

function updatethankYouPageState(data) {
    return {
        type: DRAW_THANK_TOU_PAGE,
        payload: {
            drawThankyouPage: data
        }
    }
}

function resetHistoryInState() {
    return {
        type: RESET_STORE_HISTORY,
        payload: null
    }
}



function updateLoaderinState(data) {
    return {
        type: HIDE_LOADER,
        payload: {
            isHideLoader: data
        }
    }
}

function updateShowContextChangeConfirmationState(data) {
    return {
        type: SHOW_CONTEXT_CHANGE_CONFIRMATION,
        payload: data
    }
}

function updateclearMessageDivinState(data) {
    return {
        type: CLEAR_MESSAGER_DIV,
        payload: data
    }
}

function updateInfoCradValueinState(data) {
    return {
        type: DRAW_INFOCARD,
        payload: {
            text: data.text,
            buttons: data.buttons
        }
    }
}

function updateShowOverLayinState(data) {
    return {
        type: SHOW_OVERLAY,
        payload: data
    }
}

function updateThemeState(theme) {
    return {
        type: UPDATE_THEME,
        theme: theme
    }
}

export const buttonSend = (data, time) => (dispatch) => {
    dispatch(sendData(data, time));
}

export const receivedResponse = (data, time, action) => (dispatch) => {

    dispatch(receivedData(data, time, action))
}

export const updatechatbotparams = (data) => (dispatch) => {

    dispatch(updatechatbotparamsinstate(data));
}

export const storeChatHistory = (data) => (dispatch) => {

    dispatch(storeChatHistoryinstate(data));
}


export const drawCardMenu = (data) => (dispatch) => {
    dispatch(updateCardMenuState(data))
}

export const drawOption = (data) => (dispatch) => {

    dispatch(updationOptionInState(data))
}

export const showKeyboard = (data) => (dispatch) => {
    dispatch(updateShowKeyboardStatus(data))
}

export const updateMenu = (data) => (dispatch) => {
    dispatch(updateMenuInState(data))
}

export const escalationStatusMessage = (data) => (dispatch) => {
    dispatch(updateEscalationStatusInState(data));
}
export const typingMessage = (data) => (dispatch) => {
    dispatch(updateTypingStatusMessage(data));
}
export const callbackTime = (data) => (dispatch) => {
    dispatch(updateCallbackTime(data));
}
export const closeStatusMessage = (data) => (dispatch) => {
    dispatch(updateCloseStatusMessageInState(data));
}

export const drawSurvey = (data) => (dispatch) => {
    dispatch(UpdateRatingSurveyInState(data))
}


export const updateTextBoxStatus = () => (dispatch) => {
    dispatch(updateTextBoxStatusInState())
}

export const showLoader = () => (dispatch) => {
    dispatch(updateShowLoaderStatus());
}

export const onNetworkError = (submitMessage) => (dispatch) => {
    dispatch(UpdateMessageInState(submitMessage));
}

export const onNetworkErrorSuccess = (submitMessage) => (dispatch) => {
    dispatch(UpdateMessageInStateNetworkErrorSuccess(submitMessage));
}

export const setSurveyStatus = (surveyMessage) => (dispatch => {
    dispatch(UpdateSurveyStatus(surveyMessage));
})


export const setIntialStateValue = () => (dispatch) => {
    dispatch(updateInitalStateValue())
}

export const setHistoryData = (historyData) => (dispatch) => {
    dispatch(updateHistoryDataInState(historyData));
}

export const drawRatingStar = (ratingStartData) => (dispatch) => {
    dispatch(updateRatingStarInState(ratingStartData))
}

export const closeChat = (data) => (dispatch) => {
    dispatch(updateCloseChatInState(data))
}

export const showEndChatConfirmation = (data) => (dispatch) => {
    dispatch(updateshowEndChatConfirmation(data))
}

export const drawThankyouPage = (data) => (dispatch) => {
    dispatch(updatethankYouPageState(data))
}

export const resetHistoryStore = () => (dispatch) => {
    dispatch(resetHistoryInState())
}

export const hideLoader = (data) => (dispatch) => {
    dispatch(updateLoaderinState(data))
}

export const showContextChangeConfirmation = (data) => (dispatch) => {
    dispatch(updateShowContextChangeConfirmationState(data))
}

export const clearMessagerDiv = (data) => (dispatch) => {
    dispatch(updateclearMessageDivinState(data))
}

export const setInfoCardValue = (data) => (dispatch) => {
    dispatch(updateInfoCradValueinState(data))
}

export const showOverLay = (data) => (dispatch) => {
    dispatch(updateShowOverLayinState(data))
}

export const updateTheme = (data) => (dispatch) => {
    dispatch(updateThemeState(data));
}