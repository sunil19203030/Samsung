import React from 'react'
import {
    connect
} from 'react-redux';
import Constants from '../Resources/Constants';

import './style.css';



class ChatClientDetailsForm extends React.Component {

        constructor(props) {
            super(props)
        }

        render() {
                return (

                    <
                    div >
                    <
                    div className = "conversation-container-header" > {
                        Constants.HEADER
                    } < /div> <
                    div className = "conversation-container-secondary-header" > {
                        Constants.SECONDARY_HEADER_LIST
                    } < /div>             <
                    div className = "input-field-form" >
                    <
                    div className = "input-field-container" >
                    <
                    label className = "input-field-form-label" >
                    Phone < span className = "required" > * < /span> <
                    /label>   <
                    input className = "input-field-form-input"
                    type = "tel"
                    maxLength = "10"
                    value = {
                        this.props.phone
                    }
                    onChange = {
                        this.props.handlePhoneChange
                    }
                    required / > {
                        this.props.phone && !this.props.isPhoneValid ? < p className = "input-field-form-error" > Please enter valid phone number < /p> : null} <
                        /div> <
                        div className = "input-field-container" >
                        <
                        label className = "input-field-form-label" >
                        Email < span className = "required" > * < /span> <
                        /label> <
                        input className = "input-field-form-input"
                        type = "email"
                        value = {
                            this.props.email
                        }
                        onChange = {
                            this.props.handleEmailChange
                        }
                        required / > {
                            this.props.email && !this.props.isEmailValid ? < p className = "input-field-form-error" > Please enter valid email id < /p> : null} <
                            /div> <
                            div className = "input-field-container" >
                            <
                            label className = "input-field-form-label" >
                            Name <
                            /label> <
                            input className = "input-field-form-input"
                            type = "text"
                            value = {
                                this.props.name
                            }
                            onChange = {
                                this.props.handleNameChange
                            }
                            /> <
                            /div> <
                            input disabled = {!(this.props.isPhoneValid && this.props.isEmailValid)
                            }
                            className = "input-field-form-button"
                            type = "submit"
                            onClick = {
                                this.props.handleSubmit
                            }
                            value = "Chat Now" / >
                            <
                            /div> {
                                (!this.props.isPartner && this.props.phone && this.props.isPhoneValid && this.props.email && this.props.isEmailValid) ? < div className = "conversation-container-callback-text" > Want a Call Back ? click < span className = "conversation-container-callback-link"
                                onClick = {
                                    this.props.showCallback
                                } > here < /span></div >: null
                            } <
                            /div>

                        );
                    }

                }



                const mapStateToprops = (state) => ({
                    state
                })

                export default connect(mapStateToprops)(ChatClientDetailsForm);