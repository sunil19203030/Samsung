import React from "react";
import * as NetworkHelper from '../Util/NetworkHelper';
import * as NetworkLib from '../Util/NetworkLib';
import Parser from 'html-react-parser';
import {
    connect
} from 'react-redux';
import {
    showEndChatConfirmation
} from '../actions/action';
import thankYouIcon from '../assets/thank_you.png';
import * as utils from '../Util/Util';
import './style.css';


class EndChatConfirmation extends React.Component {
        constructor(props) {
            super(props)
            this.dataObj = props.EndChatConfirmationparams;
        }

        componentDidMount() {
            this.props.hideLoader();
        }

        buttonClick(value) {
            /*to hide end chat confiramtion clearing the things*/
            let Payload = {
                "isEndChatConfirmation": false,
                "EndChatConfirmationData": null
            }
            this.props.showEndChatConfirmation(Payload);
            /*this code will work for Done*/
            if (value["tag"]) {
                let tag_params = {
                    "tag_event": value["tag"]["tag_event"],
                    "tag_action": value["tag"]["tag_action"],
                }
                utils.postMessageToParent("tag", tag_params);
            }
            utils.postMessageToParent("closeChat");
            NetworkHelper.submitSurvey(true);
            NetworkLib.closeSocketConnection();
            if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                window.frames.location.reload(true);
            }
        }

        render() {
            return ( < div className = "end_chat_confirmation" >
                <
                div style = {
                    {
                        textAlign: "center",
                        marginTop: 120,
                        marginLeft: "auto",
                        marginRight: "auto",
                        width: "80%"
                    }
                } >
                <
                div className = "thankyouDiv_end_chat_confirmation" >
                <
                img src = {
                    thankYouIcon
                }
                className = "thankYouIcon"
                alt = {
                    ""
                }
                /> <
                /div> <
                div className = {
                    "endChatTitle_confirmation"
                } > {
                    this.dataObj && this.dataObj.title ? Parser(this.dataObj.title) : ""
                } < /div> <
                div className = {
                    "endChatDescription_confirmation"
                } > {
                    this.dataObj && this.dataObj.description ? this.dataObj.description : ""
                } < /div> <
                div > {
                    this.dataObj && this.dataObj.cta && this.dataObj.cta.length > 0 ? this.dataObj.cta.map((value, key) => {
                        return <div className = {
                            "endChatbutton_confirmation"
                        }
                        key = {
                            key
                        }
                        onClick = {
                            this.buttonClick.bind(this, value)
                        } > {
                            value.text
                        } < /div>
                    }) : ""
                } < /div>

                <
                /div> <
                /div>)
            }
        }


        const mapDispatchToProps = dispatch => ({
            showEndChatConfirmation: (data) => dispatch(showEndChatConfirmation(data))
        })

        const mapStateToProps = (state) => {
            return {
                state
            }
        }

        export default connect(mapStateToProps, mapDispatchToProps)(EndChatConfirmation)