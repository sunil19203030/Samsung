import React from 'react';
import ReactDOM from 'react-dom';
import {
    connect
} from 'react-redux';
import Parser from 'html-react-parser';
import group from '../assets/group.png';
import * as utils from '../Util/Util';
import icon_error_info from '../assets/ic_error_outline.png'
import './style.css';
import Avator from '../Avator';
import {
    Store
} from '../store/store';
import {
    showKeyboard
} from '../actions/action';
import Constants from '../Resources/Constants';
import messageTone from '../assets/inflicted.mp3';

class Bubble extends React.Component {
        constructor(props) {
            super(props);
            this.messageData = this.props.messageArray;
            this.isConnectedWithAgent = this.props.isConnectedWithAgent ? this.props.isConnectedWithAgent : utils.getisConnectedWithAgent();
            this.msgType = this.props.msgType;
            this.isSocketConnected = utils.getisSocketConnected();
            this.currentDate = utils.formatAMPM(new Date());
            this.originatorInfo = this.props.originatorInfo;
            this.renderBubble = [];
            this.showtimespan = true;
            this.state = {
                "showLoader": false
            };
            this.BubbleMessage = this.messageData[0].message;
            this.isContainerValueWeb = (Store.getState().chatbotparams.containerValue ? Store.getState().chatbotparams.containerValue.toLowerCase() === 'web' : false)
            this.profilePhoto = (this.props.originatorInfo && this.props.originatorInfo.metaData && this.props.originatorInfo.metaData.profilePhotoUrl ? this.props.originatorInfo.metaData.profilePhotoUrl : null);

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }

        componentWillMount() {

            let messageList = utils.getMessagerNodeRef() && utils.getMessagerNodeRef().childNodes[1];
            let node = messageList && messageList.childNodes && messageList.childNodes[messageList.childNodes.length - 1]
            /*just compare the node with previous time and adjust the style start*/
            if (node !== undefined && node.childNodes && !this.props.Historydate) {
                if (node.childNodes[0] && node.childNodes[0].childNodes && node.childNodes[0].childNodes[0]) {

                    let timeNode = node.childNodes[0].childNodes[0];
                    if (this.props.msgType === "FromServer" && this.isConnectedWithAgent && timeNode.className && (timeNode.className.indexOf("left-timepan") !== -1 || timeNode.className.indexOf("agent_name_style") !== -1 || timeNode.className.indexOf("agent-avator") !== -1)) {
                        if (this.currentDate === utils.getSpeechBubbleLeftTime()) {
                            let node = document.getElementsByClassName("speech-bubble");
                            if (node && node.length > 0) {
                                let lastNode = node[node.length - 1];
                                if (lastNode.parentElement.childNodes[1].tagName === "IMG") {
                                    lastNode.parentElement.removeChild(lastNode.parentElement.childNodes[1]);
                                } else if (lastNode.parentElement.childNodes[1].className === "agent_name_style") {
                                    lastNode.parentElement.removeChild(lastNode.parentElement.childNodes[1])
                                }
                                if (lastNode.parentElement.childNodes[0].tagName === "IMG") {
                                    lastNode.parentElement.removeChild(lastNode.parentElement.childNodes[0])
                                } else if (lastNode.parentElement.childNodes[0].className === "agent_name_style") {
                                    lastNode.parentElement.removeChild(lastNode.parentElement.childNodes[0])
                                }
                                const theme = this.props.theme ? this.props.theme : ''
                                lastNode.className = `speech-bubbleplain speech-bubbleplain${theme}`;
                                this.showtimespan = false;
                            }
                        }
                    } else if (this.props.msgType === "FromServer" && ((timeNode.className && timeNode.className.indexOf("left-timepan") !== -1) || timeNode.className === "speech-bubble-Parent")) {
                        if (this.currentDate === utils.getSpeechBubbleLeftTime()) {

                            let node = document.getElementsByClassName("speech-bubble-Parent");
                            if (node.length > 0) {
                                let lastNode = node[node.length - 1];
                                if (lastNode.childNodes[0].tagName === "IMG") {
                                    lastNode.removeChild(lastNode.childNodes[0])
                                }
                                const theme = this.props.theme ? this.props.theme : ''
                                lastNode.childNodes[0].className = `bubbleAnimation speech-bubbleplain speech-bubbleplain${theme}`;
                                lastNode.className = "speech-bubbleplain-Parent";
                                this.showtimespan = false;
                            }

                        }
                    } else if (this.props.msgType === "FromChatBot" && (timeNode.className && (timeNode.className.indexOf("right-timepan") !== -1 || timeNode.className.indexOf("speech-bubbleright") !== -1))) {
                        if (this.currentDate === utils.getSpeechBubbleRightTime()) {
                            let node = document.getElementsByClassName("speech-bubbleright");
                            if (node.length > 0) {
                                let lastNode = node[node.length - 1];
                                const theme = this.props.theme ? this.props.theme : ''
                                lastNode.className = `speech-bubblerightplain speech-bubblerightplain${theme}`;
                                this.showtimespan = false;
                            }
                        }
                    }
                }
            }
            /*end the node style start  */

            this.bubbleMessage = this.messageData[0].message;
            if ((this.props.msgType === "FromServer" && this.props.msgType !== this.isConnectedWithAgent && !this.props.Historydate)) {
                this.renderServerBubble();
            } else if (!this.props.Historydate) {
                this.setState({
                    "showLoader": true
                });
            }
            utils.setSpeechBubbleLeftTime(this.currentDate);
            utils.setSpeechBubbleRightTime(this.currentDate);


        }

        playMessageTone = () => {

            const audioEl = document.getElementsByClassName("audio-element")[0]
            if (audioEl) {
                audioEl.play()
            }

        }
        isValidYoutubeUrl(url) {
            url = url.replace(/<\/?p[^>]*>/g, "")
            var valid = /^(http(s)?:\/\/)?((w){3}.)?youtube\.com\/embed\/\S*$/
            return valid.test(url);
        }

        componentDidMount() {
            if ((this.props.msgType !== "FromServer")) {
                this.setState({
                    "showLoader": false
                });
                if (utils.getCustomerFirstMessageNeedToSend()) {
                    utils.setCustomerFirstMessageNeedToSend(false);
                }
            }
            this.movetoLastNode(false);
            document.addEventListener("fullscreenchange", this.changeHandler, false);
            document.addEventListener("webkitfullscreenchange", this.changeHandler, false);
            document.addEventListener("mozfullscreenchange", this.changeHandler, false);
        }

        componentWillUnmount() {
            document.removeEventListener("fullscreenchange", this.changeHandler, false);
            document.removeEventListener("webkitfullscreenchange", this.changeHandler, false);
            document.removeEventListener("mozfullscreenchange", this.changeHandler, false);
        }

        /*when video is render fullscreen while closing moving to current node*/
        changeHandler(event) {
            window.isYoutubeEvent = true;
            if (document.webkitIsFullScreen === false) {
                window.isYoutubeEvent = false;
                event.target.focus();
                event.target.scrollIntoView();
            } else if (document.mozFullScreen === false) {
                window.isYoutubeEvent = false;
                event.target.focus();
                event.target.scrollIntoView();
            } else if (document.msFullscreenElement === false) {
                window.isYoutubeEvent = false;
                event.target.focus();
                event.target.scrollIntoView();
            }

        }

        removePreviousBubbleImage() {

            /*delete existing imae from bubble*/

            let node = document.getElementsByClassName("speech-bubbleplain-Parent");
            if (node.length > 0) {
                let lastNode = node[node.length - 1];
                if (lastNode.childNodes[0].tagName === "IMG") {
                    lastNode.removeChild(lastNode.childNodes[0]);
                }

            }


            /*end delete exisitng image from bubble*/
        }

        movetoLastNode(hideLoader) {

            if (hideLoader) {
                this.setState({
                    "showLoader": false
                })
                if (this.props.messageArray && this.props.messageArray[0] && this.props.messageArray[0].action) {
                    let actions = this.props.messageArray[0].action;
                    for (var i = 0; i < actions.length; i++) {
                        if (actions[i]["command"] === "show_keyboard") {
                            Store.dispatch(showKeyboard(true));
                            utils.postMessageToParent(actions[i]["command"]);

                        }
                    }
                }
            }

            //if there whit out history just render the bublle and move to the last node
            if (!this.props.Historydate) {
                // messageList.scrollTop = messageList.clientHeight + messageList.scrollTop+7
                ReactDOM.findDOMNode(this.bottomDiv).scrollIntoView(false);
            }
            /*after render the dom adjust the loader*/
            if (this.props.hideLoader) {
                this.props.hideLoader();
            }

        }

        bubbleClick(event) {
            if (event.target.nodeName === "A") {
                event.preventDefault();
                if (event.target.href && this.props.appType !== "samsung.com" && !this.isContainerValueWeb) {
                    utils.postMessageToParent("external_Redirect", {
                        "URL": event.target.href
                    })
                } else {
                    window.open(event.target.href, '_blank');
                }
            }
        }

        /*while rendering each bubble to show loader we are calling this fuction*/
        renderServerBubble() {
                const theme = this.props.theme ? this.props.theme : ''
                this.setState({
                            "showLoader": false
                        }, () => {
                            let messageList = utils.getMessagerNodeRef() && utils.getMessagerNodeRef().childNodes[1];
                            let node = messageList && messageList.childNodes[messageList.childNodes.length - 1];
                            if (node && node.childNodes.length > 1) {
                                node = node.childNodes[node.childNodes.length - 1]
                            }
                            // messageList.scrollTop = messageList.clientHeight + messageList.scrollTop+70
                            ReactDOM.findDOMNode(node).scrollIntoView(false);
                            this.timeout = setTimeout(() => {
                                    let value = this.messageData[0];
                                    let data = this.bubbleMessage[0];

                                    if (this.renderBubble.length === 0 && this.showtimespan) {
                                        this.renderBubble.push( < div className = {
                                                `left-timepan left-timepan${theme}`
                                            } > {
                                                value["messageTime"] ? utils.formatAMPM(value["messageTime"]) : this.currentDate
                                            } < /div>)
                                        }
                                        if (this.bubbleMessage.length > 1) {
                                            this.removePreviousBubbleImage();
                                            let classNames = `speech-bubbleplain speech-bubbleplain${theme} bubbleAnimation `;
                                            this.renderBubble.push( < div className = "speech-bubbleplain-Parent" >
                                                <
                                                Avator appType = {
                                                    this.props.appType
                                                }
                                                originatorInfo = {
                                                    this.originatorInfo
                                                }
                                                agentProfilePhoto = {
                                                    this.profilePhoto
                                                }
                                                isConnectedWithAgent = {
                                                    this.isConnectedWithAgent
                                                }
                                                /> <
                                                div className = {
                                                    classNames
                                                }
                                                onClick = {
                                                    this.bubbleClick.bind(this)
                                                } > {
                                                    Parser(data)
                                                } < /div> <
                                                /div>);
                                                this.bubbleMessage = this.bubbleMessage.slice(1); this.setState({
                                                    "showLoader": false
                                                }, (() => {
                                                    if (this.bubbleMessage.length >= 1) {
                                                        this.renderServerBubble()
                                                    }
                                                }))

                                            }
                                            else if (this.bubbleMessage.length === 1) {
                                                this.removePreviousBubbleImage();
                                                let classNames = `bubbleAnimation speech-bubble speech-bubble${theme}`;
                                                this.renderBubble.push( < div className = "speech-bubble-Parent" >
                                                    <
                                                    Avator appType = {
                                                        this.props.appType
                                                    }
                                                    originatorInfo = {
                                                        this.originatorInfo
                                                    }
                                                    agentProfilePhoto = {
                                                        this.profilePhoto
                                                    }
                                                    isConnectedWithAgent = {
                                                        this.isConnectedWithAgent
                                                    }
                                                    /> <
                                                    div className = {
                                                        classNames
                                                    }
                                                    onClick = {
                                                        this.bubbleClick.bind(this)
                                                    } > {
                                                        Parser(data)
                                                    } < /div> <
                                                    /div>)
                                                    this.bubbleMessage = this.bubbleMessage.slice(1); this.setState({
                                                        "showLoader": false
                                                    }, (() => {
                                                        (this.bubbleMessage.length >= 1 ? this.renderServerBubble() : this.movetoLastNode(true))
                                                    }))
                                                }

                                                if (this.bubbleMessage.length === 0) {
                                                    clearTimeout(this.timeout);
                                                    this.timeout = null;
                                                }
                                                // SIEL-445 play message tone while receiving message
                                                if (this.isConnectedWithAgent) {
                                                    this.playMessageTone()
                                                }
                                                //clearTimeout(this.timeout);
                                            }, 700)
                                    })



                            }

                            render() {
                                    const theme = this.props.theme ? this.props.theme : ''
                                    //  (this.props.hideLoader?this.props.hideLoader():null);
                                    return ( <
                                            div style = {
                                                {
                                                    clear: "both"
                                                }
                                            } > {
                                                ((this.props.msgType === "FromServer" && this.isConnectedWithAgent) || this.props.Historydate || this.props.msgType !== "FromServer") ? this.messageData.map((value, key) => {
                                                        return value["message"].map((data, index) => {
                                                                if (this.msgType === "FromServer") {
                                                                    if (value["message"].length === index + 1) {
                                                                        return <div key = {
                                                                            index
                                                                        }
                                                                        style = {
                                                                            {
                                                                                clear: "both",
                                                                                position: "relative"
                                                                            }
                                                                        } > {
                                                                            value["message"].length === 1 && this.showtimespan ? < div className = {
                                                                                `left-timepan left-timepan${theme}`
                                                                            } > {
                                                                                value["messageTime"] ? utils.formatAMPM(value["messageTime"]) : this.currentDate
                                                                            } < /div> : null} <
                                                                            Avator appType = {
                                                                                this.props.appType
                                                                            }
                                                                            originatorInfo = {
                                                                                this.originatorInfo
                                                                            }
                                                                            agentProfilePhoto = {
                                                                                this.profilePhoto
                                                                            }
                                                                            isConnectedWithAgent = {
                                                                                this.isConnectedWithAgent
                                                                            }
                                                                            /> {
                                                                                this.isValidYoutubeUrl(data) ? < div style = {
                                                                                    {
                                                                                        marginLeft: "53px",
                                                                                        marginRight: "12px"
                                                                                    }
                                                                                } > < iframe title = "youtubeVideo"
                                                                                className = "youtubeIfrmae"
                                                                                src = {
                                                                                    data.replace(/<\/?p[^>]*>/g, "")
                                                                                }
                                                                                webkitallowfullscreen = "true"
                                                                                mozallowfullscreen = "true"
                                                                                allowFullScreen = "true" > < /iframe></div >: < div className = {
                                                                                    `speech-bubble speech-bubble${theme}`
                                                                                }
                                                                                onClick = {
                                                                                        this.bubbleClick.bind(this)
                                                                                    } > {
                                                                                        Parser(data)
                                                                                    } < /div>}                                                      <
                                                                                    /div>
                                                                            } else {
                                                                                return <div key = {
                                                                                    index
                                                                                } > {
                                                                                    index === 0 ? < div className = {
                                                                                        `left-timepan left-timepan${theme}`
                                                                                    } > {
                                                                                        value["messageTime"] ? utils.formatAMPM(value["messageTime"]) : this.currentDate
                                                                                    } < /div> : null} {
                                                                                        this.isValidYoutubeUrl(data) ? < div style = {
                                                                                            {
                                                                                                marginLeft: "53px",
                                                                                                marginRight: "12px"
                                                                                            }
                                                                                        } > < iframe title = "youtubeVideo"
                                                                                        src = {
                                                                                            data.replace(/<\/?p[^>]*>/g, "")
                                                                                        }
                                                                                        className = "youtubeIfrmae"
                                                                                        webkitallowfullscreen = "true"
                                                                                        mozallowfullscreen = "true"
                                                                                        allowFullScreen = "true" > < /iframe></div >: < div className = {
                                                                                            `speech-bubbleplain speech-bubbleplain${theme}`
                                                                                        }
                                                                                        onClick = {
                                                                                                this.bubbleClick.bind(this)
                                                                                            } > {
                                                                                                Parser(data)
                                                                                            } < /div>} <
                                                                                            /div>
                                                                                    }
                                                                                }
                                                                                else {
                                                                                    return <div key = {
                                                                                        index
                                                                                    } > {
                                                                                        index === 0 && this.showtimespan ? < div className = {
                                                                                            `right-timepan right-timepan${theme}`
                                                                                        } > {
                                                                                            value["messageTime"] ? utils.formatAMPM(value["messageTime"]) : this.currentDate
                                                                                        } < /div> : null} <
                                                                                        div className = {
                                                                                            this.msgType === "NetWorkError" || (!this.isSocketConnected && !this.props.Historydate) ? "speech-bubblefailure" : (value["message"].length === index + 1 ? `speech-bubbleright speech-bubbleright${theme}` : `speech-bubblerightplain speech-bubblerightplain${theme}`)
                                                                                        } > {
                                                                                            data.replace(/<\/?p[^>]*>/g, "")
                                                                                        } < /div> {
                                                                                            this.msgType === "NetWorkError" || (!this.isSocketConnected && !this.props.Historydate) ? < div className = 'failure-info' > < img src = {
                                                                                                icon_error_info
                                                                                            }
                                                                                            alt = {
                                                                                                "Error"
                                                                                            }
                                                                                            />{"Failed to send"}</div >: null
                                                                                        } {
                                                                                            this.msgType === "NetWorkSuccess" ? < div className = 'success-info' > < img className = 'success-info-img'
                                                                                            alt = {
                                                                                                "Success"
                                                                                            }
                                                                                            src = {
                                                                                                group
                                                                                            }
                                                                                            /><div className='success-info-hint'>{"Sent"}</div > < /div> : null} <
                                                                                            /div>
                                                                                        }
                                                                                    })

                                                                            }): this.renderBubble.map((node, key) => {
                                                                            return <div key = {
                                                                                key
                                                                            } > {
                                                                                node
                                                                            } < /div>
                                                                        })
                                                                    } <
                                                                    div style = {
                                                                        {
                                                                            clear: "both"
                                                                        }
                                                                    }
                                                                    ref = {
                                                                            (refs) => {
                                                                                this.bottomDiv = refs
                                                                            }
                                                                        } > < /div> <
                                                                        audio className = "audio-element" >
                                                                        <
                                                                        source src = {
                                                                            messageTone
                                                                        }
                                                                    type = "audio/mp3" > < /source> <
                                                                        /audio> <
                                                                        /div>

                                                                )
                                                            }

                                                        }

                                                        const mapStateToProps = (state) => {
                                                            return {
                                                                theme: state.theme
                                                            }
                                                        }

                                                        export default connect(mapStateToProps)(Bubble)