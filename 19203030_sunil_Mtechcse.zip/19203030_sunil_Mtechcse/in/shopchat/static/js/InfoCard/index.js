import React from 'react';
import ReactDOM from 'react-dom';
import Parser from 'html-react-parser';


import './style.css';
import * as utils from '../Util/Util';
import Avator from '../Avator';
import * as NetworkHelper from '../Util/NetworkHelper';


export default class InforCard extends React.Component {
    constructor(props) {
        super(props)
        let message = this.props.cardObj.message;
        this.text = message[0].text;
        this.buttons = message[0].buttons;
    }
    componentDidMount() {

        if (!this.props.Historydate) {
            // messageList.scrollTop = messageList.clientHeight + messageList.scrollTop+7
            ReactDOM.findDOMNode(this.bottomDiv).scrollIntoView(false);
        }

        /*after render the dom adjust the loader*/
        if (this.props.hideLoader) {
            this.props.hideLoader();
        }
    }

    buttonClick(buttonObj) {
        if (buttonObj.cta_postback) {
            NetworkHelper.buildRequestToSend('event', buttonObj.cta_postback, NetworkHelper.getUserInfo(), {
                text: (buttonObj.cta_text ? buttonObj.cta_text : ""),
                optionsSelection: true
            })
        } else if (buttonObj.mobile_cta_url || buttonObj.web_cta_url || buttonObj.cta_url) {
            utils.postMessageToParent("external_Redirect", {
                "URL": (buttonObj.mobile_cta_url ? buttonObj.mobile_cta_url : (buttonObj.web_cta_url ? buttonObj.web_cta_url : (buttonObj.cta_url ? buttonObj.cta_url : "")))
            })
        } else if (buttonObj.cta_action) {
            utils.postMessageToParent(buttonObj.cta_action["page"])
        }
    }
    render() {
        return <div className = "infoCardMainContainer" >
            <
            Avator appType = {
                this.props.appType
            }
        originatorInfo = {
            this.props.originatorInfo
        }
        agentProfilePhoto = {
            this.profilePhoto
        }
        isConnectedWithAgent = {
            this.isConnectedWithAgent
        }
        /> <
        div className = "infoCardContainer" >
            <
            div className = "infoCardDiv" >
            <
            div className = "infoCardContentContainer" > < div className = "infoTextCard"
        style = {
                {
                    display: "inline-block"
                }
            } > < p > {
                Parser(this.text)
            } < /p> <
            /div> {
                this.buttons.map((value, key) => {
                    return <div className = "infoCardLink"
                    key = {
                        key
                    }
                    onClick = {
                        (this.buttonClick.bind(this, value))
                    } > {
                        value["cta_text"]
                    } < /div>
                })
            } <
            /div> <
            /div> <
            /div> <
            div style = {
                {
                    clear: "both"
                }
            }
        ref = {
                (refs) => {
                    this.bottomDiv = refs
                }
            } > < /div> <
            /div>
    }
}