import React from 'react';
import PropTypes from 'prop-types';
import ReactLoading from "react-loading";
import './style.css';

class Overlay extends React.Component {


        constructor(props) {
            super(props);
            this.state = {
                "isShowDialog": true
            };

        }

        render() {

            if (!this.props.show) {
                return null;
            }


            return (
                (this.state.isShowDialog ? < div className = "backdropStyle" >
                    <
                    div className = "loader-parent-div" >
                    <
                    ReactLoading type = {
                        "spin"
                    }
                    color = "#fff" / >
                    <
                    /div> <
                    /div> : null)
                );
            }
        }

        Overlay.propTypes = {
            show: PropTypes.bool
        };

        export default Overlay;