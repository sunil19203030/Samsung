import React from 'react';
import ReactDOM from 'react-dom';
import {
    connect
} from 'react-redux';
import './style.css';
import * as NetworkHelper from '../Util/NetworkHelper';
import * as utils from '../Util/Util';
import Constants from '../Resources/Constants';

class PillButtons extends React.Component {
        constructor(props) {
            super(props);

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }

        componentDidMount() {
            let messageList = utils.getMessagerNodeRef() && utils.getMessagerNodeRef().childNodes[1];
            if (!this.props.Historydate) {
                let node = messageList.childNodes[messageList.childNodes.length - 1];
                ReactDOM.findDOMNode(node.childNodes[node.childNodes.length - 1]).scrollIntoView(false);
            }
            if (this.props.hideLoader) {
                this.props.hideLoader();
            }
        }

        handleClick = (value) => {
            if (value["command"] && value["command"] === "require_login") {
                //this.pillButtonNode.remove();
                this.pillButtonNode.style.display = "none";
                utils.postMessageToParent(value["command"]);

            } else if (value && value.postback && value.postback == Constants.CALLBACK_ACTION) {
                this.props.callbackFromChat();
            } else if (value && value.postback && value.postback == Constants.EMPTY_USER_ACTION) {
                this.props.emptyUserFromChat();
            } else {
                NetworkHelper.buildRequestToSend('event', (value.postback ? value.postback : ""), NetworkHelper.getUserInfo(), {
                    text: (value.text ? value.text : ""),
                    optionsSelection: true
                });
                this.props.onHandleClick((value.text ? value.text : ""), true);
                //this.pillButtonNode.parentNode.removeChild(this.pillButtonNode);
            }


        }



        render() {
            const theme = this.props.theme ? this.props.theme : ''
            return ( <
                div className = "pillButtonsContainer"
                ref = {
                    (ref) => {
                        this.pillButtonNode = ref
                    }
                } > {
                    this.props.buttonOptions.map((value, key) => {
                        let cssClasses = `pillButtons pillButtons${theme}`;
                        if (value["align"] === "center") {
                            cssClasses = cssClasses + " pillButtons_center"
                        }
                        return <div key = {
                            key
                        }
                        className = {
                            cssClasses
                        }
                        onClick = {
                                this.handleClick.bind(this, value)
                            } > {
                                value["text"] ? value["text"] : ""
                            } <
                            /div>
                    })
                } <
                div className = {
                    "loader_bottom_div"
                } > < /div> <
                /div>);
            }


        }

        const mapStateToProps = (state) => {
            return {
                theme: state.theme
            }
        }

        export default connect(mapStateToProps)(PillButtons)