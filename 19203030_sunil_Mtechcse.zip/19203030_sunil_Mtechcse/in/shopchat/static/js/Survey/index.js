import React from 'react';
import * as utils from '../Util/Util';
import closeicon_black from '../assets/closeicon_black.png';
import * as NetworkHelper from '../Util/NetworkHelper';
import ProgressBar from '../ProgressBar';
import Parser from 'html-react-parser';
import ErrorSnackbar from '../ErrorSnackbar';
import {
    connect
} from 'react-redux';
import {
    drawThankyouPage
} from '../actions/action';
import Constants from '../Resources/Constants';



import './style.css';

class Survey extends React.Component {
        constructor(props) {
            super(props);
            this.surveyObj = utils.getSurveyObj();
            this.questionNo = 0;
            this.dispalyQuestionNo = 1;
            this.btnclassName = "";
            this.questionInfo = this.surveyObj.questions[this.questionNo];
            this.state = {
                "checkboxValue": 0,
                value: "",
                selectedStarIndex: "",
                selectedCheckBox: "-1",
                rulerValue: 0,
                "renderSurvey": true
            };
            this.slectedAnswers = [];
            this.isdrawThankYou = false;
            this.sliderChange = false;
            this.btnclassName = "";
            this.progressIncrementValue = 100 / this.surveyObj.questions.length;
            this.entryNode = props.passChatbotInitParams.entry;

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
                this.thankYouIcon = require('../assets/icon_complete.svg')
                this.startIcon = require('../assets/icon_star_unsel.svg')
                this.selectedStartIcon = require('../assets/icon_star_sel.svg')
                this.checkIcon = require('../assets/icon_check.svg')
                this.uncheckIcon = require('../assets/icon_incomplete.svg')
            } else {
                this.thankYouIcon = require('../assets/thank_you.png')
                this.startIcon = require('../assets/starIcon.png')
                this.selectedStartIcon = require('../assets/selected_star_icon.png')
            }
        }

        closeSurveyPage = () => {
            if (!this.isdrawThankYou && utils.getSurveyObj()) {
                utils.setSurveyObj(this.surveyObj);
                NetworkHelper.submitSurvey();
            }
            this.setState({
                "renderSurvey": false
            });
            document.getElementsByClassName("survey")[0].style.display = "none";
            this.props.drawThankyouPage(false);
            if (utils.getisSurveyIsRequired()) {
                utils.setisSurveyIsRequired(false);
                utils.postMessageToParent("closeChat");
                if (navigator.userAgent.indexOf('MSIE') < 0 && navigator.appVersion.indexOf('Trident/') < 0) {
                    window.frames.location.reload(true);
                }
            }
            utils.setisSurveyIsRequired(false);

        }
        drawNextPage(selectedValue) {

            if (selectedValue) {
                this.surveyObj.questions[this.questionNo]["answer"] = selectedValue["value"];
            }
            this.surveyObj.questions[this.questionNo]["questionId"] = this.surveyObj.questions[this.questionNo]["id"];
            this.questionNo = this.questionNo + 1;
            this.dispalyQuestionNo = this.dispalyQuestionNo + 1;
            this.questionInfo = this.surveyObj.questions[this.questionNo];
            if (selectedValue && this.questionInfo["condition"]) {
                let conditionValue = this.questionInfo["condition"][0]["value"];
                if (conditionValue.indexOf(selectedValue["value"]) === -1) {
                    this.questionNo = this.questionNo + 1;
                    this.dispalyQuestionNo = this.dispalyQuestionNo + 1;
                    this.questionInfo = this.surveyObj.questions[this.questionNo];
                }

            }
            this.setState({
                "value": "",
                selectedStarIndex: "",
                rulerValue: this.state.rulerValue + this.progressIncrementValue
            });
            this.sliderChange = false;

        }

        drawButtons = (buttonObj) => {
            const theme = this.props.theme ? this.props.theme : ''
            return <div className = {
                `buttonContainer buttonContainer${theme} ${this.btnclassName}`
            } > {
                buttonObj.map((value, key) => {
                    return <div key = {
                            key
                        } >
                        <
                        div className = {
                            `survey_button_parentdiv survey_button_parentdiv${theme}`
                        }
                    onClick = {
                            this.handleButtons.bind(this, value)
                        } >
                        <
                        img className = {
                            `radio-button radio-button${theme}`
                        }
                    src = {
                        this.state.selectedButtonValue === value["value"] ? this.checkIcon : this.uncheckIcon
                    }
                    alt = "" / >
                        <
                        div className = {
                            `survey_button survey_button${theme}`
                        } > {
                            value["displayValue"]
                        } < /div> <
                        /div> <
                        /div>
                })
            } < /div>
        }

        handleButtons = (value) => {
            if (this.props.theme === Constants.THEME_MEMBERS) {
                this.setState({
                    selectedButtonValue: value["value"]
                });
                setTimeout(() => {
                    this.drawNextPage({
                        "value": value["value"]
                    });
                }, 1000);
            } else {
                this.drawNextPage({
                    "value": value["value"]
                });
            }
        }

        handleChange = (value, key) => {
            // let obj = {};
            //obj["checkboxValue"] = event.target.getAttribute("value");
            if (this.state.selectedStarIndex === "") {
                this.setState({
                    "selectedStarIndex": key
                });
                setTimeout(() => {
                    this.drawNextPage({
                        "value": value["value"]
                    });
                }, 1000);
            }

        }

        handleSlideEnd = (event) => {
            if (this.sliderChange) {
                setTimeout(() => {
                    this.drawNextPage();
                }, 1000)
            }
        }



        /* drawSlider = (sliderObj) => {
         return (
             <div>
 
                 <div className="slider-div-node">
                     <input type="range" min="0" max="10" value={this.state.slidervalue} className="slider" onChange={(e) => { this.handleChange(e) }} onTouchEnd={(e) => { this.handleSlideEnd() }} onMouseUp={(e) => { this.handleSlideEnd() }} />
                     {sliderObj.map((value, key) => {
                         if (key === this.state.slidervalue) {
                             return <div key={key} draggable="true" className="sliderselected" >{this.state.slidervalue}</div>
                         } else {
                             return <div>{key === 0 || key === 10 ? <div className="div-number-style">{key}</div> : null}<div key={key} className="slider-div"></div></div>
                         }
                     })}
                 </div>
             </div>
         );
 
 
     }*/

        drawCheckBox = (checkBoxObj) => {
            /*dynamically adjust height width for checkbox*/
            let mainContainer = document.getElementsByClassName("survey")[0].offsetHeight - 50;
            let checkboxHeight = mainContainer / checkBoxObj.length;
            checkboxHeight = checkboxHeight - 20;
            const theme = this.props.theme ? this.props.theme : ''
            return ( <
                div >

                <
                div className = "slider-div-node" > {
                    checkBoxObj.map((value, key) => {
                        let displayValue = value["displayValue"];
                        let checkboxClassName = "checkbox_div";
                        let displayText = "";
                        if (displayValue.indexOf("(") !== -1) {
                            let index = displayValue.indexOf("(");
                            displayValue = displayValue.substring(0, index);
                            displayText = value["displayValue"].replace("(", "");
                            displayText = displayText.replace(")", "");
                            displayText = displayText.replace(displayValue, "");
                        }
                        if (this.state.selectedStarIndex !== "" && this.state.selectedStarIndex === key) {
                            checkboxClassName = checkboxClassName + ` checkbox_div_selected checkbox_div_selected${theme}`;
                        }
                        return <div key = {
                            key
                        }
                        className = {
                            "checkbox_maincontent-div"
                        }
                        value = {
                                displayValue
                            } >
                            <
                            div className = {
                                "checkbox_display_value"
                            }
                        value = {
                                displayValue
                            } > {
                                displayValue
                            } < /div>

                            <
                            div className = {
                                checkboxClassName
                            }
                        style = {
                            {
                                height: checkboxHeight,
                                width: checkboxHeight
                            }
                        }
                        value = {
                            displayValue
                        }
                        onClick = {
                                this.handleChange.bind(this, value, key)
                            } > < /div> <
                            div className = {
                                "content-right"
                            }
                        value = {
                                displayValue
                            } > {
                                displayText.length > 0 ? displayText : null
                            } < /div> <
                            /div>

                    })
                } <
                /div> <
                /div>
            );


        }


        updateStars = (value, key) => {
            this.setState({
                "selectedStarIndex": key,
                displayValue: value["displayValue"]
            });
            setTimeout(() => {
                this.drawNextPage(value);
            }, 1000);

        }


        drawRatingStar = (starObj) => {
                const theme = this.props.theme ? this.props.theme : ''
                return ( < div className = {
                            `rating-star-parentdiv rating-star-parentdiv${theme}`
                        } > {
                            starObj.map((value, key) => {
                                if (this.state.selectedStarIndex && this.state.selectedStarIndex >= key) {
                                    return <div className = {
                                        `rating-star-imgdiv rating-star-imgdiv${theme}`
                                    }
                                    key = {
                                        key
                                    } > < img className = {
                                        `rating-star-img rating-star-img${theme}`
                                    }
                                    src = {
                                        this.selectedStartIcon
                                    }
                                    alt = {
                                        ""
                                    }
                                    /></div >
                                } else {
                                    return <div className = {
                                        `rating-star-imgdiv rating-star-imgdiv${theme}`
                                    }
                                    key = {
                                        key
                                    } > < img className = {
                                        `rating-star-img rating-star-img${theme}`
                                    }
                                    src = {
                                        this.startIcon
                                    }
                                    alt = {
                                        ""
                                    }
                                    onClick = {
                                        this.updateStars.bind(this, value, key)
                                    }
                                    /></div >
                                }

                            })
                        } {
                            (this.state.selectedStarIndex ? < div className = {
                                    `star-display-node star-display-node${theme}`
                                } > {
                                    this.state.displayValue
                                } < /div> : null)} <
                                /div>)
                            }

                            submitValue = () => {
                                this.isdrawThankYou = false;
                                this.surveyObj.questions[this.questionNo]["answer"] = this.textbutton.value;
                                this.surveyObj.questions[this.questionNo]["questionId"] = this.surveyObj.questions[this.questionNo]["id"];
                                utils.setSurveyObj(this.surveyObj);
                                NetworkHelper.submitSurvey();
                                if (!utils.getisSocketConnected() || !utils.getisNetworkConnected()) {
                                    this.setState({
                                        "showErrorSnackBar": true
                                    });
                                    document.getElementsByClassName("btn-submit")[0].style.display = "none";
                                    if (document.getElementsByClassName("text-area").length > 0) {
                                        document.getElementsByClassName("text-area")[0].disabled = true;
                                    }
                                } else {

                                    this.setState({
                                        "showErrorSnackBar": false
                                    });
                                }

                            }


                            handleButtonEvent = (event) => {
                                let command = event.target.getAttribute("command");
                                if (command === "end_chat") {
                                    utils.postMessageToParent(command)
                                }
                                // NetworkHelper.buildRequestToSend('event',  command, NetworkHelper.getUserInfo(), {});
                                this.closeSurveyPage();
                            }

                            drawSurveyPage = () => {
                                    const theme = this.props.theme ? this.props.theme : ''
                                    let questionClassName = `questionDiv questionDiv${theme}`;
                                    if (this.questionInfo.type === "text_input") {
                                        questionClassName = questionClassName.concat(" question-with-textbox");
                                    }
                                    if (this.questionInfo.type.toLowerCase() === "button") {
                                        for (var prop in this.questionInfo.entry) {
                                            if (this.questionInfo.entry[prop]["displayValue"].length > 25) {
                                                this.btnclassName = "large-button";
                                                break;
                                            } else {
                                                this.btnclassName = "";
                                            }

                                        }
                                    }

                                    return ( <
                                        div className = {
                                            `surveypage surveypage${theme}`
                                        } >
                                        <
                                        div className = {
                                            `surveyheader surveyheader${theme}`
                                        } >
                                        <
                                        div className = "header-title" > CHAT SURVEY < /div> <
                                        div className = "close-image"
                                        onClick = {
                                            () => {
                                                this.closeSurveyPage()
                                            }
                                        } > < img src = {
                                            closeicon_black
                                        }
                                        alt = {
                                            ""
                                        }
                                        /></div >

                                        <
                                        /div> <
                                        ProgressBar trackStyle = {
                                            `progress-bar progress-bar${theme}`
                                        }
                                        percent = {
                                            this.state.rulerValue
                                        }
                                        /> <
                                        div className = {
                                            `question-container question-container${theme}`
                                        } >
                                        <
                                        div className = {
                                            questionClassName
                                        } > {
                                            this.questionInfo.label
                                        } <
                                        /div> {
                                            this.questionInfo.type.toLowerCase() === "button" ? this.drawButtons(this.questionInfo.entry) : null
                                        } {
                                            this.questionInfo.type === "slider" ? this.props.theme === Constants.THEME_MEMBERS ? this.drawButtons(this.questionInfo.entry) : this.drawCheckBox(this.questionInfo.entry) : null
                                        } {
                                            this.questionInfo.type === "star_rating" ? this.drawRatingStar(this.questionInfo.entry) : null
                                        } {
                                            this.questionInfo.type === "text_input" ? < div className = "text-parent-div" > < textarea className = {
                                                `text-area text-area${theme}`
                                            }
                                            maxlength = "200"
                                            ref = {
                                                (ref) => {
                                                    this.textbutton = ref
                                                }
                                            }
                                            placeholder = "Tell us how we can improve" > < /textarea><div className={`btn-div btn-div${theme}`}><button className={`btn-submit btn-submit${theme}`} onClick={this.submitValue}>{"SEND"}</button > < /div></div >: null
                                        } <
                                        /div> <
                                        /div>)


                                    }

                                    socketReconnect() {
                                        this.props.callSocket();
                                    }


                                    drawThankyouPageScreen = () => {
                                        const theme = this.props.theme ? this.props.theme : ''
                                        return ( <
                                            div >

                                            <
                                            div className = {
                                                `surveyheader surveyheader${theme}`
                                            } >
                                            <
                                            div className = "header-title" > CHAT SURVEY < /div> <
                                            div className = "close-image" > < img src = {
                                                closeicon_black
                                            }
                                            alt = {
                                                ""
                                            }
                                            onClick = {
                                                () => {
                                                    this.closeSurveyPage()
                                                }
                                            }
                                            /></div >
                                            <
                                            /div> <
                                            div className = {
                                                `thankU-container thankU-container${theme}`
                                            } > < div className = "thankyouDiv" >
                                            <
                                            img src = {
                                                this.thankYouIcon
                                            }
                                            className = {
                                                `thankYouIcon thankYouIcon${theme}`
                                            }
                                            alt = {
                                                ""
                                            }
                                            /> <
                                            /div> {
                                                this.surveyObj.completion_metadata ?
                                                    <
                                                    div >
                                                    <
                                                    div >
                                                    <
                                                    div className = {
                                                        `thankyoumessageDiv thankyoumessageDiv${theme}`
                                                    } > {
                                                        (this.surveyObj.completion_metadata.title ? Parser(this.surveyObj.completion_metadata.title) : "")
                                                    } <
                                                    /div> <
                                                    div className = "thankyou_info_div" > {
                                                        (this.surveyObj.completion_metadata.description ? Parser(this.surveyObj.completion_metadata.description) : "")
                                                    } <
                                                    /div> {
                                                        this.surveyObj.completion_metadata.cta ? this.surveyObj.completion_metadata.cta.map((value, key) => {
                                                            return <div key = {
                                                                key
                                                            }
                                                            className = {
                                                                `linkButton linkButton${theme}`
                                                            }
                                                            command = {
                                                                value["action"]
                                                            }
                                                            onClick = {
                                                                this.handleButtonEvent.bind(this)
                                                            } > {
                                                                value["text"]
                                                            } < /div>
                                                        }) : ""
                                                    }

                                                    <
                                                    /div>

                                                    <
                                                    /div> :
                                                    <
                                                    div >
                                                    <
                                                    div className = {
                                                        `thankyoumessageDiv thankyoumessageDiv${theme}`
                                                    } > {
                                                        "Thank you for you feedback! Your input is highly appreciated."
                                                    } <
                                                    /div>

                                                    <
                                                    /div>
                                            } <
                                            /div> {
                                                this.surveyObj.completion_metadata && (!this.surveyObj.completion_metadata.cta || (this.surveyObj.completion_metadata.cta && Array.isArray(this.surveyObj.completion_metadata.cta) && this.surveyObj.completion_metadata.cta.length === 0)) ? < div > < div className = "survey_button done_button"
                                                onClick = {
                                                    () => {
                                                        this.closeSurveyPage()
                                                    }
                                                } > {
                                                    "DONE"
                                                } < /div></div >: ""
                                            } <
                                            /div>
                                        )
                                    }

                                    render() {
                                        const theme = this.props.theme ? this.props.theme : ''
                                        return ((this.state.renderSurvey ? < div className = {
                                                    `survey_main_div survey_main_div${theme}`
                                                }
                                                ref = {
                                                    (ref) => (this.sureyrefnode = ref)
                                                } >

                                                {!this.isdrawThankYou && !this.props.showThankyoupage ? this.drawSurveyPage() : null
                                                } {
                                                    this.props.showThankyoupage ? this.drawThankyouPageScreen() : null
                                                } {
                                                    this.state.showErrorSnackBar && !this.props.showThankyoupage ? < ErrorSnackbar ref = {
                                                        (refs) => {
                                                            this.errorSnackBar = refs
                                                        }
                                                    }
                                                    handleReconnect = {
                                                        this.socketReconnect.bind(this)
                                                    }
                                                    /> : null} <
                                                    /div> : <div></div > ));
                                        }
                                    }




                                    const mapDispatchToProps = dispatch => ({
                                        drawThankyouPage: (data) => dispatch(drawThankyouPage(data))
                                    })



                                    const mapStateToProps = (state) => {
                                        return {
                                            theme: state.theme,
                                            showThankyoupage: state.drawThankyouPage
                                        }
                                    }

                                    export default connect(mapStateToProps, mapDispatchToProps)(Survey)