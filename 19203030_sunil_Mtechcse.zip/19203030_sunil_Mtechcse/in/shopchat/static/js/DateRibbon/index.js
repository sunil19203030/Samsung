import React from "react";
import {
    connect
} from 'react-redux';
import './style.css';
import Constants from '../Resources/Constants';

class DateRibbon extends React.Component {
        constructor(props) {
            super(props);

            if (props.theme === Constants.THEME_MEMBERS) {
                require('./style_members.css')
            }
        }

        render() {
            const theme = this.props.theme ? this.props.theme : ''
            return ( < div className = {
                    `date_ribbon_class date_ribbon_class${theme}`
                } > {
                    this.props.date ? this.props.date : ""
                } < /div>)
            }
        }

        const mapStateToProps = (state) => {
            return {
                theme: state.theme
            }
        }

        export default connect(mapStateToProps)(DateRibbon)