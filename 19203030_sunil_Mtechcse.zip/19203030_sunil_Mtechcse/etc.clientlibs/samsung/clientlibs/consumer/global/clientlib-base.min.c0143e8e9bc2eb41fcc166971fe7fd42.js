/*
 jQuery v3.4.1 | (c) JS Foundation and other contributors | jquery.org/license  ************************************************
 jquery.cookies.2.2.0.min.js Cookie Util
************************************************ ************************************************
 E-Store Interface 관련 공통 Util
 인터페이스명세서(NG_to_Store)_20140226-v.3.0 적용
************************************************ samsung.com GEO Cannibalization
 src : /samsungp5/components/common/cm-g-gnb-201807/clientlibs/devjs/main1.gnb1.smg.global.cookieGeo.js

 @version 1.0.0
 @since 2018.06.26
*/
var $jscomp = $jscomp || {};
$jscomp.scope = {};
$jscomp.arrayIteratorImpl = function(a) {
    var l = 0;
    return function() {
        return l < a.length ? {
            done: !1,
            value: a[l++]
        } : {
            done: !0
        }
    }
};
$jscomp.arrayIterator = function(a) {
    return {
        next: $jscomp.arrayIteratorImpl(a)
    }
};
$jscomp.ASSUME_ES5 = !1;
$jscomp.ASSUME_NO_NATIVE_MAP = !1;
$jscomp.ASSUME_NO_NATIVE_SET = !1;
$jscomp.SIMPLE_FROUND_POLYFILL = !1;
$jscomp.defineProperty = $jscomp.ASSUME_ES5 || "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, l, e) {
    a != Array.prototype && a != Object.prototype && (a[l] = e.value)
};
$jscomp.getGlobal = function(a) {
    return "undefined" != typeof window && window === a ? a : "undefined" != typeof global && null != global ? global : a
};
$jscomp.global = $jscomp.getGlobal(this);
$jscomp.SYMBOL_PREFIX = "jscomp_symbol_";
$jscomp.initSymbol = function() {
    $jscomp.initSymbol = function() {};
    $jscomp.global.Symbol || ($jscomp.global.Symbol = $jscomp.Symbol)
};
$jscomp.Symbol = function() {
    var a = 0;
    return function(l) {
        return $jscomp.SYMBOL_PREFIX + (l || "") + a++
    }
}();
$jscomp.initSymbolIterator = function() {
    $jscomp.initSymbol();
    var a = $jscomp.global.Symbol.iterator;
    a || (a = $jscomp.global.Symbol.iterator = $jscomp.global.Symbol("iterator"));
    "function" != typeof Array.prototype[a] && $jscomp.defineProperty(Array.prototype, a, {
        configurable: !0,
        writable: !0,
        value: function() {
            return $jscomp.iteratorPrototype($jscomp.arrayIteratorImpl(this))
        }
    });
    $jscomp.initSymbolIterator = function() {}
};
$jscomp.initSymbolAsyncIterator = function() {
    $jscomp.initSymbol();
    var a = $jscomp.global.Symbol.asyncIterator;
    a || (a = $jscomp.global.Symbol.asyncIterator = $jscomp.global.Symbol("asyncIterator"));
    $jscomp.initSymbolAsyncIterator = function() {}
};
$jscomp.iteratorPrototype = function(a) {
    $jscomp.initSymbolIterator();
    a = {
        next: a
    };
    a[$jscomp.global.Symbol.iterator] = function() {
        return this
    };
    return a
};
$jscomp.makeIterator = function(a) {
    var l = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
    return l ? l.call(a) : $jscomp.arrayIterator(a)
};
$jscomp.arrayFromIterator = function(a) {
    for (var l, e = []; !(l = a.next()).done;) e.push(l.value);
    return e
};
$jscomp.arrayFromIterable = function(a) {
    return a instanceof Array ? a : $jscomp.arrayFromIterator($jscomp.makeIterator(a))
};
! function(a, l) {
    "object" == typeof module && "object" == typeof module.exports ? module.exports = a.document ? l(a, !0) : function(a) {
        if (!a.document) throw Error("jQuery requires a window with a document");
        return l(a)
    } : l(a)
}("undefined" != typeof window ? window : this, function(a, l) {
    function e(f, a, b) {
        var c, d, r = (b = b || x).createElement("script");
        if (r.text = f, a)
            for (c in ab)(d = a[c] || a.getAttribute && a.getAttribute(c)) && r.setAttribute(c, d);
        b.head.appendChild(r).parentNode.removeChild(r)
    }

    function g(f) {
        return null == f ? f + "" : "object" ==
            typeof f || "function" == typeof f ? Ha[Ia.call(f)] || "object" : typeof f
    }

    function b(f) {
        var a = !!f && "length" in f && f.length,
            b = g(f);
        return !D(f) && !ua(f) && ("array" === b || 0 === a || "number" == typeof a && 0 < a && a - 1 in f)
    }

    function d(f, a) {
        return f.nodeName && f.nodeName.toLowerCase() === a.toLowerCase()
    }

    function n(f, a, b) {
        return D(a) ? k.grep(f, function(f, c) {
            return !!a.call(f, c, f) !== b
        }) : a.nodeType ? k.grep(f, function(f) {
            return f === a !== b
        }) : "string" != typeof a ? k.grep(f, function(f) {
            return -1 < Ja.call(a, f) !== b
        }) : k.filter(a, f, b)
    }

    function c(f,
        a) {
        for (;
            (f = f[a]) && 1 !== f.nodeType;);
        return f
    }

    function h(f) {
        return f
    }

    function q(f) {
        throw f;
    }

    function m(f, a, b, c) {
        var d;
        try {
            f && D(d = f.promise) ? d.call(f).done(a).fail(b) : f && D(d = f.then) ? d.call(f, a, b) : a.apply(void 0, [f].slice(c))
        } catch (Ga) {
            b.apply(void 0, [Ga])
        }
    }

    function p() {
        x.removeEventListener("DOMContentLoaded", p);
        a.removeEventListener("load", p);
        k.ready()
    }

    function u(f, a) {
        return a.toUpperCase()
    }

    function t(f) {
        return f.replace(xa, "ms-").replace(La, u)
    }

    function y() {
        this.expando = k.expando + y.uid++
    }

    function v(f,
        a, b) {
        var c, d;
        if (void 0 === b && 1 === f.nodeType)
            if (c = "data-" + a.replace(bb, "-$\x26").toLowerCase(), "string" == typeof(b = f.getAttribute(c))) {
                try {
                    b = "true" === (d = b) || "false" !== d && ("null" === d ? null : d === +d + "" ? +d : cb.test(d) ? JSON.parse(d) : d)
                } catch (Ga) {}
                ca.set(f, a, b)
            } else b = void 0;
        return b
    }

    function L(f, a, b, d) {
        var c, r, e = 20,
            h = d ? function() {
                return d.cur()
            } : function() {
                return k.css(f, a, "")
            },
            m = h(),
            p = b && b[3] || (k.cssNumber[a] ? "" : "px"),
            g = f.nodeType && (k.cssNumber[a] || "px" !== p && +m) && va.exec(k.css(f, a));
        if (g && g[3] !== p) {
            m /= 2;
            p =
                p || g[3];
            for (g = +m || 1; e--;) k.style(f, a, g + p), 0 >= (1 - r) * (1 - (r = h() / m || .5)) && (e = 0), g /= r;
            g *= 2;
            k.style(f, a, g + p);
            b = b || []
        }
        return b && (g = +g || +m || 0, c = b[1] ? g + (b[1] + 1) * b[2] : +b[2], d && (d.unit = p, d.start = g, d.end = c)), c
    }

    function J(f, a) {
        for (var b, d, c, r, e, h, m, p = [], g = 0, n = f.length; g < n; g++)(d = f[g]).style && (b = d.style.display, a ? ("none" === b && (p[g] = C.get(d, "display") || null, p[g] || (d.style.display = "")), "" === d.style.display && db(d) && (p[g] = (m = e = r = void 0, e = (c = d).ownerDocument, h = c.nodeName, (m = tb[h]) || (r = e.body.appendChild(e.createElement(h)),
            m = k.css(r, "display"), r.parentNode.removeChild(r), "none" === m && (m = "block"), tb[h] = m)))) : "none" !== b && (p[g] = "none", C.set(d, "display", b)));
        for (g = 0; g < n; g++) null != p[g] && (f[g].style.display = p[g]);
        return f
    }

    function E(f, a) {
        var b;
        return b = "undefined" != typeof f.getElementsByTagName ? f.getElementsByTagName(a || "*") : "undefined" != typeof f.querySelectorAll ? f.querySelectorAll(a || "*") : [], void 0 === a || a && d(f, a) ? k.merge([f], b) : b
    }

    function la(f, a) {
        for (var b = 0, d = f.length; b < d; b++) C.set(f[b], "globalEval", !a || C.get(a[b], "globalEval"))
    }

    function ma(f, a, b, d, c) {
        for (var r, e, h, m, p = a.createDocumentFragment(), n = [], P = 0, I = f.length; P < I; P++)
            if ((r = f[P]) || 0 === r)
                if ("object" === g(r)) k.merge(n, r.nodeType ? [r] : r);
                else if (Nb.test(r)) {
            e = e || p.appendChild(a.createElement("div"));
            h = (ub.exec(r) || ["", ""])[1].toLowerCase();
            h = oa[h] || oa._default;
            e.innerHTML = h[1] + k.htmlPrefilter(r) + h[2];
            for (h = h[0]; h--;) e = e.lastChild;
            k.merge(n, e.childNodes);
            (e = p.firstChild).textContent = ""
        } else n.push(a.createTextNode(r));
        p.textContent = "";
        for (P = 0; r = n[P++];)
            if (d && -1 < k.inArray(r,
                    d)) c && c.push(r);
            else if (m = ra(r), e = E(p.appendChild(r), "script"), m && la(e), b)
            for (h = 0; r = e[h++];) vb.test(r.type || "") && b.push(r);
        return p
    }

    function ia() {
        return !0
    }

    function V() {
        return !1
    }

    function ja(f, a) {
        a: {
            try {
                var b = x.activeElement;
                break a
            } catch (I) {}
            b = void 0
        }
        return f === b == ("focus" === a)
    }

    function G(f, a, b, d, c, e) {
        var r, h;
        if ("object" == typeof a) {
            for (h in "string" != typeof b && (d = d || b, b = void 0), a) G(f, h, b, d, a[h], e);
            return f
        }
        if (null == d && null == c ? (c = b, d = b = void 0) : null == c && ("string" == typeof b ? (c = d, d = void 0) : (c = d, d = b, b = void 0)), !1 === c) c = V;
        else if (!c) return f;
        return 1 === e && (r = c, (c = function(f) {
            return k().off(f), r.apply(this, arguments)
        }).guid = r.guid || (r.guid = k.guid++)), f.each(function() {
            k.event.add(this, a, c, d, b)
        })
    }

    function W(f, a, b) {
        b ? (C.set(f, a, !1), k.event.add(f, a, {
            namespace: !1,
            handler: function(f) {
                var d, c, e = C.get(this, a);
                if (1 & f.isTrigger && this[a])
                    if (e.length)(k.event.special[a] || {}).delegateType && f.stopPropagation();
                    else {
                        if (e = ta.call(arguments), C.set(this, a, e), d = b(this, a), this[a](), e !== (c = C.get(this, a)) || d ? C.set(this, a, !1) :
                            c = {}, e !== c) return f.stopImmediatePropagation(), f.preventDefault(), c.value
                    }
                else e.length && (C.set(this, a, {
                    value: k.event.trigger(k.extend(e[0], k.Event.prototype), e.slice(1), this)
                }), f.stopImmediatePropagation())
            }
        })) : void 0 === C.get(f, a) && k.event.add(f, a, ia)
    }

    function da(f, a) {
        return d(f, "table") && d(11 !== a.nodeType ? a : a.firstChild, "tr") && k(f).children("tbody")[0] || f
    }

    function Q(f) {
        return f.type = (null !== f.getAttribute("type")) + "/" + f.type, f
    }

    function K(f) {
        return "true/" === (f.type || "").slice(0, 5) ? f.type = f.type.slice(5) :
            f.removeAttribute("type"), f
    }

    function w(f, a) {
        var b, d, c, e, h, r;
        if (1 === a.nodeType) {
            if (C.hasData(f) && (b = C.access(f), d = C.set(a, b), r = b.events))
                for (c in delete d.handle, d.events = {}, r)
                    for (b = 0, d = r[c].length; b < d; b++) k.event.add(a, c, r[c][b]);
            ca.hasData(f) && (e = ca.access(f), h = k.extend({}, e), ca.set(a, h))
        }
    }

    function H(f, a, b, d) {
        a = Qa.apply([], a);
        var c, h, r, m = 0,
            p = f.length,
            g = p - 1,
            n = a[0],
            P = D(n);
        if (P || 1 < p && "string" == typeof n && !M.checkClone && Ob.test(n)) return f.each(function(c) {
            var e = f.eq(c);
            P && (a[0] = n.call(this, c, e.html()));
            H(e, a, b, d)
        });
        if (p && (h = (c = ma(a, f[0].ownerDocument, !1, f, d)).firstChild, 1 === c.childNodes.length && (c = h), h || d)) {
            for (r = (h = k.map(E(c, "script"), Q)).length; m < p; m++) {
                var I = c;
                m !== g && (I = k.clone(I, !0, !0), r && k.merge(h, E(I, "script")));
                b.call(f[m], I, m)
            }
            if (r)
                for (c = h[h.length - 1].ownerDocument, k.map(h, K), m = 0; m < r; m++) I = h[m], vb.test(I.type || "") && !C.access(I, "globalEval") && k.contains(c, I) && (I.src && "module" !== (I.type || "").toLowerCase() ? k._evalUrl && !I.noModule && k._evalUrl(I.src, {
                        nonce: I.nonce || I.getAttribute("nonce")
                    }) :
                    e(I.textContent.replace(Qb, ""), I, c))
        }
        return f
    }

    function F(f, a, b) {
        for (var d = a ? k.filter(a, f) : f, c = 0; null != (a = d[c]); c++) b || 1 !== a.nodeType || k.cleanData(E(a)), a.parentNode && (b && ra(a) && la(E(a, "script")), a.parentNode.removeChild(a));
        return f
    }

    function z(f, a, b) {
        var d, c, e, h, r = f.style;
        return (b = b || eb(f)) && ("" !== (h = b.getPropertyValue(a) || b[a]) || ra(f) || (h = k.style(f, a)), !M.pixelBoxStyles() && nb.test(h) && Rb.test(a) && (d = r.width, c = r.minWidth, e = r.maxWidth, r.minWidth = r.maxWidth = r.width = h, h = b.width, r.width = d, r.minWidth =
            c, r.maxWidth = e)), void 0 !== h ? h + "" : h
    }

    function Z(f, a) {
        return {
            get: function() {
                if (!f()) return (this.get = a).apply(this, arguments);
                delete this.get
            }
        }
    }

    function B(f) {
        var a;
        if (!(a = k.cssProps[f] || wb[f])) {
            if (!(f in xb)) {
                a: {
                    a = f;
                    for (var b = a[0].toUpperCase() + a.slice(1), d = yb.length; d--;)
                        if ((a = yb[d] + b) in xb) break a;a = void 0
                }
                f = wb[f] = a || f
            }
            a = f
        }
        return a
    }

    function A(f, a, b) {
        return (f = va.exec(a)) ? Math.max(0, f[2] - (b || 0)) + (f[3] || "px") : a
    }

    function X(f, a, b, d, c, e) {
        var h = "width" === a ? 1 : 0,
            r = 0,
            m = 0;
        if (b === (d ? "border" : "content")) return 0;
        for (; 4 > h; h += 2) "margin" === b && (m += k.css(f, b + qa[h], !0, c)), d ? ("content" === b && (m -= k.css(f, "padding" + qa[h], !0, c)), "margin" !== b && (m -= k.css(f, "border" + qa[h] + "Width", !0, c))) : (m += k.css(f, "padding" + qa[h], !0, c), "padding" !== b ? m += k.css(f, "border" + qa[h] + "Width", !0, c) : r += k.css(f, "border" + qa[h] + "Width", !0, c));
        return !d && 0 <= e && (m += Math.max(0, Math.ceil(f["offset" + a[0].toUpperCase() + a.slice(1)] - e - m - r - .5)) || 0), m
    }

    function N(f, a, b) {
        var d = eb(f),
            c = (!M.boxSizingReliable() || b) && "border-box" === k.css(f, "boxSizing", !1, d),
            h = c,
            e =
            z(f, a, d),
            r = "offset" + a[0].toUpperCase() + a.slice(1);
        if (nb.test(e)) {
            if (!b) return e;
            e = "auto"
        }
        return (!M.boxSizingReliable() && c || "auto" === e || !parseFloat(e) && "inline" === k.css(f, "display", !1, d)) && f.getClientRects().length && (c = "border-box" === k.css(f, "boxSizing", !1, d), (h = r in f) && (e = f[r])), (e = parseFloat(e) || 0) + X(f, a, b || (c ? "border" : "content"), h, d, e) + "px"
    }

    function S(f, a, b, d, c) {
        return new S.prototype.init(f, a, b, d, c)
    }

    function Ka() {
        fb && (!1 === x.hidden && a.requestAnimationFrame ? a.requestAnimationFrame(Ka) : a.setTimeout(Ka,
            k.fx.interval), k.fx.tick())
    }

    function Ma() {
        return a.setTimeout(function() {
            Na = void 0
        }), Na = Date.now()
    }

    function aa(f, a) {
        var b, d = 0,
            c = {
                height: f
            };
        for (a = a ? 1 : 0; 4 > d; d += 2 - a) c["margin" + (b = qa[d])] = c["padding" + b] = f;
        return a && (c.opacity = c.width = f), c
    }

    function ea(f, a, b) {
        for (var d, c = (O.tweeners[a] || []).concat(O.tweeners["*"]), e = 0, h = c.length; e < h; e++)
            if (d = c[e].call(b, a, f)) return d
    }

    function O(f, a, b) {
        var d, c = 0,
            e = O.prefilters.length,
            h = k.Deferred().always(function() {
                delete m.elem
            }),
            m = function() {
                if (d) return !1;
                var a = Na || Ma();
                a = Math.max(0, r.startTime + r.duration - a);
                for (var b = 1 - (a / r.duration || 0), c = 0, e = r.tweens.length; c < e; c++) r.tweens[c].run(b);
                return h.notifyWith(f, [r, b, a]), 1 > b && e ? a : (e || h.notifyWith(f, [r, 1, 0]), h.resolveWith(f, [r]), !1)
            },
            r = h.promise({
                elem: f,
                props: k.extend({}, a),
                opts: k.extend(!0, {
                    specialEasing: {},
                    easing: k.easing._default
                }, b),
                originalProperties: a,
                originalOptions: b,
                startTime: Na || Ma(),
                duration: b.duration,
                tweens: [],
                createTween: function(a, b) {
                    a = k.Tween(f, r.opts, a, b, r.opts.specialEasing[a] || r.opts.easing);
                    return r.tweens.push(a),
                        a
                },
                stop: function(a) {
                    var b = 0,
                        c = a ? r.tweens.length : 0;
                    if (d) return this;
                    for (d = !0; b < c; b++) r.tweens[b].run(1);
                    return a ? (h.notifyWith(f, [r, 1, 0]), h.resolveWith(f, [r, a])) : h.rejectWith(f, [r, a]), this
                }
            });
        b = r.props;
        ! function(a, f) {
            var b, c, d, e, h;
            for (b in a)
                if (d = f[c = t(b)], e = a[b], Array.isArray(e) && (d = e[1], e = a[b] = e[0]), b !== c && (a[c] = e, delete a[b]), (h = k.cssHooks[c]) && "expand" in h)
                    for (b in e = h.expand(e), delete a[c], e) b in a || (a[b] = e[b], f[b] = d);
                else f[c] = d
        }(b, r.opts.specialEasing);
        for (; c < e; c++)
            if (a = O.prefilters[c].call(r,
                    f, b, r.opts)) return D(a.stop) && (k._queueHooks(r.elem, r.opts.queue).stop = a.stop.bind(a)), a;
        return k.map(b, ea, r), D(r.opts.start) && r.opts.start.call(f, r), r.progress(r.opts.progress).done(r.opts.done, r.opts.complete).fail(r.opts.fail).always(r.opts.always), k.fx.timer(k.extend(m, {
            elem: f,
            anim: r,
            queue: r.opts.queue
        })), r
    }

    function R(a) {
        return (a.match(Y) || []).join(" ")
    }

    function fa(a) {
        return a.getAttribute && a.getAttribute("class") || ""
    }

    function ka(a) {
        return Array.isArray(a) ? a : "string" == typeof a && a.match(Y) || []
    }

    function wa(a, b, c, d) {
        var f;
        if (Array.isArray(b)) k.each(b, function(f, b) {
            c || Sb.test(a) ? d(a, b) : wa(a + "[" + ("object" == typeof b && null != b ? f : "") + "]", b, c, d)
        });
        else if (c || "object" !== g(b)) d(a, b);
        else
            for (f in b) wa(a + "[" + f + "]", b[f], c, d)
    }

    function pa(a) {
        return function(f, b) {
            "string" != typeof f && (b = f, f = "*");
            var c = 0,
                d = f.toLowerCase().match(Y) || [];
            if (D(b))
                for (; f = d[c++];) "+" === f[0] ? (f = f.slice(1) || "*", (a[f] = a[f] || []).unshift(b)) : (a[f] = a[f] || []).push(b)
        }
    }

    function Ra(a, b, c, d) {
        function f(m) {
            var r;
            return e[m] = !0, k.each(a[m] || [], function(a, m) {
                a = m(b, c, d);
                return "string" != typeof a || h || e[a] ? h ? !(r = a) : void 0 : (b.dataTypes.unshift(a), f(a), !1)
            }), r
        }
        var e = {},
            h = a === ob;
        return f(b.dataTypes[0]) || !e["*"] && f("*")
    }

    function na(a, b) {
        var f, c, d = k.ajaxSettings.flatOptions || {};
        for (f in b) void 0 !== b[f] && ((d[f] ? a : c || (c = {}))[f] = b[f]);
        return c && k.extend(!0, a, c), a
    }
    var T = [],
        x = a.document,
        za = Object.getPrototypeOf,
        ta = T.slice,
        Qa = T.concat,
        Oa = T.push,
        Ja = T.indexOf,
        Ha = {},
        Ia = Ha.toString,
        Aa = Ha.hasOwnProperty,
        Pa = Aa.toString,
        Ba = Pa.call(Object),
        M = {},
        D = function(a) {
            return "function" ==
                typeof a && "number" != typeof a.nodeType
        },
        ua = function(a) {
            return null != a && a === a.window
        },
        ab = {
            type: !0,
            src: !0,
            nonce: !0,
            noModule: !0
        },
        k = function(a, b) {
            return new k.fn.init(a, b)
        },
        gb = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g;
    $jscomp.initSymbol();
    $jscomp.initSymbol();
    $jscomp.initSymbolIterator();
    $jscomp.initSymbol();
    $jscomp.initSymbolIterator();
    k.fn = k.prototype = {
        jquery: "3.4.1",
        constructor: k,
        length: 0,
        toArray: function() {
            return ta.call(this)
        },
        get: function(a) {
            return null == a ? ta.call(this) : 0 > a ? this[a + this.length] : this[a]
        },
        pushStack: function(a) {
            a = k.merge(this.constructor(), a);
            return a.prevObject = this, a
        },
        each: function(a) {
            return k.each(this, a)
        },
        map: function(a) {
            return this.pushStack(k.map(this, function(f, b) {
                return a.call(f, b, f)
            }))
        },
        slice: function() {
            return this.pushStack(ta.apply(this, arguments))
        },
        first: function() {
            return this.eq(0)
        },
        last: function() {
            return this.eq(-1)
        },
        eq: function(a) {
            var f = this.length;
            a = +a + (0 > a ? f : 0);
            return this.pushStack(0 <= a && a < f ? [this[a]] : [])
        },
        end: function() {
            return this.prevObject || this.constructor()
        },
        push: Oa,
        sort: T.sort,
        splice: T.splice
    };
    k.extend = k.fn.extend = function() {
        var a, b, c, d, e, h = arguments[0] || {},
            m = 1,
            p = arguments.length,
            g = !1;
        "boolean" == typeof h && (g = h, h = arguments[m] || {}, m++);
        "object" == typeof h || D(h) || (h = {});
        for (m === p && (h = this, m--); m < p; m++)
            if (null != (a = arguments[m]))
                for (b in a) {
                    var n = a[b];
                    "__proto__" !== b && h !== n && (g && n && (k.isPlainObject(n) || (d = Array.isArray(n))) ? (c = h[b], e = d && !Array.isArray(c) ? [] : d || k.isPlainObject(c) ? c : {}, d = !1, h[b] = k.extend(g, e, n)) : void 0 !== n && (h[b] = n))
                }
        return h
    };
    k.extend({
        expando: "jQuery" +
            ("3.4.1" + Math.random()).replace(/\D/g, ""),
        isReady: !0,
        error: function(a) {
            throw Error(a);
        },
        noop: function() {},
        isPlainObject: function(a) {
            var f, b;
            return !(!a || "[object Object]" !== Ia.call(a)) && (!(f = za(a)) || "function" == typeof(b = Aa.call(f, "constructor") && f.constructor) && Pa.call(b) === Ba)
        },
        isEmptyObject: function(a) {
            for (var f in a) return !1;
            return !0
        },
        globalEval: function(a, b) {
            e(a, {
                nonce: b && b.nonce
            })
        },
        each: function(a, c) {
            var f, d = 0;
            if (b(a))
                for (f = a.length; d < f && !1 !== c.call(a[d], d, a[d]); d++);
            else
                for (d in a)
                    if (!1 === c.call(a[d],
                            d, a[d])) break;
            return a
        },
        trim: function(a) {
            return null == a ? "" : (a + "").replace(gb, "")
        },
        makeArray: function(a, c) {
            c = c || [];
            return null != a && (b(Object(a)) ? k.merge(c, "string" == typeof a ? [a] : a) : Oa.call(c, a)), c
        },
        inArray: function(a, b, c) {
            return null == b ? -1 : Ja.call(b, a, c)
        },
        merge: function(a, b) {
            for (var f = +b.length, c = 0, d = a.length; c < f; c++) a[d++] = b[c];
            return a.length = d, a
        },
        grep: function(a, b, c) {
            var f = [],
                d = 0,
                e = a.length;
            for (c = !c; d < e; d++) !b(a[d], d) !== c && f.push(a[d]);
            return f
        },
        map: function(a, c, d) {
            var f, e, h = 0,
                m = [];
            if (b(a))
                for (f =
                    a.length; h < f; h++) null != (e = c(a[h], h, d)) && m.push(e);
            else
                for (h in a) null != (e = c(a[h], h, d)) && m.push(e);
            return Qa.apply([], m)
        },
        guid: 1,
        support: M
    });
    "function" == typeof Symbol && (k.fn[Symbol.iterator] = T[Symbol.iterator]);
    k.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function(a, b) {
        Ha["[object " + b + "]"] = b.toLowerCase()
    });
    var sa = function(a) {
        function f(a, f, b, c) {
            var d, e, h, m;
            var p = f && f.ownerDocument;
            var g = f ? f.nodeType : 9;
            if (b = b || [], "string" != typeof a || !a || 1 !== g && 9 !== g && 11 !==
                g) return b;
            if (!c && ((f ? f.ownerDocument || f : D) !== E && Z(f), f = f || E, ba)) {
                if (11 !== g && (m = da.exec(a)))
                    if (d = m[1])
                        if (9 === g) {
                            if (!(e = f.getElementById(d))) return b;
                            if (e.id === d) return b.push(e), b
                        } else {
                            if (p && (e = p.getElementById(d)) && S(f, e) && e.id === d) return b.push(e), b
                        }
                else {
                    if (m[2]) return R.apply(b, f.getElementsByTagName(a)), b;
                    if ((d = m[3]) && v.getElementsByClassName && f.getElementsByClassName) return R.apply(b, f.getElementsByClassName(d)), b
                }
                if (!(!v.qsa || La[a + " "] || N && N.test(a) || 1 === g && "object" === f.nodeName.toLowerCase())) {
                    if (d =
                        a, p = f, 1 === g && W.test(a)) {
                        (h = f.getAttribute("id")) ? h = h.replace(cb, ja): f.setAttribute("id", h = x);
                        for (p = (g = J(a)).length; p--;) g[p] = "#" + h + " " + q(g[p]);
                        d = g.join(",");
                        p = qa.test(a) && k(f.parentNode) || f
                    }
                    try {
                        return R.apply(b, p.querySelectorAll(d)), b
                    } catch (vc) {
                        La(a, !0)
                    } finally {
                        h === x && f.removeAttribute("id")
                    }
                }
            }
            return y(a.replace(va, "$1"), f, b, c)
        }

        function b() {
            var a = [];
            return function zb(f, b) {
                return a.push(f + " ") > z.cacheLength && delete zb[a.shift()], zb[f + " "] = b
            }
        }

        function c(a) {
            return a[x] = !0, a
        }

        function d(a) {
            var f = E.createElement("fieldset");
            try {
                return !!a(f)
            } catch (tc) {
                return !1
            } finally {
                f.parentNode && f.parentNode.removeChild(f)
            }
        }

        function e(a, f) {
            a = a.split("|");
            for (var b = a.length; b--;) z.attrHandle[a[b]] = f
        }

        function h(a, f) {
            var b = f && a,
                c = b && 1 === a.nodeType && 1 === f.nodeType && a.sourceIndex - f.sourceIndex;
            if (c) return c;
            if (b)
                for (; b = b.nextSibling;)
                    if (b === f) return -1;
            return a ? 1 : -1
        }

        function m(a) {
            return function(f) {
                return "input" === f.nodeName.toLowerCase() && f.type === a
            }
        }

        function p(a) {
            return function(f) {
                var b = f.nodeName.toLowerCase();
                return ("input" === b || "button" ===
                    b) && f.type === a
            }
        }

        function g(a) {
            return function(f) {
                return "form" in f ? f.parentNode && !1 === f.disabled ? "label" in f ? "label" in f.parentNode ? f.parentNode.disabled === a : f.disabled === a : f.isDisabled === a || f.isDisabled !== !a && oa(f) === a : f.disabled === a : "label" in f && f.disabled === a
            }
        }

        function n(a) {
            return c(function(f) {
                return f = +f, c(function(b, c) {
                    for (var d, e = a([], b.length, f), h = e.length; h--;) b[d = e[h]] && (b[d] = !(c[d] = b[d]))
                })
            })
        }

        function k(a) {
            return a && "undefined" != typeof a.getElementsByTagName && a
        }

        function l() {}

        function q(a) {
            for (var f =
                    0, b = a.length, c = ""; f < b; f++) c += a[f].value;
            return c
        }

        function u(a, f, b) {
            var c = f.dir,
                d = f.next,
                e = d || c,
                h = b && "parentNode" === e,
                m = ka++;
            return f.first ? function(f, b, d) {
                for (; f = f[c];)
                    if (1 === f.nodeType || h) return a(f, b, d);
                return !1
            } : function(f, b, p) {
                var g, r, n, k = [O, m];
                if (p)
                    for (; f = f[c];) {
                        if ((1 === f.nodeType || h) && a(f, b, p)) return !0
                    } else
                        for (; f = f[c];)
                            if (1 === f.nodeType || h)
                                if (r = (n = f[x] || (f[x] = {}))[f.uniqueID] || (n[f.uniqueID] = {}), d && d === f.nodeName.toLowerCase()) f = f[c] || f;
                                else {
                                    if ((g = r[e]) && g[0] === O && g[1] === m) return k[2] = g[2];
                                    if ((r[e] = k)[2] = a(f, b, p)) return !0
                                }
                return !1
            }
        }

        function t(a) {
            return 1 < a.length ? function(f, b, c) {
                for (var d = a.length; d--;)
                    if (!a[d](f, b, c)) return !1;
                return !0
            } : a[0]
        }

        function w(a, f, b, c, d) {
            for (var e, h = [], m = 0, p = a.length, g = null != f; m < p; m++)(e = a[m]) && (b && !b(e, c, d) || (h.push(e), g && f.push(m)));
            return h
        }

        function A(a, b, d, e, h, m) {
            return e && !e[x] && (e = A(e)), h && !h[x] && (h = A(h, m)), c(function(c, m, p, g) {
                var r, n = [],
                    k = [],
                    P = m.length,
                    l;
                if (!(l = c)) {
                    l = b || "*";
                    for (var q = p.nodeType ? [p] : p, I = [], u = 0, $a = q.length; u < $a; u++) f(l, q[u], I);
                    l = I
                }
                l = !a ||
                    !c && b ? l : w(l, n, a, p, g);
                q = d ? h || (c ? a : P || e) ? [] : m : l;
                if (d && d(l, q, p, g), e) {
                    var t = w(q, k);
                    e(t, [], p, g);
                    for (p = t.length; p--;)(r = t[p]) && (q[k[p]] = !(l[k[p]] = r))
                }
                if (c) {
                    if (h || a) {
                        if (h) {
                            t = [];
                            for (p = q.length; p--;)(r = q[p]) && t.push(l[p] = r);
                            h(null, q = [], t, g)
                        }
                        for (p = q.length; p--;)(r = q[p]) && -1 < (t = h ? fa(c, r) : n[p]) && (c[t] = !(m[t] = r))
                    }
                } else q = w(q === m ? q.splice(P, q.length) : q), h ? h(null, m, q, g) : R.apply(m, q)
            })
        }

        function H(a) {
            var f, b, c = a.length,
                d = z.relative[a[0].type];
            var e = d || z.relative[" "];
            for (var h = d ? 1 : 0, m = u(function(a) {
                        return a === f
                    },
                    e, !0), p = u(function(a) {
                    return -1 < fa(f, a)
                }, e, !0), g = [function(a, b, c) {
                    a = !d && (c || b !== Ea) || ((f = b).nodeType ? m(a, b, c) : p(a, b, c));
                    return f = null, a
                }]; h < c; h++)
                if (e = z.relative[a[h].type]) g = [u(t(g), e)];
                else {
                    if ((e = z.filter[a[h].type].apply(null, a[h].matches))[x]) {
                        for (b = ++h; b < c && !z.relative[a[b].type]; b++);
                        return A(1 < h && t(g), 1 < h && q(a.slice(0, h - 1).concat({
                            value: " " === a[h - 2].type ? "*" : ""
                        })).replace(va, "$1"), e, h < b && H(a.slice(h, b)), b < c && H(a = a.slice(b)), b < c && q(a))
                    }
                    g.push(e)
                }
            return t(g)
        }
        var F, v, z, ha, Y, J, B, y, Ea, X, L, Z, E, C,
            ba, N, xa, ca, S, x = "sizzle" + 1 * new Date,
            D = a.document,
            O = 0,
            ka = 0,
            la = b(),
            G = b(),
            bb = b(),
            La = b(),
            Fa = function(a, f) {
                return a === f && (L = !0), 0
            },
            K = {}.hasOwnProperty,
            aa = [],
            M = aa.pop,
            Ka = aa.push,
            R = aa.push,
            ea = aa.slice,
            fa = function(a, f) {
                for (var b = 0, c = a.length; b < c; b++)
                    if (a[b] === f) return b;
                return -1
            },
            kb = /[\x20\t\r\n\f]+/g,
            va = /^[\x20\t\r\n\f]+|((?:^|[^\\])(?:\\.)*)[\x20\t\r\n\f]+$/g,
            ma = /^[\x20\t\r\n\f]*,[\x20\t\r\n\f]*/,
            ia = /^[\x20\t\r\n\f]*([>+~]|[\x20\t\r\n\f])[\x20\t\r\n\f]*/,
            W = /[\x20\t\r\n\f]|>/,
            pa = /:((?:\\.|[\w-]|[^\x00-\xa0])+)(?:\((('((?:\\.|[^\\'])*)'|"((?:\\.|[^\\"])*)")|((?:\\.|[^\\()[\]]|\[[\x20\t\r\n\f]*((?:\\.|[\w-]|[^\x00-\xa0])+)(?:[\x20\t\r\n\f]*([*^$|!~]?=)[\x20\t\r\n\f]*(?:'((?:\\.|[^\\'])*)'|"((?:\\.|[^\\"])*)"|((?:\\.|[\w-]|[^\x00-\xa0])+))|)[\x20\t\r\n\f]*\])*)|.*)\)|)/,
            V = /^(?:\\.|[\w-]|[^\x00-\xa0])+$/,
            Q = {
                ID: /^#((?:\\.|[\w-]|[^\x00-\xa0])+)/,
                CLASS: /^\.((?:\\.|[\w-]|[^\x00-\xa0])+)/,
                TAG: /^((?:\\.|[\w-]|[^\x00-\xa0])+|[*])/,
                ATTR: /^\[[\x20\t\r\n\f]*((?:\\.|[\w-]|[^\x00-\xa0])+)(?:[\x20\t\r\n\f]*([*^$|!~]?=)[\x20\t\r\n\f]*(?:'((?:\\.|[^\\'])*)'|"((?:\\.|[^\\"])*)"|((?:\\.|[\w-]|[^\x00-\xa0])+))|)[\x20\t\r\n\f]*\]/,
                PSEUDO: /^:((?:\\.|[\w-]|[^\x00-\xa0])+)(?:\((('((?:\\.|[^\\'])*)'|"((?:\\.|[^\\"])*)")|((?:\\.|[^\\()[\]]|\[[\x20\t\r\n\f]*((?:\\.|[\w-]|[^\x00-\xa0])+)(?:[\x20\t\r\n\f]*([*^$|!~]?=)[\x20\t\r\n\f]*(?:'((?:\\.|[^\\'])*)'|"((?:\\.|[^\\"])*)"|((?:\\.|[\w-]|[^\x00-\xa0])+))|)[\x20\t\r\n\f]*\])*)|.*)\)|)/,
                CHILD: /^:(only|first|last|nth|nth-last)-(child|of-type)(?:\([\x20\t\r\n\f]*(even|odd|(([+-]|)(\d*)n|)[\x20\t\r\n\f]*(?:([+-]|)[\x20\t\r\n\f]*(\d+)|))[\x20\t\r\n\f]*\)|)/i,
                bool: /^(?:checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped)$/i,
                needsContext: /^[\x20\t\r\n\f]*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\([\x20\t\r\n\f]*((?:-\d)?\d*)[\x20\t\r\n\f]*\)|)(?=[^-]|$)/i
            },
            Ma = /HTML$/i,
            wa = /^(?:input|select|textarea|button)$/i,
            jb =
            /^h\d$/i,
            ra = /^[^{]+\{\s*\[native \w/,
            da = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
            qa = /[+~]/,
            T = /\\([\da-f]{1,6}[\x20\t\r\n\f]?|([\x20\t\r\n\f])|.)/ig,
            U = function(a, f, b) {
                a = "0x" + f - 65536;
                return a != a || b ? f : 0 > a ? String.fromCharCode(a + 65536) : String.fromCharCode(a >> 10 | 55296, 1023 & a | 56320)
            },
            cb = /([\0-\x1f\x7f]|^-?\d)|^-$|[^\0-\x1f\x7f-\uFFFF\w-]/g,
            ja = function(a, f) {
                return f ? "\x00" === a ? "\ufffd" : a.slice(0, -1) + "\\" + a.charCodeAt(a.length - 1).toString(16) + " " : "\\" + a
            },
            na = function() {
                Z()
            },
            oa = u(function(a) {
                return !0 === a.disabled &&
                    "fieldset" === a.nodeName.toLowerCase()
            }, {
                dir: "parentNode",
                next: "legend"
            });
        try {
            R.apply(aa = ea.call(D.childNodes), D.childNodes), aa[D.childNodes.length].nodeType
        } catch (sc) {
            R = {
                apply: aa.length ? function(a, f) {
                    Ka.apply(a, ea.call(f))
                } : function(a, f) {
                    for (var b = a.length, c = 0; a[b++] = f[c++];);
                    a.length = b - 1
                }
            }
        }
        for (F in v = f.support = {}, Y = f.isXML = function(a) {
                var f = (a.ownerDocument || a).documentElement;
                return !Ma.test(a.namespaceURI || f && f.nodeName || "HTML")
            }, Z = f.setDocument = function(a) {
                var f, b;
                a = a ? a.ownerDocument || a : D;
                return a !==
                    E && 9 === a.nodeType && a.documentElement && (C = (E = a).documentElement, ba = !Y(E), D !== E && (b = E.defaultView) && b.top !== b && (b.addEventListener ? b.addEventListener("unload", na, !1) : b.attachEvent && b.attachEvent("onunload", na)), v.attributes = d(function(a) {
                            return a.className = "i", !a.getAttribute("className")
                        }), v.getElementsByTagName = d(function(a) {
                            return a.appendChild(E.createComment("")), !a.getElementsByTagName("*").length
                        }), v.getElementsByClassName = ra.test(E.getElementsByClassName), v.getById = d(function(a) {
                            return C.appendChild(a).id =
                                x, !E.getElementsByName || !E.getElementsByName(x).length
                        }), v.getById ? (z.filter.ID = function(a) {
                            var f = a.replace(T, U);
                            return function(a) {
                                return a.getAttribute("id") === f
                            }
                        }, z.find.ID = function(a, f) {
                            if ("undefined" != typeof f.getElementById && ba) return (a = f.getElementById(a)) ? [a] : []
                        }) : (z.filter.ID = function(a) {
                            var f = a.replace(T, U);
                            return function(a) {
                                return (a = "undefined" != typeof a.getAttributeNode && a.getAttributeNode("id")) && a.value === f
                            }
                        }, z.find.ID = function(a, f) {
                            if ("undefined" != typeof f.getElementById && ba) {
                                var b,
                                    c = f.getElementById(a);
                                if (c) {
                                    if ((b = c.getAttributeNode("id")) && b.value === a) return [c];
                                    var d = f.getElementsByName(a);
                                    for (f = 0; c = d[f++];)
                                        if ((b = c.getAttributeNode("id")) && b.value === a) return [c]
                                }
                                return []
                            }
                        }), z.find.TAG = v.getElementsByTagName ? function(a, f) {
                            return "undefined" != typeof f.getElementsByTagName ? f.getElementsByTagName(a) : v.qsa ? f.querySelectorAll(a) : void 0
                        } : function(a, f) {
                            var b = [],
                                c = 0;
                            f = f.getElementsByTagName(a);
                            if ("*" === a) {
                                for (; a = f[c++];) 1 === a.nodeType && b.push(a);
                                return b
                            }
                            return f
                        }, z.find.CLASS = v.getElementsByClassName &&
                        function(a, f) {
                            if ("undefined" != typeof f.getElementsByClassName && ba) return f.getElementsByClassName(a)
                        }, xa = [], N = [], (v.qsa = ra.test(E.querySelectorAll)) && (d(function(a) {
                            C.appendChild(a).innerHTML = "\x3ca id\x3d'" + x + "'\x3e\x3c/a\x3e\x3cselect id\x3d'" + x + "-\r\\' msallowcapture\x3d''\x3e\x3coption selected\x3d''\x3e\x3c/option\x3e\x3c/select\x3e";
                            a.querySelectorAll("[msallowcapture^\x3d'']").length && N.push("[*^$]\x3d[\\x20\\t\\r\\n\\f]*(?:''|\"\")");
                            a.querySelectorAll("[selected]").length || N.push("\\[[\\x20\\t\\r\\n\\f]*(?:value|checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped)");
                            a.querySelectorAll("[id~\x3d" + x + "-]").length || N.push("~\x3d");
                            a.querySelectorAll(":checked").length || N.push(":checked");
                            a.querySelectorAll("a#" + x + "+*").length || N.push(".#.+[+~]")
                        }), d(function(a) {
                            a.innerHTML = "\x3ca href\x3d'' disabled\x3d'disabled'\x3e\x3c/a\x3e\x3cselect disabled\x3d'disabled'\x3e\x3coption/\x3e\x3c/select\x3e";
                            var f = E.createElement("input");
                            f.setAttribute("type", "hidden");
                            a.appendChild(f).setAttribute("name", "D");
                            a.querySelectorAll("[name\x3dd]").length && N.push("name[\\x20\\t\\r\\n\\f]*[*^$|!~]?\x3d");
                            2 !== a.querySelectorAll(":enabled").length && N.push(":enabled", ":disabled");
                            C.appendChild(a).disabled = !0;
                            2 !== a.querySelectorAll(":disabled").length && N.push(":enabled", ":disabled");
                            a.querySelectorAll("*,:x");
                            N.push(",.*:")
                        })), (v.matchesSelector = ra.test(ca = C.matches || C.webkitMatchesSelector || C.mozMatchesSelector || C.oMatchesSelector || C.msMatchesSelector)) && d(function(a) {
                            v.disconnectedMatch = ca.call(a, "*");
                            ca.call(a, "[s!\x3d'']:x");
                            xa.push("!\x3d", ":((?:\\\\.|[\\w-]|[^\x00-\\xa0])+)(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|\\[[\\x20\\t\\r\\n\\f]*((?:\\\\.|[\\w-]|[^\x00-\\xa0])+)(?:[\\x20\\t\\r\\n\\f]*([*^$|!~]?\x3d)[\\x20\\t\\r\\n\\f]*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|((?:\\\\.|[\\w-]|[^\x00-\\xa0])+))|)[\\x20\\t\\r\\n\\f]*\\])*)|.*)\\)|)")
                        }),
                        N = N.length && new RegExp(N.join("|")), xa = xa.length && new RegExp(xa.join("|")), f = ra.test(C.compareDocumentPosition), S = f || ra.test(C.contains) ? function(a, f) {
                            var b = 9 === a.nodeType ? a.documentElement : a;
                            f = f && f.parentNode;
                            return a === f || !(!f || 1 !== f.nodeType || !(b.contains ? b.contains(f) : a.compareDocumentPosition && 16 & a.compareDocumentPosition(f)))
                        } : function(a, f) {
                            if (f)
                                for (; f = f.parentNode;)
                                    if (f === a) return !0;
                            return !1
                        }, Fa = f ? function(a, f) {
                            if (a === f) return L = !0, 0;
                            var b = !a.compareDocumentPosition - !f.compareDocumentPosition;
                            return b || (1 & (b = (a.ownerDocument || a) === (f.ownerDocument || f) ? a.compareDocumentPosition(f) : 1) || !v.sortDetached && f.compareDocumentPosition(a) === b ? a === E || a.ownerDocument === D && S(D, a) ? -1 : f === E || f.ownerDocument === D && S(D, f) ? 1 : X ? fa(X, a) - fa(X, f) : 0 : 4 & b ? -1 : 1)
                        } : function(a, f) {
                            if (a === f) return L = !0, 0;
                            var b = 0,
                                c = a.parentNode,
                                d = f.parentNode,
                                e = [a],
                                m = [f];
                            if (!c || !d) return a === E ? -1 : f === E ? 1 : c ? -1 : d ? 1 : X ? fa(X, a) - fa(X, f) : 0;
                            if (c === d) return h(a, f);
                            for (; a = a.parentNode;) e.unshift(a);
                            for (a = f; a = a.parentNode;) m.unshift(a);
                            for (; e[b] ===
                                m[b];) b++;
                            return b ? h(e[b], m[b]) : e[b] === D ? -1 : m[b] === D ? 1 : 0
                        }), E
            }, f.matches = function(a, b) {
                return f(a, null, null, b)
            }, f.matchesSelector = function(a, b) {
                if ((a.ownerDocument || a) !== E && Z(a), !(!v.matchesSelector || !ba || La[b + " "] || xa && xa.test(b) || N && N.test(b))) try {
                    var c = ca.call(a, b);
                    if (c || v.disconnectedMatch || a.document && 11 !== a.document.nodeType) return c
                } catch (uc) {
                    La(b, !0)
                }
                return 0 < f(b, E, null, [a]).length
            }, f.contains = function(a, f) {
                return (a.ownerDocument || a) !== E && Z(a), S(a, f)
            }, f.attr = function(a, f) {
                (a.ownerDocument ||
                    a) !== E && Z(a);
                var b = z.attrHandle[f.toLowerCase()];
                b = b && K.call(z.attrHandle, f.toLowerCase()) ? b(a, f, !ba) : void 0;
                return void 0 !== b ? b : v.attributes || !ba ? a.getAttribute(f) : (b = a.getAttributeNode(f)) && b.specified ? b.value : null
            }, f.escape = function(a) {
                return (a + "").replace(cb, ja)
            }, f.error = function(a) {
                throw Error("Syntax error, unrecognized expression: " + a);
            }, f.uniqueSort = function(a) {
                var f, b = [],
                    c = 0,
                    d = 0;
                if (L = !v.detectDuplicates, X = !v.sortStable && a.slice(0), a.sort(Fa), L) {
                    for (; f = a[d++];) f === a[d] && (c = b.push(d));
                    for (; c--;) a.splice(b[c],
                        1)
                }
                return X = null, a
            }, ha = f.getText = function(a) {
                var f, b = "",
                    c = 0;
                if (f = a.nodeType)
                    if (1 === f || 9 === f || 11 === f) {
                        if ("string" == typeof a.textContent) return a.textContent;
                        for (a = a.firstChild; a; a = a.nextSibling) b += ha(a)
                    } else {
                        if (3 === f || 4 === f) return a.nodeValue
                    }
                else
                    for (; f = a[c++];) b += ha(f);
                return b
            }, (z = f.selectors = {
                cacheLength: 50,
                createPseudo: c,
                match: Q,
                attrHandle: {},
                find: {},
                relative: {
                    "\x3e": {
                        dir: "parentNode",
                        first: !0
                    },
                    " ": {
                        dir: "parentNode"
                    },
                    "+": {
                        dir: "previousSibling",
                        first: !0
                    },
                    "~": {
                        dir: "previousSibling"
                    }
                },
                preFilter: {
                    ATTR: function(a) {
                        return a[1] =
                            a[1].replace(T, U), a[3] = (a[3] || a[4] || a[5] || "").replace(T, U), "~\x3d" === a[2] && (a[3] = " " + a[3] + " "), a.slice(0, 4)
                    },
                    CHILD: function(a) {
                        return a[1] = a[1].toLowerCase(), "nth" === a[1].slice(0, 3) ? (a[3] || f.error(a[0]), a[4] = +(a[4] ? a[5] + (a[6] || 1) : 2 * ("even" === a[3] || "odd" === a[3])), a[5] = +(a[7] + a[8] || "odd" === a[3])) : a[3] && f.error(a[0]), a
                    },
                    PSEUDO: function(a) {
                        var f, b = !a[6] && a[2];
                        return Q.CHILD.test(a[0]) ? null : (a[3] ? a[2] = a[4] || a[5] || "" : b && pa.test(b) && (f = J(b, !0)) && (f = b.indexOf(")", b.length - f) - b.length) && (a[0] = a[0].slice(0,
                            f), a[2] = b.slice(0, f)), a.slice(0, 3))
                    }
                },
                filter: {
                    TAG: function(a) {
                        var f = a.replace(T, U).toLowerCase();
                        return "*" === a ? function() {
                            return !0
                        } : function(a) {
                            return a.nodeName && a.nodeName.toLowerCase() === f
                        }
                    },
                    CLASS: function(a) {
                        var f = la[a + " "];
                        return f || (f = new RegExp("(^|[\\x20\\t\\r\\n\\f])" + a + "([\\x20\\t\\r\\n\\f]|$)"), la(a, function(a) {
                            return f.test("string" == typeof a.className && a.className || "undefined" != typeof a.getAttribute && a.getAttribute("class") || "")
                        }))
                    },
                    ATTR: function(a, b, c) {
                        return function(d) {
                            d = f.attr(d,
                                a);
                            return null == d ? "!\x3d" === b : !b || (d += "", "\x3d" === b ? d === c : "!\x3d" === b ? d !== c : "^\x3d" === b ? c && 0 === d.indexOf(c) : "*\x3d" === b ? c && -1 < d.indexOf(c) : "$\x3d" === b ? c && d.slice(-c.length) === c : "~\x3d" === b ? -1 < (" " + d.replace(kb, " ") + " ").indexOf(c) : "|\x3d" === b && (d === c || d.slice(0, c.length + 1) === c + "-"))
                        }
                    },
                    CHILD: function(a, f, b, c, d) {
                        var e = "nth" !== a.slice(0, 3),
                            h = "last" !== a.slice(-4),
                            m = "of-type" === f;
                        return 1 === c && 0 === d ? function(a) {
                            return !!a.parentNode
                        } : function(f, b, p) {
                            var g, r, n, k;
                            b = e !== h ? "nextSibling" : "previousSibling";
                            var q =
                                f.parentNode,
                                l = m && f.nodeName.toLowerCase(),
                                P = !p && !m,
                                I = !1;
                            if (q) {
                                if (e) {
                                    for (; b;) {
                                        for (n = f; n = n[b];)
                                            if (m ? n.nodeName.toLowerCase() === l : 1 === n.nodeType) return !1;
                                        var u = b = "only" === a && !u && "nextSibling"
                                    }
                                    return !0
                                }
                                if (u = [h ? q.firstChild : q.lastChild], h && P)
                                    for (I = (k = (g = (p = (r = (n = q)[x] || (n[x] = {}))[n.uniqueID] || (r[n.uniqueID] = {}))[a] || [])[0] === O && g[1]) && g[2], n = k && q.childNodes[k]; n = ++k && n && n[b] || (I = k = 0) || u.pop();) {
                                        if (1 === n.nodeType && ++I && n === f) {
                                            p[a] = [O, k, I];
                                            break
                                        }
                                    } else if (P && (I = k = (g = ((r = (n = f)[x] || (n[x] = {}))[n.uniqueID] ||
                                            (r[n.uniqueID] = {}))[a] || [])[0] === O && g[1]), !1 === I)
                                        for (;
                                            (n = ++k && n && n[b] || (I = k = 0) || u.pop()) && ((m ? n.nodeName.toLowerCase() !== l : 1 !== n.nodeType) || !++I || (P && ((p = (r = n[x] || (n[x] = {}))[n.uniqueID] || (r[n.uniqueID] = {}))[a] = [O, I]), n !== f)););
                                return (I -= d) === c || 0 == I % c && 0 <= I / c
                            }
                        }
                    },
                    PSEUDO: function(a, b) {
                        var d, h = z.pseudos[a] || z.setFilters[a.toLowerCase()] || f.error("unsupported pseudo: " + a);
                        return h[x] ? h(b) : 1 < h.length ? (d = [a, a, "", b], z.setFilters.hasOwnProperty(a.toLowerCase()) ? c(function(a, f) {
                            for (var c, d = h(a, b), e = d.length; e--;) a[c =
                                fa(a, d[e])] = !(f[c] = d[e])
                        }) : function(a) {
                            return h(a, 0, d)
                        }) : h
                    }
                },
                pseudos: {
                    not: c(function(a) {
                        var f = [],
                            b = [],
                            d = B(a.replace(va, "$1"));
                        return d[x] ? c(function(a, f, b, c) {
                            var h;
                            b = d(a, null, c, []);
                            for (c = a.length; c--;)(h = b[c]) && (a[c] = !(f[c] = h))
                        }) : function(a, c, h) {
                            return f[0] = a, d(f, null, h, b), f[0] = null, !b.pop()
                        }
                    }),
                    has: c(function(a) {
                        return function(b) {
                            return 0 < f(a, b).length
                        }
                    }),
                    contains: c(function(a) {
                        return a = a.replace(T, U),
                            function(f) {
                                return -1 < (f.textContent || ha(f)).indexOf(a)
                            }
                    }),
                    lang: c(function(a) {
                        return V.test(a || "") ||
                            f.error("unsupported lang: " + a), a = a.replace(T, U).toLowerCase(),
                            function(f) {
                                var b;
                                do
                                    if (b = ba ? f.lang : f.getAttribute("xml:lang") || f.getAttribute("lang")) return (b = b.toLowerCase()) === a || 0 === b.indexOf(a + "-"); while ((f = f.parentNode) && 1 === f.nodeType);
                                return !1
                            }
                    }),
                    target: function(f) {
                        var b = a.location && a.location.hash;
                        return b && b.slice(1) === f.id
                    },
                    root: function(a) {
                        return a === C
                    },
                    focus: function(a) {
                        return a === E.activeElement && (!E.hasFocus || E.hasFocus()) && !!(a.type || a.href || ~a.tabIndex)
                    },
                    enabled: g(!1),
                    disabled: g(!0),
                    checked: function(a) {
                        var f = a.nodeName.toLowerCase();
                        return "input" === f && !!a.checked || "option" === f && !!a.selected
                    },
                    selected: function(a) {
                        return a.parentNode && a.parentNode.selectedIndex, !0 === a.selected
                    },
                    empty: function(a) {
                        for (a = a.firstChild; a; a = a.nextSibling)
                            if (6 > a.nodeType) return !1;
                        return !0
                    },
                    parent: function(a) {
                        return !z.pseudos.empty(a)
                    },
                    header: function(a) {
                        return jb.test(a.nodeName)
                    },
                    input: function(a) {
                        return wa.test(a.nodeName)
                    },
                    button: function(a) {
                        var f = a.nodeName.toLowerCase();
                        return "input" === f && "button" ===
                            a.type || "button" === f
                    },
                    text: function(a) {
                        var f;
                        return "input" === a.nodeName.toLowerCase() && "text" === a.type && (null == (f = a.getAttribute("type")) || "text" === f.toLowerCase())
                    },
                    first: n(function() {
                        return [0]
                    }),
                    last: n(function(a, f) {
                        return [f - 1]
                    }),
                    eq: n(function(a, f, b) {
                        return [0 > b ? b + f : b]
                    }),
                    even: n(function(a, f) {
                        for (var b = 0; b < f; b += 2) a.push(b);
                        return a
                    }),
                    odd: n(function(a, f) {
                        for (var b = 1; b < f; b += 2) a.push(b);
                        return a
                    }),
                    lt: n(function(a, f, b) {
                        for (f = 0 > b ? b + f : f < b ? f : b; 0 <= --f;) a.push(f);
                        return a
                    }),
                    gt: n(function(a, f, b) {
                        for (b = 0 > b ?
                            b + f : b; ++b < f;) a.push(b);
                        return a
                    })
                }
            }).pseudos.nth = z.pseudos.eq, {
                radio: !0,
                checkbox: !0,
                file: !0,
                password: !0,
                image: !0
            }) z.pseudos[F] = m(F);
        for (F in {
                submit: !0,
                reset: !0
            }) z.pseudos[F] = p(F);
        return l.prototype = z.filters = z.pseudos, z.setFilters = new l, J = f.tokenize = function(a, b) {
            var c, d, h, e, m, p;
            if (m = G[a + " "]) return b ? 0 : m.slice(0);
            m = a;
            var g = [];
            for (p = z.preFilter; m;) {
                for (e in c && !(d = ma.exec(m)) || (d && (m = m.slice(d[0].length) || m), g.push(h = [])), c = !1, (d = ia.exec(m)) && (c = d.shift(), h.push({
                            value: c,
                            type: d[0].replace(va, " ")
                        }),
                        m = m.slice(c.length)), z.filter) !(d = Q[e].exec(m)) || p[e] && !(d = p[e](d)) || (c = d.shift(), h.push({
                    value: c,
                    type: e,
                    matches: d
                }), m = m.slice(c.length));
                if (!c) break
            }
            return b ? m.length : m ? f.error(a) : G(a, g).slice(0)
        }, B = f.compile = function(a, b) {
            var d, h, e, m, p = [],
                g = [],
                r = bb[a + " "];
            if (!r) {
                b || (b = J(a));
                for (d = b.length; d--;)(r = H(b[d]))[x] ? p.push(r) : g.push(r);
                (r = bb(a, (h = 0 < p.length, e = 0 < g.length, m = function(a, b, c, d, m) {
                    var r, n, k = 0,
                        q = "0",
                        l = a && [],
                        P = [],
                        I = Ea,
                        u = a || e && z.find.TAG("*", m),
                        $a = O += null == I ? 1 : Math.random() || .1,
                        t = u.length;
                    for (m &&
                        (Ea = b === E || b || m); q !== t && null != (r = u[q]); q++) {
                        if (e && r) {
                            var Ga = 0;
                            for (b || r.ownerDocument === E || (Z(r), c = !ba); n = g[Ga++];)
                                if (n(r, b || E, c)) {
                                    d.push(r);
                                    break
                                }
                            m && (O = $a)
                        }
                        h && ((r = !n && r) && k--, a && l.push(r))
                    }
                    if (k += q, h && q !== k) {
                        for (Ga = 0; n = p[Ga++];) n(l, P, b, c);
                        if (a) {
                            if (0 < k)
                                for (; q--;) l[q] || P[q] || (P[q] = M.call(d));
                            P = w(P)
                        }
                        R.apply(d, P);
                        m && !a && 0 < P.length && 1 < k + p.length && f.uniqueSort(d)
                    }
                    return m && (O = $a, Ea = I), l
                }, h ? c(m) : m))).selector = a
            }
            return r
        }, y = f.select = function(a, f, b, c) {
            var d, h, e, m, p, g = "function" == typeof a && a,
                r = !c && J(a = g.selector ||
                    a);
            if (b = b || [], 1 === r.length) {
                if (2 < (h = r[0] = r[0].slice(0)).length && "ID" === (e = h[0]).type && 9 === f.nodeType && ba && z.relative[h[1].type]) {
                    if (!(f = (z.find.ID(e.matches[0].replace(T, U), f) || [])[0])) return b;
                    g && (f = f.parentNode);
                    a = a.slice(h.shift().value.length)
                }
                for (d = Q.needsContext.test(a) ? 0 : h.length; d-- && (e = h[d], !z.relative[m = e.type]);)
                    if ((p = z.find[m]) && (c = p(e.matches[0].replace(T, U), qa.test(h[0].type) && k(f.parentNode) || f))) {
                        if (h.splice(d, 1), !(a = c.length && q(h))) return R.apply(b, c), b;
                        break
                    }
            }
            return (g || B(a, r))(c,
                f, !ba, b, !f || qa.test(a) && k(f.parentNode) || f), b
        }, v.sortStable = x.split("").sort(Fa).join("") === x, v.detectDuplicates = !!L, Z(), v.sortDetached = d(function(a) {
            return 1 & a.compareDocumentPosition(E.createElement("fieldset"))
        }), d(function(a) {
            return a.innerHTML = "\x3ca href\x3d'#'\x3e\x3c/a\x3e", "#" === a.firstChild.getAttribute("href")
        }) || e("type|href|height|width", function(a, f, b) {
            if (!b) return a.getAttribute(f, "type" === f.toLowerCase() ? 1 : 2)
        }), v.attributes && d(function(a) {
            return a.innerHTML = "\x3cinput/\x3e", a.firstChild.setAttribute("value",
                ""), "" === a.firstChild.getAttribute("value")
        }) || e("value", function(a, f, b) {
            if (!b && "input" === a.nodeName.toLowerCase()) return a.defaultValue
        }), d(function(a) {
            return null == a.getAttribute("disabled")
        }) || e("checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped", function(a, f, b) {
            var c;
            if (!b) return !0 === a[f] ? f.toLowerCase() : (c = a.getAttributeNode(f)) && c.specified ? c.value : null
        }), f
    }(a);
    k.find = sa;
    k.expr = sa.selectors;
    k.expr[":"] = k.expr.pseudos;
    k.uniqueSort =
        k.unique = sa.uniqueSort;
    k.text = sa.getText;
    k.isXMLDoc = sa.isXML;
    k.contains = sa.contains;
    k.escapeSelector = sa.escape;
    var U = function(a, b, c) {
            for (var f = [], d = void 0 !== c;
                (a = a[b]) && 9 !== a.nodeType;)
                if (1 === a.nodeType) {
                    if (d && k(a).is(c)) break;
                    f.push(a)
                }
            return f
        },
        Ca = function(a, b) {
            for (var f = []; a; a = a.nextSibling) 1 === a.nodeType && a !== b && f.push(a);
            return f
        },
        ya = k.expr.match.needsContext,
        Sa = /^<([a-z][^\/\0>:\x20\t\r\n\f]*)[\x20\t\r\n\f]*\/?>(?:<\/\1>|)$/i;
    k.filter = function(a, b, c) {
        var f = b[0];
        return c && (a = ":not(" + a + ")"), 1 ===
            b.length && 1 === f.nodeType ? k.find.matchesSelector(f, a) ? [f] : [] : k.find.matches(a, k.grep(b, function(a) {
                return 1 === a.nodeType
            }))
    };
    k.fn.extend({
        find: function(a) {
            var f, b = this.length,
                c = this;
            if ("string" != typeof a) return this.pushStack(k(a).filter(function() {
                for (f = 0; f < b; f++)
                    if (k.contains(c[f], this)) return !0
            }));
            var d = this.pushStack([]);
            for (f = 0; f < b; f++) k.find(a, c[f], d);
            return 1 < b ? k.uniqueSort(d) : d
        },
        filter: function(a) {
            return this.pushStack(n(this, a || [], !1))
        },
        not: function(a) {
            return this.pushStack(n(this, a || [], !0))
        },
        is: function(a) {
            return !!n(this, "string" == typeof a && ya.test(a) ? k(a) : a || [], !1).length
        }
    });
    var hb = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]+))$/;
    (k.fn.init = function(a, b, c) {
        var f, d;
        if (!a) return this;
        if (c = c || ib, "string" == typeof a) {
            if (!(f = "\x3c" === a[0] && "\x3e" === a[a.length - 1] && 3 <= a.length ? [null, a, null] : hb.exec(a)) || !f[1] && b) return !b || b.jquery ? (b || c).find(a) : this.constructor(b).find(a);
            if (f[1]) {
                if (b = b instanceof k ? b[0] : b, k.merge(this, k.parseHTML(f[1], b && b.nodeType ? b.ownerDocument || b : x, !0)), Sa.test(f[1]) && k.isPlainObject(b))
                    for (f in b) D(this[f]) ?
                        this[f](b[f]) : this.attr(f, b[f]);
                return this
            }
            return (d = x.getElementById(f[2])) && (this[0] = d, this.length = 1), this
        }
        return a.nodeType ? (this[0] = a, this.length = 1, this) : D(a) ? void 0 !== c.ready ? c.ready(a) : a(k) : k.makeArray(a, this)
    }).prototype = k.fn;
    var ib = k(x);
    var Da = /^(?:parents|prev(?:Until|All))/,
        Ta = {
            children: !0,
            contents: !0,
            next: !0,
            prev: !0
        };
    k.fn.extend({
        has: function(a) {
            var f = k(a, this),
                b = f.length;
            return this.filter(function() {
                for (var a = 0; a < b; a++)
                    if (k.contains(this, f[a])) return !0
            })
        },
        closest: function(a, b) {
            var f,
                c = 0,
                d = this.length,
                h = [],
                e = "string" != typeof a && k(a);
            if (!ya.test(a))
                for (; c < d; c++)
                    for (f = this[c]; f && f !== b; f = f.parentNode)
                        if (11 > f.nodeType && (e ? -1 < e.index(f) : 1 === f.nodeType && k.find.matchesSelector(f, a))) {
                            h.push(f);
                            break
                        }
            return this.pushStack(1 < h.length ? k.uniqueSort(h) : h)
        },
        index: function(a) {
            return a ? "string" == typeof a ? Ja.call(k(a), this[0]) : Ja.call(this, a.jquery ? a[0] : a) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
        },
        add: function(a, b) {
            return this.pushStack(k.uniqueSort(k.merge(this.get(), k(a,
                b))))
        },
        addBack: function(a) {
            return this.add(null == a ? this.prevObject : this.prevObject.filter(a))
        }
    });
    k.each({
        parent: function(a) {
            return (a = a.parentNode) && 11 !== a.nodeType ? a : null
        },
        parents: function(a) {
            return U(a, "parentNode")
        },
        parentsUntil: function(a, b, c) {
            return U(a, "parentNode", c)
        },
        next: function(a) {
            return c(a, "nextSibling")
        },
        prev: function(a) {
            return c(a, "previousSibling")
        },
        nextAll: function(a) {
            return U(a, "nextSibling")
        },
        prevAll: function(a) {
            return U(a, "previousSibling")
        },
        nextUntil: function(a, b, c) {
            return U(a,
                "nextSibling", c)
        },
        prevUntil: function(a, b, c) {
            return U(a, "previousSibling", c)
        },
        siblings: function(a) {
            return Ca((a.parentNode || {}).firstChild, a)
        },
        children: function(a) {
            return Ca(a.firstChild)
        },
        contents: function(a) {
            return "undefined" != typeof a.contentDocument ? a.contentDocument : (d(a, "template") && (a = a.content || a), k.merge([], a.childNodes))
        }
    }, function(a, b) {
        k.fn[a] = function(f, c) {
            var d = k.map(this, b, f);
            return "Until" !== a.slice(-5) && (c = f), c && "string" == typeof c && (d = k.filter(c, d)), 1 < this.length && (Ta[a] || k.uniqueSort(d),
                Da.test(a) && d.reverse()), this.pushStack(d)
        }
    });
    var Y = /[^\x20\t\r\n\f]+/g;
    k.Callbacks = function(a) {
        var f, b;
        a = "string" == typeof a ? (f = a, b = {}, k.each(f.match(Y) || [], function(a, f) {
            b[f] = !0
        }), b) : k.extend({}, a);
        var c, d, h, e, m = [],
            p = [],
            n = -1,
            q = function() {
                e = e || a.once;
                for (h = c = !0; p.length; n = -1)
                    for (d = p.shift(); ++n < m.length;) !1 === m[n].apply(d[0], d[1]) && a.stopOnFalse && (n = m.length, d = !1);
                a.memory || (d = !1);
                c = !1;
                e && (m = d ? [] : "")
            },
            l = {
                add: function() {
                    return m && (d && !c && (n = m.length - 1, p.push(d)), function Pb(f) {
                        k.each(f, function(f,
                            b) {
                            D(b) ? a.unique && l.has(b) || m.push(b) : b && b.length && "string" !== g(b) && Pb(b)
                        })
                    }(arguments), d && !c && q()), this
                },
                remove: function() {
                    return k.each(arguments, function(a, f) {
                        for (var b; - 1 < (b = k.inArray(f, m, b));) m.splice(b, 1), b <= n && n--
                    }), this
                },
                has: function(a) {
                    return a ? -1 < k.inArray(a, m) : 0 < m.length
                },
                empty: function() {
                    return m && (m = []), this
                },
                disable: function() {
                    return e = p = [], m = d = "", this
                },
                disabled: function() {
                    return !m
                },
                lock: function() {
                    return e = p = [], d || c || (m = d = ""), this
                },
                locked: function() {
                    return !!e
                },
                fireWith: function(a, f) {
                    return e ||
                        (f = [a, (f = f || []).slice ? f.slice() : f], p.push(f), c || q()), this
                },
                fire: function() {
                    return l.fireWith(this, arguments), this
                },
                fired: function() {
                    return !!h
                }
            };
        return l
    };
    k.extend({
        Deferred: function(f) {
            var b = [
                    ["notify", "progress", k.Callbacks("memory"), k.Callbacks("memory"), 2],
                    ["resolve", "done", k.Callbacks("once memory"), k.Callbacks("once memory"), 0, "resolved"],
                    ["reject", "fail", k.Callbacks("once memory"), k.Callbacks("once memory"), 1, "rejected"]
                ],
                c = "pending",
                d = {
                    state: function() {
                        return c
                    },
                    always: function() {
                        return e.done(arguments).fail(arguments),
                            this
                    },
                    "catch": function(a) {
                        return d.then(null, a)
                    },
                    pipe: function() {
                        var a = arguments;
                        return k.Deferred(function(f) {
                            k.each(b, function(b, c) {
                                var d = D(a[c[4]]) && a[c[4]];
                                e[c[1]](function() {
                                    var a = d && d.apply(this, arguments);
                                    a && D(a.promise) ? a.promise().progress(f.notify).done(f.resolve).fail(f.reject) : f[c[0] + "With"](this, d ? [a] : arguments)
                                })
                            });
                            a = null
                        }).promise()
                    },
                    then: function(f, c, d) {
                        function e(f, b, c, d) {
                            return function() {
                                var p = this,
                                    g = arguments,
                                    n = function() {
                                        var a;
                                        if (!(f < m)) {
                                            if ((a = c.apply(p, g)) === b.promise()) throw new TypeError("Thenable self-resolution");
                                            var n = a && ("object" == typeof a || "function" == typeof a) && a.then;
                                            D(n) ? d ? n.call(a, e(m, b, h, d), e(m, b, q, d)) : (m++, n.call(a, e(m, b, h, d), e(m, b, q, d), e(m, b, h, b.notifyWith))) : (c !== h && (p = void 0, g = [a]), (d || b.resolveWith)(p, g))
                                        }
                                    },
                                    r = d ? n : function() {
                                        try {
                                            n()
                                        } catch (Ab) {
                                            k.Deferred.exceptionHook && k.Deferred.exceptionHook(Ab, r.stackTrace), m <= f + 1 && (c !== q && (p = void 0, g = [Ab]), b.rejectWith(p, g))
                                        }
                                    };
                                f ? r() : (k.Deferred.getStackHook && (r.stackTrace = k.Deferred.getStackHook()), a.setTimeout(r))
                            }
                        }
                        var m = 0;
                        return k.Deferred(function(a) {
                            b[0][3].add(e(0,
                                a, D(d) ? d : h, a.notifyWith));
                            b[1][3].add(e(0, a, D(f) ? f : h));
                            b[2][3].add(e(0, a, D(c) ? c : q))
                        }).promise()
                    },
                    promise: function(a) {
                        return null != a ? k.extend(a, d) : d
                    }
                },
                e = {};
            return k.each(b, function(a, f) {
                var h = f[2],
                    m = f[5];
                d[f[1]] = h.add;
                m && h.add(function() {
                    c = m
                }, b[3 - a][2].disable, b[3 - a][3].disable, b[0][2].lock, b[0][3].lock);
                h.add(f[3].fire);
                e[f[0]] = function() {
                    return e[f[0] + "With"](this === e ? void 0 : this, arguments), this
                };
                e[f[0] + "With"] = h.fireWith
            }), d.promise(e), f && f.call(e, e), e
        },
        when: function(a) {
            var f = arguments.length,
                b =
                f,
                c = Array(b),
                d = ta.call(arguments),
                e = k.Deferred(),
                h = function(a) {
                    return function(b) {
                        c[a] = this;
                        d[a] = 1 < arguments.length ? ta.call(arguments) : b;
                        --f || e.resolveWith(c, d)
                    }
                };
            if (1 >= f && (m(a, e.done(h(b)).resolve, e.reject, !f), "pending" === e.state() || D(d[b] && d[b].then))) return e.then();
            for (; b--;) m(d[b], h(b), e.reject);
            return e.promise()
        }
    });
    var ha = /^(Eval|Internal|Range|Reference|Syntax|Type|URI)Error$/;
    k.Deferred.exceptionHook = function(f, b) {
        a.console && a.console.warn && f && ha.test(f.name) && a.console.warn("jQuery.Deferred exception: " +
            f.message, f.stack, b)
    };
    k.readyException = function(f) {
        a.setTimeout(function() {
            throw f;
        })
    };
    var Ea = k.Deferred();
    k.fn.ready = function(a) {
        return Ea.then(a)["catch"](function(a) {
            k.readyException(a)
        }), this
    };
    k.extend({
        isReady: !1,
        readyWait: 1,
        ready: function(a) {
            (!0 === a ? --k.readyWait : k.isReady) || (k.isReady = !0) !== a && 0 < --k.readyWait || Ea.resolveWith(x, [k])
        }
    });
    k.ready.then = Ea.then;
    "complete" === x.readyState || "loading" !== x.readyState && !x.documentElement.doScroll ? a.setTimeout(k.ready) : (x.addEventListener("DOMContentLoaded",
        p), a.addEventListener("load", p));
    var ba = function(a, b, c, d, e, h, m) {
            var f = 0,
                p = a.length,
                n = null == c;
            if ("object" === g(c))
                for (f in e = !0, c) ba(a, b, f, c[f], !0, h, m);
            else if (void 0 !== d && (e = !0, D(d) || (m = !0), n && (m ? (b.call(a, d), b = null) : (n = b, b = function(a, f, b) {
                    return n.call(k(a), b)
                })), b))
                for (; f < p; f++) b(a[f], c, m ? d : d.call(a[f], f, b(a[f], c)));
            return e ? a : n ? b.call(a) : p ? b(a[0], c) : h
        },
        xa = /^-ms-/,
        La = /-([a-z])/g,
        Fa = function(a) {
            return 1 === a.nodeType || 9 === a.nodeType || !+a.nodeType
        };
    y.uid = 1;
    y.prototype = {
        cache: function(a) {
            var f = a[this.expando];
            return f || (f = {}, Fa(a) && (a.nodeType ? a[this.expando] = f : Object.defineProperty(a, this.expando, {
                value: f,
                configurable: !0
            }))), f
        },
        set: function(a, b, c) {
            var f;
            a = this.cache(a);
            if ("string" == typeof b) a[t(b)] = c;
            else
                for (f in b) a[t(f)] = b[f];
            return a
        },
        get: function(a, b) {
            return void 0 === b ? this.cache(a) : a[this.expando] && a[this.expando][t(b)]
        },
        access: function(a, b, c) {
            return void 0 === b || b && "string" == typeof b && void 0 === c ? this.get(a, b) : (this.set(a, b, c), void 0 !== c ? c : b)
        },
        remove: function(a, b) {
            var f = a[this.expando];
            if (void 0 !==
                f) {
                if (void 0 !== b) {
                    var c = (b = Array.isArray(b) ? b.map(t) : (b = t(b)) in f ? [b] : b.match(Y) || []).length;
                    for (; c--;) delete f[b[c]]
                }(void 0 === b || k.isEmptyObject(f)) && (a.nodeType ? a[this.expando] = void 0 : delete a[this.expando])
            }
        },
        hasData: function(a) {
            a = a[this.expando];
            return void 0 !== a && !k.isEmptyObject(a)
        }
    };
    var C = new y,
        ca = new y,
        cb = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
        bb = /[A-Z]/g;
    k.extend({
        hasData: function(a) {
            return ca.hasData(a) || C.hasData(a)
        },
        data: function(a, b, c) {
            return ca.access(a, b, c)
        },
        removeData: function(a, b) {
            ca.remove(a,
                b)
        },
        _data: function(a, b, c) {
            return C.access(a, b, c)
        },
        _removeData: function(a, b) {
            C.remove(a, b)
        }
    });
    k.fn.extend({
        data: function(a, b) {
            var f, c, d, e = this[0],
                h = e && e.attributes;
            if (void 0 === a) {
                if (this.length && (d = ca.get(e), 1 === e.nodeType && !C.get(e, "hasDataAttrs"))) {
                    for (f = h.length; f--;) h[f] && 0 === (c = h[f].name).indexOf("data-") && (c = t(c.slice(5)), v(e, c, d[c]));
                    C.set(e, "hasDataAttrs", !0)
                }
                return d
            }
            return "object" == typeof a ? this.each(function() {
                ca.set(this, a)
            }) : ba(this, function(b) {
                var f;
                if (e && void 0 === b) return void 0 !== (f =
                    ca.get(e, a)) ? f : void 0 !== (f = v(e, a)) ? f : void 0;
                this.each(function() {
                    ca.set(this, a, b)
                })
            }, null, b, 1 < arguments.length, null, !0)
        },
        removeData: function(a) {
            return this.each(function() {
                ca.remove(this, a)
            })
        }
    });
    k.extend({
        queue: function(a, b, c) {
            var f;
            if (a) return b = (b || "fx") + "queue", f = C.get(a, b), c && (!f || Array.isArray(c) ? f = C.access(a, b, k.makeArray(c)) : f.push(c)), f || []
        },
        dequeue: function(a, b) {
            b = b || "fx";
            var f = k.queue(a, b),
                c = f.length,
                d = f.shift(),
                e = k._queueHooks(a, b);
            "inprogress" === d && (d = f.shift(), c--);
            d && ("fx" === b && f.unshift("inprogress"),
                delete e.stop, d.call(a, function() {
                    k.dequeue(a, b)
                }, e));
            !c && e && e.empty.fire()
        },
        _queueHooks: function(a, b) {
            var f = b + "queueHooks";
            return C.get(a, f) || C.access(a, f, {
                empty: k.Callbacks("once memory").add(function() {
                    C.remove(a, [b + "queue", f])
                })
            })
        }
    });
    k.fn.extend({
        queue: function(a, b) {
            var f = 2;
            return "string" != typeof a && (b = a, a = "fx", f--), arguments.length < f ? k.queue(this[0], a) : void 0 === b ? this : this.each(function() {
                var f = k.queue(this, a, b);
                k._queueHooks(this, a);
                "fx" === a && "inprogress" !== f[0] && k.dequeue(this, a)
            })
        },
        dequeue: function(a) {
            return this.each(function() {
                k.dequeue(this,
                    a)
            })
        },
        clearQueue: function(a) {
            return this.queue(a || "fx", [])
        },
        promise: function(a, b) {
            var f, c = 1,
                d = k.Deferred(),
                e = this,
                h = this.length,
                m = function() {
                    --c || d.resolveWith(e, [e])
                };
            "string" != typeof a && (b = a, a = void 0);
            for (a = a || "fx"; h--;)(f = C.get(e[h], a + "queueHooks")) && f.empty && (c++, f.empty.add(m));
            return m(), d.promise(b)
        }
    });
    var jb = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
        va = new RegExp("^(?:([+-])\x3d|)(" + jb + ")([a-z%]*)$", "i"),
        qa = ["Top", "Right", "Bottom", "Left"],
        Ua = x.documentElement,
        ra = function(a) {
            return k.contains(a.ownerDocument,
                a)
        },
        Ub = {
            composed: !0
        };
    Ua.getRootNode && (ra = function(a) {
        return k.contains(a.ownerDocument, a) || a.getRootNode(Ub) === a.ownerDocument
    });
    var db = function(a, b) {
            return "none" === (a = b || a).style.display || "" === a.style.display && ra(a) && "none" === k.css(a, "display")
        },
        kb = function(a, b, c, d) {
            var f, e = {};
            for (f in b) e[f] = a.style[f], a.style[f] = b[f];
            for (f in c = c.apply(a, d || []), b) a.style[f] = e[f];
            return c
        },
        tb = {};
    k.fn.extend({
        show: function() {
            return J(this, !0)
        },
        hide: function() {
            return J(this)
        },
        toggle: function(a) {
            return "boolean" == typeof a ?
                a ? this.show() : this.hide() : this.each(function() {
                    db(this) ? k(this).show() : k(this).hide()
                })
        }
    });
    var Va = /^(?:checkbox|radio)$/i,
        ub = /<([a-z][^\/\0>\x20\t\r\n\f]*)/i,
        vb = /^$|^module$|\/(?:java|ecma)script/i,
        oa = {
            option: [1, "\x3cselect multiple\x3d'multiple'\x3e", "\x3c/select\x3e"],
            thead: [1, "\x3ctable\x3e", "\x3c/table\x3e"],
            col: [2, "\x3ctable\x3e\x3ccolgroup\x3e", "\x3c/colgroup\x3e\x3c/table\x3e"],
            tr: [2, "\x3ctable\x3e\x3ctbody\x3e", "\x3c/tbody\x3e\x3c/table\x3e"],
            td: [3, "\x3ctable\x3e\x3ctbody\x3e\x3ctr\x3e", "\x3c/tr\x3e\x3c/tbody\x3e\x3c/table\x3e"],
            _default: [0, "", ""]
        };
    oa.optgroup = oa.option;
    oa.tbody = oa.tfoot = oa.colgroup = oa.caption = oa.thead;
    oa.th = oa.td;
    var lb, Nb = /<|&#?\w+;/;
    var mb = x.createDocumentFragment().appendChild(x.createElement("div"));
    (lb = x.createElement("input")).setAttribute("type", "radio");
    lb.setAttribute("checked", "checked");
    lb.setAttribute("name", "t");
    mb.appendChild(lb);
    M.checkClone = mb.cloneNode(!0).cloneNode(!0).lastChild.checked;
    mb.innerHTML = "\x3ctextarea\x3ex\x3c/textarea\x3e";
    M.noCloneChecked = !!mb.cloneNode(!0).lastChild.defaultValue;
    var Vb = /^key/,
        Wb = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
        Bb = /^([^.]*)(?:\.(.+)|)/;
    k.event = {
        global: {},
        add: function(a, b, c, d, e) {
            var f, h, m, p, g, n, r, q, l;
            if (g = C.get(a))
                for (c.handler && (c = (f = c).handler, e = f.selector), e && k.find.matchesSelector(Ua, e), c.guid || (c.guid = k.guid++), (p = g.events) || (p = g.events = {}), (h = g.handle) || (h = g.handle = function(b) {
                        return "undefined" != typeof k && k.event.triggered !== b.type ? k.event.dispatch.apply(a, arguments) : void 0
                    }), g = (b = (b || "").match(Y) || [""]).length; g--;) {
                    var u = l = (m = Bb.exec(b[g]) || [])[1];
                    m = (m[2] || "").split(".").sort();
                    u && (r = k.event.special[u] || {}, u = (e ? r.delegateType : r.bindType) || u, r = k.event.special[u] || {}, n = k.extend({
                            type: u,
                            origType: l,
                            data: d,
                            handler: c,
                            guid: c.guid,
                            selector: e,
                            needsContext: e && k.expr.match.needsContext.test(e),
                            namespace: m.join(".")
                        }, f), (q = p[u]) || ((q = p[u] = []).delegateCount = 0, r.setup && !1 !== r.setup.call(a, d, m, h) || a.addEventListener && a.addEventListener(u, h)), r.add && (r.add.call(a, n), n.handler.guid || (n.handler.guid = c.guid)), e ? q.splice(q.delegateCount++, 0, n) : q.push(n),
                        k.event.global[u] = !0)
                }
        },
        remove: function(a, b, c, d, e) {
            var f, h, m, p, g, n, r, q, l = C.hasData(a) && C.get(a);
            if (l && (p = l.events)) {
                for (g = (b = (b || "").match(Y) || [""]).length; g--;)
                    if (n = q = (m = Bb.exec(b[g]) || [])[1], r = (m[2] || "").split(".").sort(), n) {
                        var u = k.event.special[n] || {};
                        var P = p[n = (d ? u.delegateType : u.bindType) || n] || [];
                        m = m[2] && new RegExp("(^|\\.)" + r.join("\\.(?:.*\\.|)") + "(\\.|$)");
                        for (h = f = P.length; f--;) {
                            var I = P[f];
                            !e && q !== I.origType || c && c.guid !== I.guid || m && !m.test(I.namespace) || d && d !== I.selector && ("**" !== d || !I.selector) ||
                                (P.splice(f, 1), I.selector && P.delegateCount--, u.remove && u.remove.call(a, I))
                        }
                        h && !P.length && (u.teardown && !1 !== u.teardown.call(a, r, l.handle) || k.removeEvent(a, n, l.handle), delete p[n])
                    } else
                        for (n in p) k.event.remove(a, n + b[g], c, d, !0);
                k.isEmptyObject(p) && C.remove(a, "handle events")
            }
        },
        dispatch: function(a) {
            var b, f, c, d, e = k.event.fix(a),
                h = Array(arguments.length);
            var m = (C.get(this, "events") || {})[e.type] || [];
            var p = k.event.special[e.type] || {};
            h[0] = e;
            for (b = 1; b < arguments.length; b++) h[b] = arguments[b];
            if (e.delegateTarget =
                this, !p.preDispatch || !1 !== p.preDispatch.call(this, e)) {
                var g = k.event.handlers.call(this, e, m);
                for (b = 0;
                    (c = g[b++]) && !e.isPropagationStopped();)
                    for (e.currentTarget = c.elem, m = 0;
                        (d = c.handlers[m++]) && !e.isImmediatePropagationStopped();) e.rnamespace && !1 !== d.namespace && !e.rnamespace.test(d.namespace) || (e.handleObj = d, e.data = d.data, void 0 !== (f = ((k.event.special[d.origType] || {}).handle || d.handler).apply(c.elem, h)) && !1 === (e.result = f) && (e.preventDefault(), e.stopPropagation()));
                return p.postDispatch && p.postDispatch.call(this,
                    e), e.result
            }
        },
        handlers: function(a, b) {
            var f, c, d, e = [],
                h = b.delegateCount,
                m = a.target;
            if (h && m.nodeType && !("click" === a.type && 1 <= a.button))
                for (; m !== this; m = m.parentNode || this)
                    if (1 === m.nodeType && ("click" !== a.type || !0 !== m.disabled)) {
                        var p = [];
                        var g = {};
                        for (f = 0; f < h; f++) void 0 === g[d = (c = b[f]).selector + " "] && (g[d] = c.needsContext ? -1 < k(d, this).index(m) : k.find(d, this, null, [m]).length), g[d] && p.push(c);
                        p.length && e.push({
                            elem: m,
                            handlers: p
                        })
                    }
            return m = this, h < b.length && e.push({
                elem: m,
                handlers: b.slice(h)
            }), e
        },
        addProp: function(a,
            b) {
            Object.defineProperty(k.Event.prototype, a, {
                enumerable: !0,
                configurable: !0,
                get: D(b) ? function() {
                    if (this.originalEvent) return b(this.originalEvent)
                } : function() {
                    if (this.originalEvent) return this.originalEvent[a]
                },
                set: function(b) {
                    Object.defineProperty(this, a, {
                        enumerable: !0,
                        configurable: !0,
                        writable: !0,
                        value: b
                    })
                }
            })
        },
        fix: function(a) {
            return a[k.expando] ? a : new k.Event(a)
        },
        special: {
            load: {
                noBubble: !0
            },
            click: {
                setup: function(a) {
                    a = this || a;
                    return Va.test(a.type) && a.click && d(a, "input") && W(a, "click", ia), !1
                },
                trigger: function(a) {
                    a =
                        this || a;
                    return Va.test(a.type) && a.click && d(a, "input") && W(a, "click"), !0
                },
                _default: function(a) {
                    a = a.target;
                    return Va.test(a.type) && a.click && d(a, "input") && C.get(a, "click") || d(a, "a")
                }
            },
            beforeunload: {
                postDispatch: function(a) {
                    void 0 !== a.result && a.originalEvent && (a.originalEvent.returnValue = a.result)
                }
            }
        }
    };
    k.removeEvent = function(a, b, c) {
        a.removeEventListener && a.removeEventListener(b, c)
    };
    k.Event = function(a, b) {
        if (!(this instanceof k.Event)) return new k.Event(a, b);
        a && a.type ? (this.originalEvent = a, this.type = a.type,
            this.isDefaultPrevented = a.defaultPrevented || void 0 === a.defaultPrevented && !1 === a.returnValue ? ia : V, this.target = a.target && 3 === a.target.nodeType ? a.target.parentNode : a.target, this.currentTarget = a.currentTarget, this.relatedTarget = a.relatedTarget) : this.type = a;
        b && k.extend(this, b);
        this.timeStamp = a && a.timeStamp || Date.now();
        this[k.expando] = !0
    };
    k.Event.prototype = {
        constructor: k.Event,
        isDefaultPrevented: V,
        isPropagationStopped: V,
        isImmediatePropagationStopped: V,
        isSimulated: !1,
        preventDefault: function() {
            var a = this.originalEvent;
            this.isDefaultPrevented = ia;
            a && !this.isSimulated && a.preventDefault()
        },
        stopPropagation: function() {
            var a = this.originalEvent;
            this.isPropagationStopped = ia;
            a && !this.isSimulated && a.stopPropagation()
        },
        stopImmediatePropagation: function() {
            var a = this.originalEvent;
            this.isImmediatePropagationStopped = ia;
            a && !this.isSimulated && a.stopImmediatePropagation();
            this.stopPropagation()
        }
    };
    k.each({
        altKey: !0,
        bubbles: !0,
        cancelable: !0,
        changedTouches: !0,
        ctrlKey: !0,
        detail: !0,
        eventPhase: !0,
        metaKey: !0,
        pageX: !0,
        pageY: !0,
        shiftKey: !0,
        view: !0,
        "char": !0,
        code: !0,
        charCode: !0,
        key: !0,
        keyCode: !0,
        button: !0,
        buttons: !0,
        clientX: !0,
        clientY: !0,
        offsetX: !0,
        offsetY: !0,
        pointerId: !0,
        pointerType: !0,
        screenX: !0,
        screenY: !0,
        targetTouches: !0,
        toElement: !0,
        touches: !0,
        which: function(a) {
            var b = a.button;
            return null == a.which && Vb.test(a.type) ? null != a.charCode ? a.charCode : a.keyCode : !a.which && void 0 !== b && Wb.test(a.type) ? 1 & b ? 1 : 2 & b ? 3 : 4 & b ? 2 : 0 : a.which
        }
    }, k.event.addProp);
    k.each({
        focus: "focusin",
        blur: "focusout"
    }, function(a, b) {
        k.event.special[a] = {
            setup: function() {
                return W(this,
                    a, ja), !1
            },
            trigger: function() {
                return W(this, a), !0
            },
            delegateType: b
        }
    });
    k.each({
        mouseenter: "mouseover",
        mouseleave: "mouseout",
        pointerenter: "pointerover",
        pointerleave: "pointerout"
    }, function(a, b) {
        k.event.special[a] = {
            delegateType: b,
            bindType: b,
            handle: function(a) {
                var f, c = a.relatedTarget,
                    d = a.handleObj;
                return c && (c === this || k.contains(this, c)) || (a.type = d.origType, f = d.handler.apply(this, arguments), a.type = b), f
            }
        }
    });
    k.fn.extend({
        on: function(a, b, c, d) {
            return G(this, a, b, c, d)
        },
        one: function(a, b, c, d) {
            return G(this, a, b,
                c, d, 1)
        },
        off: function(a, b, c) {
            var f, d;
            if (a && a.preventDefault && a.handleObj) return f = a.handleObj, k(a.delegateTarget).off(f.namespace ? f.origType + "." + f.namespace : f.origType, f.selector, f.handler), this;
            if ("object" == typeof a) {
                for (d in a) this.off(d, b, a[d]);
                return this
            }
            return !1 !== b && "function" != typeof b || (c = b, b = void 0), !1 === c && (c = V), this.each(function() {
                k.event.remove(this, a, c, b)
            })
        }
    });
    var Xb = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([a-z][^\/\0>\x20\t\r\n\f]*)[^>]*)\/>/gi,
        Yb = /<script|<style|<link/i,
        Ob = /checked\s*(?:[^=]|=\s*.checked.)/i,
        Qb = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g;
    k.extend({
        htmlPrefilter: function(a) {
            return a.replace(Xb, "\x3c$1\x3e\x3c/$2\x3e")
        },
        clone: function(a, b, c) {
            var f, d, e, h = a.cloneNode(!0),
                m = ra(a);
            if (!(M.noCloneChecked || 1 !== a.nodeType && 11 !== a.nodeType || k.isXMLDoc(a))) {
                var p = E(h);
                var g = 0;
                for (f = (d = E(a)).length; g < f; g++) {
                    var n = d[g];
                    var r = p[g];
                    void 0;
                    "input" === (e = r.nodeName.toLowerCase()) && Va.test(n.type) ? r.checked = n.checked : "input" !== e && "textarea" !== e || (r.defaultValue = n.defaultValue)
                }
            }
            if (b)
                if (c)
                    for (d =
                        d || E(a), p = p || E(h), g = 0, f = d.length; g < f; g++) w(d[g], p[g]);
                else w(a, h);
            return 0 < (p = E(h, "script")).length && la(p, !m && E(a, "script")), h
        },
        cleanData: function(a) {
            for (var b, f, c, d = k.event.special, e = 0; void 0 !== (f = a[e]); e++)
                if (Fa(f)) {
                    if (b = f[C.expando]) {
                        if (b.events)
                            for (c in b.events) d[c] ? k.event.remove(f, c) : k.removeEvent(f, c, b.handle);
                        f[C.expando] = void 0
                    }
                    f[ca.expando] && (f[ca.expando] = void 0)
                }
        }
    });
    k.fn.extend({
        detach: function(a) {
            return F(this, a, !0)
        },
        remove: function(a) {
            return F(this, a)
        },
        text: function(a) {
            return ba(this,
                function(a) {
                    return void 0 === a ? k.text(this) : this.empty().each(function() {
                        1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || (this.textContent = a)
                    })
                }, null, a, arguments.length)
        },
        append: function() {
            return H(this, arguments, function(a) {
                1 !== this.nodeType && 11 !== this.nodeType && 9 !== this.nodeType || da(this, a).appendChild(a)
            })
        },
        prepend: function() {
            return H(this, arguments, function(a) {
                if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                    var b = da(this, a);
                    b.insertBefore(a, b.firstChild)
                }
            })
        },
        before: function() {
            return H(this,
                arguments,
                function(a) {
                    this.parentNode && this.parentNode.insertBefore(a, this)
                })
        },
        after: function() {
            return H(this, arguments, function(a) {
                this.parentNode && this.parentNode.insertBefore(a, this.nextSibling)
            })
        },
        empty: function() {
            for (var a, b = 0; null != (a = this[b]); b++) 1 === a.nodeType && (k.cleanData(E(a, !1)), a.textContent = "");
            return this
        },
        clone: function(a, b) {
            return a = null != a && a, b = null == b ? a : b, this.map(function() {
                return k.clone(this, a, b)
            })
        },
        html: function(a) {
            return ba(this, function(a) {
                var b = this[0] || {},
                    f = 0,
                    c = this.length;
                if (void 0 === a && 1 === b.nodeType) return b.innerHTML;
                if ("string" == typeof a && !Yb.test(a) && !oa[(ub.exec(a) || ["", ""])[1].toLowerCase()]) {
                    a = k.htmlPrefilter(a);
                    try {
                        for (; f < c; f++) 1 === (b = this[f] || {}).nodeType && (k.cleanData(E(b, !1)), b.innerHTML = a);
                        b = 0
                    } catch (Ga) {}
                }
                b && this.empty().append(a)
            }, null, a, arguments.length)
        },
        replaceWith: function() {
            var a = [];
            return H(this, arguments, function(b) {
                var f = this.parentNode;
                0 > k.inArray(this, a) && (k.cleanData(E(this)), f && f.replaceChild(b, this))
            }, a)
        }
    });
    k.each({
        appendTo: "append",
        prependTo: "prepend",
        insertBefore: "before",
        insertAfter: "after",
        replaceAll: "replaceWith"
    }, function(a, b) {
        k.fn[a] = function(a) {
            for (var f = [], c = k(a), d = c.length - 1, e = 0; e <= d; e++) a = e === d ? this : this.clone(!0), k(c[e])[b](a), Oa.apply(f, a.get());
            return this.pushStack(f)
        }
    });
    var nb = new RegExp("^(" + jb + ")(?!px)[a-z%]+$", "i"),
        eb = function(b) {
            var f = b.ownerDocument.defaultView;
            return f && f.opener || (f = a), f.getComputedStyle(b)
        },
        Rb = new RegExp(qa.join("|"), "i");
    ! function() {
        function b() {
            if (g) {
                p.style.cssText = "position:absolute;left:-11111px;width:60px;margin-top:1px;padding:0;border:0";
                g.style.cssText = "position:relative;display:block;box-sizing:border-box;overflow:scroll;margin:auto;border:1px;padding:1px;width:60%;top:1%";
                Ua.appendChild(p).appendChild(g);
                var b = a.getComputedStyle(g);
                c = "1%" !== b.top;
                m = 12 === Math.round(parseFloat(b.marginLeft));
                g.style.right = "60%";
                h = 36 === Math.round(parseFloat(b.right));
                d = 36 === Math.round(parseFloat(b.width));
                g.style.position = "absolute";
                e = 12 === Math.round(parseFloat(g.offsetWidth / 3));
                Ua.removeChild(p);
                g = null
            }
        }
        var c, d, e, h, m, p = x.createElement("div"),
            g = x.createElement("div");
        g.style && (g.style.backgroundClip = "content-box", g.cloneNode(!0).style.backgroundClip = "", M.clearCloneStyle = "content-box" === g.style.backgroundClip, k.extend(M, {
            boxSizingReliable: function() {
                return b(), d
            },
            pixelBoxStyles: function() {
                return b(), h
            },
            pixelPosition: function() {
                return b(), c
            },
            reliableMarginLeft: function() {
                return b(), m
            },
            scrollboxSize: function() {
                return b(), e
            }
        }))
    }();
    var yb = ["Webkit", "Moz", "ms"],
        xb = x.createElement("div").style,
        wb = {},
        Zb = /^(none|table(?!-c[ea]).+)/,
        Cb = /^--/,
        $b = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        },
        Db = {
            letterSpacing: "0",
            fontWeight: "400"
        };
    k.extend({
        cssHooks: {
            opacity: {
                get: function(a, b) {
                    if (b) return a = z(a, "opacity"), "" === a ? "1" : a
                }
            }
        },
        cssNumber: {
            animationIterationCount: !0,
            columnCount: !0,
            fillOpacity: !0,
            flexGrow: !0,
            flexShrink: !0,
            fontWeight: !0,
            gridArea: !0,
            gridColumn: !0,
            gridColumnEnd: !0,
            gridColumnStart: !0,
            gridRow: !0,
            gridRowEnd: !0,
            gridRowStart: !0,
            lineHeight: !0,
            opacity: !0,
            order: !0,
            orphans: !0,
            widows: !0,
            zIndex: !0,
            zoom: !0
        },
        cssProps: {},
        style: function(a, b, c, d) {
            if (a && 3 !== a.nodeType && 8 !== a.nodeType &&
                a.style) {
                var f, e, h, m = t(b),
                    p = Cb.test(b),
                    g = a.style;
                if (p || (b = B(m)), h = k.cssHooks[b] || k.cssHooks[m], void 0 === c) return h && "get" in h && void 0 !== (f = h.get(a, !1, d)) ? f : g[b];
                "string" === (e = typeof c) && (f = va.exec(c)) && f[1] && (c = L(a, b, f), e = "number");
                null != c && c == c && ("number" !== e || p || (c += f && f[3] || (k.cssNumber[m] ? "" : "px")), M.clearCloneStyle || "" !== c || 0 !== b.indexOf("background") || (g[b] = "inherit"), h && "set" in h && void 0 === (c = h.set(a, c, d)) || (p ? g.setProperty(b, c) : g[b] = c))
            }
        },
        css: function(a, b, c, d) {
            var f, e, h, m = t(b);
            return Cb.test(b) ||
                (b = B(m)), (h = k.cssHooks[b] || k.cssHooks[m]) && "get" in h && (f = h.get(a, !0, c)), void 0 === f && (f = z(a, b, d)), "normal" === f && b in Db && (f = Db[b]), "" === c || c ? (e = parseFloat(f), !0 === c || isFinite(e) ? e || 0 : f) : f
        }
    });
    k.each(["height", "width"], function(a, b) {
        k.cssHooks[b] = {
            get: function(a, c, f) {
                if (c) return !Zb.test(k.css(a, "display")) || a.getClientRects().length && a.getBoundingClientRect().width ? N(a, b, f) : kb(a, $b, function() {
                    return N(a, b, f)
                })
            },
            set: function(a, c, f) {
                var d, e = eb(a),
                    h = !M.scrollboxSize() && "absolute" === e.position,
                    m = (h || f) &&
                    "border-box" === k.css(a, "boxSizing", !1, e);
                f = f ? X(a, b, f, m, e) : 0;
                return m && h && (f -= Math.ceil(a["offset" + b[0].toUpperCase() + b.slice(1)] - parseFloat(e[b]) - X(a, b, "border", !1, e) - .5)), f && (d = va.exec(c)) && "px" !== (d[3] || "px") && (a.style[b] = c, c = k.css(a, b)), A(0, c, f)
            }
        }
    });
    k.cssHooks.marginLeft = Z(M.reliableMarginLeft, function(a, b) {
        if (b) return (parseFloat(z(a, "marginLeft")) || a.getBoundingClientRect().left - kb(a, {
            marginLeft: 0
        }, function() {
            return a.getBoundingClientRect().left
        })) + "px"
    });
    k.each({
            margin: "",
            padding: "",
            border: "Width"
        },
        function(a, b) {
            k.cssHooks[a + b] = {
                expand: function(c) {
                    var f = 0,
                        d = {};
                    for (c = "string" == typeof c ? c.split(" ") : [c]; 4 > f; f++) d[a + qa[f] + b] = c[f] || c[f - 2] || c[0];
                    return d
                }
            };
            "margin" !== a && (k.cssHooks[a + b].set = A)
        });
    k.fn.extend({
        css: function(a, b) {
            return ba(this, function(a, b, c) {
                var f, d = {},
                    e = 0;
                if (Array.isArray(b)) {
                    c = eb(a);
                    for (f = b.length; e < f; e++) d[b[e]] = k.css(a, b[e], !1, c);
                    return d
                }
                return void 0 !== c ? k.style(a, b, c) : k.css(a, b)
            }, a, b, 1 < arguments.length)
        }
    });
    ((k.Tween = S).prototype = {
        constructor: S,
        init: function(a, b, c, d, e, h) {
            this.elem =
                a;
            this.prop = c;
            this.easing = e || k.easing._default;
            this.options = b;
            this.start = this.now = this.cur();
            this.end = d;
            this.unit = h || (k.cssNumber[c] ? "" : "px")
        },
        cur: function() {
            var a = S.propHooks[this.prop];
            return a && a.get ? a.get(this) : S.propHooks._default.get(this)
        },
        run: function(a) {
            var b, c = S.propHooks[this.prop];
            return this.options.duration ? this.pos = b = k.easing[this.easing](a, this.options.duration * a, 0, 1, this.options.duration) : this.pos = b = a, this.now = (this.end - this.start) * b + this.start, this.options.step && this.options.step.call(this.elem,
                this.now, this), c && c.set ? c.set(this) : S.propHooks._default.set(this), this
        }
    }).init.prototype = S.prototype;
    (S.propHooks = {
        _default: {
            get: function(a) {
                var b;
                return 1 !== a.elem.nodeType || null != a.elem[a.prop] && null == a.elem.style[a.prop] ? a.elem[a.prop] : (b = k.css(a.elem, a.prop, "")) && "auto" !== b ? b : 0
            },
            set: function(a) {
                k.fx.step[a.prop] ? k.fx.step[a.prop](a) : 1 !== a.elem.nodeType || !k.cssHooks[a.prop] && null == a.elem.style[B(a.prop)] ? a.elem[a.prop] = a.now : k.style(a.elem, a.prop, a.now + a.unit)
            }
        }
    }).scrollTop = S.propHooks.scrollLeft = {
        set: function(a) {
            a.elem.nodeType && a.elem.parentNode && (a.elem[a.prop] = a.now)
        }
    };
    k.easing = {
        linear: function(a) {
            return a
        },
        swing: function(a) {
            return .5 - Math.cos(a * Math.PI) / 2
        },
        _default: "swing"
    };
    k.fx = S.prototype.init;
    k.fx.step = {};
    var Na, fb, ac = /^(?:toggle|show|hide)$/,
        bc = /queueHooks$/;
    k.Animation = k.extend(O, {
        tweeners: {
            "*": [function(a, b) {
                var c = this.createTween(a, b);
                return L(c.elem, a, va.exec(b), c), c
            }]
        },
        tweener: function(a, b) {
            D(a) ? (b = a, a = ["*"]) : a = a.match(Y);
            for (var c, d = 0, f = a.length; d < f; d++) c = a[d], O.tweeners[c] =
                O.tweeners[c] || [], O.tweeners[c].unshift(b)
        },
        prefilters: [function(a, b, c) {
            var d, f, e, h, m, p, g, n = "width" in b || "height" in b,
                q = this,
                l = {},
                r = a.style,
                u = a.nodeType && db(a),
                t = C.get(a, "fxshow");
            for (d in c.queue || (null == (h = k._queueHooks(a, "fx")).unqueued && (h.unqueued = 0, m = h.empty.fire, h.empty.fire = function() {
                    h.unqueued || m()
                }), h.unqueued++, q.always(function() {
                    q.always(function() {
                        h.unqueued--;
                        k.queue(a, "fx").length || h.empty.fire()
                    })
                })), b)
                if (f = b[d], ac.test(f)) {
                    if (delete b[d], e = e || "toggle" === f, f === (u ? "hide" : "show")) {
                        if ("show" !==
                            f || !t || void 0 === t[d]) continue;
                        u = !0
                    }
                    l[d] = t && t[d] || k.style(a, d)
                }
            if ((b = !k.isEmptyObject(b)) || !k.isEmptyObject(l))
                for (d in n && 1 === a.nodeType && (c.overflow = [r.overflow, r.overflowX, r.overflowY], null == (p = t && t.display) && (p = C.get(a, "display")), "none" === (g = k.css(a, "display")) && (p ? g = p : (J([a], !0), p = a.style.display || p, g = k.css(a, "display"), J([a]))), ("inline" === g || "inline-block" === g && null != p) && "none" === k.css(a, "float") && (b || (q.done(function() {
                        r.display = p
                    }), null == p && (g = r.display, p = "none" === g ? "" : g)), r.display = "inline-block")),
                    c.overflow && (r.overflow = "hidden", q.always(function() {
                        r.overflow = c.overflow[0];
                        r.overflowX = c.overflow[1];
                        r.overflowY = c.overflow[2]
                    })), b = !1, l) b || (t ? "hidden" in t && (u = t.hidden) : t = C.access(a, "fxshow", {
                    display: p
                }), e && (t.hidden = !u), u && J([a], !0), q.done(function() {
                    for (d in u || J([a]), C.remove(a, "fxshow"), l) k.style(a, d, l[d])
                })), b = ea(u ? t[d] : 0, d, q), d in t || (t[d] = b.start, u && (b.end = b.start, b.start = 0))
        }],
        prefilter: function(a, b) {
            b ? O.prefilters.unshift(a) : O.prefilters.push(a)
        }
    });
    k.speed = function(a, b, c) {
        var d = a && "object" ==
            typeof a ? k.extend({}, a) : {
                complete: c || !c && b || D(a) && a,
                duration: a,
                easing: c && b || b && !D(b) && b
            };
        return k.fx.off ? d.duration = 0 : "number" != typeof d.duration && (d.duration in k.fx.speeds ? d.duration = k.fx.speeds[d.duration] : d.duration = k.fx.speeds._default), null != d.queue && !0 !== d.queue || (d.queue = "fx"), d.old = d.complete, d.complete = function() {
            D(d.old) && d.old.call(this);
            d.queue && k.dequeue(this, d.queue)
        }, d
    };
    k.fn.extend({
        fadeTo: function(a, b, c, d) {
            return this.filter(db).css("opacity", 0).show().end().animate({
                    opacity: b
                }, a,
                c, d)
        },
        animate: function(a, b, c, d) {
            var f = k.isEmptyObject(a),
                e = k.speed(b, c, d);
            b = function() {
                var b = O(this, k.extend({}, a), e);
                (f || C.get(this, "finish")) && b.stop(!0)
            };
            return b.finish = b, f || !1 === e.queue ? this.each(b) : this.queue(e.queue, b)
        },
        stop: function(a, b, c) {
            var d = function(a) {
                var b = a.stop;
                delete a.stop;
                b(c)
            };
            return "string" != typeof a && (c = b, b = a, a = void 0), b && !1 !== a && this.queue(a || "fx", []), this.each(function() {
                var b = !0,
                    f = null != a && a + "queueHooks",
                    e = k.timers,
                    h = C.get(this);
                if (f) h[f] && h[f].stop && d(h[f]);
                else
                    for (f in h) h[f] &&
                        h[f].stop && bc.test(f) && d(h[f]);
                for (f = e.length; f--;) e[f].elem !== this || null != a && e[f].queue !== a || (e[f].anim.stop(c), b = !1, e.splice(f, 1));
                !b && c || k.dequeue(this, a)
            })
        },
        finish: function(a) {
            return !1 !== a && (a = a || "fx"), this.each(function() {
                var b = C.get(this),
                    c = b[a + "queue"];
                var d = b[a + "queueHooks"];
                var f = k.timers,
                    e = c ? c.length : 0;
                b.finish = !0;
                k.queue(this, a, []);
                d && d.stop && d.stop.call(this, !0);
                for (d = f.length; d--;) f[d].elem === this && f[d].queue === a && (f[d].anim.stop(!0), f.splice(d, 1));
                for (d = 0; d < e; d++) c[d] && c[d].finish &&
                    c[d].finish.call(this);
                delete b.finish
            })
        }
    });
    k.each(["toggle", "show", "hide"], function(a, b) {
        var c = k.fn[b];
        k.fn[b] = function(a, d, f) {
            return null == a || "boolean" == typeof a ? c.apply(this, arguments) : this.animate(aa(b, !0), a, d, f)
        }
    });
    k.each({
        slideDown: aa("show"),
        slideUp: aa("hide"),
        slideToggle: aa("toggle"),
        fadeIn: {
            opacity: "show"
        },
        fadeOut: {
            opacity: "hide"
        },
        fadeToggle: {
            opacity: "toggle"
        }
    }, function(a, b) {
        k.fn[a] = function(a, c, d) {
            return this.animate(b, a, c, d)
        }
    });
    k.timers = [];
    k.fx.tick = function() {
        var a, b = 0,
            c = k.timers;
        for (Na =
            Date.now(); b < c.length; b++)(a = c[b])() || c[b] !== a || c.splice(b--, 1);
        c.length || k.fx.stop();
        Na = void 0
    };
    k.fx.timer = function(a) {
        k.timers.push(a);
        k.fx.start()
    };
    k.fx.interval = 13;
    k.fx.start = function() {
        fb || (fb = !0, Ka())
    };
    k.fx.stop = function() {
        fb = null
    };
    k.fx.speeds = {
        slow: 600,
        fast: 200,
        _default: 400
    };
    k.fn.delay = function(b, c) {
        return b = k.fx && k.fx.speeds[b] || b, c = c || "fx", this.queue(c, function(c, d) {
            var f = a.setTimeout(c, b);
            d.stop = function() {
                a.clearTimeout(f)
            }
        })
    };
    var Wa = x.createElement("input");
    var cc = x.createElement("select").appendChild(x.createElement("option"));
    Wa.type = "checkbox";
    M.checkOn = "" !== Wa.value;
    M.optSelected = cc.selected;
    (Wa = x.createElement("input")).value = "t";
    Wa.type = "radio";
    M.radioValue = "t" === Wa.value;
    var Xa = k.expr.attrHandle;
    k.fn.extend({
        attr: function(a, b) {
            return ba(this, k.attr, a, b, 1 < arguments.length)
        },
        removeAttr: function(a) {
            return this.each(function() {
                k.removeAttr(this, a)
            })
        }
    });
    k.extend({
        attr: function(a, b, c) {
            var d, f, e = a.nodeType;
            if (3 !== e && 8 !== e && 2 !== e) return "undefined" == typeof a.getAttribute ? k.prop(a, b, c) : (1 === e && k.isXMLDoc(a) || (f = k.attrHooks[b.toLowerCase()] ||
                (k.expr.match.bool.test(b) ? dc : void 0)), void 0 !== c ? null === c ? void k.removeAttr(a, b) : f && "set" in f && void 0 !== (d = f.set(a, c, b)) ? d : (a.setAttribute(b, c + ""), c) : f && "get" in f && null !== (d = f.get(a, b)) ? d : null == (d = k.find.attr(a, b)) ? void 0 : d)
        },
        attrHooks: {
            type: {
                set: function(a, b) {
                    if (!M.radioValue && "radio" === b && d(a, "input")) {
                        var c = a.value;
                        return a.setAttribute("type", b), c && (a.value = c), b
                    }
                }
            }
        },
        removeAttr: function(a, b) {
            var c = 0,
                d = b && b.match(Y);
            if (d && 1 === a.nodeType)
                for (; b = d[c++];) a.removeAttribute(b)
        }
    });
    var dc = {
        set: function(a,
            b, c) {
            return !1 === b ? k.removeAttr(a, c) : a.setAttribute(c, c), c
        }
    };
    k.each(k.expr.match.bool.source.match(/\w+/g), function(a, b) {
        var c = Xa[b] || k.find.attr;
        Xa[b] = function(a, b, d) {
            var f, e, h = b.toLowerCase();
            return d || (e = Xa[h], Xa[h] = f, f = null != c(a, b, d) ? h : null, Xa[h] = e), f
        }
    });
    var ec = /^(?:input|select|textarea|button)$/i,
        fc = /^(?:a|area)$/i;
    k.fn.extend({
        prop: function(a, b) {
            return ba(this, k.prop, a, b, 1 < arguments.length)
        },
        removeProp: function(a) {
            return this.each(function() {
                delete this[k.propFix[a] || a]
            })
        }
    });
    k.extend({
        prop: function(a,
            b, c) {
            var d, f, e = a.nodeType;
            if (3 !== e && 8 !== e && 2 !== e) return 1 === e && k.isXMLDoc(a) || (b = k.propFix[b] || b, f = k.propHooks[b]), void 0 !== c ? f && "set" in f && void 0 !== (d = f.set(a, c, b)) ? d : a[b] = c : f && "get" in f && null !== (d = f.get(a, b)) ? d : a[b]
        },
        propHooks: {
            tabIndex: {
                get: function(a) {
                    var b = k.find.attr(a, "tabindex");
                    return b ? parseInt(b, 10) : ec.test(a.nodeName) || fc.test(a.nodeName) && a.href ? 0 : -1
                }
            }
        },
        propFix: {
            "for": "htmlFor",
            "class": "className"
        }
    });
    M.optSelected || (k.propHooks.selected = {
        get: function(a) {
            a = a.parentNode;
            return a && a.parentNode &&
                a.parentNode.selectedIndex, null
        },
        set: function(a) {
            a = a.parentNode;
            a && (a.selectedIndex, a.parentNode && a.parentNode.selectedIndex)
        }
    });
    k.each("tabIndex readOnly maxLength cellSpacing cellPadding rowSpan colSpan useMap frameBorder contentEditable".split(" "), function() {
        k.propFix[this.toLowerCase()] = this
    });
    k.fn.extend({
        addClass: function(a) {
            var b, c, d, f, e, h, m, p = 0;
            if (D(a)) return this.each(function(b) {
                k(this).addClass(a.call(this, b, fa(this)))
            });
            if ((b = ka(a)).length)
                for (; c = this[p++];)
                    if (f = fa(c), d = 1 === c.nodeType &&
                        " " + R(f) + " ") {
                        for (h = 0; e = b[h++];) 0 > d.indexOf(" " + e + " ") && (d += e + " ");
                        f !== (m = R(d)) && c.setAttribute("class", m)
                    }
            return this
        },
        removeClass: function(a) {
            var b, c, d, f, e, h, m, p = 0;
            if (D(a)) return this.each(function(b) {
                k(this).removeClass(a.call(this, b, fa(this)))
            });
            if (!arguments.length) return this.attr("class", "");
            if ((b = ka(a)).length)
                for (; c = this[p++];)
                    if (f = fa(c), d = 1 === c.nodeType && " " + R(f) + " ") {
                        for (h = 0; e = b[h++];)
                            for (; - 1 < d.indexOf(" " + e + " ");) d = d.replace(" " + e + " ", " ");
                        f !== (m = R(d)) && c.setAttribute("class", m)
                    }
            return this
        },
        toggleClass: function(a, b) {
            var c = typeof a,
                d = "string" === c || Array.isArray(a);
            return "boolean" == typeof b && d ? b ? this.addClass(a) : this.removeClass(a) : D(a) ? this.each(function(c) {
                k(this).toggleClass(a.call(this, c, fa(this), b), b)
            }) : this.each(function() {
                var b, f;
                if (d) {
                    var e = 0;
                    var h = k(this);
                    for (f = ka(a); b = f[e++];) h.hasClass(b) ? h.removeClass(b) : h.addClass(b)
                } else void 0 !== a && "boolean" !== c || ((b = fa(this)) && C.set(this, "__className__", b), this.setAttribute && this.setAttribute("class", b || !1 === a ? "" : C.get(this, "__className__") ||
                    ""))
            })
        },
        hasClass: function(a) {
            var b, c = 0;
            for (a = " " + a + " "; b = this[c++];)
                if (1 === b.nodeType && -1 < (" " + R(fa(b)) + " ").indexOf(a)) return !0;
            return !1
        }
    });
    var gc = /\r/g;
    k.fn.extend({
        val: function(a) {
            var b, c, d, f = this[0];
            return arguments.length ? (d = D(a), this.each(function(c) {
                var f;
                1 === this.nodeType && (null == (f = d ? a.call(this, c, k(this).val()) : a) ? f = "" : "number" == typeof f ? f += "" : Array.isArray(f) && (f = k.map(f, function(a) {
                        return null == a ? "" : a + ""
                    })), (b = k.valHooks[this.type] || k.valHooks[this.nodeName.toLowerCase()]) && "set" in b &&
                    void 0 !== b.set(this, f, "value") || (this.value = f))
            })) : f ? (b = k.valHooks[f.type] || k.valHooks[f.nodeName.toLowerCase()]) && "get" in b && void 0 !== (c = b.get(f, "value")) ? c : "string" == typeof(c = f.value) ? c.replace(gc, "") : null == c ? "" : c : void 0
        }
    });
    k.extend({
        valHooks: {
            option: {
                get: function(a) {
                    var b = k.find.attr(a, "value");
                    return null != b ? b : R(k.text(a))
                }
            },
            select: {
                get: function(a) {
                    var b, c, f = a.options,
                        e = a.selectedIndex,
                        h = "select-one" === a.type,
                        m = h ? null : [],
                        p = h ? e + 1 : f.length;
                    for (c = 0 > e ? p : h ? e : 0; c < p; c++)
                        if (!(!(b = f[c]).selected && c !==
                                e || b.disabled || b.parentNode.disabled && d(b.parentNode, "optgroup"))) {
                            if (a = k(b).val(), h) return a;
                            m.push(a)
                        }
                    return m
                },
                set: function(a, b) {
                    var c, d, f = a.options;
                    b = k.makeArray(b);
                    for (var e = f.length; e--;)((d = f[e]).selected = -1 < k.inArray(k.valHooks.option.get(d), b)) && (c = !0);
                    return c || (a.selectedIndex = -1), b
                }
            }
        }
    });
    k.each(["radio", "checkbox"], function() {
        k.valHooks[this] = {
            set: function(a, b) {
                if (Array.isArray(b)) return a.checked = -1 < k.inArray(k(a).val(), b)
            }
        };
        M.checkOn || (k.valHooks[this].get = function(a) {
            return null === a.getAttribute("value") ?
                "on" : a.value
        })
    });
    M.focusin = "onfocusin" in a;
    var Eb = /^(?:focusinfocus|focusoutblur)$/,
        Fb = function(a) {
            a.stopPropagation()
        };
    k.extend(k.event, {
        trigger: function(b, c, d, e) {
            var f, h, m, p, g, n, q = [d || x],
                l = Aa.call(b, "type") ? b.type : b;
            var u = Aa.call(b, "namespace") ? b.namespace.split(".") : [];
            if (f = n = h = d = d || x, 3 !== d.nodeType && 8 !== d.nodeType && !Eb.test(l + k.event.triggered) && (-1 < l.indexOf(".") && (l = (u = l.split(".")).shift(), u.sort()), m = 0 > l.indexOf(":") && "on" + l, (b = b[k.expando] ? b : new k.Event(l, "object" == typeof b && b)).isTrigger =
                    e ? 2 : 3, b.namespace = u.join("."), b.rnamespace = b.namespace ? new RegExp("(^|\\.)" + u.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, b.result = void 0, b.target || (b.target = d), c = null == c ? [b] : k.makeArray(c, [b]), g = k.event.special[l] || {}, e || !g.trigger || !1 !== g.trigger.apply(d, c))) {
                if (!e && !g.noBubble && !ua(d)) {
                    var r = g.delegateType || l;
                    for (Eb.test(r + l) || (f = f.parentNode); f; f = f.parentNode) q.push(f), h = f;
                    h === (d.ownerDocument || x) && q.push(h.defaultView || h.parentWindow || a)
                }
                for (u = 0;
                    (f = q[u++]) && !b.isPropagationStopped();) n = f, b.type = 1 <
                    u ? r : g.bindType || l, (p = (C.get(f, "events") || {})[b.type] && C.get(f, "handle")) && p.apply(f, c), (p = m && f[m]) && p.apply && Fa(f) && (b.result = p.apply(f, c), !1 === b.result && b.preventDefault());
                return b.type = l, e || b.isDefaultPrevented() || g._default && !1 !== g._default.apply(q.pop(), c) || !Fa(d) || m && D(d[l]) && !ua(d) && ((h = d[m]) && (d[m] = null), k.event.triggered = l, b.isPropagationStopped() && n.addEventListener(l, Fb), d[l](), b.isPropagationStopped() && n.removeEventListener(l, Fb), k.event.triggered = void 0, h && (d[m] = h)), b.result
            }
        },
        simulate: function(a,
            b, c) {
            a = k.extend(new k.Event, c, {
                type: a,
                isSimulated: !0
            });
            k.event.trigger(a, null, b)
        }
    });
    k.fn.extend({
        trigger: function(a, b) {
            return this.each(function() {
                k.event.trigger(a, b, this)
            })
        },
        triggerHandler: function(a, b) {
            var c = this[0];
            if (c) return k.event.trigger(a, b, c, !0)
        }
    });
    M.focusin || k.each({
        focus: "focusin",
        blur: "focusout"
    }, function(a, b) {
        var c = function(a) {
            k.event.simulate(b, a.target, k.event.fix(a))
        };
        k.event.special[b] = {
            setup: function() {
                var d = this.ownerDocument || this,
                    f = C.access(d, b);
                f || d.addEventListener(a, c, !0);
                C.access(d, b, (f || 0) + 1)
            },
            teardown: function() {
                var d = this.ownerDocument || this,
                    f = C.access(d, b) - 1;
                f ? C.access(d, b, f) : (d.removeEventListener(a, c, !0), C.remove(d, b))
            }
        }
    });
    var Ya = a.location,
        Gb = Date.now(),
        qb = /\?/;
    k.parseXML = function(b) {
        if (!b || "string" != typeof b) return null;
        try {
            var c = (new a.DOMParser).parseFromString(b, "text/xml")
        } catch (P) {
            c = void 0
        }
        return c && !c.getElementsByTagName("parsererror").length || k.error("Invalid XML: " + b), c
    };
    var Sb = /\[\]$/,
        Hb = /\r?\n/g,
        hc = /^(?:submit|button|image|reset|file)$/i,
        ic = /^(?:input|select|textarea|keygen)/i;
    k.param = function(a, b) {
        var c, d = [],
            f = function(a, b) {
                b = D(b) ? b() : b;
                d[d.length] = encodeURIComponent(a) + "\x3d" + encodeURIComponent(null == b ? "" : b)
            };
        if (null == a) return "";
        if (Array.isArray(a) || a.jquery && !k.isPlainObject(a)) k.each(a, function() {
            f(this.name, this.value)
        });
        else
            for (c in a) wa(c, a[c], b, f);
        return d.join("\x26")
    };
    k.fn.extend({
        serialize: function() {
            return k.param(this.serializeArray())
        },
        serializeArray: function() {
            return this.map(function() {
                var a = k.prop(this, "elements");
                return a ? k.makeArray(a) : this
            }).filter(function() {
                var a =
                    this.type;
                return this.name && !k(this).is(":disabled") && ic.test(this.nodeName) && !hc.test(a) && (this.checked || !Va.test(a))
            }).map(function(a, b) {
                a = k(this).val();
                return null == a ? null : Array.isArray(a) ? k.map(a, function(a) {
                    return {
                        name: b.name,
                        value: a.replace(Hb, "\r\n")
                    }
                }) : {
                    name: b.name,
                    value: a.replace(Hb, "\r\n")
                }
            }).get()
        }
    });
    var jc = /%20/g,
        kc = /#.*$/,
        lc = /([?&])_=[^&]*/,
        mc = /^(.*?):[ \t]*([^\r\n]*)$/gm,
        nc = /^(?:GET|HEAD)$/,
        oc = /^\/\//,
        Ib = {},
        ob = {},
        Jb = "*/".concat("*"),
        rb = x.createElement("a");
    rb.href = Ya.href;
    k.extend({
        active: 0,
        lastModified: {},
        etag: {},
        ajaxSettings: {
            url: Ya.href,
            type: "GET",
            isLocal: /^(?:about|app|app-storage|.+-extension|file|res|widget):$/.test(Ya.protocol),
            global: !0,
            processData: !0,
            async: !0,
            contentType: "application/x-www-form-urlencoded; charset\x3dUTF-8",
            accepts: {
                "*": Jb,
                text: "text/plain",
                html: "text/html",
                xml: "application/xml, text/xml",
                json: "application/json, text/javascript"
            },
            contents: {
                xml: /\bxml\b/,
                html: /\bhtml/,
                json: /\bjson\b/
            },
            responseFields: {
                xml: "responseXML",
                text: "responseText",
                json: "responseJSON"
            },
            converters: {
                "* text": String,
                "text html": !0,
                "text json": JSON.parse,
                "text xml": k.parseXML
            },
            flatOptions: {
                url: !0,
                context: !0
            }
        },
        ajaxSetup: function(a, b) {
            return b ? na(na(a, k.ajaxSettings), b) : na(k.ajaxSettings, a)
        },
        ajaxPrefilter: pa(Ib),
        ajaxTransport: pa(ob),
        ajax: function(b, c) {
            function d(b, c, d, m) {
                var n, l, H, v, z, Y = c;
                ha || (ha = !0, p && a.clearTimeout(p), e = void 0, h = m || "", F.readyState = 0 < b ? 4 : 0, n = 200 <= b && 300 > b || 304 === b, d && (v = function(a, b, c) {
                    for (var d, e, f, h, m = a.contents, p = a.dataTypes;
                        "*" === p[0];) p.shift(), void 0 === d && (d = a.mimeType ||
                        b.getResponseHeader("Content-Type"));
                    if (d)
                        for (e in m)
                            if (m[e] && m[e].test(d)) {
                                p.unshift(e);
                                break
                            }
                    if (p[0] in c) f = p[0];
                    else {
                        for (e in c) {
                            if (!p[0] || a.converters[e + " " + p[0]]) {
                                f = e;
                                break
                            }
                            h || (h = e)
                        }
                        f = f || h
                    }
                    if (f) return f !== p[0] && p.unshift(f), c[f]
                }(q, F, d)), v = function(a, b, c, d) {
                    var e, f, h, m, p, g = {},
                        n = a.dataTypes.slice();
                    if (n[1])
                        for (h in a.converters) g[h.toLowerCase()] = a.converters[h];
                    for (f = n.shift(); f;)
                        if (a.responseFields[f] && (c[a.responseFields[f]] = b), !p && d && a.dataFilter && (b = a.dataFilter(b, a.dataType)), p = f, f = n.shift())
                            if ("*" ===
                                f) f = p;
                            else if ("*" !== p && p !== f) {
                        if (!(h = g[p + " " + f] || g["* " + f]))
                            for (e in g)
                                if ((m = e.split(" "))[1] === f && (h = g[p + " " + m[0]] || g["* " + m[0]])) {
                                    !0 === h ? h = g[e] : !0 !== g[e] && (f = m[0], n.unshift(m[1]));
                                    break
                                }
                        if (!0 !== h)
                            if (h && a["throws"]) b = h(b);
                            else try {
                                b = h(b)
                            } catch (Tb) {
                                return {
                                    state: "parsererror",
                                    error: h ? Tb : "No conversion from " + p + " to " + f
                                }
                            }
                    }
                    return {
                        state: "success",
                        data: b
                    }
                }(q, v, F, n), n ? (q.ifModified && ((z = F.getResponseHeader("Last-Modified")) && (k.lastModified[f] = z), (z = F.getResponseHeader("etag")) && (k.etag[f] = z)), 204 === b ||
                    "HEAD" === q.type ? Y = "nocontent" : 304 === b ? Y = "notmodified" : (Y = v.state, l = v.data, n = !(H = v.error))) : (H = Y, !b && Y || (Y = "error", 0 > b && (b = 0))), F.status = b, F.statusText = (c || Y) + "", n ? r.resolveWith(u, [l, Y, F]) : r.rejectWith(u, [F, Y, H]), F.statusCode(A), A = void 0, g && t.trigger(n ? "ajaxSuccess" : "ajaxError", [F, q, n ? l : H]), w.fireWith(u, [F, Y]), g && (t.trigger("ajaxComplete", [F, q]), --k.active || k.event.trigger("ajaxStop")))
            }
            "object" == typeof b && (c = b, b = void 0);
            c = c || {};
            var e, f, h, m, p, g, n, l, q = k.ajaxSetup({}, c),
                u = q.context || q,
                t = q.context && (u.nodeType ||
                    u.jquery) ? k(u) : k.event,
                r = k.Deferred(),
                w = k.Callbacks("once memory"),
                A = q.statusCode || {},
                H = {},
                v = {},
                z = "canceled",
                F = {
                    readyState: 0,
                    getResponseHeader: function(a) {
                        var b;
                        if (ha) {
                            if (!m)
                                for (m = {}; b = mc.exec(h);) m[b[1].toLowerCase() + " "] = (m[b[1].toLowerCase() + " "] || []).concat(b[2]);
                            b = m[a.toLowerCase() + " "]
                        }
                        return null == b ? null : b.join(", ")
                    },
                    getAllResponseHeaders: function() {
                        return ha ? h : null
                    },
                    setRequestHeader: function(a, b) {
                        return null == ha && (a = v[a.toLowerCase()] = v[a.toLowerCase()] || a, H[a] = b), this
                    },
                    overrideMimeType: function(a) {
                        return null ==
                            ha && (q.mimeType = a), this
                    },
                    statusCode: function(a) {
                        var b;
                        if (a)
                            if (ha) F.always(a[F.status]);
                            else
                                for (b in a) A[b] = [A[b], a[b]];
                        return this
                    },
                    abort: function(a) {
                        a = a || z;
                        return e && e.abort(a), d(0, a), this
                    }
                };
            if (r.promise(F), q.url = ((b || q.url || Ya.href) + "").replace(oc, Ya.protocol + "//"), q.type = c.method || c.type || q.method || q.type, q.dataTypes = (q.dataType || "*").toLowerCase().match(Y) || [""], null == q.crossDomain) {
                b = x.createElement("a");
                try {
                    b.href = q.url, b.href = b.href, q.crossDomain = rb.protocol + "//" + rb.host != b.protocol + "//" +
                        b.host
                } catch (pb) {
                    q.crossDomain = !0
                }
            }
            if (q.data && q.processData && "string" != typeof q.data && (q.data = k.param(q.data, q.traditional)), Ra(Ib, q, c, F), ha) return F;
            for (n in (g = k.event && q.global) && 0 == k.active++ && k.event.trigger("ajaxStart"), q.type = q.type.toUpperCase(), q.hasContent = !nc.test(q.type), f = q.url.replace(kc, ""), q.hasContent ? q.data && q.processData && 0 === (q.contentType || "").indexOf("application/x-www-form-urlencoded") && (q.data = q.data.replace(jc, "+")) : (l = q.url.slice(f.length), q.data && (q.processData || "string" ==
                    typeof q.data) && (f += (qb.test(f) ? "\x26" : "?") + q.data, delete q.data), !1 === q.cache && (f = f.replace(lc, "$1"), l = (qb.test(f) ? "\x26" : "?") + "_\x3d" + Gb++ + l), q.url = f + l), q.ifModified && (k.lastModified[f] && F.setRequestHeader("If-Modified-Since", k.lastModified[f]), k.etag[f] && F.setRequestHeader("If-None-Match", k.etag[f])), (q.data && q.hasContent && !1 !== q.contentType || c.contentType) && F.setRequestHeader("Content-Type", q.contentType), F.setRequestHeader("Accept", q.dataTypes[0] && q.accepts[q.dataTypes[0]] ? q.accepts[q.dataTypes[0]] +
                    ("*" !== q.dataTypes[0] ? ", " + Jb + "; q\x3d0.01" : "") : q.accepts["*"]), q.headers) F.setRequestHeader(n, q.headers[n]);
            if (q.beforeSend && (!1 === q.beforeSend.call(u, F, q) || ha)) return F.abort();
            if (z = "abort", w.add(q.complete), F.done(q.success), F.fail(q.error), e = Ra(ob, q, c, F)) {
                if (F.readyState = 1, g && t.trigger("ajaxSend", [F, q]), ha) return F;
                q.async && 0 < q.timeout && (p = a.setTimeout(function() {
                    F.abort("timeout")
                }, q.timeout));
                try {
                    var ha = !1;
                    e.send(H, d)
                } catch (pb) {
                    if (ha) throw pb;
                    d(-1, pb)
                }
            } else d(-1, "No Transport");
            return F
        },
        getJSON: function(a,
            b, c) {
            return k.get(a, b, c, "json")
        },
        getScript: function(a, b) {
            return k.get(a, void 0, b, "script")
        }
    });
    k.each(["get", "post"], function(a, b) {
        k[b] = function(a, c, d, f) {
            return D(c) && (f = f || d, d = c, c = void 0), k.ajax(k.extend({
                url: a,
                type: b,
                dataType: f,
                data: c,
                success: d
            }, k.isPlainObject(a) && a))
        }
    });
    k._evalUrl = function(a, b) {
        return k.ajax({
            url: a,
            type: "GET",
            dataType: "script",
            cache: !0,
            async: !1,
            global: !1,
            converters: {
                "text script": function() {}
            },
            dataFilter: function(a) {
                k.globalEval(a, b)
            }
        })
    };
    k.fn.extend({
        wrapAll: function(a) {
            var b;
            return this[0] && (D(a) && (a = a.call(this[0])), b = k(a, this[0].ownerDocument).eq(0).clone(!0), this[0].parentNode && b.insertBefore(this[0]), b.map(function() {
                for (var a = this; a.firstElementChild;) a = a.firstElementChild;
                return a
            }).append(this)), this
        },
        wrapInner: function(a) {
            return D(a) ? this.each(function(b) {
                k(this).wrapInner(a.call(this, b))
            }) : this.each(function() {
                var b = k(this),
                    c = b.contents();
                c.length ? c.wrapAll(a) : b.append(a)
            })
        },
        wrap: function(a) {
            var b = D(a);
            return this.each(function(c) {
                k(this).wrapAll(b ? a.call(this,
                    c) : a)
            })
        },
        unwrap: function(a) {
            return this.parent(a).not("body").each(function() {
                k(this).replaceWith(this.childNodes)
            }), this
        }
    });
    k.expr.pseudos.hidden = function(a) {
        return !k.expr.pseudos.visible(a)
    };
    k.expr.pseudos.visible = function(a) {
        return !!(a.offsetWidth || a.offsetHeight || a.getClientRects().length)
    };
    k.ajaxSettings.xhr = function() {
        try {
            return new a.XMLHttpRequest
        } catch (f) {}
    };
    var pc = {
            0: 200,
            1223: 204
        },
        Za = k.ajaxSettings.xhr();
    M.cors = !!Za && "withCredentials" in Za;
    M.ajax = Za = !!Za;
    k.ajaxTransport(function(b) {
        var c,
            d;
        if (M.cors || Za && !b.crossDomain) return {
            send: function(e, f) {
                var h, m = b.xhr();
                if (m.open(b.type, b.url, b.async, b.username, b.password), b.xhrFields)
                    for (h in b.xhrFields) m[h] = b.xhrFields[h];
                for (h in b.mimeType && m.overrideMimeType && m.overrideMimeType(b.mimeType), b.crossDomain || e["X-Requested-With"] || (e["X-Requested-With"] = "XMLHttpRequest"), e) m.setRequestHeader(h, e[h]);
                c = function(a) {
                    return function() {
                        c && (c = d = m.onload = m.onerror = m.onabort = m.ontimeout = m.onreadystatechange = null, "abort" === a ? m.abort() : "error" === a ?
                            "number" != typeof m.status ? f(0, "error") : f(m.status, m.statusText) : f(pc[m.status] || m.status, m.statusText, "text" !== (m.responseType || "text") || "string" != typeof m.responseText ? {
                                binary: m.response
                            } : {
                                text: m.responseText
                            }, m.getAllResponseHeaders()))
                    }
                };
                m.onload = c();
                d = m.onerror = m.ontimeout = c("error");
                void 0 !== m.onabort ? m.onabort = d : m.onreadystatechange = function() {
                    4 === m.readyState && a.setTimeout(function() {
                        c && d()
                    })
                };
                c = c("abort");
                try {
                    m.send(b.hasContent && b.data || null)
                } catch (Mb) {
                    if (c) throw Mb;
                }
            },
            abort: function() {
                c &&
                    c()
            }
        }
    });
    k.ajaxPrefilter(function(a) {
        a.crossDomain && (a.contents.script = !1)
    });
    k.ajaxSetup({
        accepts: {
            script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
        },
        contents: {
            script: /\b(?:java|ecma)script\b/
        },
        converters: {
            "text script": function(a) {
                return k.globalEval(a), a
            }
        }
    });
    k.ajaxPrefilter("script", function(a) {
        void 0 === a.cache && (a.cache = !1);
        a.crossDomain && (a.type = "GET")
    });
    k.ajaxTransport("script", function(a) {
        var b, c;
        if (a.crossDomain || a.scriptAttrs) return {
            send: function(d,
                e) {
                b = k("\x3cscript\x3e").attr(a.scriptAttrs || {}).prop({
                    charset: a.scriptCharset,
                    src: a.url
                }).on("load error", c = function(a) {
                    b.remove();
                    c = null;
                    a && e("error" === a.type ? 404 : 200, a.type)
                });
                x.head.appendChild(b[0])
            },
            abort: function() {
                c && c()
            }
        }
    });
    var Kb, Lb = [],
        sb = /(=)\?(?=&|$)|\?\?/;
    k.ajaxSetup({
        jsonp: "callback",
        jsonpCallback: function() {
            var a = Lb.pop() || k.expando + "_" + Gb++;
            return this[a] = !0, a
        }
    });
    k.ajaxPrefilter("json jsonp", function(b, c, d) {
        var e, h, f, m = !1 !== b.jsonp && (sb.test(b.url) ? "url" : "string" == typeof b.data && 0 ===
            (b.contentType || "").indexOf("application/x-www-form-urlencoded") && sb.test(b.data) && "data");
        if (m || "jsonp" === b.dataTypes[0]) return e = b.jsonpCallback = D(b.jsonpCallback) ? b.jsonpCallback() : b.jsonpCallback, m ? b[m] = b[m].replace(sb, "$1" + e) : !1 !== b.jsonp && (b.url += (qb.test(b.url) ? "\x26" : "?") + b.jsonp + "\x3d" + e), b.converters["script json"] = function() {
            return f || k.error(e + " was not called"), f[0]
        }, b.dataTypes[0] = "json", h = a[e], a[e] = function() {
            f = arguments
        }, d.always(function() {
            void 0 === h ? k(a).removeProp(e) : a[e] = h;
            b[e] &&
                (b.jsonpCallback = c.jsonpCallback, Lb.push(e));
            f && D(h) && h(f[0]);
            f = h = void 0
        }), "script"
    });
    M.createHTMLDocument = ((Kb = x.implementation.createHTMLDocument("").body).innerHTML = "\x3cform\x3e\x3c/form\x3e\x3cform\x3e\x3c/form\x3e", 2 === Kb.childNodes.length);
    k.parseHTML = function(a, b, c) {
        return "string" != typeof a ? [] : ("boolean" == typeof b && (c = b, b = !1), b || (M.createHTMLDocument ? ((d = (b = x.implementation.createHTMLDocument("")).createElement("base")).href = x.location.href, b.head.appendChild(d)) : b = x), h = !c && [], (e = Sa.exec(a)) ? [b.createElement(e[1])] : (e = ma([a], b, h), h && h.length && k(h).remove(), k.merge([], e.childNodes)));
        var d, e, h
    };
    k.fn.load = function(a, b, c) {
        var d, e, h, f = this,
            m = a.indexOf(" ");
        return -1 < m && (d = R(a.slice(m)), a = a.slice(0, m)), D(b) ? (c = b, b = void 0) : b && "object" == typeof b && (e = "POST"), 0 < f.length && k.ajax({
                url: a,
                type: e || "GET",
                dataType: "html",
                data: b
            }).done(function(a) {
                h = arguments;
                f.html(d ? k("\x3cdiv\x3e").append(k.parseHTML(a)).find(d) : a)
            }).always(c && function(a, b) {
                f.each(function() {
                    c.apply(this, h || [a.responseText, b, a])
                })
            }),
            this
    };
    k.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "), function(a, b) {
        k.fn[b] = function(a) {
            return this.on(b, a)
        }
    });
    k.expr.pseudos.animated = function(a) {
        return k.grep(k.timers, function(b) {
            return a === b.elem
        }).length
    };
    k.offset = {
        setOffset: function(a, b, c) {
            var d, e, h, f = k.css(a, "position"),
                m = k(a),
                p = {};
            "static" === f && (a.style.position = "relative");
            var g = m.offset();
            var n = k.css(a, "top");
            var q = k.css(a, "left");
            ("absolute" === f || "fixed" === f) && -1 < (n + q).indexOf("auto") ? (h = (d = m.position()).top,
                e = d.left) : (h = parseFloat(n) || 0, e = parseFloat(q) || 0);
            D(b) && (b = b.call(a, c, k.extend({}, g)));
            null != b.top && (p.top = b.top - g.top + h);
            null != b.left && (p.left = b.left - g.left + e);
            "using" in b ? b.using.call(a, p) : m.css(p)
        }
    };
    k.fn.extend({
        offset: function(a) {
            if (arguments.length) return void 0 === a ? this : this.each(function(b) {
                k.offset.setOffset(this, a, b)
            });
            var b, c, d = this[0];
            return d ? d.getClientRects().length ? (b = d.getBoundingClientRect(), c = d.ownerDocument.defaultView, {
                top: b.top + c.pageYOffset,
                left: b.left + c.pageXOffset
            }) : {
                top: 0,
                left: 0
            } : void 0
        },
        position: function() {
            if (this[0]) {
                var a, b = this[0],
                    c = {
                        top: 0,
                        left: 0
                    };
                if ("fixed" === k.css(b, "position")) var d = b.getBoundingClientRect();
                else {
                    d = this.offset();
                    var e = b.ownerDocument;
                    for (a = b.offsetParent || e.documentElement; a && (a === e.body || a === e.documentElement) && "static" === k.css(a, "position");) a = a.parentNode;
                    a && a !== b && 1 === a.nodeType && ((c = k(a).offset()).top += k.css(a, "borderTopWidth", !0), c.left += k.css(a, "borderLeftWidth", !0))
                }
                return {
                    top: d.top - c.top - k.css(b, "marginTop", !0),
                    left: d.left - c.left - k.css(b,
                        "marginLeft", !0)
                }
            }
        },
        offsetParent: function() {
            return this.map(function() {
                for (var a = this.offsetParent; a && "static" === k.css(a, "position");) a = a.offsetParent;
                return a || Ua
            })
        }
    });
    k.each({
        scrollLeft: "pageXOffset",
        scrollTop: "pageYOffset"
    }, function(a, b) {
        var c = "pageYOffset" === b;
        k.fn[a] = function(d) {
            return ba(this, function(a, d, e) {
                var h;
                if (ua(a) ? h = a : 9 === a.nodeType && (h = a.defaultView), void 0 === e) return h ? h[b] : a[d];
                h ? h.scrollTo(c ? h.pageXOffset : e, c ? e : h.pageYOffset) : a[d] = e
            }, a, d, arguments.length)
        }
    });
    k.each(["top", "left"],
        function(a, b) {
            k.cssHooks[b] = Z(M.pixelPosition, function(a, c) {
                if (c) return c = z(a, b), nb.test(c) ? k(a).position()[b] + "px" : c
            })
        });
    k.each({
        Height: "height",
        Width: "width"
    }, function(a, b) {
        k.each({
            padding: "inner" + a,
            content: b,
            "": "outer" + a
        }, function(c, d) {
            k.fn[d] = function(e, h) {
                var f = arguments.length && (c || "boolean" != typeof e),
                    m = c || (!0 === e || !0 === h ? "margin" : "border");
                return ba(this, function(b, c, e) {
                    var h;
                    return ua(b) ? 0 === d.indexOf("outer") ? b["inner" + a] : b.document.documentElement["client" + a] : 9 === b.nodeType ? (h = b.documentElement,
                        Math.max(b.body["scroll" + a], h["scroll" + a], b.body["offset" + a], h["offset" + a], h["client" + a])) : void 0 === e ? k.css(b, c, m) : k.style(b, c, e, m)
                }, b, f ? e : void 0, f)
            }
        })
    });
    k.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function(a, b) {
        k.fn[b] = function(a, c) {
            return 0 < arguments.length ? this.on(b, null, a, c) : this.trigger(b)
        }
    });
    k.fn.extend({
        hover: function(a, b) {
            return this.mouseenter(a).mouseleave(b ||
                a)
        }
    });
    k.fn.extend({
        bind: function(a, b, c) {
            return this.on(a, null, b, c)
        },
        unbind: function(a, b) {
            return this.off(a, null, b)
        },
        delegate: function(a, b, c, d) {
            return this.on(b, a, c, d)
        },
        undelegate: function(a, b, c) {
            return 1 === arguments.length ? this.off(a, "**") : this.off(b, a || "**", c)
        }
    });
    k.proxy = function(a, b) {
        var c, d, e;
        if ("string" == typeof b && (c = a[b], b = a, a = c), D(a)) return d = ta.call(arguments, 2), (e = function() {
            return a.apply(b || this, d.concat(ta.call(arguments)))
        }).guid = a.guid = a.guid || k.guid++, e
    };
    k.holdReady = function(a) {
        a ? k.readyWait++ :
            k.ready(!0)
    };
    k.isArray = Array.isArray;
    k.parseJSON = JSON.parse;
    k.nodeName = d;
    k.isFunction = D;
    k.isWindow = ua;
    k.camelCase = t;
    k.type = g;
    k.now = Date.now;
    k.isNumeric = function(a) {
        var b = k.type(a);
        return ("number" === b || "string" === b) && !isNaN(a - parseFloat(a))
    };
    "function" == typeof define && define.amd && define("jquery", [], function() {
        return k
    });
    var qc = a.jQuery,
        rc = a.$;
    return k.noConflict = function(b) {
        return a.$ === k && (a.$ = rc), b && a.jQuery === k && (a.jQuery = qc), k
    }, l || (a.jQuery = a.$ = k), k
});
window.Granite = window.Granite || {};
(function(a, l) {
    a.Util = function() {
        return {
            patchText: function(a, g) {
                if (g)
                    if (l.isArray(g))
                        for (var b = 0; b < g.length; b++) a = a.replace("{" + b + "}", g[b]);
                    else a = a.replace("{0}", g);
                return a
            }
        }
    }()
})(Granite, jQuery);
(function(a, l, e) {
    a.HTTP = function() {
        var g = null,
            b = /^(?:http|https):\/\/[^\/]+(\/.*)\/(?:etc(\/.*)*\/clientlibs|libs(\/.*)*\/clientlibs|apps(\/.*)*\/clientlibs).*\.js(\?.*)?$/,
            d = /[^1\w-\.!~\*'\(\)\/%;:@&=\$,]/,
            n = !1,
            c = {
                getSchemeAndAuthority: function(a) {
                    try {
                        if (-1 === a.indexOf("://")) return "";
                        var b = a.indexOf("/", a.indexOf("://") + 3);
                        return -1 === b ? a : a.substring(0, b)
                    } catch (m) {
                        return ""
                    }
                },
                getContextPath: function() {
                    return g
                },
                detectContextPath: function() {
                    try {
                        if (window.CQURLInfo) g = CQURLInfo.contextPath || "";
                        else {
                            for (var a =
                                    document.getElementsByTagName("script"), c = 0; c < a.length; c++) {
                                var d = b.exec(a[c].src);
                                if (d) {
                                    g = d[1];
                                    return
                                }
                            }
                            g = ""
                        }
                    } catch (p) {}
                },
                externalize: function(a) {
                    try {
                        0 === a.indexOf("/") && g && 0 !== a.indexOf(g + "/") && (a = g + a)
                    } catch (q) {}
                    return a
                },
                internalize: function(a, b) {
                    if ("/" === a.charAt(0)) return g === a ? "" : g && 0 === a.indexOf(g + "/") ? a.substring(g.length) : a;
                    b || (b = document);
                    b = c.getSchemeAndAuthority(b.location.href);
                    var d = c.getSchemeAndAuthority(a);
                    return b === d ? a.substring(d.length + (g ? g.length : 0)) : a
                },
                getPath: function(a) {
                    if (a) a =
                        c.removeParameters(a), a = c.removeAnchor(a);
                    else {
                        if (window.CQURLInfo && CQURLInfo.requestPath) return CQURLInfo.requestPath;
                        a = window.location.pathname
                    }
                    a = c.internalize(a);
                    var b = a.indexOf(".", a.lastIndexOf("/")); - 1 !== b && (a = a.substring(0, b));
                    return a
                },
                removeAnchor: function(a) {
                    return -1 !== a.indexOf("#") ? a.substring(0, a.indexOf("#")) : a
                },
                removeParameters: function(a) {
                    return -1 !== a.indexOf("?") ? a.substring(0, a.indexOf("?")) : a
                },
                encodePathOfURI: function(a) {
                    if (-1 !== a.indexOf("?")) {
                        a = a.split("?");
                        var b = "?"
                    } else -1 !==
                        a.indexOf("#") ? (a = a.split("#"), b = "#") : a = [a];
                    d.test(a[0]) && (a[0] = c.encodePath(a[0]));
                    return a.join(b)
                },
                encodePath: function(a) {
                    a = encodeURI(a).replace(/%5B/g, "[").replace(/%5D/g, "]");
                    a = a.replace(/\+/g, "%2B");
                    a = a.replace(/\?/g, "%3F");
                    a = a.replace(/;/g, "%3B");
                    a = a.replace(/#/g, "%23");
                    a = a.replace(/=/g, "%3D");
                    a = a.replace(/\$/g, "%24");
                    a = a.replace(/,/g, "%2C");
                    a = a.replace(/'/g, "%27");
                    return a = a.replace(/"/g, "%22")
                },
                handleLoginRedirect: function() {
                    if (!n) {
                        n = !0;
                        alert(a.I18n.get("Your request could not be completed because you have been signed out."));
                        var b = l.getTopWindow().document.location;
                        b.href = c.externalize(sling.LOGIN_URL) + "?resource\x3d" + encodeURIComponent(b.pathname + b.search + b.hash)
                    }
                },
                getXhrHook: function(a, b, c) {
                    b = b || "GET";
                    return window.G_XHR_HOOK && e.isFunction(G_XHR_HOOK) ? (a = {
                        url: a,
                        method: b
                    }, c && (a.params = c), G_XHR_HOOK(a)) : null
                },
                eval: function(a) {
                    "object" !== typeof a && (a = e.ajax({
                        url: a,
                        type: "get",
                        async: !1
                    }));
                    try {
                        return eval("(" + (a.body ? a.body : a.responseText) + ")")
                    } catch (q) {}
                    return null
                }
            };
        return c
    }()
})(Granite, Granite.Util, jQuery);
(function(a, l, e, g, b) {
    l.I18n = function() {
        var a = {},
            n = "/aemapi/v6/common/i18n/dict.",
            c = ".b2c",
            h = ".json",
            q = void 0,
            m = !1,
            p = null,
            l = {},
            t = !1,
            y = function(a) {
                b("#i18nAppsParam").val() && -1 < b("#i18nAppsParam").val().length && (c += "." + b("#i18nAppsParam").val());
                if (t) return n + a + c + h;
                var d = b("html").attr("data-i18n-dictionary-src");
                return d ? d.replace("{locale}", encodeURIComponent(a)).replace("{+locale}", a) : n + a + c + h
            };
        l.LOCALE_DEFAULT = "en";
        l.PSEUDO_LANGUAGE = "zz";
        l.PSEUDO_PATTERN_KEY = "_pseudoPattern_";
        l.init = function(a) {
            a =
                a || {};
            this.setLocale(a.locale);
            this.setUrlPrefix(a.urlPrefix);
            this.setUrlSuffix(a.urlSuffix)
        };
        l.setLocale = function(a) {
            a && (q = b("#language").val() || a)
        };
        l.getLocale = function() {
            b.isFunction(q) && (q = q());
            return b("#language").val() || l.LOCALE_DEFAULT
        };
        l.setUrlPrefix = function(a) {
            a && (n = a, t = !0)
        };
        l.setUrlSuffix = function(a) {
            a && (h = a, t = !0)
        };
        l.getDictionary = function(c) {
            c = c || l.getLocale();
            if (!a[c]) {
                m = 0 === c.indexOf(l.PSEUDO_LANGUAGE);
                try {
                    var d = b.ajax(y(c), {
                        async: !1,
                        dataType: "json"
                    });
                    a[c] = b.parseJSON(d.responseText)
                } catch (J) {}
                a[c] ||
                    (a[c] = {})
            }
            return a[c]
        };
        l.get = function(a, b, c) {
            var d;
            var h = l.getDictionary();
            var p = m ? l.PSEUDO_PATTERN_KEY : c ? a + " ((" + c + "))" : a;
            h && (d = h[p]);
            d || (d = a);
            m && (d = d.replace("{string}", a).replace("{comment}", c ? c : ""));
            return e.patchText(d, b)
        };
        l.getVar = function(a, b) {
            return a ? l.get(a, null, b) : null
        };
        l.getLanguages = function() {
            if (!p) try {
                var a = g.eval("/libs/wcm/core/resources/languages.overlay.infinity.json");
                b.each(a, function(a, b) {
                    b.title = l.getVar(b.language);
                    b.title && b.country && "*" !== b.country && (b.title += " (" + l.getVar(b.country) +
                        ")")
                });
                p = a
            } catch (L) {
                p = {}
            }
            return p
        };
        l.parseLocale = function(a) {
            if (!a) return null;
            var b = a.indexOf("_");
            0 > b && (b = a.indexOf("-"));
            if (0 > b) {
                var c = a;
                b = null
            } else c = a.substring(0, b), b = a.substring(b + 1);
            return {
                code: a,
                language: c,
                country: b
            }
        };
        return l
    }()
})(document, Granite, Granite.Util, Granite.HTTP, jQuery);
Granite.HTTP.detectContextPath();
var jaaulde = window.jaaulde || {};
jaaulde.utils = jaaulde.utils || {};
jaaulde.utils.cookies = function() {
    var a = {
        expiresAt: null,
        path: "/",
        domain: null,
        secure: !1
    };
    var l = function(b) {
        if ("object" !== typeof b || null === b) var d = a;
        else {
            d = {
                expiresAt: a.expiresAt,
                path: a.path,
                domain: a.domain,
                secure: a.secure
            };
            if ("object" === typeof b.expiresAt && b.expiresAt instanceof Date) d.expiresAt = b.expiresAt;
            else if ("number" === typeof b.hoursToLive && 0 !== b.hoursToLive) {
                var c = new Date;
                c.setTime(c.getTime() + 36E5 * b.hoursToLive);
                d.expiresAt = c
            }
            "string" === typeof b.path && "" !== b.path && (d.path = b.path);
            "string" ===
            typeof b.domain && "" !== b.domain && (d.domain = b.domain);
            !0 === b.secure && (d.secure = b.secure)
        }
        return d
    };
    var e = function(a) {
        a = l(a);
        return ("object" === typeof a.expiresAt && a.expiresAt instanceof Date ? "; expires\x3d" + a.expiresAt.toGMTString() : "") + "; path\x3d" + a.path + ("string" === typeof a.domain ? "; domain\x3d" + a.domain : "") + (!0 === a.secure ? "; secure" : "")
    };
    var g = function() {
        var a = {},
            b, c = document.cookie.split(";");
        for (b = 0; b < c.length; b += 1) {
            var e = c[b].split("\x3d");
            var g = e[0].replace(/^\s*/, "").replace(/\s*$/, "");
            try {
                var m =
                    decodeURIComponent(e[1])
            } catch (u) {
                m = e[1]
            }
            if ("object" === typeof JSON && null !== JSON && "function" === typeof JSON.parse) try {
                var p = m;
                m = JSON.parse(m)
            } catch (u) {
                m = p
            }
            a[g] = m
        }
        return a
    };
    var b = function() {};
    b.prototype.get = function(a) {
        var b, c = g();
        if ("string" === typeof a) var d = "undefined" !== typeof c[a] ? c[a] : null;
        else if ("object" === typeof a && null !== a)
            for (b in d = {}, a) d[a[b]] = "undefined" !== typeof c[a[b]] ? c[a[b]] : null;
        else d = c;
        return d
    };
    b.prototype.filter = function(a) {
        var b, c = {},
            d = g();
        "string" === typeof a && (a = new RegExp(a));
        for (b in d) b.match(a) && (c[b] = d[b]);
        return c
    };
    b.prototype.set = function(a, b, c) {
        if ("object" !== typeof c || null === c) c = {};
        if ("undefined" === typeof b || null === b) b = "", c.hoursToLive = -8760;
        else if ("string" !== typeof b)
            if ("object" === typeof JSON && null !== JSON && "function" === typeof JSON.stringify) b = JSON.stringify(b);
            else throw Error("cookies.set() received non-string value and could not serialize.");
        c = e(c);
        document.cookie = a + "\x3d" + encodeURIComponent(b) + c
    };
    b.prototype.del = function(a, b) {
        var c = {},
            d;
        if ("object" !== typeof b ||
            null === b) b = {};
        "boolean" === typeof a && !0 === a ? c = this.get() : "string" === typeof a && (c[a] = !0);
        for (d in c) "string" === typeof d && "" !== d && this.set(d, null, b)
    };
    b.prototype.test = function() {
        var a = !1;
        this.set("cT", "data");
        "data" === this.get("cT") && (this.del("cT"), a = !0);
        return a
    };
    b.prototype.setOptions = function(b) {
        "object" !== typeof b && (b = null);
        a = l(b)
    };
    return new b
}();
(function() {
    window.jQuery && function(a) {
        a.cookies = jaaulde.utils.cookies;
        a.each({
            cookify: function(l) {
                return this.each(function() {
                    var e, g = ["name", "id"],
                        b = a(this),
                        d;
                    for (e in g)
                        if (!isNaN(e)) {
                            var n = b.attr(g[e]);
                            if ("string" === typeof n && "" !== n) {
                                b.is(":checkbox, :radio") ? b.attr("checked") && (d = b.val()) : d = b.is(":input") ? b.val() : b.html();
                                if ("string" !== typeof d || "" === d) d = null;
                                a.cookies.set(n, d, l);
                                break
                            }
                        }
                })
            },
            cookieFill: function() {
                return this.each(function() {
                    var l, e, g = ["name", "id"],
                        b = a(this);
                    for (e = function() {
                            l =
                                g.pop();
                            return !!l
                        }; e();) {
                        var d = b.attr(l);
                        if ("string" === typeof d && "" !== d) {
                            e = a.cookies.get(d);
                            null !== e && (b.is(":checkbox, :radio") ? b.val() === e ? b.attr("checked", "checked") : b.removeAttr("checked") : b.is(":input") ? b.val(e) : b.html(e));
                            break
                        }
                    }
                })
            },
            cookieBind: function(l) {
                return this.each(function() {
                    var e = a(this);
                    e.cookieFill().change(function() {
                        e.cookify(l)
                    })
                })
            }
        }, function(l) {
            a.fn[l] = this
        })
    }(window.jQuery)
})();
Granite.I18n.setLocale($("#language").val());
var currencyComma = function(a, l) {
        null != l && (l = l.toLowerCase());
        if (null === a || "" === a) return "";
        var e = String(a),
            g = $("#siteCode").val();
        if (-1 < e.indexOf(".")) {
            var b = e.split(".");
            1 < b.length && 2 > b[1].length ? e += "0" : 2 < b[1].length && (e = Number(e).toFixed(2))
        }
        var d = b = "";
        if ("levant" === g) d = "jo";
        else if ("levant_ar" === g) d = "jo_ar";
        else if ("ae" === g || "ae_ar" === g) d = $.cookies.get("dotcom_multistore") ? $.cookies.get("dotcom_multistore").toString() : "";
        switch (l) {
            case "usd":
                if ("n_africa" === g) return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g,
                    " ") : e.replace(/\B(?=(\d{3})+(?!\d))/g, " ") + ".00", b + " DH";
                b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00";
                return "$" + b;
            case "dollar":
                if ("ca_fr" === g) return -1 < e.indexOf(".") ? (b = e.replace(/\B(?=(\d{3})+(?!\d))/g, " "), b = b.replace(".", ",")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, " ") + ",00", b + " $";
                b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00";
                return "$" + b;
            case "eur":
                if ("de" === g || "es" === g || "be_fr" ===
                    g || "it" === g || "pt" === g) return -1 < e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, ".")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + ",00", "be_fr" === g ? b : b + " \u20ac";
                if ("fi" === g || "fr" === g || "sk" === g || "at" === g || "ee" === g || "lt" === g || "lv" === g) return -1 < e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, " ")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, " ") + ",00", b + " \u20ac";
                if ("gr" === g) return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g,
                    ",") + ".00", "\u20ac" + b; - 1 < e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, ".")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + ",00";
                return "be" === g || "nl" === g ? b : "\u20ac " + b;
            case "gbp":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "\u00a3" + b;
            case "sek":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g, " "), b + " kr";
            case "dkk":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g, " "), b + " kr";
            case "nok":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g,
                    " "), b + " kr";
            case "brl":
                return -1 < e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, ".")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + ",00", "R$ " + b;
            case "inr":
                return l = ".00", -1 < e.indexOf(".") ? (a = e.substring(0, e.indexOf(".")), l = e.substring(e.indexOf("."))) : a = e, "\u20b9" + (a + l);
            case "krw":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ","), b + "\uc6d0";
            case "aed":
                if ("ae_ar" === g) return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00",
                    "kw_ar" == d ? b + " \u062f.\u0643" : "om_ar" == d ? b + " \u0631.\u0639." : "bh_ar" == d ? b + " .\u062f.\u0628" : b + " \u062f.\u0625";
                b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00";
                return "kw" == d ? b + " KD" : "bh" == d ? b + " BD" : "om" == d ? b + " RO" : b + " AED";
            case "rub":
                return -1 < e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, " ")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, " "), b + " \u20bd";
            case "twd":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ","), "NT$" + b;
            case "czk":
                return -1 <
                    e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, " ")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, " "), b + " K\u010d";
            case "myr":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "RM " + b;
            case "idr":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g, "."), "Rp " + b;
            case "pln":
                return -1 < e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, " ")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, " ") + ",00", b + " z\u0142";
            case "ron":
                return -1 <
                    e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, ".")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + ",00", b + " lei";
            case "php":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "\u20b1" + b;
            case "sar":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "sa" == siteCode ? b + " \u0631.\u0633" : b + " SAR";
            case "pab":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g,
                    ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "US$ " + b;
            case "mxn":
                return "$ " + a;
            case "ars":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "$ " + b;
            case "pen":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "S/. " + b;
            case "clp":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ","), "$ " + b;
            case "cop":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ","), "$ " + b;
            case "vnd":
                return b = e.replace(/\B(?=(\d{3})+(?!\d))/g,
                    "."), b + " \u20ab";
            case "chf":
                if ("ch" === g || "ch_fr" === g) return -1 < e.indexOf(".") ? (b = e.replace(".", ","), b = b.replace(/\B(?=(\d{3})+(?!\d))/g, ".")) : b = e.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + ",00", b + " CHF";
                b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, "'") : e.replace(/\B(?=(\d{3})+(?!\d))/g, "'") + ".00";
                return "CHF " + b;
            case "hkd":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "HK$ " + b;
            case "lbp":
                b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g,
                    ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00";
                if ("jo" == d) return b + " JD";
                if ("jo_ar" == d) return b + " \u062f.\u0627";
                break;
            case "pkr":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", "Rs. " + b;
            case "ils":
                return b = -1 < e.indexOf(".") ? e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") : e.replace(/\B(?=(\d{3})+(?!\d))/g, ",") + ".00", b + " \u20aa";
            default:
                try {
                    b = parseFloat(e).toLocaleString($("#hreflang").val(), {
                        style: "currency",
                        currency: l.toUpperCase()
                    })
                } catch (n) {
                    b =
                        e
                }
                return b
        }
    },
    deleteCurrencyComma = function(a, l) {
        var e = "",
            g = $("#siteCode").val();
        null != l && (l = l.toLowerCase());
        if (fnIsNull(a)) return "";
        "ca_fr" === g || "eur" === l && "gr" !== g || "rub" === l || "brl" === l || "pln" === l || "ron" === l || "cop" === l || "clp" === l || "krw" === l || "twd" === l || "ch" === g || "ch_fr" === g ? -1 < a.indexOf(",") ? (a = a.split(","), null != a[0] && "" != a[0] && (e = a[0].replace(/[^0-9]/g, "")), null != a[1] && "" != a[1] && (e += "." + a[1].replace(/[^0-9]/g, ""))) : e = a.replace(/[^0-9]/g, "") : "pk" === g ? -1 < a.indexOf(".") && (a = a.split("."), null != a[1] &&
            "" != a[1] && (e = a[1].replace(/[^0-9]/g, "")), null != a[2] && "" != a[2] && (e += "." + a[2].replace(/[^0-9]/g, ""))) : -1 < a.indexOf(".") ? (a = a.split("."), null != a[0] && "" != a[0] && (e = a[0].replace(/[^0-9]/g, "")), null != a[1] && "" != a[1] && (e += "." + a[1].replace(/[^0-9]/g, ""))) : e = a.replace(/[^0-9]/g, "");
        return e
    },
    deleteCurrency = function(a, l) {
        if (fnIsNull(a)) return "";
        if ("cl" == siteCode || "py" == siteCode) a = a.replace(/[^0-9]/g, "");
        else if (("pe" == siteCode || "ar" == siteCode || "co" == siteCode || "pk" === siteCode) && -1 < a.indexOf(".")) {
            var e = a.split(".");
            "pk" === siteCode ? null != e[1] && "" != e[1] && (a = e[1].replace(/[^0-9]/g, "")) : null != e[0] && "" != e[0] && (a = e[0].replace(/[^0-9]/g, ""))
        }
        e = a;
        null != l && (l = l.toLowerCase());
        switch (l) {
            case "usd":
                return -1 < a.indexOf("$") && (e = a.replace("$", "")), e;
            case "dollar":
                return -1 < a.indexOf("$") && (e = a.replace("$", "")), e;
            case "eur":
                return -1 < a.indexOf("\u20ac") && (e = a.replace("\u20ac", "")), e;
            case "gbp":
                return -1 < a.indexOf("\u00a3") && (e = a.replace("\u00a3", "")), e;
            case "sek":
                return -1 < a.indexOf("kr") && (e = a.replace("kr", "")), e;
            case "dkk":
                return -1 <
                    a.indexOf("kr") && (e = a.replace("kr", "")), e;
            case "nok":
                return -1 < a.indexOf("kr") && (e = a.replace("kr", "")), e;
            case "brl":
                return -1 < a.indexOf("R$") && (e = a.replace(".", "").replace("R$", "").replace(" ", "").replace(",", ".")), e;
            case "inr":
                return -1 < a.indexOf("\u20b9") && (e = a.replace("\u20b9", "")), "\u20b9" + e;
            case "krw":
                return -1 < a.indexOf("\uc6d0") && (e = a.replace("\uc6d0", "")), e;
            case "ae":
                return "ae_ar" === siteCode ? -1 < a.indexOf("\u062f.\u0625") && (e = a.replace("\u062f.\u0625", "")) : -1 < a.indexOf("AED") && (e = a.replace("AED",
                    "")), e;
            case "rub":
                return -1 < a.indexOf("\u20bd") && (e = a.replace("\u20bd", "")), e;
            case "twd":
                return -1 < a.indexOf("NT$") && (e = a.replace("NT$", "")), "NT$" + e;
            case "czk":
                return -1 < a.indexOf("K\u010d") && (e = a.replace("K\u010d", "")), e;
            case "myr":
                return -1 < a.indexOf("RM") && (e = a.replace("RM", "")), e;
            case "aed":
                return -1 < a.indexOf(" \u062f.\u0625") && (e = a.replace(" \u062f.\u0625", "")), e;
            case "pab":
                return -1 < a.indexOf("U$S") ? e = a.replace("U$S", "").replace(",", "").replace(" ", "") : -1 < a.indexOf("US$") && (e = a.replace("US$", "").replace(",",
                    "").replace(" ", "")), e;
            case "mxn":
                return -1 < a.indexOf("$") && (e = a.replace("$", "").replace(" ", "")), e;
            case "ars":
                return -1 < a.indexOf("$") && (e = a.replace("$", "").replace(" ", "")), e;
            case "pen":
                return -1 < a.indexOf("S/.") && (e = a.replace("S/.", "").replace(" ", "")), e;
            case "clp":
                return -1 < a.indexOf("$") && (e = a.replace("$", "").replace(" ", "")), e;
            case "cop":
                return -1 < a.indexOf("$") && (e = a.replace("$", "").replace(" ", "")), e;
            case "pyg":
                return -1 < a.indexOf("\u20b2") && (e = a.replace("\u20b2", "").replace(" ", "")), e;
            case "hkd":
                return -1 <
                    a.indexOf("HK$") && (e = a.replace("HK$", "").replace(" ", "")), e;
            case "pkr":
                return a.indexOf("Rs."), e;
            case "ils":
                return -1 < a.indexOf("\u20aa") && (e = a.replace("\u20aa", "").replace(" ", "")), e;
            default:
                return a
        }
    },
    imagePreset = function(a) {
        return -1 < a.indexOf("jpg") ? "?$ORIGIN_JPG$" : -1 < a.indexOf("jpeg") ? "?$ORIGIN_JPG$" : -1 < a.indexOf("png") ? "?$ORIGIN_PNG$" : -1 < a.indexOf("gif") ? "?$ORIGIN_GIF$" : "?$ORIGIN_PNG$"
    },
    imgDomain = function(a, l) {
        var e = "",
            g = $("#scene7domain").val();
        null !== a && (-1 < a.indexOf("image.samsung.com") ? e =
            a + imagePreset(a) : -1 < a.indexOf("http:") || "" === a ? e = a : (l && (g = g.replace("/image/", "/content/")), e = g + a + imagePreset(a)));
        return e
    },
    jqueryImgsrc = function(a, l, e) {
        if (null === a) return ""; - 1 < a.indexOf("/content/dam/samsung") && ("qa" === l ? (a = "stg" === e ? a.replace("/content/dam/samsung", "//stg-images.samsung.com/is/image/samsung/assets") : "prod" === e ? a.replace("/content/dam/samsung", "//stg-images.samsung.com/is/image/samsung/assets") : a.replace("/content/dam/samsung", "//stg-images.samsung.com/is/image/samsungdev/assets"),
            a += imagePreset(a)) : "live" === l && (a = "stg" === e ? a.replace("/content/dam/samsung", "//images.samsung.com/is/image/samsungstg/assets") : "prod" === e ? a.replace("/content/dam/samsung", "//images.samsung.com/is/image/samsung/assets") : a.replace("/content/dam/samsung", "//images.samsung.com/is/image/samsungdev/assets"), a += imagePreset(a)));
        return a
    },
    dateFormat = function() {
        var a = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
            l = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
            e = /[^-+\dA-Z]/g,
            g = function(a, d) {
                a = String(a);
                for (d = d || 2; a.length < d;) a = "0" + a;
                return a
            };
        return function(b, d, n) {
            var c = dateFormat;
            1 !== arguments.length || "[object String]" !== Object.prototype.toString.call(b) || /\d/.test(b) || (d = b, b = void 0);
            b = b ? new Date(b) : new Date;
            if (isNaN(b)) throw SyntaxError("invalid date");
            d = String(c.masks[d] || d || c.masks["default"]);
            "UTC:" === d.slice(0, 4) && (d = d.slice(4), n = !0);
            var h = n ? "getUTC" : "get",
                q = b[h + "Date"](),
                m = b[h + "Day"](),
                p = b[h + "Month"](),
                u = b[h + "FullYear"](),
                t = b[h + "Hours"](),
                y = b[h +
                    "Minutes"](),
                v = b[h + "Seconds"]();
            h = b[h + "Milliseconds"]();
            var L = n ? 0 : b.getTimezoneOffset(),
                J = {
                    d: q,
                    dd: g(q),
                    ddd: c.i18n.dayNames[m],
                    dddd: c.i18n.dayNames[m + 7],
                    m: p + 1,
                    mm: g(p + 1),
                    mmm: c.i18n.monthNames[p],
                    mmmm: c.i18n.monthNames[p + 12],
                    yy: String(u).slice(2),
                    yyyy: u,
                    h: t % 12 || 12,
                    hh: g(t % 12 || 12),
                    H: t,
                    HH: g(t),
                    M: y,
                    MM: g(y),
                    s: v,
                    ss: g(v),
                    l: g(h, 3),
                    L: g(99 < h ? Math.round(h / 10) : h),
                    t: 12 > t ? "a" : "p",
                    tt: 12 > t ? "am" : "pm",
                    T: 12 > t ? "A" : "P",
                    TT: 12 > t ? "AM" : "PM",
                    Z: n ? "UTC" : (String(b).match(l) || [""]).pop().replace(e, ""),
                    o: (0 < L ? "-" : "+") + g(100 * Math.floor(Math.abs(L) /
                        60) + Math.abs(L) % 60, 4),
                    S: ["th", "st", "nd", "rd"][3 < q % 10 ? 0 : (10 !== q % 100 - q % 10) * q % 10]
                };
            return d.replace(a, function(a) {
                return a in J ? J[a] : a.slice(1, a.length - 1)
            })
        }
    }();
dateFormat.masks = {
    "default": "ddd mmm dd yyyy HH:MM:ss",
    shortDate: "m/d/yy",
    mediumDate: "mmm d, yyyy",
    longDate: "mmmm d, yyyy",
    fullDate: "dddd, mmmm d, yyyy",
    shortTime: "h:MM TT",
    mediumTime: "h:MM:ss TT",
    longTime: "h:MM:ss TT Z",
    isoDate: "yyyy-mm-dd",
    isoTime: "HH:MM:ss",
    isoDateTime: "yyyy-mm-dd'T'HH:MM:ss",
    isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'"
};
dateFormat.i18n = {
    dayNames: "Sun Mon Tue Wed Thu Fri Sat Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" "),
    monthNames: "Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec January February March April May June July August September October November December".split(" ")
};
Date.prototype.format = function(a, l) {
    return dateFormat(this, a, l)
};
var loginJwtApiCal = function(a, l, e) {
        var g = {
            jwt: loginJwt
        };
        if ("us" === siteCode) {
            var b = $.cookies.get("epp_verified", {
                    domain: ".samsung.com"
                }),
                d = $.cookies.get("tmktid", {
                    domain: ".samsung.com"
                }),
                n = $.cookies.get("store_id", {
                    domain: ".samsung.com"
                });
            null != b && (b = b.toString(), "true" == b && null != d && "" != d ? g.store_id = d.toString() : null != n && "" != n && (g.store_id = n.toString()))
        }
        $.ajax({
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            url: a + "/v1/sso/user/validate",
            type: "POST",
            dataType: "json",
            data: JSON.stringify(g),
            timeout: 1E4,
            xhrFields: {
                withCredentials: !0
            },
            async: !1,
            beforeSend: function(a) {
                "Y" === buyingMultiLanguageYn && a.setRequestHeader("x-ecom-locale", l)
            },
            success: function(a) {
                if (200 !== a.statusCode && "200" !== a.statusCode) return $.cookies.del("jwt_" + e, {
                    domain: ".samsung.com"
                }), {
                    isValidJwtToken: !1
                }
            },
            error: function(a, b, d) {
                console.error(b);
                return null == a.responseJSON || "StoreIdNotPresent" !== a.responseJSON.error ? ($.cookies.del("jwt_" + e, {
                    domain: ".samsung.com"
                }), {
                    isValidJwtToken: !1
                }) : {
                    loginFlag: !1
                }
            }
        })
    },
    isValidJwtTokenApiCal = function(a, l, e, g) {
        $.cookies.get("ReD", {
            domain: ".samsung.com"
        });
        a = $("#siteCode").val();
        var b = !1;
        $.ajax({
            url: "/aemapi/v6/data-login/callSALogin." + a + ".json",
            type: "GET",
            dataType: "json",
            success: function(a) {
                200 === a.statusCode && "Y" === a.redCookieChk && $.cookies.get("jwt_" + e, {
                    domain: ".samsung.com"
                }) && (b = !0)
            },
            error: function(a, b, c) {}
        });
        return b
    },
    loginJwtValidateApiCal = function(a, l, e, g, b) {
        var d = !1;
        e = {
            jwt: b
        };
        if ("us" === siteCode) {
            b = $.cookies.get("epp_verified", {
                domain: ".samsung.com"
            });
            var n = $.cookies.get("tmktid", {
                    domain: ".samsung.com"
                }),
                c = $.cookies.get("store_id", {
                    domain: ".samsung.com"
                });
            null != b && (b = b.toString(), "true" == b && null != n && "" != n ? e.store_id = n.toString() : null != c && "" != c && (e.store_id = c.toString()))
        }
        $.ajax({
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            url: a + "/v1/sso/user/validate",
            type: "POST",
            dataType: "json",
            data: JSON.stringify(e),
            xhrFields: {
                withCredentials: !0
            },
            async: !1,
            beforeSend: function(a) {
                "Y" === g && a.setRequestHeader("x-ecom-locale",
                    l)
            },
            success: function(a) {
                200 === a.statusCode || "200" === a.statusCode ? (d = !0, $("#loginValidateYnForGPv2").val("Y")) : $("#loginValidateYnForGPv2").val("N")
            },
            error: function() {
                $("#loginValidateYnForGPv2").val("N")
            }
        });
        return d
    },
    commonLoginCheck = function() {
        var a = function() {
            $("#loginValidateYnForGPv2").val("N");
            return !1
        };
        if ("GPv2" === $("#shopIntegrationFlag").val()) {
            var l = $("#storeDomain").val(),
                e = $("#countryIsoCode").val(),
                g = $("#multiLanguageYn").val(),
                b = $("#hreflang").val(),
                d = $.cookies.get("xsdcxyn", {
                    domain: ".samsung.com"
                }),
                n = $.cookies.get("jwt_" + e, {
                    domain: ".samsung.com"
                }),
                c = $("#loginValidateYnForGPv2").val(),
                h = !1,
                q = !0;
            if (c) {
                if ("Y" === c) return !0;
                if ("N" === c) return !1
            } else {
                if (null != n) {
                    d = {
                        jwt: n
                    };
                    var m = !1;
                    "us" === siteCode && (h = $.cookies.get("epp_verified", {
                        domain: ".samsung.com"
                    }), n = $.cookies.get("tmktid", {
                        domain: ".samsung.com"
                    }), c = $.cookies.get("store_id", {
                        domain: ".samsung.com"
                    }), null != h && (h = h.toString(), "true" == h && null != n && "" != n ? d.store_id = n.toString() : null != c && "" != c && (d.store_id = c.toString())), $.ajax({
                        headers: {
                            "Cache-Control": "no-cache",
                            "Content-Type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        },
                        url: STORE_DOMAIN + "/v1/sso/jwt/details",
                        type: "POST",
                        async: !1,
                        dataType: "json",
                        data: JSON.stringify(d),
                        xhrFields: {
                            withCredentials: !0
                        },
                        success: function(a) {
                            null == a || "" === a || null == a.login_type || "guest_epp_store" !== a.login_type && "referral_url" !== a.login_type || (m = !0)
                        }
                    }));
                    m ? h = a() : $.ajax({
                        headers: {
                            "Cache-Control": "no-cache",
                            "Content-Type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        },
                        url: l + "/v1/sso/user/validate",
                        type: "POST",
                        dataType: "json",
                        data: JSON.stringify(d),
                        async: !1,
                        xhrFields: {
                            withCredentials: !0
                        },
                        beforeSend: function(a) {
                            "Y" === g && a.setRequestHeader("x-ecom-locale", b)
                        },
                        success: function(a) {
                            200 !== a.statusCode && "200" !== a.statusCode && (q = !1)
                        },
                        error: function(a, b, c) {
                            console.error(b);
                            q = !1
                        }
                    });
                    q ? ($("#loginValidateYnForGPv2").val("Y"), h = !0) : isValidJwtTokenApiCal(l, b, e, g) ? (a = $.cookies.get("jwt_" + e, {
                        domain: ".samsung.com"
                    }).toString(), h = loginJwtValidateApiCal(l, b, e, g, a)) : h = a()
                } else null != d ? isValidJwtTokenApiCal(l, b, e, g) ? (a = $.cookies.get("jwt_" +
                    e, {
                        domain: ".samsung.com"
                    }).toString(), h = loginJwtValidateApiCal(l, b, e, g, a)) : h = a() : h = a();
                return h
            }
        } else return ss.Auth.checkSignIn()
    },
    addedWishList = [],
    commonGetWishlist = function(a) {
        var l = $("#storeDomain").val(),
            e = $("#countryIsoCode").val();
        e = $.cookies.get("jwt_" + e, {
            domain: ".samsung.com"
        });
        var g = $("#multiLanguageYn").val(),
            b = $("#hreflang").val();
        null != e ? $.ajax({
            headers: {
                "Cache-Control": "no-cache",
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "x-ecom-app-id": "identity-store-global",
                "x-ecom-jwt": e
            },
            url: l + "/v4/identity/wishlist",
            type: "GET",
            dataType: "json",
            timeout: 2E4,
            xhrFields: {
                withCredentials: !0
            },
            beforeSend: function(a) {
                "Y" === g && a.setRequestHeader("x-ecom-locale", b)
            },
            success: function(a) {
                null != a && (addedWishList = a)
            },
            error: function(a) {
                addedWishList = []
            },
            complete: function() {
                a && "function" === typeof a && a()
            }
        }) : a && "function" === typeof a && a()
    };

function fnIsNull(a) {
    return "" === a || void 0 === a || null === a
}

function def(a, l) {
    for (var e in l) Object.prototype.hasOwnProperty.call(l, e) && ("object" === $.type(a[e]) ? a[e] = this.isArray(a[e]) ? l[e].slice(0) : this.def(a[e], l[e]) : a[e] = l[e]);
    return a
}
var cookies = function() {
    var a = {
        expires: "",
        path: "/",
        domain: "",
        secure: ""
    };
    return {
        setCookie: function(l, e, g) {
            var b = new Date;
            b.setTime(b.getTime() + 864E5 * (g || 0));
            g = def(a, {
                expires: b
            });
            document.cookie = [l, "\x3d", e, g.expires ? "; expires\x3d" + g.expires.toUTCString() : "", g.path ? "; path\x3d" + g.path : "", g.domain ? "; domain\x3d" + g.domain : "", g.secure ? "; secure" : ""].join("")
        },
        getCookie: function(a) {
            a += "\x3d";
            for (var e = document.cookie.split(";"), g, b = 0, d = e.length; b < d; b++) {
                for (g = e[b];
                    " " === g.charAt(0);) g = g.substring(1);
                if (-1 !==
                    g.indexOf(a)) return g.substring(a.length, g.length)
            }
            return ""
        }
    }
}();
void 0 === window.sg && (window.sg = {});
void 0 === window.sg.components && (window.sg.components = {});
window.sg.components.pfdevfn = {
    afterAddWishlist: function(a, l, e, g, b) {
        fnIsNull(a) || (a.hasClass(l) ? "GPv2" === g && a.removeClass(l) : a.addClass(l), a.attr("aria-selected", !0), "hybrisIntg" === g ? (a.prop("disabled", !0), a.attr("data-add-text", e), a.removeAttr("aria-label"), a.addClass("cta--disabled")) : "GPv2" === g && (a.hasClass("js-delete-wishlist-btn") ? (a.removeClass("js-delete-wishlist-btn"), a.attr("aria-selected", !1), a.removeAttr("data-added-text"), a.attr("data-add-text", e), a.attr("an-la", "add to wishlist"), a.find("span").text(e),
            a.blur()) : (a.addClass("js-delete-wishlist-btn"), a.removeAttr("data-add-text"), a.attr("data-added-text", e), a.attr("an-la", "remove from wishlist"), a.find("span").text(e), a = {}, a.sku = b, a.deleted = !1, addedWishList.push(a)), window.sg.components.wishlistIcon.reInit()))
    },
    spliceAddedWishList: function(a) {
        if (0 < addedWishList.length)
            for (var l = 0; l < addedWishList.length; l++)
                if (addedWishList[l].sku === a) {
                    addedWishList.splice(l, 1);
                    break
                }
    }
};

function modelCodeToSelector(a) {
    var l = "";
    a && (l = a.replace(/\//g, "@$"));
    return l
}
(function(a) {
    "undefined" === typeof a.cookies && (a.cookies = {});
    var l = a("#siteCode").val();
    a.cookies.data = a.cookies.data || {};
    a.cookies.data.SEARCH_NAME = "sk";
    a.cookies.getDefaultOption = function(a, g) {
        a && a instanceof Date || (a = new Date, a.setTime(a.getTime() + 864E5));
        g ? -1 < window.location.pathname.indexOf("/content/samsung") && (g = "/content/samsung" + g) : g = "/";
        return {
            expiresAt: a,
            path: g,
            domain: ".samsung.com",
            secure: !1
        }
    };
    a.cookies.setSearchKeyword = function(e, g) {
        var b = this.data.SEARCH_NAME,
            d = this.get(b);
        if (d) {
            if (0 <=
                a.inArray(e, d)) return;
            4 <= d.length && d.splice(0, 1);
            d.push(e)
        } else d = [e];
        this.set(b, d, this.getDefaultOption(g, "/" + l + "/"))
    };
    a.cookies.getSearchKeyword = function() {
        var e = this.get(this.data.SEARCH_NAME);
        return e && a.isArray(e) ? e : []
    };
    a.cookies.clearSearchKeyword = function(a) {
        this.del(this.data.SEARCH_NAME, this.getDefaultOption(a, "/" + l + "/"))
    }
})(window.jQuery);
(function(a, l) {
    function e(a, d) {
        if (d.children)
            for (var m = 0; m < d.children.length;) {
                var h = d.children[m],
                    p = h.classList;
                if (p && p.contains("sdf-component-metadata")) g(a, h);
                else if (p && p.contains("sdf-component-templates")) {
                    p = h.children;
                    for (var q = 0; q < p.length;) {
                        var l = p[q];
                        l.hasAttribute("data-sdf-template") ? b(a, l) : q++
                    }
                    d.removeChild(h)
                } else h.hasAttribute("data-sdf-template") ? b(a, h) : (h.hasAttribute("data-sdf-test") && (p = h.sdfContext = {}, n(p, h.getAttribute("data-sdf-test")), h.removeAttribute("data-sdf-test")), h.hasAttribute("data-sdf-call") ?
                    (p = h.sdfContext = {}, c(p, h.getAttribute("data-sdf-call")), h.removeAttribute("data-sdf-call")) : (e(a, h), m++))
            }
    }

    function g(b, c) {
        c = a(c);
        c.find("[data-sdf-prop]").each(function(c) {
            (c = a.trim(this.getAttribute("data-sdf-prop"))) && 0 < c.length && b.metadata.set(c, a.trim(this.textContent))
        });
        c.remove()
    }

    function b(b, c) {
        var e = a(c),
            h = c.parentElement;
        e.removeClass("sdf-component-template");
        var g = a.trim(c.getAttribute("data-sdf-template"));
        if (0 === g.length) log.error("[SDF] Illegal template attribute: template name required: " +
            ja(c));
        else {
            var n = g.indexOf("@");
            var q = 0 > n ? g : a.trim(g.substring(0, n));
            if (0 === q.length) log.error("[SDF] Illegal template attribute: template name is empty: " + ja(c));
            else {
                var t = a.trim(g.substring(n + 1));
                g = [];
                n = !1;
                if (0 < t.length) {
                    t = t.split(",");
                    for (var w = 0; w < t.length; w++) {
                        var H = a.trim(t[w]);
                        if (0 !== H.length) {
                            var v = H.indexOf("\x3d");
                            if (0 > v) g.push({
                                variable: H
                            });
                            else {
                                var y = a.trim(H.substring(0, v));
                                H = u(a.trim(H.substring(v + 1)));
                                !n && H && (n = !0);
                                g.push({
                                    variable: y,
                                    reference: H
                                })
                            }
                        }
                    }
                }
                c.removeAttribute("data-sdf-template");
                if (n) {
                    h = l.createElement(c.localName);
                    if (c.hasAttributes()) {
                        n = c.attributes;
                        for (t = 0; t < n.length; t++) h.setAttribute(n[t].localName, n[t].nodeValue);
                        n = c.attributes;
                        for (t = n.length - 1; 0 <= t; t--) c.removeAttribute(n[t].localName)
                    }
                    if (c.hasChildNodes())
                        for (; c.firstChild;) h.appendChild(c.firstChild);
                    n = p(q);
                    c.sdfContext = {
                        invokeTemplate: {
                            template: q,
                            isDynamic: n,
                            nameToken: n ? m(q) : null,
                            binds: g
                        }
                    };
                    c = h
                } else h && h.removeChild(c);
                h = c;
                n = (n = e.parent()) && 0 < n.length && !n.hasClass("sdf-component-templates") ? n.get(0) : null;
                e = {
                    name: q,
                    element: h,
                    $element: e,
                    variables: g,
                    target: n
                };
                b.templates.set(q, e);
                c.sdfContext = c.sdfContext || {};
                c.sdfContext.template = e;
                d(b, e, c)
            }
        }
    }

    function d(e, g, t) {
        if (t.nodeType === l.ELEMENT_NODE) {
            a: {
                t.sdfContext = t.sdfContext || {};
                if (t.hasAttributes()) {
                    if (t.hasAttribute("data-sdf-template")) {
                        b(e, t);
                        e = !0;
                        break a
                    }
                    for (var w = t.attributes, H = t.sdfContext, F = 0; F < w.length; F++) {
                        var A = w[F],
                            v = A.name;
                        A = A.nodeValue;
                        if ("data-sdf-test" === v) n(H, A);
                        else if ("data-sdf-call" === v) c(H, A);
                        else if ("data-sdf-unwrap" === v) v = H, p(A) ? v.unwrap = {
                            isDynamic: !0,
                            value: u(A)
                        } : (A = a.trim(A), v.unwrap = {
                            isDynamic: !1,
                            value: 0 === A.length || "true" === A.toLowerCase()
                        });
                        else if ("data-sdf-element" === v) v = H, p(A) ? v.element = {
                            isDynamic: !0,
                            value: u(A)
                        } : v.element = {
                            isDynamic: !1,
                            value: a.trim(A)
                        };
                        else if (0 === v.indexOf("data-sdf-attr")) {
                            var y = H;
                            v = v.substring(13);
                            1 >= v.length || "." !== v.charAt(0) ? console.warn("[SDF] Empty dynamic attribute name: " + v + '\x3d"' + A + '"') : q(y, !0, !1, v.substring(1), m(A))
                        } else 0 === v.indexOf("data-sdf-list") ? h("data-sdf-list", H, v, A) : 0 === v.indexOf("data-sdf-repeat") ?
                            h("data-sdf-repeat", H, v, A) : (y = p(A), q(H, y, !0, v, y ? m(A) : A))
                    }
                    t.sdfContext = H
                }
                if (t.hasChildNodes())
                    for (t = t.childNodes, w = 0; w < t.length;) d(e, g, t[w]) || w++;e = !1
            }
            return e
        }
        t.nodeType === l.TEXT_NODE && 0 <= t.nodeValue.indexOf("{{") && (e = m(t.nodeValue), t.sdfContext = {
            bindTokens: e
        });
        return !1
    }

    function n(b, c) {
        var d = p(c),
            e = d ? u(a.trim(c)) : c.toLowerCase();
        e && 0 < e.length ? b.test = d ? e : "true" === e : console.warn("[SDF] Empty test attribute: " + aname + '\x3d"' + c + '"')
    }

    function c(b, c) {
        var d = a.trim(c).split(/\s*@\s*/);
        if (0 === d[0].length) console.warn("[SDF] Illegal template call: " +
            c + '"');
        else {
            c = d[0];
            var e = p(c);
            b.invokeTemplate = {
                template: c,
                isDynamic: e,
                nameTokens: e ? m(c) : null
            };
            if (1 < d.length && 0 < d[1].length) {
                c = [];
                d = d[1].split(/\s*,\s*/);
                for (e = 0; e < d.length; e++)
                    if (0 < d[e].length) {
                        var h = d[e].split(/\s*=\s*/);
                        2 < h.length || 0 === h[0].length ? console.warn("[SDF] Illegal variable binds: " + d[e]) : c.push({
                            variable: h[0],
                            reference: 2 === h.length ? u(h[1]) : null
                        })
                    }
                0 < c.length && (b.invokeTemplate.binds = c)
            }
        }
    }

    function h(a, b, c, d) {
        c = c.substring(a.length);
        var e = 1 < c.length && "." === c.charAt(0) ? c.substring(1) : "";
        0 === e.length && (e = "item");
        var h = u(d);
        0 === h.length ? console.warn("[SDF] Illegal '" + a + "' directive: " + c + '\x3d"' + d + '"') : b["data-sdf-list" === a ? "list" : "repeat"] = {
            variable: e,
            reference: h
        }
    }

    function q(a, b, c, d, e) {
        d && e && 0 < e.length && (a.attributes || (a.attributes = {}), a.attributes[d] = {
            isDynamic: b,
            isAllowBlank: c,
            isNamespaceProvided: 0 < d.indexOf(":"),
            name: d,
            value: e
        })
    }

    function m(a) {
        for (var b = 0, c = 0, d = []; b < a.length;) {
            b = a.indexOf("{{", c);
            if (0 > b) {
                d.push(a.substring(c));
                break
            }
            d.push(a.substring(c, b));
            c = a.indexOf("}}", b + 2);
            if (0 > c) {
                d.push(a.substring(b));
                break
            }
            d.push(a.substring(b + 2, c));
            b = c += 2
        }
        return d
    }

    function p(a) {
        var b = a.indexOf("{{");
        return 0 <= b ? 0 < a.indexOf("}}", b + 2 + 1) : !1
    }

    function u(a) {
        if (!a || 4 > a.length) return "";
        var b = a.indexOf("{{"),
            c = a.indexOf("}}");
        return 0 > b || 0 > c || b > c || b + 2 === c ? (console.warn("[SDF] Illegal expression: " + a), "") : a.substring(b + 2, c)
    }

    function t(a, b, c, d) {
        if (d = d || b.target) {
            var e = y({
                component: a,
                template: b,
                bindObject: c,
                target: d,
                parent: d,
                currentNode: b.element
            });
            e && (e.boundData = c);
            0 < a.observers.length &&
                a.notify("onTemplateRendered", {
                    template: b,
                    target: d,
                    boundData: c
                });
            return e
        }
        console.error("[SDF] Unknown bind target")
    }

    function y(a) {
        var b = a.currentNode,
            c = b.sdfContext;
        if (b.nodeType === l.TEXT_NODE) {
            var d = b.nodeValue;
            c ? c.bindTokens && (d = E(c.bindTokens, a.bindObject)) : p(d) && (d = m(d), d = E(d, a.bindObject));
            c = document.createElement("div");
            for (c.innerHTML = d; c.firstChild;) a.parent.appendChild(c.firstChild);
            return b
        }
        a: if (d = c || {}, b = a.bindObject, la(d, b)) {
            if (d.invokeTemplate) {
                c = d.invokeTemplate;
                var e = c.isDynamic ? E(c.nameTokens,
                        b) : c.template,
                    h = a.component.templates.get(e);
                if (h) {
                    a = v(a.component, h, c.binds, b, a.parent);
                    break a
                } else console.warn("[SDF] Unknown template '" + e + "'")
            }
            c = !1;
            d.unwrap && (e = d.unwrap, !e.isDynamic && !0 === e.value || e.isDynamic && !0 === J(e.value)) && (c = !0);
            e = void 0;
            if (d.repeat || d.list) {
                if (d.repeat) {
                    h = c;
                    var g = J(b, d.repeat.reference);
                    if (g && 0 < g.length) {
                        for (var n = a.parent, q = a.currentNode, u = d.repeat.variable, t = 0; t < g.length; t++) {
                            var w = g[t];
                            b[u] = w;
                            w.loopIndex = t.toString();
                            w.loopCount = (t + 1).toString();
                            a.parent = h ? n : ma(n,
                                q, d, b);
                            a.currentNode = q;
                            L(a)
                        }
                        delete b[u];
                        a.parent = n
                    }
                }
                if (d.list && (e = void 0, (h = J(b, d.list.reference)) && 0 < h.length)) {
                    g = a.parent;
                    n = a.currentNode;
                    q = d.list.variable;
                    c || (e = ma(g, n, d, b), a.parent = e);
                    for (d = 0; d < h.length; d++) u = h[d], b[q] = u, u.loopIndex = d.toString(), u.loopCount = (d + 1).toString(), a.parent = c ? g : e, a.currentNode = n, L(a);
                    delete b[q];
                    a.parent = g
                }
            } else c || (e = ma(a.parent, a.currentNode, d, b), a.parent = e), L(a);
            a = e
        } else a = void 0;
        return a
    }

    function v(a, b, c, d, e) {
        var h = {};
        if (c && 0 < c.length)
            for (var m = 0; m < c.length; m++) h[c[m].variable] =
                J(d, c[m].reference);
        return t(a, b, h, e || b.target)
    }

    function L(a) {
        var b = a.parent,
            c = a.currentNode.childNodes;
        if (c && 0 < c.length)
            for (var d = 0; d < c.length; d++) a.parent = b, a.currentNode = c[d], y(a);
        a.parent = b
    }

    function J(b, c) {
        if (b && c) {
            c = a.trim(c).split(".");
            for (var d = 0; d < c.length && (b = b[c[d]], b); d++);
            return b
        }
    }

    function E(a, b) {
        var c = [];
        if (a && 0 < a.length)
            for (var d = 0; d < a.length; d++) {
                var e = a[d],
                    h = J(b, e);
                void 0 !== h && null !== h && (h = h.toString());
                c.push(0 == d % 2 ? e : h)
            }
        return c.join("")
    }

    function la(a, b) {
        return "undefined" !== typeof a.test &&
            (a = "string" === typeof a.test ? J(b, a.test) : a.test, void 0 === a || null === a || !1 === a || "undefined" !== typeof a.length && 0 === a.length) ? !1 : !0
    }

    function ma(b, c, d, e) {
        var h = c.localName;
        if (d.element) {
            var m = d.element;
            h = a.trim(m.isDynamic ? J(m.value) : m.value);
            0 === h.length && (console.warn("[SDF] Empty dynamic tag name: use default '" + c.localName + "'"), h = c.localName)
        }
        m = null;
        try {
            if (c.prefix) {
                var p = da[c.prefix];
                p ? m = l.createElementNS(p, h) : (console.warn("[SDF] Unsupported name prefix of element: " + c.name + "; namespace ignored"),
                    m = l.createElement(h))
            } else m = l.createElement(h)
        } catch (N) {
            console.warn("[SDF] Can't create element: " + N.toString() + ": use default '" + c.localName + "'"), m = l.createElement(c.localName)
        }
        if (c = d.attributes)
            for (var g in c)
                if (p = c[g], d = p.isDynamic ? E(p.value, e) : p.value, p.isAllowBlank || !p.isAllowBlank && 0 < d.length) p.isNamespaceProvided ? (p = g.substring(0, g.indexOf(":")), (p = da[p]) ? m.setAttributeNS(p, g, d) : (console.warn("[SDF] Unsupported name prefix of attribute: " + g + "; namespace ignored"), m.setAttribute(g, d))) : m.setAttribute(g,
                    d);
        b.appendChild(m);
        return m
    }

    function ia(a, b, c) {
        if (b.nodeType === l.TEXT_NODE) V(b, c);
        else {
            if (b.sdfContext) {
                var d = b.sdfContext;
                if (!la(d, c)) {
                    b.parentElement.removeChild(b);
                    return
                }
                if (d.invokeTemplate) {
                    d = b.parentElement;
                    var e = b.sdfContext.invokeTemplate,
                        h = e.isDynamic ? E(e.nameTokens, c) : e.template;
                    if (h = a.templates.get(h)) {
                        for (var m = b.childNodes, p = m.length - 1; 0 <= p; p--) b.removeChild(m[p]);
                        v(a, h, e.binds, c, b);
                        if (d)
                            for (; b.hasChildNodes();) d.insertBefore(b.firstChild, b)
                    }
                    d && d.removeChild(b);
                    return
                }
            }
            if (b.hasAttributes())
                for (d =
                    b.attributes, e = 0; e < d.length; e++) 0 > d[e].localName.indexOf("data-sdf-") && V(d[e], c);
            if (b.hasChildNodes())
                for (d = 0; d < b.childNodes.length; d++) ia(a, b.childNodes[d], c)
        }
    }

    function V(a, b) {
        if (p(a.nodeValue)) {
            var c = m(a.nodeValue);
            a.nodeValue = E(c, b)
        }
    }

    function ja(a) {
        var b = "\x3c" + a.nodeName.toLowerCase();
        if (a.hasAttributes()) {
            a = a.attributes;
            for (var c = 0; c < a.length; c++) b += " " + a[c].name + '\x3d"' + a[c].nodeValue + '"'
        }
        return b + "\x3e"
    }

    function G(a, b, c) {
        if ((a = Q.get(a)) && 0 < a.length)
            for (var d = 0; d < a.length; d++) {
                var e = a[d];
                if (e[b]) try {
                    e[b].call(e,
                        c)
                } catch (B) {
                    console.warn("[SDF] Can't notify component event '" + b + "': " + B)
                }
            }
    }

    function W(a, b) {
        this.selector = a;
        this.$ui = b;
        this.rootElement = b.get(0);
        this.metadata = new Map;
        this.templates = new Map;
        this.observers = [];
        e(this, this.rootElement)
    }
    window.sg = window.sg || {};
    window.sg.sdf = window.sg.sdf || {};
    var da = {
            html: "http://www.w3.org/1999/xhtml",
            xlink: "http://www.w3.org/1999/xlink",
            svg: "http://www.w3.org/2000/svg",
            xbl: "http://www.mozilla.org/xbl",
            xul: "http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul"
        },
        Q = new Map,
        K = new Map;
    W.prototype = {
        init: function(a) {
            G(this.selector, "onBeforeInit", this);
            var b = u(this.rootElement.getAttribute("data-sdf-bind"));
            b && 0 < b.length && ((a = J(a, b)) && ia(this, this.rootElement, a), this.rootElement.removeAttribute("data-sdf-bind"), this.rootElement.boundData = a);
            G(this.selector, "onAfterInit", this)
        },
        meta: function(a) {
            return this.metadata.get(a)
        },
        invokeTemplate: function(a, b, c) {
            p(a) && (a = m(a), a = E(a, b));
            return (a = this.templates.get(a)) ? t(this, a, b, c) : null
        },
        addObserver: function(a) {
            this.observers.push(a)
        },
        removeObserver: function(a) {
            a = this.observers.indexOf(a);
            0 <= a && this.observers.splice(a, 1)
        },
        notify: function(a, b) {
            for (var c = 0; c < this.observers.length; c++) {
                var d = this.observers[c];
                if (d[a]) try {
                    d[a].call(d, b)
                } catch (Z) {
                    console.warn("[SDF] Notification failure: '" + a + "': " + Z)
                }
            }
        }
    };
    window.sg.sdf.comp = {
        dispatch: function(b) {
            var c = a(b);
            if (0 !== c.length) {
                var d = K.get(b);
                d || (d = [], K.set(b, d), c.each(function() {
                    var c = new W(b, a(this));
                    G(b, "onCreated", c);
                    d.push(c)
                }));
                return 1 === d.length ? d[0] : d
            }
        },
        dispose: function(a) {
            if (K.has(a)) {
                for (var b =
                        K.get(a), c = 0; c < b.length; c++) G(a, "onDispose", b[c]);
                K["delete"](a)
            }
        },
        attachListener: function(a, b) {
            var c = Q.get(a);
            c || (c = [], Q.set(a, c));
            c.push(b)
        },
        detachListener: function(a, b) {
            (a = Q.get(a)) && 0 < a.length && (b = a.indexOf(b), 0 <= b && a.splice(b, 1))
        }
    }
})(jQuery, document);
(function(a) {
    window.sg = window.sg || {};
    window.sg.sdf = window.sg.sdf || {};
    window.sg.sdf.util = {
        getImagePreset: function(l, e, g) {
            e = a.trim(e || "").toLowerCase();
            if (0 > e.indexOf("?$")) {
                l = "?$" + l + "_";
                if (g && "" !== a.trim(g)) return l + a.trim(g).toUpperCase() + "$";
                g = e.lastIndexOf(".");
                if (0 < g) switch (e.substring(g + 1)) {
                    case "jpg":
                    case "jpeg":
                        return l + "JPG$";
                    case "png":
                        return l + "PNG$";
                    case "gif":
                        return l + "GIF$";
                    default:
                        return l + "IMG$"
                }
            }
            return ""
        },
        presetImage: function(l, e, g) {
            return 0 < a.trim(e).length ? e + this.getImagePreset(l,
                e, g) : e
        },
        previewImageSrc: function(a, e) {
            return this.presetImage("LazyLoad_Home", a, e)
        },
        productCardImageSrc: function(a, e) {
            return this.presetImage("PC_PRD_CARD", a, e)
        }
    }
})(jQuery);
(function(a) {
    function l(e, g) {
        a(e).each(function(a, d) {
            d.hasAttribute(g) || d.setAttribute(g, "")
        })
    }
    a(function() {
        l("a", "title");
        l("img", "alt")
    })
})(jQuery);
(function() {
    function a(a, g) {
        var b = g + "_desktop",
            d = a[b],
            e = g + "_mobile",
            c = a[e];
        "mobile" === l ? c && 0 < c.length ? a[g] = c : !a[g] && d && 0 < d.length && (a[g] = d) : "desktop" === l && (d && 0 < d.length ? a[g] = d : !a[g] && c && 0 < c.length && (a[g] = c));
        delete a[b];
        delete a[e]
    }
    var l = function() {
        var a = window,
            g = "inner";
        "innerWidth" in window || (g = "client", a = document.documentElement || document.body);
        return 767 < a[g + "Width"] ? "desktop" : "mobile"
    }();
    (function() {
        var e = document.querySelectorAll("script[data-object-type\x3d'VideoObject']");
        if (e && 0 < e.length)
            for (var g =
                    0, b = e.length; g < b; g++) {
                var d = JSON.parse(e[g].innerText);
                a(d, "thumbnailUrl");
                a(d, "contentUrl");
                e[g].innerText = JSON.stringify(d)
            }
    })()
})();
(function() {
    window.sg = window.sg || {};
    window.sg.common = window.sg.common || {};
    window.sg.components = window.sg.components || {};
    var a = {
            BREAKPOINTS: {
                DESKTOP: 1440,
                MOBILE: 767,
                MOBILE_UNDER: 360
            },
            SELECTOR: {
                RES_IMG: ".responsive-img",
                VIDEO: ".video",
                LAZY_LOAD: ".lazy-load",
                PREVIEW_IMG: ".preview",
                INDICATOR: ".indicator"
            },
            KEY_CODE: {
                TAB: 9,
                ENTER: 13,
                SPACE: 32,
                PAGE_UP: 33,
                PAGE_DOWN: 34,
                END: 35,
                HOME: 36,
                LEFT: 37,
                UP: 38,
                RIGHT: 39,
                DOWN: 40,
                ESC: 27
            }
        },
        l, e, g = "",
        b = {
            getViewPort: function() {
                var a = window,
                    b = "inner";
                "innerWidth" in window || (b = "client",
                    a = document.documentElement || document.body);
                return {
                    width: a[b + "Width"],
                    height: a[b + "Height"]
                }
            },
            getCurrentDevice: function() {
                return b.getViewPort().width > a.BREAKPOINTS.MOBILE ? "desktop" : "mobile"
            },
            getCurrentMediaType: function() {
                var d = b.getViewPort().width;
                return d > a.BREAKPOINTS.MOBILE ? d > a.BREAKPOINTS.DESKTOP ? "desktop-over" : "desktop" : d > a.BREAKPOINTS.MOBILE_UNDER ? "mobile" : "mobile-under"
            },
            isInVerticalViewPort: function(a) {
                a = a.getBoundingClientRect();
                return a.top - 200 <= b.getViewPort().height && 0 <= a.bottom
            },
            isInHorizontalViewPort: function(a) {
                a =
                    a.getBoundingClientRect();
                return a.left - 200 <= b.getViewPort().width && 0 <= a.right + 200
            },
            isVerticalVisible: function(a) {
                return b.isInVerticalViewPort(a) && !!(a.offsetWidth || a.offsetHeight || a.getClientRects().length)
            },
            isHorizontalVisible: function(a) {
                return b.isInHorizontalViewPort(a) && !!(a.offsetWidth || a.offsetHeight || a.getClientRects().length)
            },
            isInViewPort: function(a) {
                return b.isInVerticalViewPort(a) && b.isInHorizontalViewPort(a)
            },
            isVisible: function(a) {
                return b.isInViewPort(a) && !!(a.offsetWidth || a.offsetHeight ||
                    a.getClientRects().length)
            },
            scrollTo: function(a, e) {
                var c = document.documentElement,
                    d = c.scrollTop,
                    g = c.scrollHeight,
                    m = c.clientHeight;
                c = c.scrollLeft;
                a > g - m && (a = g - m);
                var p = isNaN(e) ? d : e;
                p += (a - d) / 7;
                0 > p ? p = 0 : p > g - m && (p = g - m);
                e = Math.ceil(p);
                window.scrollTo(c, e);
                e !== a ? l = setTimeout(function() {
                    b.scrollTo(a, p)
                }, 15) : clearTimeout(l)
            },
            setImageSpecGuide: function(a, b) {
                var c = document.createElement("span");
                c.innerHTML = b;
                c.style.position = "absolute";
                c.style.display = "inline-block";
                c.style.top = "50%";
                c.style.right = "50%";
                c.style.width =
                    "100%";
                c.style.textAlign = "center";
                c.style.fontStyle = "italic";
                c.style.transform = "translateX(50%) translateY(-50%)";
                c.style.color = "#fff";
                c.style.fontSize = "30px";
                c.classList.add("media-size-guide");
                a.appendChild(c)
            },
            extend: function(a, b) {
                Object.keys(b).forEach(function(c) {
                    a[c] = b[c]
                });
                return a
            },
            setCookie: function(a, b, c) {
                var d = new Date;
                d.setTime(d.getTime() + 864E5 * c);
                document.cookie = a + "\x3d" + b + "; expires\x3d" + d.toUTCString() + "; path\x3d/"
            },
            getCookie: function(a) {
                return (a = document.cookie.match("(^|;) ?" + a +
                    "\x3d([^;]*)(;|$)")) ? a[2] : null
            },
            triggerEvent: function(a, b, c, e, g) {
                c = void 0 === c ? null : c;
                e = void 0 === e ? !1 : e;
                g = void 0 === g ? !0 : g;
                if (null === c) {
                    var d = document.createEvent("HTMLEvents");
                    d.initEvent(b, e, g)
                } else d = document.createEvent("CustomEvent"), d.initCustomEvent(b, e, g, c);
                a.dispatchEvent(d)
            },
            hiddenScroll: function() {
                this.scrollFlag = !0;
                this.currentPos = window.scrollY || document.documentElement.scrollTop;
                var a = document.querySelector("body");
                var b = 0 < this.currentPos ? "-" + this.currentPos + "px" : 0;
                a.style.position = "fixed";
                a.style.width = "100%";
                a.style.top = b
            },
            visibleScroll: function() {
                if (!0 === this.scrollFlag) {
                    this.scrollFlag = !1;
                    var a = document.querySelector("body");
                    a.style.position = "";
                    a.style.width = "";
                    a.style.top = "";
                    window.scrollTo(0, this.currentPos)
                }
            },
            getDirection: function() {
                return window.getComputedStyle(document.body).direction
            },
            addEventListener: function(a, b, c) {
                if (a) {
                    e || (e = new WeakMap);
                    var d = e.has(a) ? e.get(a) : {};
                    d[b] || (d[b] = []);
                    d[b].push(c);
                    e.set(a, d);
                    a.addEventListener(b, c)
                }
            },
            removeAllEventListeners: function(a, b) {
                if (a &&
                    e && e.has(a)) {
                    var c = e.get(a);
                    c[b] && (c[b].forEach(function(c) {
                        a.removeEventListener(b, c)
                    }), e.delete(a))
                }
            },
            closest: function(a, b) {
                do {
                    if (a.matches ? a.matches(b) : a.msMatchesSelector(b)) return a;
                    a = a.parentElement || a.parentNode
                } while (null !== a && 1 === a.nodeType);
                return null
            },
            popupControl: {
                closeParam: null,
                popstateHandler: function() {
                    window.history.state ? "popOpen" === window.history.state.page && (window.sg.common.utils.popupControl.closeParam(), window.sg.common.utils.popupControl.close()) : (window.sg.common.utils.popupControl.closeParam(),
                        window.sg.common.utils.popupControl.close())
                },
                open: function(a) {
                    this.closeParam = a;
                    window.removeEventListener("popstate", this.popstateHandler);
                    window.addEventListener("popstate", this.popstateHandler);
                    window.history.pushState({
                        page: "popOpen"
                    }, "", "" + window.location.href)
                },
                close: function() {
                    this.closeParam = null;
                    window.history.state && "popOpen" === window.history.state.page && (window.history.forward(), window.removeEventListener("popstate", this.popstateHandler))
                }
            },
            setSwiperIndicatorTaggingAttributes: function(a,
                b) {
                var c = JSON.parse(a);
                [].concat($jscomp.arrayFromIterable(b.querySelectorAll(".swiper-pagination-bullet"))).forEach(function(a, b) {
                    a.setAttribute("an-tr", c.anTr);
                    a.setAttribute("an-ca", c.anCa);
                    a.setAttribute("an-ac", c.anAc);
                    a.setAttribute("an-la", "" + c.anLa + (b + 1))
                })
            },
            isEnglish: function(a) {
                return /^[a-zA-Z]*$/.test(a)
            },
            isNumber: function(a) {
                return /^[0-9]*$/.test(a)
            },
            isEngNum: function(a) {
                return /^[a-zA-Z0-9]*$/.test(a)
            },
            isEmail: function(a) {
                return /^[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*@[0-9a-zA-Z]([-_.]?[0-9a-zA-Z])*.[a-zA-Z]{2,3}$/i.test(a)
            },
            detectTransitionEndEvent: function(a) {
                for (var b = {
                        transition: "transitionend",
                        OTransition: "oTransitionEnd",
                        MozTransition: "transitionend",
                        WebkitTransition: "webkitTransitionEnd"
                    }, c = Object.keys(b), d = 0; d < c.length; d++)
                    if (void 0 !== a.style[c[d]]) return b[c[d]]
            },
            isRtl: function() {
                return "RTL" === getComputedStyle(document.body).direction.toUpperCase()
            },
            setMobileFocusLoop: function(a) {
                do {
                    for (var b = a.parentElement.childNodes, c = 0; c < b.length; c++) 1 === b[c].nodeType && b[c] !== a && "SCRIPT" !== b[c].tagName.toUpperCase() && "STYLE" !==
                        b[c].tagName.toUpperCase() && (b[c].setAttribute("data-aria-hidden", b[c].getAttribute("aria-hidden") || "null"), b[c].setAttribute("aria-hidden", "true"));
                    a = a.parentElement
                } while (a !== document.body)
            },
            removeMobileFocusLoop: function() {
                for (var a = document.querySelectorAll("[data-aria-hidden]"), b = 0; b < a.length; b++) {
                    var c = a[b].getAttribute("data-aria-hidden");
                    "null" === c ? a[b].removeAttribute("aria-hidden") : a[b].setAttribute("aria-hidden", c);
                    a[b].removeAttribute("data-aria-hidden")
                }
            },
            detectScrollType: function() {
                if (g) return g;
                g = "reverse";
                var a = document.createElement("div");
                a.appendChild(document.createTextNode("tmpDivEl"));
                a.dir = "rtl";
                a.style.fontSize = "12px";
                a.style.width = "4px";
                a.style.height = "2px";
                a.style.position = "absolute";
                a.style.overflow = "scroll";
                document.body.appendChild(a);
                0 < a.scrollLeft ? g = "default" : (a.scrollLeft = 2, 2 > a.scrollLeft && (g = "negative"));
                document.body.removeChild(a);
                return g
            },
            getNormalizedScrollLeft: function(a) {
                if (b.isRtl()) switch (b.detectScrollType()) {
                    case "negative":
                        return a.scrollWidth - a.clientWidth +
                            a.scrollLeft;
                    case "reverse":
                        return a.scrollWidth - a.clientWidth - a.scrollLeft
                }
                return a.scrollLeft
            },
            setNormalizedScrollLeft: function(a, e) {
                if (b.isRtl()) switch (b.detectScrollType()) {
                    case "negative":
                        a.scrollLeft = a.clientWidth - a.scrollWidth + e;
                        break;
                    case "reverse":
                        a.scrollLeft = a.scrollWidth - a.clientWidth - e;
                        break;
                    default:
                        a.scrollLeft = e
                } else a.scrollLeft = e
            },
            isPassiveSupport: function() {
                var a = !1;
                try {
                    window.addEventListener("test", null, Object.defineProperty({}, "passive", {
                        get: function() {
                            a = !0
                        }
                    }))
                } catch (n) {}
                return a
            }
        };
    window.sg.common.constants = a;
    window.sg.common.utils = b
})();
(function() {
    var a = [];
    window.sg.common.observer = {
        register: function(l) {
            "function" === typeof l && -1 === a.indexOf(l) && a.push(l)
        },
        unRegister: function(l) {
            if ("function" === typeof l) {
                var e = a.indexOf(l); - 1 < e && l.splice(e, 1)
            }
        },
        test: function() {
            a.forEach(function(a) {
                a(document)
            })
        },
        handlers: a
    }
})();
(function() {
    var a = function(a) {
        this.target = "object" === typeof a ? Array.isArray(a) ? a : [a] : a ? Array.prototype.slice.call(document.querySelectorAll(a)) : []
    };
    a.prototype.find = function(e) {
        var g = [];
        this.target.forEach(function(a) {
            g = g.concat(Array.prototype.slice.call(a.querySelectorAll(e)))
        });
        return new a(g)
    };
    a.prototype.eq = function(e) {
        e = this.target[e];
        return new a(e ? [e] : "")
    };
    a.prototype.parent = function() {
        return 0 === this.target.length ? new a("") : new a(this.target[0].parentNode ? [this.target[0].parentNode] : "")
    };
    a.prototype.children = function(e) {
        e = void 0 === e ? null : e;
        var g = [];
        this.target.forEach(function(a) {
            g = e ? g.concat(Array.prototype.slice.call(a.querySelectorAll(e))) : g.concat(Array.prototype.slice.call(a.children))
        });
        return new a(g)
    };
    a.prototype.closest = function(e) {
        function g(a) {
            return (a.matches ? a.matches(e) : a.webkitMatchesSelector ? a.webkitMatchesSelector(e) : a.msMatchesSelector(e)) ? a : a === document.body ? null : null !== a.parentNode ? g(a.parentNode) : null
        }

        function b(a) {
            return a === e ? a : a === document.body ? null : b(a.parentNode)
        }
        if (0 === this.target.length) return this;
        if (!this.target[0].parentElement) return new a([this.target]);
        var d = [],
            n = "string" === typeof e;
        this.target.forEach(function(a) {
            a = n ? g(a) : b(a);
            null !== a && d.push(a)
        });
        return new a(d)
    };
    a.prototype.siblings = function() {
        return new a(function(a) {
            return [].concat($jscomp.arrayFromIterable(a.parentElement.children)).filter(function(e) {
                return e !== a
            })
        }(this.target[0]))
    };
    a.prototype.setLayerFocus = function(a, g) {
        var b = this.find(a);
        b.attr("tabindex", 0);
        b.addClass("layer-popup__looping");
        this.find(".layer-popup__looping--first").target.length || b.prepend('\x3cbutton class\x3d"layer-popup__looping--first hidden"\x3e\x3c/button\x3e');
        var d = this.find(g);
        this.find(".layer-popup__looping--end").target.length || d.after('\x3cbutton class\x3d"layer-popup__looping--end hidden"\x3e\x3c/button\x3e');
        a = this.find(".layer-popup__looping--first");
        g = this.find(".layer-popup__looping--end");
        a.off("focus").on("focus", function() {
            d.focus()
        });
        g.off("focus").on("focus", function() {
            b.focus()
        });
        b.focus()
    };
    a.prototype.offLayerFocus =
        function() {
            this.find(".layer-popup__looping").removeAttr("tabindex");
            this.find(".layer-popup__looping--first").off("focus").remove();
            this.find(".layer-popup__looping--end").off("focus").remove()
        };
    a.prototype.css = function(a) {
        var e = this.target[0];
        if (e) {
            if ("string" === typeof a) return window.getComputedStyle(e)[a];
            this.target.forEach(function(b) {
                Object.keys(a).forEach(function(d) {
                    b.style[d] = a[d]
                })
            })
        }
    };
    a.prototype.show = function() {
        var a = this.target;
        a && a.forEach(function(a) {
            l(a).css({
                display: "block"
            })
        })
    };
    a.prototype.hide = function() {
        var a = this.target;
        a && a.forEach(function(a) {
            l(a).css({
                display: "none"
            })
        })
    };
    a.prototype.scrollTop = function(a) {
        var e = this.target[0];
        if (e) {
            if (void 0 === a) return e.scrollTop;
            e.scrollTop = a
        }
    };
    a.prototype.animate = function(a, g, b, d) {
        var e = this;
        b = void 0 === b ? null : b;
        d = void 0 === d ? null : d;
        "string" !== typeof b && (d = b, b = null);
        var c = "webkitTransitionEnd oTransitionEnd otransitionend mozTransitionEnd moztransitionend transitionend transitionEnd".split(" ");
        this.target.forEach(function(e) {
            function h(a) {
                if (void 0 ===
                    a || a.target === e) null !== d && d(e), e.style.transition = p, c.forEach(function(a) {
                    e.removeEventListener(a, h);
                    e.animateComplete = null
                })
            }
            var m = window.getComputedStyle(e);
            Object.keys(a).forEach(function(a) {
                e.style[a] = m[a]
            });
            var p = e.style.transition;
            e.style.transitionDuration = g / 1E3 + "s";
            null !== b && (e.style.transitionTimingFunction = b);
            ["o", "ms", "moz", "webkit"].forEach(function(a) {
                e.style[a + "TransitionDuration"] = g / 1E3 + "s";
                null !== b && (e.style[a + "transitionTimingFunction"] = b)
            });
            e.animateComplete = h;
            c.forEach(function(a) {
                e.addEventListener(a,
                    h)
            })
        });
        setTimeout(function() {
            e.css(a)
        }.bind(this), 30)
    };
    a.prototype.finish = function() {
        var a = this;
        if (this.target[0]) {
            var g = document.createEvent("Event");
            "webkitTransitionEnd oTransitionEnd otransitionend mozTransitionEnd moztransitionend transitionend transitionEnd".split(" ").forEach(function(b) {
                g.initEvent(b, !1, !0);
                a.target.forEach(function(a) {
                    a.dispatchEvent(g)
                })
            });
            return this
        }
    };
    a.prototype.stop = function() {
        this.target.forEach(function(a) {
            for (var e = 0, b = window.getComputedStyle(a); a.style.length > e;) {
                e++;
                var d = a.style[e - 1]; - 1 < d.indexOf("transition") || (a.style[d] = b[d])
            }
            a.style.transitionDuration = "0s";
            ["o", "ms", "moz", "webkit"].forEach(function(b) {
                a.style[b + "TransitionDuration"] = "0s"
            });
            var n = a.animateComplete;
            "webkitTransitionEnd oTransitionEnd otransitionend mozTransitionEnd moztransitionend transitionend transitionEnd".split(" ").forEach(function(b) {
                a.removeEventListener(b, n);
                a.animateComplete = null
            })
        });
        return this
    };
    a.prototype.isAnimate = function() {
        return this.target.some(function(a) {
            if ("function" ===
                typeof a.animateComplete) return !0
        })
    };
    a.prototype.slideDown = function(a, g) {
        var b = this;
        this.target.forEach(function(d) {
            var e = d.style.height,
                c = d.style.display;
            d.style.display = "block";
            var h = window.getComputedStyle(d).height;
            d.style.height = "0px";
            var q = d.style.overflow;
            d.style.overflow = "hidden";
            b.css({
                overflow: "hidden"
            });
            b.animate({
                height: h
            }, a, function() {
                d.style.display = c;
                d.style.height = e;
                d.style.overflow = q;
                void 0 !== g && g()
            })
        })
    };
    a.prototype.slideUp = function(a, g) {
        var b = this;
        this.target.forEach(function(d) {
            function e() {
                d.style.height =
                    c.height;
                d.style.overflow = c.overflow;
                d.style.padding = c.padding;
                void 0 !== g && g()
            }
            var c = {
                height: d.style.height,
                overflow: d.style.overflow,
                padding: d.style.padding
            };
            d.style.height = window.getComputedStyle(d).height;
            setTimeout(function() {
                b.animate({
                    overflow: "hidden",
                    height: "0px",
                    paddingTop: "0px",
                    paddingBottom: "0px"
                }, a, e)
            }.bind(b), 30)
        })
    };
    a.prototype.index = function() {
        var a = this.target[0];
        if (a) {
            var g = 0;
            Array.prototype.slice.call(a.parentNode.children).forEach(function(b, d) {
                a === b && (g = d)
            });
            return g
        }
    };
    a.prototype.offset =
        function() {
            var a = this.target[0];
            if (a) return a.getBoundingClientRect()
        };
    a.prototype.width = function() {
        var a = this.target[0];
        if (a) {
            var g = window.getComputedStyle(a);
            return a.offsetWidth - parseInt(g.paddingLeft, 10) - parseInt(g.paddingRight, 10) - parseInt(g.borderLeftWidth, 10) - parseInt(g.borderRightWidth, 10)
        }
    };
    a.prototype.innerWidth = function() {
        var a = this.target[0];
        if (a) {
            var g = window.getComputedStyle(a);
            return a.offsetWidth - parseInt(g.borderLeftWidth, 10) - parseInt(g.borderRightWidth, 10)
        }
    };
    a.prototype.outerWidth =
        function() {
            var a = this.target[0];
            if (a) return a.clientWidth
        };
    a.prototype.height = function() {
        var a = this.target[0];
        if (a) {
            var g = window.getComputedStyle(a);
            return a.offsetHeight - parseInt(g.paddingTop, 10) - parseInt(g.paddingBottom, 10) - parseInt(g.borderTopWidth, 10) - parseInt(g.borderBottomWidth, 10)
        }
    };
    a.prototype.innerHeight = function() {
        var a = this.target[0];
        if (a) {
            var g = window.getComputedStyle(a);
            return a.offsetHeight - parseInt(g.borderTopWidth, 10) - parseInt(g.borderBottomWidth, 10)
        }
    };
    a.prototype.outerHeight = function() {
        var a =
            this.target[0];
        if (a) return a.clientHeight
    };
    a.prototype.isImageLoad = function() {
        return 0 < this.target[0].naturalWidth && this.target[0].naturalHeight ? !0 : !1
    };
    a.prototype.hasClass = function(a) {
        var e = this.target[0];
        if (e) return (new RegExp("(\\s|^)" + a + "(\\s|$)")).test(e.className)
    };
    a.prototype.addClass = function(a) {
        var e = this.target;
        e && e.forEach(function(b) {
            b.classList.add(a)
        })
    };
    a.prototype.removeClass = function(a) {
        var e = this.target;
        e && e.forEach(function(b) {
            b.classList.remove(a)
        })
    };
    a.prototype.toggleClass = function(a) {
        var e =
            this.target;
        e && e.forEach(function(b) {
            b.classList.toggle(a)
        })
    };
    a.prototype.attr = function(a, g) {
        if (this.target) {
            if (1 < arguments.length) this.target.forEach(function(b) {
                b.setAttribute && b.setAttribute(a, g)
            });
            else {
                var b = this.target[0];
                return b ? b.getAttribute(a) : !1
            }
            return this
        }
    };
    a.prototype.removeAttr = function(a) {
        this.target && this.target.forEach(function(e) {
            e.removeAttribute(a)
        })
    };
    a.prototype.text = function(a) {
        this.target.forEach(function(e) {
            e.textContent = a
        })
    };
    a.prototype.innerHTML = function(a) {
        this.target &&
            (this.target[0].innerHTML = a)
    };
    a.prototype.append = function(a) {
        this.target.forEach(function(e) {
            Array.isArray(a) ? a.forEach(function(a) {
                "string" === typeof a ? e.insertAdjacentHTML("beforeend", a) : e.appendChild(a)
            }) : "string" === typeof a ? e.insertAdjacentHTML("beforeend", a) : e.appendChild(a)
        })
    };
    a.prototype.after = function(a) {
        this.target.forEach(function(e) {
            Array.isArray(a) ? (a = [].concat($jscomp.arrayFromIterable(a)).reverse(), a.forEach(function(a) {
                "string" === typeof a ? e.insertAdjacentHTML("afterend", a) : e.insertAdjacentElement("afterend",
                    a)
            })) : "string" === typeof a ? e.insertAdjacentHTML("afterend", a) : e.insertAdjacentElement("afterend", a)
        })
    };
    a.prototype.prepend = function(a) {
        this.target.forEach(function(e) {
            Array.isArray(a) ? a.forEach(function(a) {
                "string" === typeof a ? e.insertAdjacentHTML("beforebegin", a) : a && e.insertBefore(a, e.firstChild)
            }) : "string" === typeof a ? e.insertAdjacentHTML("beforebegin", a) : a && e.insertBefore(a, e.firstChild)
        })
    };
    a.prototype.before = function() {};
    a.prototype.clone = function() {
        if (this.target[0]) {
            var a = [];
            this.target.forEach(function(e) {
                a.push(e.cloneNode(!0))
            });
            return a
        }
    };
    a.prototype.remove = function() {
        this.target[0] && this.target.forEach(function(a) {
            a.parentNode.removeChild(a)
        })
    };
    a.prototype.focus = function() {
        var a = this.target[0];
        if (a && a.focus) return a.focus(), this
    };
    a.prototype.blur = function() {
        var a = this.target[0];
        if (a) return a.blur(), this
    };
    a.prototype.on = function(e, g) {
        var b = this.target;
        b && b.forEach(function(b) {
            a.instances.has(b) || a.instances.set(b, {
                event: [],
                handler: []
            });
            a.instances.get(b).handler.push({
                event: e,
                handler: g
            });
            b.addEventListener(e, g)
        })
    };
    a.prototype.off =
        function(e, g) {
            var b = this.target;
            if (b) return b.forEach(function(b) {
                if (a.instances.has(b)) {
                    var d = a.instances.get(b);
                    if (e && g) {
                        var c = [];
                        d.handler.forEach(function(a) {
                            a.event === e && a.handler === g ? b.removeEventListener(a.event, a.handler) : c.push({
                                event: a.event,
                                handler: a.handler
                            })
                        });
                        d.handler = c
                    } else if (e) {
                        var h = [];
                        d.handler.forEach(function(a) {
                            a.event === e && b !== window ? b.removeEventListener(a.event, a.handler) : h.push({
                                event: a.event,
                                handler: a.handler
                            })
                        });
                        d.handler = h
                    } else b !== window && (d.handler.forEach(function(a) {
                        b.removeEventListener(a.event,
                            a.handler)
                    }), d.handler = [])
                }
            }), this
        };
    a.prototype.trigger = function(a) {
        if (this.target[0]) {
            var e = document.createEvent("Event");
            e.initEvent(a, !1, !0);
            this.target.forEach(function(a) {
                a.dispatchEvent(e)
            })
        }
    };
    a.prototype.moveScroll = function(a, g, b) {
        g = void 0 === g ? 500 : g;
        b = void 0 === b ? null : b;
        var d = (new Date).getTime();
        if (0 === this.target.length) return !1;
        if ("HTML" !== this.target[0].tagName && "BODY" !== this.target[0].tagName) {
            var e = this.target[0],
                c = a - e.scrollTop,
                h = g,
                q = Math.ceil(Math.abs(c) / Math.ceil(h / 16));
            requestAnimationFrame(function L() {
                var m =
                    (new Date).getTime() - d;
                if (0 < c) {
                    var p = e.scrollTop + q;
                    e.scrollTop = e.scrollTop > a ? a : p
                } else p = e.scrollTop - q, e.scrollTop = e.scrollTop < a ? a : p;
                m <= h ? requestAnimationFrame(L) : (0 < c ? e.scrollTop < a && (e.scrollTop = a) : e.scrollTop > a && (e.scrollTop = a), null !== b && b())
            })
        } else {
            var m = Math.round(a),
                p = m - (document.body.scrollTop || document.documentElement.scrollTop),
                l = Math.ceil(Math.abs(p) / (g / 16)),
                t = document.body.scrollLeft || document.documentElement.scrollLeft,
                y = null;
            requestAnimationFrame(function L() {
                var a = document.body.scrollTop ||
                    document.documentElement.scrollTop;
                if (y === a) null !== b && b();
                else {
                    if (0 < p) {
                        var c = a + l;
                        c > m && (c = m)
                    } else c = a - l, c < m && (c = m);
                    window.scrollTo(t, c);
                    y = a;
                    m !== c ? requestAnimationFrame(L) : null !== b && b()
                }
            })
        }
    };
    a.prototype.moveScrollX = function(a, g, b) {
        function d() {
            h.scrollLeft = c;
            null !== b && b()
        }
        g = void 0 === g ? 500 : g;
        b = void 0 === b ? null : b;
        var e = (new Date).getTime();
        if (0 === this.target.length) return !1;
        var c = a,
            h = this.target[0],
            q = c - h.scrollLeft,
            m = g,
            p = Math.ceil(Math.abs(q) / Math.ceil(m / 16));
        requestAnimationFrame(function t() {
            var a = (new Date).getTime() -
                e;
            if (0 < q) {
                var b = h.scrollLeft + p;
                if (h.scrollLeft > c) {
                    d();
                    return
                }
            } else if (b = h.scrollLeft - p, h.scrollLeft < c) {
                d();
                return
            }
            h.scrollLeft = b;
            a <= m ? requestAnimationFrame(t) : 0 < q ? h.scrollLeft < c && d() : h.scrollLeft > c && d()
        })
    };
    a.instances = new WeakMap;
    var l = function(e) {
        return new a(e)
    };
    l.ready = function(a) {
        "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", a) : a()
    };
    l.load = function(a) {
        document.addEventListener("readystatechange", function(e) {
            "complete" === e.target.readyState && a()
        })
    };
    window.sg.common.libs = {
        keyCode: {
            TAB_KEY: 9,
            ENTER: 13,
            SPACE: 32,
            PAGE_UP: 33,
            PAGE_DOWN: 34,
            END: 35,
            HOME: 36,
            LEFT: 37,
            UP: 38,
            RIGHT: 39,
            DOWN: 40
        },
        extend: function(a, g) {
            Object.keys(g).forEach(function(b) {
                a[b] = g[b]
            });
            return a
        }
    };
    window.sg.common.$q = l
})();
(function() {
    var a = window.sg.common.utils.isVerticalVisible,
        l = window.sg.common.utils.isHorizontalVisible,
        e = function(a) {
            this.el = a = void 0 === a ? document : a;
            this.lazyEls = [];
            this.disabled = this.active = !1;
            this.init()
        };
    e.prototype.init = function() {
        this.setLazyLoad();
        this.bindEvents()
    };
    e.prototype.dispose = function() {
        this.el = null;
        this.lazyEls = [];
        this.unBindEvents()
    };
    e.prototype.setDisabled = function(a) {
        (this.disabled = a = void 0 === a ? !0 : a) || this.setLazyLoad()
    };
    e.prototype.getEls = function() {
        this.el && (this.lazyEls = [].concat($jscomp.arrayFromIterable(this.el.querySelectorAll(".lazy-load"))))
    };
    e.prototype.reInit = function() {
        this.disabled = this.active = !1;
        this.setLazyLoad();
        this.unBindEvents();
        this.bindEvents()
    };
    e.prototype.handleLazyLoad = function() {
        this.setLazyLoad()
    };
    e.prototype.setLazyLoad = function(a) {
        var b = this;
        a = void 0 === a ? 200 : a;
        var e = function() {
            b.disabled || (b.getEls(), b.lazyEls.forEach(function(a) {
                b.load(a);
                0 === b.lazyEls.length && b.unBindEvents()
            }))
        };
        this.active || (0 < a ? (this.active = !0, setTimeout(function() {
            e();
            b.active = !1
        }, a)) : e())
    };
    e.prototype.setPreviewImageLoaded = function(b) {
        var d = this,
            e = function() {
                a(b) && ([].concat($jscomp.arrayFromIterable(b.querySelectorAll(".image__preview"))).forEach(function(a) {
                    a.classList.contains("lazy-load") && d.loadImage(a)
                }), document.removeEventListener("scroll", e), window.removeEventListener("resize", e), window.removeEventListener("orientationchange", e))
            };
        document.addEventListener("scroll", e);
        window.addEventListener("resize", e);
        window.addEventListener("orientationchange", e)
    };
    e.prototype.loadImmediately = function(a) {
        a.classList.contains("image__preview") ||
            a.classList.contains("image__main") || a.classList.contains("image__hover-image--hover") ? this.loadImage(a) : a.classList.contains("video") && this.loadVideo(a);
        a.classList.contains("image-v2") && this.loadImage(a, "all")
    };
    e.prototype.setLazyLoadManually = function(a) {
        var b = this;
        a.classList.contains(".lazy-load-man") ? (this.loadImmediately(a), a.classList.remove("lazy-load-man")) : [].concat($jscomp.arrayFromIterable(a.querySelectorAll(".lazy-load-man"))).forEach(function(a) {
            b.loadImmediately(a);
            a.classList.remove("lazy-load-man")
        })
    };
    e.prototype.ignoreLazyLoadOnceUnder = function(a, d) {
        [].concat($jscomp.arrayFromIterable(a.querySelectorAll(".lazy-load"))).forEach(function(a) {
            var b = window.pageYOffset,
                e = a.getBoundingClientRect();
            (e.bottom + b < d || e.top + b < d) && a.classList.add("lazy-load-ignore-once")
        })
    };
    e.prototype.forceLoad = function(a) {
        var b = this;
        a.classList.contains("lazy-load") ? this.loadImmediately(a) : [].concat($jscomp.arrayFromIterable(a.querySelectorAll(".lazy-load"))).forEach(function(a) {
            b.loadImmediately(a)
        })
    };
    e.prototype.load = function(b) {
        b.classList.contains("lazy-load-ignore-once") ||
            (a(b) && (b.classList.contains("image__preview") ? this.loadImage(b) : l(b) && (b.classList.contains("image__main") || b.classList.contains("image__hover-image--hover") ? this.loadImage(b) : b.classList.contains("video") && this.loadVideo(b))), b.classList.contains("image-v2") && a(b) && (this.loadImage(b, "preview"), l(b) && this.loadImage(b, "main")));
        b.classList.remove("lazy-load-ignore-once")
    };
    e.prototype.clearLazy = function(a) {
        if (a.classList.contains("image-v2")) {
            var b = !1;
            [].concat($jscomp.arrayFromIterable(a.querySelectorAll("img"))).forEach(function(a) {
                a.dataset.src &&
                    (b = !0)
            });
            if (b) return
        }
        a.classList.remove("lazy-load");
        this.lazyEls = this.lazyEls.filter(function(b) {
            return b !== a
        })
    };
    e.prototype.loadImage = function(a, d) {
        var b = (d = void 0 === d ? null : d) ? window.sg.common.imagev2 : window.sg.common.image;
        b && b.load(a, d);
        this.clearLazy(a)
    };
    e.prototype.loadVideo = function(a) {
        var b = window.sg.common.video;
        b && b.load(a);
        this.clearLazy(a)
    };
    e.prototype.bindEvents = function() {
        this.handleLazyLoad = this.handleLazyLoad.bind(this);
        document.addEventListener("scroll", this.handleLazyLoad);
        window.addEventListener("resize",
            this.handleLazyLoad);
        window.addEventListener("orientationchange", this.handleLazyLoad)
    };
    e.prototype.unBindEvents = function() {
        document.removeEventListener("scroll", this.handleLazyLoad);
        window.removeEventListener("resize", this.handleLazyLoad);
        window.removeEventListener("orientationchange", this.handleLazyLoad)
    };
    e.instance = null;
    var g = {
        initAll: function() {
            e.instance && (e.instance.dispose(), e.instance = null);
            e.instance = new e
        },
        reInit: function() {
            e.instance ? e.instance.reInit() : e.instance = new e
        },
        setLazyLoad: function() {
            e.instance ||
                (e.instance = new e);
            e.instance.setLazyLoad(0)
        },
        setPreviewImageLoaded: function(a) {
            e.instance || (e.instance = new e);
            e.instance.setPreviewImageLoaded(a)
        },
        setLazyLoadManually: function(a) {
            a && (e.instance || (e.instance = new e), e.instance.setLazyLoadManually(a))
        },
        ignoreLazyLoadOnceUnder: function(a, d) {
            e.instance || (e.instance = new e);
            e.instance.ignoreLazyLoadOnceUnder(a, d)
        },
        setDisabled: function(a) {
            a = void 0 === a ? !0 : a;
            e.instance || (e.instance = new e);
            e.instance.setDisabled(a)
        },
        forceLoad: function(a) {
            a && (e.instance || (e.instance =
                new e), e.instance.forceLoad(a))
        }
    };
    window.sg.common.lazyLoad = g;
    document.addEventListener("DOMContentLoaded", g.initAll);
    "loading" !== document.readyState && g.initAll()
})();
(function() {
    var a = window.sg.common.utils.getViewPort,
        l = window.sg.common.utils.getCurrentDevice,
        e = function(a) {
            this.els = {
                el: a,
                previewImgEl: null,
                mainImgEl: null
            };
            this.dpr = this.maxWidth = this.device = "";
            this.init()
        };
    e.prototype.init = function() {
        e.instances.has(this.els.el) || (e.instances.set(this.els.el, this), this.setElement(), this.els.mainImgEl.complete && 0 !== this.els.mainImgEl.naturalWidth && this.handleLoad(), this.setResponsive(), this.bindEvents())
    };
    e.prototype.setElement = function() {
        this.els.previewImgEl =
            this.els.el.querySelector(".image-v2__preview");
        this.els.mainImgEl = this.els.el.querySelector(".image-v2__main")
    };
    e.prototype.setResponsive = function() {
        var a = this,
            d = l(),
            e = this.getCurrentMaxWidth(),
            c = this.getCurrentDpr(),
            h = this.els.el.classList.contains("lazy-load") || this.els.el.classList.contains("lazy-load-man"),
            g = function(b, c) {
                h ? (b.dataset.src = void 0 === b.dataset.src ? "" : b.dataset.src, 0 > b.dataset.src.indexOf(c) && (b.dataset.src = c)) : 0 > decodeURI(b.src).indexOf(c) && (b === a.els.mainImgEl && a.els.el.classList.remove("image-v2--main-loaded"),
                    b.src = c)
            };
        this.els.previewImgEl && this.device !== d && (this.device = d, g(this.els.previewImgEl, this.els.previewImgEl.dataset[this.device + "Src"]));
        if (this.maxWidth !== e || this.dpr !== c) this.maxWidth = e, this.dpr = c, g(this.els.mainImgEl, this.els.mainImgEl.dataset[this.maxWidth + "w" + this.dpr + "xSrc"])
    };
    e.prototype.load = function(a) {
        var b = this,
            e = function(a) {
                a && a.dataset.src && 0 > decodeURI(a.src).indexOf(a.dataset.src) && (a === b.els.mainImgEl && b.els.el.classList.remove("image-v2--main-loaded"), a.src = a.dataset.src, a.removeAttribute("data-src"))
            };
        "preview" === a ? e(this.els.previewImgEl) : ("main" !== a && e(this.els.previewImgEl), e(this.els.mainImgEl))
    };
    e.prototype.handleLoad = function() {
        this.els.el.classList.add("image-v2--main-loaded")
    };
    e.prototype.bindEvents = function() {
        this.setResponsive = this.setResponsive.bind(this);
        window.addEventListener("resize", this.setResponsive);
        this.handleLoad = this.handleLoad.bind(this);
        this.els.mainImgEl.addEventListener("load", this.handleLoad)
    };
    e.prototype.getCurrentMaxWidth = function() {
        var b = a().width;
        return 768 > b ? "360" :
            768 <= b && 1366 > b ? "768" : "1366"
    };
    e.prototype.getCurrentDpr = function() {
        return 1.5 > window.devicePixelRatio ? 1 : 2
    };
    e.instances = new WeakMap;
    var g = {
        initAll: function(a) {
            a = void 0 === a ? document : a;
            var b = function(a) {
                e.instances.has(a) || new e(a)
            };
            a !== document && a.classList && a.classList.contain("image-v2") ? b(a) : (a.querySelectorAll || (a = document), [].concat($jscomp.arrayFromIterable(a.querySelectorAll(".image-v2"))).forEach(function(a) {
                b(a)
            }))
        },
        load: function(a, d) {
            d = void 0 === d ? "all" : d;
            e.instances.has(a) ? e.instances.get(a).load(d) :
                (new e(a)).load(d)
        }
    };
    window.sg.common.imagev2 = g;
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", g.initAll) : g.initAll()
})();
(function() {
    var a = window.sg.common.utils.getCurrentDevice,
        l = window.sg.common.utils.detectTransitionEndEvent,
        e = window.sg.common.observer,
        g = function(a) {
            this.el = a;
            this.init()
        };
    g.prototype.init = function() {
        g.instances.has(this.el) || (g.instances.set(this.el, this), this.setResponsiveImage(), this.bindEvents())
    };
    g.prototype.destroy = function() {
        this.unBindEvents();
        g.instances.has(this.el) && g.instances.delete(this.el);
        this.el = null
    };
    g.prototype.load = function() {
        0 > decodeURI(this.el.src).indexOf(this.el.dataset.src) &&
            (this.el.src = this.el.dataset.src, this.el.classList.remove("image--loaded"), this.el.classList.remove("image--hide"));
        this.el.removeAttribute("data-src")
    };
    g.prototype.setImageLoaded = function() {
        var a = this;
        this.el.classList.add("image--loaded");
        if (this.el.classList.contains("image__main")) {
            this.el.style.transition = "visibility .2s, opacity .2s";
            this.el.parentElement.classList.add("image--main-loaded");
            var b = function() {
                    a.el.style.transition = "";
                    var b = a.el.parentElement.querySelector(".image__preview");
                    b &&
                        b.classList.add("image--hide")
                },
                d = l(this.el);
            if (d) {
                var e = function() {
                    b();
                    a.el.removeEventListener(d, e)
                };
                this.el.addEventListener(d, e)
            } else setTimeout(b, 200)
        }
    };
    g.prototype.bindImageLoad = function() {
        if (this.el.classList.contains("image__main") || this.el.classList.contains("image__preview")) this.el.complete && 0 !== this.el.naturalWidth && this.setImageLoaded(), this.setImageLoaded = this.setImageLoaded.bind(this), this.el.addEventListener("load", this.setImageLoaded)
    };
    g.prototype.bindResponsive = function() {
        this.el.dataset.desktopSrc !==
            this.el.dataset.mobileSrc && (this.setResponsiveImage = this.setResponsiveImage.bind(this), window.addEventListener("resize", this.setResponsiveImage))
    };
    g.prototype.bindEvents = function() {
        this.el.classList.contains("responsive-img") && this.bindResponsive();
        this.bindImageLoad()
    };
    g.prototype.unBindEvents = function() {
        this.el.removeEventListener("load", this.setImageLoaded);
        window.removeEventListener("resize", this.setResponsiveImage)
    };
    g.prototype.setResponsiveImage = function() {
        if (this.el.classList.contains("responsive-img")) {
            var b =
                a();
            this.device !== b && (this.device = b, (b = this.el.dataset[this.device + "Src"]) ? this.el.style.removeProperty("display") : this.el.style.display = "none", this.el.classList.contains("lazy-load") || this.el.classList.contains("lazy-load-man") ? (this.el.dataset.src = void 0 === this.el.dataset.src ? "" : this.el.dataset.src, 0 > this.el.dataset.src.indexOf(b) && (this.el.dataset.src = b)) : 0 > decodeURI(this.el.src).indexOf(b) && (this.el.classList.remove("image--loaded"), this.el.classList.remove("image--hide"), this.el.src = b))
        }
    };
    g.instances =
        new WeakMap;
    var b = !1,
        d = function() {
            b || (e.register(n.destroy), b = !0)
        },
        n = {
            initAll: function() {
                [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".image img"))).forEach(function(a) {
                    g.instances.has(a) || (new g(a), d())
                })
            },
            load: function(a) {
                g.instances.has(a) ? g.instances.get(a).load() : ((new g(a)).load(), d())
            },
            delete: function(a) {
                g.instances.delete(a)
            },
            destroy: function(a) {
                a.classList && a.classList.contains("image") ? [].concat($jscomp.arrayFromIterable(a.querySelectorAll("img"))).forEach(function(a) {
                    g.instances.has(a) &&
                        g.instances.get(a).destroy()
                }) : [].concat($jscomp.arrayFromIterable(a.querySelectorAll(".image img"))).forEach(function(a) {
                    g.instances.has(a) && g.instances.get(a).destroy()
                })
            }
        };
    window.sg.common.image = n;
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", n.initAll) : n.initAll()
})();
(function() {
    var a = {
        index: 0,
        isYoutubeReady: !1,
        callbacks: [],
        enqueueOnYoutubeIframeApiReady: function(b) {
            a.isYoutubeReady ? b() : a.callbacks.push(b)
        },
        onYouTubeIframeApiReady: function() {
            a.isYoutubeReady = !0;
            a.callbacks.forEach(function(a) {
                a()
            });
            a.callbacks.splice(0)
        }
    };
    window.sg.common.videoApi = a;
    window.onYouTubeIframeAPIReady = a.onYouTubeIframeApiReady;
    var l = {
            ACE: {
                accountId: "5685289444001",
                playerId: "WO3Tb7i1g"
            },
            AE: {
                accountId: "923227814001",
                playerId: "YVPxrKSek"
            },
            AE_ARABIC: {
                accountId: "923136719001",
                playerId: "E3oao1olw"
            },
            AE_ARABIC_CS: {
                accountId: "5711373595001",
                playerId: "9urZPAGHD"
            },
            AE_CS: {
                accountId: "5711373594001",
                playerId: "0XMYguG2Nw"
            },
            AFRICA_EN: {
                accountId: "923270648001",
                playerId: "lsyG00Wz0"
            },
            AFRICA_EN_CS: {
                accountId: "5711373605001",
                playerId: "t1guP7iYwy"
            },
            AFRICA_FR: {
                accountId: "923227818001",
                playerId: "Tmx2dzbrT"
            },
            AFRICA_FR_CS: {
                accountId: "5711373606001",
                playerId: "gLuvxDp4b"
            },
            AFRICA_PT: {
                accountId: "923136723001",
                playerId: "1CZXrnviEE"
            },
            AFRICA_PT_CS: {
                accountId: "5711373607001",
                playerId: "azVZUTl7x"
            },
            AL: {
                accountId: "5395474900001",
                playerId: "oKHrt1Hn6"
            },
            AL_CS: {
                accountId: "5711373614001",
                playerId: "if48zX24H"
            },
            AR: {
                accountId: "923270634001",
                playerId: "gqJSxYCzB"
            },
            AR_CS: {
                accountId: "5709700884001",
                playerId: "ojd4uMnUWl"
            },
            AT: {
                accountId: "923227809001",
                playerId: "wnRfbwIVL"
            },
            AT_CS: {
                accountId: "5711373581001",
                playerId: "cGZtAkJpT"
            },
            AU: {
                accountId: "923162666001",
                playerId: "VMb9FyMxk"
            },
            AU_CS: {
                accountId: "5709700889001",
                playerId: "bB2vkQudw"
            },
            BE: {
                accountId: "923136716001",
                playerId: "LzbXypCvz"
            },
            BE_CS: {
                accountId: "5675787971001",
                playerId: "sEimKv7IW"
            },
            BE_FR: {
                accountId: "923162674001",
                playerId: "FleM4KQofp"
            },
            BE_FR_CS: {
                accountId: "5675787972001",
                playerId: "7WhhmlxJj"
            },
            BG: {
                accountId: "923270643001",
                playerId: "Jo7zzVtd5"
            },
            BG_CS: {
                accountId: "5711373580001",
                playerId: "e6AWwoixf"
            },
            BR: {
                accountId: "923162661001",
                playerId: "v2BLpgM8d"
            },
            BR_CS: {
                accountId: "5709700879001",
                playerId: "qjm3J8bZLB"
            },
            CA: {
                accountId: "923270632001",
                playerId: "RUxsKbp4e"
            },
            CA_CS: {
                accountId: "5709700877001",
                playerId: "VCXS3jzBQ"
            },
            CA_FR: {
                accountId: "923227798001",
                playerId: "db9VQnzIIo"
            },
            CA_FR_CS: {
                accountId: "5709700876001",
                playerId: "Hghbkb4GOc"
            },
            CH: {
                accountId: "923162673001",
                playerId: "U0Tv0wE3G"
            },
            CH_CS: {
                accountId: "5711373582001",
                playerId: "wfkyW1T9N"
            },
            CH_FR: {
                accountId: "923227810001",
                playerId: "wvyBB7ZyD"
            },
            CH_FR_CS: {
                accountId: "5711373583001",
                playerId: "8iaLX3eay"
            },
            CL: {
                accountId: "923227801001",
                playerId: "nbGAqWiyZ"
            },
            CL_CS: {
                accountId: "5709700885001",
                playerId: "seAio3Iab1"
            },
            CN: {
                accountId: "923270636001",
                playerId: "UOGt9s1Ot"
            },
            CN_CS: {
                accountId: "5711373561001",
                playerId: "0polYNx0hB"
            },
            CO: {
                accountId: "923162663001",
                playerId: "VN3FsuEmoA"
            },
            CO_CS: {
                accountId: "5709700883001",
                playerId: "QkIcs4LRi"
            },
            CZ: {
                accountId: "923270642001",
                playerId: "JofGmsuUaU"
            },
            CZ_CS: {
                accountId: "5711373577001",
                playerId: "W4LcfRCdX"
            },
            DE: {
                accountId: "923227805001",
                playerId: "r5nOZyzd1"
            },
            DEV: {
                accountId: "901961867001",
                playerId: "jSPFC1gYrR"
            },
            DE_CS: {
                accountId: "5675787970001",
                playerId: "Ojq20h6rI"
            },
            DK: {
                accountId: "923270638001",
                playerId: "zThis2SPx"
            },
            DK_CS: {
                accountId: "5711373569001",
                playerId: "V6MCi9Amm"
            },
            EE: {
                accountId: "923227812001",
                playerId: "89aGBrdO5"
            },
            EE_CS: {
                accountId: "5711373586001",
                playerId: "h1RB4WzC8h"
            },
            EG: {
                accountId: "923162680001",
                playerId: "KWJoclhcD"
            },
            EG_CS: {
                accountId: "5711373603001",
                playerId: "t6vHuEvebf"
            },
            ES: {
                accountId: "923162670001",
                playerId: "yq8Y8zZ3dG"
            },
            ES_CS: {
                accountId: "5711373566001",
                playerId: "AzllJfpFb"
            },
            FI: {
                accountId: "923162672001",
                playerId: "B8mrwLnI6"
            },
            FI_CS: {
                accountId: "5711373571001",
                playerId: "1d4N0XfEj"
            },
            FR: {
                accountId: "923227807001",
                playerId: "aACd9IQvK"
            },
            FR_CS: {
                accountId: "5711373573001",
                playerId: "wfmvyAQHg"
            },
            GCS: {
                accountId: "1852113008001",
                playerId: "b1SElAGyQ"
            },
            GLOBAL: {
                accountId: "2933392367001",
                playerId: "i8zNocbMqF"
            },
            GR: {
                accountId: "923136713001",
                playerId: "VXwt3KwO7"
            },
            GR_CS: {
                accountId: "5711373576001",
                playerId: "OHk0ZpVMG"
            },
            HK: {
                accountId: "923227804001",
                playerId: "BlUhaVyrM"
            },
            HK_CS: {
                accountId: "5711373562001",
                playerId: "rUnBOAERZ"
            },
            HK_EN: {
                accountId: "923136709001",
                playerId: "y80dQbj5o"
            },
            HK_EN_CS: {
                accountId: "5711373563001",
                playerId: "oiUmA2Dpb"
            },
            HR: {
                accountId: "923270646001",
                playerId: "rtDIMNREJ"
            },
            HR_CS: {
                accountId: "5711373588001",
                playerId: "4dpG0kuPi"
            },
            HU: {
                accountId: "923270637001",
                playerId: "J3N8K2Ta8"
            },
            HU_CS: {
                accountId: "5711373567001",
                playerId: "xhpdyXZwQC"
            },
            ID: {
                accountId: "923162667001",
                playerId: "8VQZlxO23"
            },
            ID_CS: {
                accountId: "5709700891001",
                playerId: "eS8Ygw9D5N"
            },
            IE: {
                accountId: "923136711001",
                playerId: "Eby5I5ug3"
            },
            IE_CS: {
                accountId: "5711373564001",
                playerId: "g2yJSJmLr"
            },
            IL: {
                accountId: "923162679001",
                playerId: "CNuem5Ud0"
            },
            IL_CS: {
                accountId: "5711373596001",
                playerId: "CuXrQqYtZ"
            },
            IN: {
                accountId: "923162669001",
                playerId: "q6Ut0BCj1"
            },
            IN_CS: {
                accountId: "5711373560001",
                playerId: "CcOagXw6na"
            },
            IRAN: {
                accountId: "923270650001",
                playerId: "z13tWzaxK"
            },
            IRAN_CS: {
                accountId: "5711373600001",
                playerId: "rLjx2H1MSc"
            },
            IT: {
                accountId: "923136712001",
                playerId: "JhjbQ74fF"
            },
            IT_CS: {
                accountId: "5711373565001",
                playerId: "YeJZJaeSW"
            },
            JP: {
                accountId: "923162668001",
                playerId: "5syx1iggoU"
            },
            JP_CS: {
                accountId: "5711373559001",
                playerId: "1pWQq0OoW"
            },
            KZ_RU_CS: {
                accountId: "5711373593001",
                playerId: "IjzGA4NhB"
            },
            KZ_UR: {
                accountId: "923270647001",
                playerId: "1wWJHtrJL"
            },
            LATIN: {
                accountId: "923136703001",
                playerId: "Ejglgn7vR"
            },
            LATIN_CS: {
                accountId: "5709700880001",
                playerId: "xtj1AknXN"
            },
            LATIN_EN: {
                accountId: "923227800001",
                playerId: "PqDI8nhcAF"
            },
            LATIN_EN_CS: {
                accountId: "5709700881001",
                playerId: "BwUsVdHWJ"
            },
            LB: {
                accountId: "5359769185001",
                playerId: "I6JB29uKP"
            },
            LB_CS: {
                accountId: "5711373613001",
                playerId: "PF3r8iX45"
            },
            LED: {
                accountId: "2172563229001",
                playerId: "fZOTwR23Ja"
            },
            LEVANT: {
                accountId: "923227815001",
                playerId: "sNmJq2Rhtq"
            },
            LEVANT_CS: {
                accountId: "5711373601001",
                playerId: "S2BFseOxn"
            },
            LIVE: {
                accountId: "901973578001",
                playerId: "rkHiJmE8b"
            },
            LIVE2: {
                accountId: "901973578001",
                playerId: "BJroFThOM"
            },
            LT: {
                accountId: "923227813001",
                playerId: "UnNH8Q0aA"
            },
            LT_CS: {
                accountId: "5711373585001",
                playerId: "PLBhOXxqd"
            },
            LV: {
                accountId: "923270644001",
                playerId: "8DWjAYXe8t"
            },
            LV_CS: {
                accountId: "5711373584001",
                playerId: "wVmguU4uL"
            },
            MM: {
                accountId: "5395474902001",
                playerId: "vF6OMxYpz"
            },
            MM_CS: {
                accountId: "5711373615001",
                playerId: "HRve5S5Wk"
            },
            MX: {
                accountId: "923227799001",
                playerId: "yWADI9eqWt"
            },
            MX_CS: {
                accountId: "5709700878001",
                playerId: "fMFwGNOoA"
            },
            MY: {
                accountId: "923136706001",
                playerId: "kkY3yWnfk2"
            },
            MY_CS: {
                accountId: "5711373556001",
                playerId: "TUr9f1ZrD"
            },
            NL: {
                accountId: "923136717001",
                playerId: "Lv58R1RvL"
            },
            NL_CS: {
                accountId: "5675788007001",
                playerId: "MKP6lFpdB"
            },
            NO: {
                accountId: "923227806001",
                playerId: "RtYYg3Lhz"
            },
            NO_CS: {
                accountId: "5711373572001",
                playerId: "lpa9BAvSi"
            },
            NZ: {
                accountId: "923136704001",
                playerId: "uc2rRn2xNM"
            },
            NZ_CS: {
                accountId: "5709700890001",
                playerId: "C200YutMY"
            },
            N_AFRICA: {
                accountId: "923227817001",
                playerId: "xMwGwNxoe"
            },
            N_AFRICA_CS: {
                accountId: "5711373604001",
                playerId: "trym9TQi9"
            },
            PE: {
                accountId: "923162664001",
                playerId: "QnLGOyhWT"
            },
            PE_CS: {
                accountId: "5709700887001",
                playerId: "8g7eqsa4b"
            },
            PH: {
                accountId: "923136707001",
                playerId: "TPkcStHQq"
            },
            PH_CS: {
                accountId: "5711373557001",
                playerId: "XAANJvPl4I"
            },
            PK: {
                accountId: "923227816001",
                playerId: "KMGcvTLwI"
            },
            PK_CS: {
                accountId: "5711373602001",
                playerId: "ucBD9N7Wo"
            },
            PL: {
                accountId: "923270641001",
                playerId: "w6lBgsUzX"
            },
            PL_CS: {
                accountId: "5711373575001",
                playerId: "oimMVhVjJ"
            },
            PT: {
                accountId: "923270640001",
                playerId: "sdOVA4ZFD"
            },
            PT_CS: {
                accountId: "5711373574001",
                playerId: "coEoIreou"
            },
            PY: {
                accountId: "4455299568001",
                playerId: "DVT5m3yv2"
            },
            PY_CS: {
                accountId: "5711373610001",
                playerId: "Pog90o2pZ"
            },
            RO: {
                accountId: "923136715001",
                playerId: "Xpb5ogQRq"
            },
            RO_CS: {
                accountId: "5711373579001",
                playerId: "7m3xl6r857"
            },
            RS: {
                accountId: "923162676001",
                playerId: "An8gNEU4n"
            },
            RS_CS: {
                accountId: "5711373587001",
                playerId: "XkZo8R4hQ"
            },
            RU: {
                accountId: "923136718001",
                playerId: "prEGLNvtgw"
            },
            RU_CS: {
                accountId: "5711373589001",
                playerId: "TGIYbAEj4"
            },
            SA: {
                accountId: "923136720001",
                playerId: "UGyvbSD4m"
            },
            SA_CS: {
                accountId: "5711373597001",
                playerId: "e8LeXD9z2"
            },
            SA_EN: {
                accountId: "2571515532001",
                playerId: "e1aY2iob1"
            },
            SA_EN_CS: {
                accountId: "5711373598001",
                playerId: "HMfJhv02t"
            },
            SC: {
                accountId: "1275380501001",
                playerId: "uOrcEND0S"
            },
            SE: {
                accountId: "923162671001",
                playerId: "87s7LoiYm"
            },
            SEC: {
                accountId: "923136708001",
                playerId: "O0UmvJBBkC"
            },
            SE_CS: {
                accountId: "5711373568001",
                playerId: "YQAEzeCh7"
            },
            SG: {
                accountId: "923162665001",
                playerId: "VcCu1i5eGY"
            },
            SG_CS: {
                accountId: "5709700888001",
                playerId: "1uAHw2z66"
            },
            SI: {
                accountId: "3855502820001",
                playerId: "3iQ8u8kzHJ"
            },
            SI_CS: {
                accountId: "5711373609001",
                playerId: "aWXzB4G7Y"
            },
            SK: {
                accountId: "923227808001",
                playerId: "6pYCGSOVM"
            },
            SK_CS: {
                accountId: "5711373578001",
                playerId: "DtyAUtIWf"
            },
            TH: {
                accountId: "923227802001",
                playerId: "GjtcZdzhG"
            },
            TH_CS: {
                accountId: "5711373553001",
                playerId: "jhV8EaiQ2P"
            },
            TR: {
                accountId: "923136721001",
                playerId: "eo4EiXfOZ6"
            },
            TR_CS: {
                accountId: "5711373599001",
                playerId: "uw0Vade3U"
            },
            TW: {
                accountId: "923270635001",
                playerId: "gB0Jrk4eC"
            },
            TW_CS: {
                accountId: "5711373558001",
                playerId: "zRLdsvdiUi"
            },
            UA: {
                accountId: "923162678001",
                playerId: "1ZqNirAQQ"
            },
            UA_CS: {
                accountId: "5711373590001",
                playerId: "1oPqU5Hja"
            },
            UA_RU: {
                accountId: "923162677001",
                playerId: "TNhyfS3s0z"
            },
            UA_RU_CS: {
                accountId: "5711373592001",
                playerId: "n355uJ5toG"
            },
            UK: {
                accountId: "923136710001",
                playerId: "Ta4g51Ongy"
            },
            UK_CS: {
                accountId: "5675787969001",
                playerId: "X4XabEZljp"
            },
            UR: {
                accountId: "4455299570001",
                playerId: "6Sn4qURxs"
            },
            UR_CS: {
                accountId: "5711373612001",
                playerId: "SQg3bJxYB"
            },
            US: {
                accountId: "923227797001",
                playerId: "COJfPFSPz"
            },
            US_CS: {
                accountId: "5709700875001",
                playerId: "YtbrW77H5e"
            },
            VE: {
                accountId: "923162662001",
                playerId: "NGFTP7VzK"
            },
            VE_CS: {
                accountId: "5709700882001",
                playerId: "t00eQogYI"
            },
            VN: {
                accountId: "923136705001",
                playerId: "V8VheyNOH"
            },
            VN_CS: {
                accountId: "5711373555001",
                playerId: "4gy4Qw9sC"
            },
            ZA: {
                accountId: "2571515531001",
                playerId: "ohoOzqLWr"
            },
            ZA_CS: {
                accountId: "5711373608001",
                playerId: "lK2PT9hyDT"
            }
        },
        e = window.sg.common.utils.isVisible,
        g = window.sg.common.utils.getCurrentDevice,
        b = window.sg.common.utils.getCookie,
        d = window.sg.common.utils.triggerEvent,
        n = window.sg.common.observer,
        c =
        function(a) {
            this.el = a;
            this.type = "";
            this.isResonsiveBind = this.isScrollPlayBind = this.isResponsive = this.isScrollPlay = this.isLazyLoad = this.isEmbed = !1;
            this.option = {};
            this.defaultOption = {
                mp4: {
                    videoEl: '\x3cvideo class\x3d"video-player" playsinline\x3e\x3csource src\x3d"" type\x3d"video/mp4"\x3e\x3c/video\x3e',
                    src: "",
                    desktopSrc: "",
                    mobileSrc: "",
                    autoplay: !1,
                    muted: !1,
                    controls: !1,
                    loop: !1,
                    scrollplay: !1
                },
                youtube: {
                    videoEl: '\x3ciframe class\x3d"video-player" src\x3d\'about:blank\' frameborder\x3d\'0\' webkitallowfullscreen mozallowfullscreen allowfullscreen allow\x3d"autoplay" sandbox\x3d"allow-scripts allow-same-origin allow-presentation"\x3e\x3c/iframe\x3e',
                    src: "https://www.youtube.com/embed/{{VIDEO_ID}}?wmode\x3dopaque\x26rel\x3d0\x26enablejsapi\x3d1\x26version\x3d3\x26origin\x3d{{ORIGIN}}",
                    id: "",
                    autoplay: !1,
                    muted: !1
                },
                brightCove: {
                    countryCode: "DEV",
                    videoEl: '\x3cvideo data-embed\x3d"default" controls class\x3d"video-js video-player"\x3e\x3c/video\x3e',
                    id: "",
                    autoplay: !1,
                    muted: !1
                },
                aparat: {
                    videoEl: "\x3ciframe src\x3d'about:blank' frameborder\x3d'0' webkitallowfullscreen mozallowfullscreen allowfullscreen\x3e\x3c/iframe\x3e",
                    src: "https://www.aparat.com/video/video/embed/videohash/{{VIDEO_ID}}/vt/frame",
                    liveSrc: "",
                    autoplay: !1
                },
                url: {
                    videoEl: "\x3ciframe src\x3d'about:blank' frameborder\x3d'0' webkitallowfullscreen mozallowfullscreen allowfullscreen\x3e\x3c/iframe\x3e",
                    src: ""
                }
            };
            this.videoInfo = {};
            this.toVideoState = "";
            this.useDefaultImage = !1;
            this.init()
        };
    c.prototype.init = function() {
        c.instances.has(this.el) || (c.instances.set(this.el, this), this.el.setAttribute("data-comp-name", "common.video"), this.isLazyLoad = this.el.classList.contains("lazy-load") || this.el.classList.contains("lazy-load-man"), this.isEmbed =
            "TRUE" === this.el.dataset.videoEmbed.toUpperCase(), this.videoData = JSON.parse(this.el.dataset.videoData), this.type = this.el.dataset.videoType, this.setDefaultImage(), !this.isLazyLoad && this.isEmbed && this.setVideo())
    };
    c.prototype.load = function() {
        !this.isLazyLoad && this.isEmbed || this.setVideo()
    };
    c.prototype.setDefaultImage = function() {
        var a = this.el.querySelector(".image");
        a && (a.style.width = this.videoData.width ? this.videoData.width : "100%", a.style.height = this.videoData.height ? this.videoData.height : "100%");
        if (this.useDefaultImage =
            "TRUE" === this.el.dataset.imageDefault.toUpperCase()) {
            var c = b("__COM_SPEED");
            if (null === c || "L" !== c.toString().toUpperCase()) this.useDefaultImage = !1
        }
        this.el.dataset.imageDefault = this.useDefaultImage.toString();
        a && (this.useDefaultImage ? a.classList.add("default-image--show") : a.setAttribute("aria-hidden", "true"))
    };
    c.prototype.setVideo = function() {
        if (!this.useDefaultImage) {
            switch (this.type) {
                case "mp4":
                    this.setMp4(this.videoData);
                    break;
                case "youtube":
                    this.setYoutube(this.videoData);
                    break;
                case "brightcove":
                    this.setBrightCove(this.videoData);
                    break;
                case "aparat":
                    this.setAparat(this.videoData);
                    break;
                case "url":
                    this.setIframe(this.videoData)
            }
            d(this.el, "videoInit", this.type)
        }
    };
    c.prototype.setMp4 = function(a) {
        var b = JSON.parse(JSON.stringify(this.defaultOption.mp4)),
            c = this.getEl(b.videoEl, this.el),
            d = c.querySelector("source");
        this.videoInfo.el = c;
        this.videoInfo.sourceEl = d;
        this.option = this.setOption(b, a);
        "" !== this.option.src ? d.setAttribute("src", this.option.src) : (this.setResponsiveVideo(), this.isResponsive = !0, this.isResonsiveBind || (this.bindResponsive(),
            this.isResonsiveBind = !0));
        this.bindPlay();
        c.muted = this.option.muted;
        c.autoplay = this.option.autoplay;
        c.controls = this.option.controls;
        c.loop = this.option.loop;
        this.isEmbed && (c.disableRemotePlayback = !0);
        c.poster = "data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw\x3d\x3d";
        this.option.scrollplay && this.isEmbed && (c.preload = "auto", c.autoplay = !1, this.videoInfo.state = "stop", this.isScrollPlay = !0, this.isScrollPlayBind || (this.bindScrollPlay(), this.isScrollPlayBind = !0));
        c.style.width =
            this.option.width ? this.option.width : "100%";
        c.style.height = this.option.height ? this.option.height : "100%";
        this.setCaption(this.option.caption, c);
        "play" === this.toVideoState ? this.playMp4Video() : "stop" === this.toVideoState && this.stopMp4Video();
        this.toVideoState = ""
    };
    c.prototype.setPlayed = function() {
        this.videoInfo.el.parentElement.classList.contains("video--played") || this.videoInfo.el.parentElement.classList.add("video--played")
    };
    c.prototype.bindPlay = function() {
        "mp4" === this.type && (this.setPlayed = this.setPlayed.bind(this),
            this.videoInfo.el.addEventListener("play", this.setPlayed))
    };
    c.prototype.setScrollPlayVideo = function() {
        e(this.videoInfo.el) ? "play" !== this.videoInfo.state && 1 <= this.videoInfo.el.readyState && (this.videoInfo.el.currentTime = 0, this.videoInfo.el.play(), this.videoInfo.state = "play") : "play" === this.videoInfo.state && 1 <= this.videoInfo.el.readyState && (this.videoInfo.el.pause(), this.videoInfo.state = "pause")
    };
    c.prototype.bindScrollPlay = function() {
        "mp4" === this.type && this.isScrollPlay && (this.setScrollPlayVideo = this.setScrollPlayVideo.bind(this),
            this.videoInfo.el.addEventListener("loadedmetadata", this.setScrollPlayVideo), document.addEventListener("scroll", this.setScrollPlayVideo), window.addEventListener("resize", this.setScrollPlayVideo), window.addEventListener("orientationchange", this.setScrollPlayVideo), this.setScrollPlayVideo())
    };
    c.prototype.setResponsiveVideo = function() {
        var a = g();
        this.isEmbed && this.device === a || (this.device = a, a = this.option[this.device + "Src"], 0 > this.videoInfo.sourceEl.src.indexOf(a) && (this.videoInfo.sourceEl.src = a, this.videoInfo.el.load(),
            this.isScrollPlay && (this.videoInfo.state = "stop")))
    };
    c.prototype.bindResponsive = function() {
        "mp4" === this.type && this.isResponsive && (this.setResponsiveVideo = this.setResponsiveVideo.bind(this), window.addEventListener("resize", this.setResponsiveVideo))
    };
    c.prototype.unBindEvents = function() {
        this.videoInfo.el && (this.videoInfo.el.removeEventListener("play", this.setPlayed), this.videoInfo.el.removeEventListener("loadedmetadata", this.setScrollPlayVideo));
        document.removeEventListener("scroll", this.setScrollPlayVideo);
        window.removeEventListener("resize", this.setResponsiveVideo);
        window.removeEventListener("resize", this.setScrollPlayVideo);
        window.removeEventListener("orientationchange", this.setScrollPlayVideo)
    };
    c.prototype.destroy = function() {
        console.log("video destroy");
        this.unBindEvents();
        this.dispose();
        c.instances.has(this.el) && c.instances.delete(this.el);
        this.videoInfo = this.el = null
    };
    c.prototype.setYoutube = function(a) {
        var b = this,
            c = window.sg.common.videoApi,
            d = JSON.parse(JSON.stringify(this.defaultOption.youtube)),
            e = this.getEl(d.videoEl, this.el);
        this.option = this.setOption(d, a);
        this.option.muted = void 0 !== a.muted ? a.muted : this.option.autoplay;
        this.option.src = this.option.src.replace("{{VIDEO_ID}}", this.option.id).replace("{{ORIGIN}}", window.location.origin) + "\x26autoplay\x3d" + (this.option.autoplay ? "1" : "0") + "\x26mute\x3d" + (this.option.muted ? "1" : "0");
        var m = this.option.id + c.index++;
        e.setAttribute("id", m);
        e.setAttribute("src", this.option.src);
        e.setAttribute("title", this.option.title);
        e.style.width = this.option.width ?
            this.option.width : "100%";
        e.style.height = this.option.height ? this.option.height : "100%";
        this.setCaption(this.option.caption, e);
        a = document.createElement("script");
        a.src = "https://www.youtube.com/iframe_api";
        document.querySelector('script[src\x3d"' + a.src + '"]') || document.body.appendChild(a);
        var h = function() {
            "play" === b.toVideoState ? b.playYoutubeVideo() : "stop" === b.toVideoState && b.stopYoutubeVideo();
            b.toVideoState = ""
        };
        c.enqueueOnYoutubeIframeApiReady(function() {
            b.videoInfo.player = new YT.Player(m, {
                host: "https://www.youtube.com",
                events: {
                    onReady: h
                }
            })
        })
    };
    c.prototype.setBrightCove = function(a) {
        var b = this,
            c = window.sg.common.videoApi,
            d = JSON.parse(JSON.stringify(this.defaultOption.brightCove)),
            e = this.getEl(d.videoEl, this.el);
        this.option = this.setOption(d, a);
        this.option.muted = void 0 !== a.muted ? a.muted : this.option.autoplay;
        a = this.option.countryCode.toUpperCase();
        var m = this.option.id + c.index++;
        e.setAttribute("id", m);
        e.setAttribute("data-video-id", this.option.id);
        e.setAttribute("data-account", l[a].accountId);
        e.setAttribute("data-player",
            l[a].playerId);
        e.style.width = this.option.width ? this.option.width : "100%";
        e.style.height = this.option.height ? this.option.height : "100%";
        this.setCaption(this.option.caption, e);
        c = "https://players.brightcove.net/" + l[a].accountId + "/" + l[a].playerId + "_default/index.min.js";
        e = document.createElement("script");
        e.src = c;
        document.body.appendChild(e);
        e.onload = function() {
            return b.setBrightCovePlayer(m, b.option)
        }
    };
    c.prototype.setBrightCovePlayer = function(a, b) {
        var c = this;
        this.videoInfo.player = videojs(a);
        a = function() {
            c.option.muted &&
                c.videoInfo.player.muted(!0);
            c.videoInfo.player.play()
        };
        var d = function() {
            "play" === c.toVideoState ? c.playBrightCoveVideo() : "stop" === c.toVideoState && c.stopBrightCoveVideo();
            c.toVideoState = ""
        };
        if (1 > this.videoInfo.player.readyState()) {
            if (b.autoplay) this.videoInfo.player.on("loadedmetadata", a);
            this.videoInfo.player.on("loadedmetadata", d)
        } else b.autoplay && a(), d()
    };
    c.prototype.setAparat = function(a) {
        var b = JSON.parse(JSON.stringify(this.defaultOption.aparat)),
            c = this.getEl(b.videoEl, this.el);
        this.option = this.setOption(b,
            a);
        this.option.src = this.option.liveSrc ? this.option.liveSrc : "" + this.option.src.replace("{{VIDEO_ID}}", this.option.id);
        c.setAttribute("src", this.option.src);
        c.setAttribute("title", this.option.title);
        c.style.width = this.option.width ? this.option.width : "100%";
        c.style.height = this.option.height ? this.option.height : "100%";
        this.setCaption(this.option.caption, c)
    };
    c.prototype.setIframe = function(a) {
        var b = JSON.parse(JSON.stringify(this.defaultOption.url)),
            c = this.getEl(b.videoEl, this.el);
        this.option = this.setOption(b,
            a);
        c.setAttribute("src", this.option.src);
        c.setAttribute("title", this.option.title);
        c.style.width = this.option.width ? this.option.width : "100%";
        c.style.height = this.option.height ? this.option.height : "100%";
        this.setCaption(this.option.caption, c)
    };
    c.prototype.setOption = function(a, b) {
        for (var c = Object.keys(b), d = 0; d < c.length; d++) {
            var e = c[d];
            a[e] = b[e] ? b[e] : a[e]
        }
        return a
    };
    c.prototype.setCaption = function(a, b) {
        a && b.insertAdjacentHTML("afterend", '\x3cp class\x3d"hidden"\x3e' + a + "\x3c/p\x3e")
    };
    c.prototype.getEl = function(a,
        b) {
        b.querySelector("figure") || b.insertAdjacentHTML("beforeend", "\x3cfigure\x3e\x3c/figure\x3e");
        b = b.lastElementChild;
        b.style.width = this.videoData.width ? this.videoData.width : "100%";
        b.style.height = this.videoData.height ? this.videoData.height : "100%";
        b.querySelector(".video-player") || b.insertAdjacentHTML("afterbegin", a);
        return b.firstElementChild
    };
    c.prototype.play = function() {
        switch (this.type) {
            case "mp4":
                this.playMp4Video();
                break;
            case "youtube":
                this.playYoutubeVideo();
                break;
            case "brightcove":
                this.playBrightCoveVideo()
        }
    };
    c.prototype.stop = function() {
        switch (this.type) {
            case "mp4":
                this.stopMp4Video();
                break;
            case "youtube":
                this.stopYoutubeVideo();
                break;
            case "brightcove":
                this.stopBrightCoveVideo()
        }
    };
    c.prototype.playMp4Video = function() {
        "mp4" === this.type && (this.videoInfo.el ? this.isScrollPlay || (this.videoInfo.el.play(), this.videoInfo.state = "play") : this.toVideoState = "play")
    };
    c.prototype.stopMp4Video = function() {
        "mp4" === this.type && (this.videoInfo.el ? (this.videoInfo.el.pause(), this.videoInfo.el.currentTime = 0, this.videoInfo.state =
            "stop") : this.toVideoState = "stop")
    };
    c.prototype.playYoutubeVideo = function() {
        "youtube" === this.type && (this.videoInfo.player ? (this.videoInfo.player.playVideo(), this.videoInfo.state = "play") : this.toVideoState = "play")
    };
    c.prototype.stopYoutubeVideo = function() {
        "youtube" === this.type && (this.videoInfo.player ? (this.videoInfo.player.stopVideo(), this.videoInfo.state = "stop") : this.toVideoState = "stop")
    };
    c.prototype.playBrightCoveVideo = function() {
        var a = this;
        if ("brightcove" === this.type)
            if (this.videoInfo.player)
                if (1 >
                    this.videoInfo.player.readyState()) this.videoInfo.player.on("loadedmetadata", function() {
                    a.videoInfo.player.play();
                    a.videoInfo.state = "play"
                });
                else this.videoInfo.player.play(), this.videoInfo.state = "play";
        else this.toVideoState = "play"
    };
    c.prototype.stopBrightCoveVideo = function() {
        var a = this;
        if ("brightcove" === this.type)
            if (this.videoInfo.player)
                if (1 > this.videoInfo.player.readyState()) this.videoInfo.player.on("loadedmetadata", function() {
                    a.videoInfo.player.pause();
                    a.videoInfo.player.currentTime(0);
                    a.videoInfo.state =
                        "stop"
                });
                else this.videoInfo.player.pause(), this.videoInfo.player.currentTime(0), this.videoInfo.state = "stop";
        else this.toVideoState = "stop"
    };
    c.prototype.dispose = function() {
        if (this.el.lastElementChild && !this.isEmbed) {
            if ("brightcove" === this.type) {
                this.videoInfo.player && this.videoInfo.player.dispose();
                var a = this.option.countryCode.toUpperCase();
                (a = document.querySelector('script[src\x3d"' + ("https://players.brightcove.net/" + l[a].accountId + "/" + l[a].playerId + "_default/index.min.js") + '"]')) && document.body.removeChild(a)
            } else "youtube" ===
                this.type && (a = document.querySelector('script[src\x3d"https://www.youtube.com/iframe_api"]')) && document.body.removeChild(a);
            for (; this.el.lastElementChild.hasChildNodes();) this.el.lastElementChild.removeChild(this.el.lastElementChild.firstChild);
            this.el.removeChild(this.el.lastElementChild)
        }
    };
    c.instances = new WeakMap;
    var h = !1,
        q = function() {
            h || (n.register(m.destroy), h = !0)
        },
        m = {
            initAll: function() {
                for (var a = [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".video"))), b = [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".static-content .video"))),
                        d = 0; d < a.length; d++) {
                    for (var e = a[d], m = !1, h = 0; h < b.length; h++)
                        if (e === b[h]) {
                            m = !0;
                            break
                        }
                    m || c.instances.has(e) || (new c(e), q())
                }
            },
            init: function(a) {
                c.instances.has(a) ? a = c.instances.get(a) : (a = new c(a), q());
                a.load();
                return a
            },
            dispose: function(a) {
                c.instances.has(a) && c.instances.get(a).dispose()
            },
            load: function(a) {
                c.instances.has(a) ? c.instances.get(a).load() : ((new c(a)).load(), q())
            },
            play: function(a) {
                c.instances.has(a) ? c.instances.get(a).play() : ((new c(a)).play(), q())
            },
            stop: function(a) {
                c.instances.has(a) ? c.instances.get(a).stop() :
                    ((new c(a)).stop(), q())
            },
            destroy: function(a) {
                c.instances.has(a) && c.instances.get(a).destroy()
            }
        };
    window.sg.common.video = m;
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", m.initAll) : m.initAll()
})();
(function() {
    var a = window.sg.common.$q,
        l = window.BezierEasing,
        e = window.sg.common.utils.closest,
        g = window.sg.common.utils.getNormalizedScrollLeft,
        b = window.sg.common.utils.setNormalizedScrollLeft,
        d = window.sg.common.observer,
        n = function(a) {
            this.els = {
                el: a,
                contentsEl: null,
                wrapEl: null,
                horizTrackEl: null,
                horizTrackContentEl: null,
                horizBarEl: null,
                vertTrackEl: null,
                vertTrackContentEl: null,
                vertBarEl: null
            };
            this.init()
        };
    n.prototype.init = function() {
        n.instances.has(this.els.el) || (n.instances.set(this.els.el, this), this.initValues(),
            this.setElement(), this.resize(), this.initHandlers(), this.bindEvents())
    };
    n.prototype.initValues = function() {
        this.barScrollTop = this.barScrollLeft = 0;
        this.isAnim = this.isContentsDragging = this.isbarDragging = !1
    };
    n.prototype.reInit = function() {
        this.unBindEvents();
        this.initValues();
        this.setElement();
        this.resize();
        this.bindEvents()
    };
    n.prototype.destroy = function() {
        this.unBindEvents();
        n.instances.has(this.els.el) && n.instances.delete(this.els.el);
        this.els = this.els.el = null
    };
    n.prototype.setElement = function() {
        this.els.contentsEl =
            this.els.el.querySelector(".scrollbar__contents");
        this.els.wrapEl = this.els.el.querySelector(".scrollbar__wrap");
        this.els.wrapEl || (this.els.el.insertAdjacentHTML("afterbegin", '\x3cdiv class\x3d"scrollbar__wrap"\x3e\x3c/div\x3e'), this.els.wrapEl = this.els.el.querySelector(".scrollbar__wrap"), this.els.wrapEl.insertAdjacentElement("afterbegin", this.els.contentsEl));
        this.els.horizTrackEl = this.els.el.querySelector(".scrollbar-horizontal__track");
        this.els.horizTrackEl || (this.els.el.insertAdjacentHTML("beforeend",
            '\x3cdiv class\x3d"scrollbar-horizontal__track"\x3e\x3cdiv class\x3d"scrollbar-horizontal__track-content"\x3e\x3cdiv class\x3d"scrollbar-horizontal__bar"\x3e\x3c/div\x3e\x3c/div\x3e'), this.els.horizTrackEl = this.els.el.querySelector(".scrollbar-horizontal__track"));
        this.els.horizTrackContentEl = this.els.el.querySelector(".scrollbar-horizontal__track-content");
        this.els.horizBarEl = this.els.el.querySelector(".scrollbar-horizontal__bar");
        this.els.vertTrackEl = this.els.el.querySelector(".scrollbar-vertical__track");
        this.els.vertTrackEl || (this.els.el.insertAdjacentHTML("beforeend", '\x3cdiv class\x3d"scrollbar-vertical__track"\x3e\x3cdiv class\x3d"scrollbar-vertical__track-content"\x3e\x3cdiv class\x3d"scrollbar-vertical__bar"\x3e\x3c/div\x3e'), this.els.vertTrackEl = this.els.el.querySelector(".scrollbar-vertical__track"));
        this.els.vertTrackContentEl = this.els.el.querySelector(".scrollbar-vertical__track-content");
        this.els.vertBarEl = this.els.el.querySelector(".scrollbar-vertical__bar");
        this.els.wrapEl.style["-ms-user-select"] =
            "";
        this.els.wrapEl.style.userSelect = "";
        this.els.wrapEl.style.cursor = "";
        this.els.wrapEl.style.overscrollBehaviorX = ""
    };
    n.prototype.setBarSize = function() {
        this.els.horizTrackEl.style.display = "";
        var a = Math.ceil(this.els.wrapEl.getBoundingClientRect().width),
            b = this.els.contentsEl.scrollWidth,
            c = Math.ceil(this.els.horizTrackContentEl.getBoundingClientRect().width),
            d = a / b;
        1 > d ? (this.els.horizTrackEl.style.display = "", this.horizBarWidth = c * d, this.els.horizBarEl.style.width = this.horizBarWidth + "px", this.contentsMaxScrollLeft =
            b - a, this.barMaxScrollLeft = c - c * d, this.isHorizBar = !0, this.els.wrapEl.style["-ms-user-select"] = "none", this.els.wrapEl.style.userSelect = "none", this.els.wrapEl.style.cursor = "default", this.els.wrapEl.style.overscrollBehaviorX = "contain") : (this.els.horizTrackEl.style.display = "none", this.barMaxScrollLeft = this.contentsMaxScrollLeft = 0, this.isHorizBar = !1);
        this.els.vertTrackEl.style.display = "";
        a = Math.ceil(this.els.wrapEl.getBoundingClientRect().height);
        b = this.els.contentsEl.scrollHeight;
        c = Math.ceil(this.els.vertTrackContentEl.getBoundingClientRect().height);
        d = a / b;
        1 > d ? (this.els.vertTrackEl.style.display = "", this.els.vertBarEl.style.height = c * d + "px", this.contentsMaxScrollTop = b - a, this.barMaxScrollTop = c - c * d, this.isVertBar = !0) : (this.els.vertTrackEl.style.display = "none", this.barMaxScrollTop = this.contentsMaxScrollTop = 0, this.isVertBar = !1)
    };
    n.prototype.scrollHorizBar = function(a) {
        0 > a ? a = 0 : a > this.barMaxScrollLeft && (a = this.barMaxScrollLeft);
        this.barScrollLeft = a;
        this.els.horizBarEl.style.transition = "";
        this.els.horizBarEl.style.transform = "translate3d(" + a + "px, 0, 0)"
    };
    n.prototype.scrollVertBar = function(a) {
        0 > a ? a = 0 : a > this.barMaxScrollTop && (a = this.barMaxScrollTop);
        this.barScrollTop = a;
        this.els.vertBarEl.style.transform = "translate3d(0, " + a + "px, 0)"
    };
    n.prototype.scrollHoriz = function(a) {
        var c = a;
        0 > a ? c = 0 : a > this.contentsMaxScrollLeft && (c = this.contentsMaxScrollLeft);
        b(this.els.wrapEl, c)
    };
    n.prototype.scrollVert = function(a) {
        0 > a ? a = 0 : a > this.contentsMaxScrollTop && (a = this.contentsMaxScrollTop);
        this.els.wrapEl.scrollTop = a
    };
    n.prototype.handleScroll = function() {
        if (this.isHorizBar) {
            var b =
                g(this.els.wrapEl);
            this.scrollHorizBar(b / this.contentsMaxScrollLeft * this.barMaxScrollLeft)
        }
        this.isVertBar && this.scrollVertBar(this.els.wrapEl.scrollTop / this.contentsMaxScrollTop * this.barMaxScrollTop);
        a(document).trigger("scroll")
    };
    n.prototype.handleBarScrollStart = function(a) {
        this.isbarDragging = !0;
        this.prevPointX = a.screenX;
        this.prevPointY = a.screenY;
        a.target === this.els.horizBarEl ? this.els.horizTrackContentEl.classList.add("bar-dragging") : a.target === this.els.vertBarEl && this.els.vertTrackContentEl.classList.add("bar-dragging");
        document.addEventListener("mousemove", this.handleBarScroll);
        document.addEventListener("mouseup", this.handleBarScrollEnd);
        document.addEventListener("selectstart", this.handleSelect)
    };
    n.prototype.handleBarScrollTouchStart = function(a) {
        this.isbarDragging = !0;
        this.prevPointX = a.touches[0].screenX;
        this.prevPointY = a.touches[0].screenY;
        a.target === this.els.horizBarEl ? this.els.horizTrackContentEl.classList.add("bar-dragging") : a.target === this.els.vertBarEl && this.els.vertTrackContentEl.classList.add("bar-dragging");
        document.addEventListener("touchmove", this.handleBarScroll);
        document.addEventListener("touchend", this.handleBarScrollEnd)
    };
    n.prototype.handleBarScroll = function(a) {
        if (!this.isAnim && this.isbarDragging) {
            if (this.isHorizBar) {
                var b = void 0 !== a.screenX ? a.screenX : a.touches[0].screenX,
                    c = this.barScrollLeft + (b - this.prevPointX);
                this.scrollHorizBar(c);
                this.scrollHoriz(c * this.contentsMaxScrollLeft / this.barMaxScrollLeft);
                this.prevPointX = b
            }
            this.isVertBar && (a = void 0 !== a.screenY ? a.screenY : a.touches[0].screenY, b = this.barScrollTop +
                (a - this.prevPointY), this.scrollVertBar(b), this.scrollVert(b * this.contentsMaxScrollTop / this.barMaxScrollTop), this.prevPointY = a)
        }
    };
    n.prototype.handleBarScrollEnd = function() {
        this.isbarDragging = !1;
        this.prevPointY = this.prevPointX = 0;
        this.els.horizTrackContentEl.classList.remove("bar-dragging");
        this.els.vertTrackContentEl.classList.remove("bar-dragging");
        document.removeEventListener("mousemove", this.handleBarScroll);
        document.removeEventListener("mouseup", this.handleBarScrollEnd);
        document.removeEventListener("touchmove",
            this.handleBarScroll);
        document.removeEventListener("touchend", this.handleBarScrollEnd);
        document.removeEventListener("selectstart", this.handleSelect)
    };
    n.prototype.handleSelect = function(a) {
        a.stopPropagation();
        a.preventDefault();
        return !1
    };
    n.prototype.handleContentsDragStart = function(a) {
        this.isHorizBar && "hidden" !== window.getComputedStyle(this.els.wrapEl).overflow && (this.startX = a.clientX + g(this.els.wrapEl), this.isContentsDragging = !0, this.isClickDisabled = !1, this.diffX = 0, document.addEventListener("mousemove",
            this.handleContentsDrag), document.addEventListener("mouseup", this.handleContentsDragEnd))
    };
    n.prototype.handleContentsDrag = function(a) {
        if (!this.isAnim && this.isContentsDragging) {
            this.diffX = this.startX - (a.clientX + g(this.els.wrapEl));
            this.scrollHoriz(g(this.els.wrapEl) + this.diffX);
            var b = function(a) {
                e(a.target, "a") && (a.preventDefault(), a.stopPropagation());
                document.removeEventListener("click", b)
            };
            this.isClickDisabled || (document.addEventListener("click", b), this.isClickDisabled = !0)
        }
    };
    n.prototype.handleContentsDragEnd =
        function() {
            this.isContentsDragging = !1;
            document.removeEventListener("mousemove", this.handleContentsDrag);
            document.removeEventListener("mouseup", this.handleContentsDragEnd)
        };
    n.prototype.handleHorizTrackContentClick = function(a) {
        a = a.clientX - this.els.horizTrackContentEl.getBoundingClientRect().left;
        a < this.barScrollLeft ? this.scrollTo(-this.els.wrapEl.getBoundingClientRect().width, null, !1, 200) : a > this.barScrollLeft + this.horizBarWidth && this.scrollTo(this.els.wrapEl.getBoundingClientRect().width, null, !1, 200)
    };
    n.prototype.handleDragStart = function(a) {
        a.preventDefault()
    };
    n.prototype.resize = function() {
        this.setBarSize();
        this.handleScroll()
    };
    n.prototype.bindRaf = function(a) {
        var b = !1;
        return function(c) {
            b || (b = !0, requestAnimationFrame(function() {
                b = !1;
                a(c)
            }))
        }
    };
    n.prototype.initHandlers = function() {
        this.handleScroll = this.bindRaf(this.handleScroll.bind(this));
        this.handleBarScrollStart = this.handleBarScrollStart.bind(this);
        this.handleBarScrollTouchStart = this.handleBarScrollTouchStart.bind(this);
        this.handleBarScroll = this.bindRaf(this.handleBarScroll.bind(this));
        this.handleBarScrollEnd = this.handleBarScrollEnd.bind(this);
        this.handleSelect = this.handleSelect.bind(this);
        this.handleContentsDragStart = this.handleContentsDragStart.bind(this);
        this.handleContentsDrag = this.bindRaf(this.handleContentsDrag.bind(this));
        this.handleContentsDragEnd = this.handleContentsDragEnd.bind(this);
        this.resize = this.resize.bind(this);
        this.handleHorizTrackContentClick = this.handleHorizTrackContentClick.bind(this);
        this.handleDragStart = this.handleDragStart.bind(this)
    };
    n.prototype.bindEvents =
        function() {
            this.els.wrapEl.addEventListener("scroll", this.handleScroll);
            this.els.horizTrackContentEl.addEventListener("click", this.handleHorizTrackContentClick);
            this.els.horizBarEl.addEventListener("mousedown", this.handleBarScrollStart);
            this.els.horizBarEl.addEventListener("touchstart", this.handleBarScrollTouchStart);
            this.els.vertBarEl.addEventListener("mousedown", this.handleBarScrollStart);
            this.els.vertBarEl.addEventListener("touchstart", this.handleBarScrollTouchStart);
            this.els.wrapEl.addEventListener("mousedown",
                this.handleContentsDragStart);
            this.els.wrapEl.addEventListener("dragstart", this.handleDragStart);
            window.addEventListener("resize", this.resize)
        };
    n.prototype.unBindEvents = function() {
        this.els.wrapEl.removeEventListener("scroll", this.handleScroll);
        this.els.horizTrackContentEl.removeEventListener("click", this.handleHorizTrackContentClick);
        this.els.horizBarEl.removeEventListener("mousedown", this.handleBarScrollStart);
        this.els.horizBarEl.removeEventListener("touchstart", this.handleBarScrollTouchStart);
        this.els.vertBarEl.removeEventListener("mousedown",
            this.handleBarScrollStart);
        this.els.vertBarEl.removeEventListener("touchstart", this.handleBarScrollTouchStart);
        this.els.wrapEl.removeEventListener("mousedown", this.handleContentsDragStart);
        this.els.wrapEl.removeEventListener("dragstart", this.handleDragStart);
        window.removeEventListener("resize", this.resize)
    };
    n.prototype.scrollBottom = function() {
        this.scrollTo(null, this.contentsMaxScrollTop - this.els.wrapEl.scrollTop)
    };
    n.prototype.scrollTo = function(a, b, c, d, e) {
        var h = this;
        d = void 0 === d ? 300 : d;
        e = void 0 === e ?
            l(.4, 0, .2, 1) : e;
        var m = g(this.els.wrapEl),
            p = this.els.wrapEl.scrollTop;
        c ? (a && (a > this.contentsMaxScrollLeft && (a = this.contentsMaxScrollLeft), 0 > a && (a = 0), a -= m), b && (b > this.contentsMaxScrollTop && (b = this.contentsMaxScrollTop), 0 > a && (b = 0), b -= p)) : (a && (m + a > this.contentsMaxScrollLeft && (a = this.contentsMaxScrollLeft - m), 0 > m + a && (a = -m)), b && (p + b > this.contentsMaxScrollTop && (b = this.contentsMaxScrollTop - p), 0 > p + a && (b = -p)));
        c = function(c) {
            a && h.scrollHoriz(m + a * c);
            b && h.scrollVert(p + b * c)
        };
        0 < d ? this.isAnim || this.animate(c, d, e) :
            c(1)
    };
    n.prototype.animate = function(a, b, c) {
        var d = this,
            e = Date.now();
        this.isAnim = !0;
        this.isbarDragging = this.isContentsDragging = !1;
        var h = function() {
            var m = (Date.now() - e) / b;
            1 < m ? (a(1), d.isAnim = !1) : (requestAnimationFrame(h), a(c(m)))
        };
        h()
    };
    n.instances = new WeakMap;
    var c = !1,
        h = function() {
            c || (d.register(q.destroy), c = !0)
        },
        q = {
            initAll: function() {
                [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".scrollbar"))).forEach(function(a) {
                    n.instances.has(a) || (new n(a), h())
                })
            },
            init: function(a) {
                n.instances.has(a) ?
                    a = n.instances.get(a) : (a = new n(a), h());
                return a
            },
            reInit: function(a) {
                n.instances.has(a) ? (a = n.instances.get(a), a.reInit()) : (a = new n(a), h());
                return a
            },
            scrollTo: function(a, b, c, d) {
                d = void 0 === d ? !1 : d;
                n.instances.has(a) && n.instances.get(a).scrollTo(b, c, d)
            },
            scrollBottom: function(a) {
                n.instances.has(a) && n.instances.get(a).scrollBottom()
            },
            resize: function(a) {
                n.instances.has(a) && n.instances.get(a).resize()
            },
            destroy: function(a) {
                a.classList && a.classList.contains("scrollbar") ? n.instances.has(a) && n.instances.get(a).destroy() : [].concat($jscomp.arrayFromIterable(a.querySelectorAll(".scrollbar"))).forEach(function(a) {
                    n.instances.has(a) && n.instances.get(a).destroy()
                })
            }
        };
    window.sg.common.scrollbar = q;
    a.ready(q.initAll)
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.constants.BREAKPOINTS,
        e = window.sg.common.utils,
        g = window.sg.common.scrollbar,
        b = function(d) {
            this.ele = {
                window: a(window),
                section: a(d),
                scrollPopup: null,
                boxWrap: null
            };
            this.setProperty();
            this.handler = {
                resize: this.resize.bind(this)
            };
            b.instances.set(d, this);
            this.init()
        };
    b.prototype.setProperty = function() {
        this.ele.scrollPopup = this.ele.section.find(".layer-popup__contents.scrollbar");
        this.ele.boxWrap = this.ele.section.find(".layer-popup__inner")
    };
    b.prototype.init =
        function() {
            var a = this;
            0 >= this.ele.scrollPopup.target.length || (this.bindEvents(), this.resize(), setTimeout(function() {
                a.resize()
            }, 500))
        };
    b.prototype.reInit = function() {
        var a = this;
        this.setProperty();
        0 >= this.ele.scrollPopup.target.length || (this.bindEvents(), this.resize(), setTimeout(function() {
            a.resize()
        }, 500))
    };
    b.prototype.resize = function() {
        this.setScrollHeight()
    };
    b.prototype.setScrollHeight = function() {
        var a = this.ele.scrollPopup.find(".scrollbar__wrap").eq(0),
            b = a.target[0].scrollTop,
            c = e.getViewPort().height;
        a.css({
            maxHeight: ""
        });
        c -= this.ele.scrollPopup.target[0].offsetTop;
        c -= this.ele.boxWrap.offset().bottom - this.ele.scrollPopup.offset().bottom;
        c = void 0 === this.ele.section.target[0].dataset.paddingCustom ? c - (l.MOBILE < e.getViewPort().width ? 60 : 2 * this.ele.boxWrap.target[0].offsetTop) : c - 2 * this.ele.boxWrap.target[0].offsetTop;
        0 > c && (c = 0);
        a.height() - 1 > Math.round(c) && a.css({
            maxHeight: c + "px"
        });
        a.target[0].scrollTop = b;
        g.resize(this.ele.scrollPopup.target[0])
    };
    b.prototype.bindEvents = function() {
        this.ele.window.off("resize",
            this.handler.resize).on("resize", this.handler.resize)
    };
    b.instances = new WeakMap;
    window.sg.common.layerPopupMaxHeight = {
        initAll: function() {
            a(".layer-popup").target.forEach(function(a) {
                if (0 < a.querySelectorAll(".layer-popup__contents.scrollbar").length && !b.instances.has(a)) new b(a);
                else return null
            })
        },
        init: function(a) {
            if (0 < a.querySelectorAll(".layer-popup__contents.scrollbar").length && !b.instances.has(a))[].concat($jscomp.arrayFromIterable(a.querySelectorAll(".scrollbar"))).forEach(function(a) {
                    g.init(a)
                }),
                new b(a);
            else return null
        },
        reInit: function(a) {
            if (0 < a.querySelectorAll(".layer-popup__contents.scrollbar").length && b.instances.has(a)) b.instances.get(a).reInit();
            else return null
        },
        setMax: function(a) {
            if (0 < a.querySelectorAll(".layer-popup__contents.scrollbar").length && b.instances.has(a)) b.instances.get(a).setScrollHeight();
            else return null
        }
    }
})();
(function() {
    var a = window.sg.common.$q,
        l = window.Swiper,
        e = window.sg.common.constants.BREAKPOINTS,
        g = window.sg.common.utils,
        b = window.sg.common.lazyLoad,
        d = window.sg.common.utils.removeAllEventListeners,
        n = {
            init: function() {
                a(".basic-swiper").target.forEach(function(a) {
                    new c(a)
                })
            },
            reInit: function() {
                b.reInit();
                a(".basic-swiper").target.forEach(function(a) {
                    c.instances.has(a) ? c.instances.get(a).swiper.reInit() : new c(a)
                })
            },
            update: function() {
                a(".basic-swiper").target.forEach(function(a) {
                    c.instances.has(a) && (a =
                        c.instances.get(a).swiper, a.slideResize(), a.update())
                })
            },
            getSwiper: function(a) {
                if (c.instances.has(a)) return c.instances.get(a).swiper.getSwiper()
            },
            slideChange: function(a, b) {
                c.instances.has(a) && c.instances.get(a).swiper.slideChange(b)
            },
            slideChangeTransitionEnd: function(a, b) {
                c.instances.has(a) && c.instances.get(a).swiper.slideChangeTransitionEnd(b)
            },
            slideReInit: function(a) {
                c.instances.has(a) ? c.instances.get(a).swiper.reInit() : new c(a)
            },
            slideUpdate: function(a, b) {
                c.instances.has(a) && c.instances.get(a).swiper.slideUpdate(b)
            },
            slideInit: function(a, b) {
                new c(a, b)
            },
            slideRemove: function(a) {
                c.instances.has(a) && c.instances.get(a).swiper.remove()
            },
            slideInitEnd: function(a, b) {
                c.instances.has(a) && c.instances.get(a).swiper.slideInitEnd(b)
            },
            slideSwiperDestory: function(a) {
                c.instances.has(a) && c.instances.get(a).swiper.slideSwiperDestory()
            },
            slideStop: function(a) {
                c.instances.has(a) && c.instances.get(a).swiper.slideStop()
            },
            slideStart: function(a) {
                c.instances.has(a) && c.instances.get(a).swiper.slideStart()
            }
        },
        c = function(b, e) {
            var h = this;
            this.indicator =
                window.sg.common.indicator;
            this.selector = {
                imageMain: ".image \x3e .image__main",
                swiperSlide: ".swiper-slide",
                swiperWrapper: ".swiper-wrapper",
                swiperButtonNext: ".swiper-button-next",
                swiperButtonPrev: ".swiper-button-prev",
                indicator: ".indicator",
                indicatorList: ".indicator__list",
                indicatorControls: ".indicator__controls",
                indicatorItem: ".indicator__item",
                hiddenButton: ".hiddenButton"
            };
            this.el = {
                componentEl: null,
                containerEl: null,
                indicatorEl: null,
                prevEl: null,
                nextEl: null,
                autoPlayBtnEl: null
            };
            this.group = 0;
            this.el.containerEl =
                a(b);
            b = this.el.containerEl.attr("data-swiper-option") ? JSON.parse(this.el.containerEl.target[0].dataset.swiperOption) : {};
            this.el.componentEl = this.el.containerEl.closest(b.componentEl);
            var p = {
                slidesPerView: 1,
                spaceBetween: 0,
                longSwipes: !0,
                longSwipesRatio: .1,
                keepWrapper: !0,
                offSlideAccessibility: !1
            };
            p = g.extend(p, b);
            p.on = {};
            p.threshold = 10;
            p.init = !1;
            p.accessibility = !0;
            e && (p = g.extend(p, e));
            p.freeMode && (p.threshold = 0, p.freeModeSticky = !0, p.freeModeMomentumRatio = .01, p.centeredSlidesBounds = !0, p.touchStartPreventDefault = !1);
            p.passiveListeners = !1;
            p.a11y = !1;
            p.autoplay && (p.autoplay.disableOnInteraction = !1, !1 === p.autoplay.start && (p.autoplay = !1));
            this.$qwindow = a(window);
            this.option = p;
            this.focusInCheck = this.autoPlayCheck = null;
            this.clickCheck = !1;
            this.activeSlide = 0;
            this.slideChangeHandler = this.slideInitEndHandler = this.slideChangeTransitionEndHandler = null;
            this.prevImageCheck = !1;
            this.wrapperStr = '\x3cdiv class\x3d"swiper-wrapper" role\x3d"listbox"\x3e';
            this.focusElementStr = "a, button, h1, h2, h3, h4, h5, h6, p, .video, video";
            this.focusClass = ".three-column-carousel__content, .swiper-slide-focus";
            this.swiperStopEle = ".swiper-wrapper";
            this.hiddenButton = '\x3cbutton type\x3d"button" class\x3d"hidden hiddenButton" tabindex\x3d"-1"\x3eStop automatic slide show\x3c/button\x3e';
            this.textColorArr = [];
            this.textColorArr[0] = ".text-white";
            this.textColorArr[1] = ".text-black";
            this.bulletColorArr = [];
            this.bulletColorArr[0] = "text-color--white";
            this.bulletColorArr[1] = "text-color--black";
            this.sw = !1;
            this.handler = {
                setImageCheck: function() {
                    var a =
                        h.el.containerEl.find(h.selector.imageMain).eq(0);
                    0 >= a.height() && (h.el.containerEl.css({
                        "min-height": "2px"
                    }), a.on("load", h.handler.checkImageLoad))
                },
                checkImageLoad: function(b) {
                    h.el.containerEl.css({
                        "min-height": ""
                    });
                    h.slideResize();
                    a(b.target).off("load", h.handler.checkImageLoad)
                },
                autoPlayHandler: function() {
                    h.autoPlayCheck = h.autoPlayCheck ? !1 : !0;
                    h.autoPlayCheck ? (h.sw.autoplay.start(), h.handler.autoPlayBtnSetup(!1)) : (h.sw.autoplay.stop(), h.handler.autoPlayBtnSetup(!0))
                },
                autoPlayBtnSetup: function(a) {
                    if (h.el.autoPlayBtnEl.target.length) {
                        var b =
                            h.el.autoPlayBtnEl.attr("an-la");
                        a ? (h.el.autoPlayBtnEl.attr("an-la", b.replace(":stop", ":play")), h.el.autoPlayBtnEl.find(".hidden").innerHTML("play"), h.el.indicatorEl && h.indicator.pause(h.el.indicatorEl), h.el.autoPlayBtnEl.addClass("indicator__controls--play")) : (h.el.autoPlayBtnEl.attr("an-la", b.replace(":play", ":stop")), h.el.autoPlayBtnEl.find(".hidden").innerHTML("stop"), h.el.indicatorEl && h.indicator.play(h.el.indicatorEl), h.el.autoPlayBtnEl.removeClass("indicator__controls--play"))
                    }
                },
                focusInHandler: function(a) {
                    a.preventDefault();
                    h.sw.autoplay && !h.focusInCheck && (h.focusInCheck = !0, h.autoPlayCheck = h.sw.autoplay.running, "focusin" !== a.type.toLowerCase() && "mouseover" !== a.type.toLowerCase() || h.handler.autoPlayBtnSetup(!0), h.sw.autoplay.stop())
                },
                focusOutHandler: function(a) {
                    a.preventDefault();
                    h.sw.autoplay && h.focusInCheck && (h.focusInCheck = !1, h.autoPlayCheck && (h.clickCheck = !1, h.sw.autoplay.start(), h.handler.autoPlayBtnSetup(!1)))
                },
                renderIndicator: function() {
                    if (h.el.indicatorEl) {
                        var a = h.indicator.init(h.el.indicatorEl);
                        a && a.reInit();
                        h.el.componentEl.find(h.selector.indicatorItem).target.length && h.indicator.move(h.el.indicatorEl, h.activeSlide)
                    }
                    h.el.autoPlayBtnEl.target.length && (h.el.autoPlayBtnEl.find(".hidden").innerHTML("stop"), d(h.el.autoPlayBtnEl.target[0], "click"), h.el.autoPlayBtnEl.removeClass("indicator__controls--play"), a = function(a) {
                        h.el.indicatorEl || h.el.autoPlayBtnEl.toggleClass("indicator__controls--play");
                        a.preventDefault();
                        h.focusInCheck && !h.clickCheck && (h.clickCheck = !0, setTimeout(function() {
                                h.handler.autoPlayHandler(!0)
                            },
                            100));
                        h.handler.autoPlayHandler()
                    }, h.el.autoPlayBtnEl.off("click").on("click", a), h.el.containerEl.find(h.selector.hiddenButton).off("click").on("click", a))
                },
                paginationUpdateHandler: function(b, c) {
                    b = a(c).find(h.selector.indicatorItem + ".swiper-pagination-bullet-active").target[0];
                    c = a(c).find(h.selector.indicatorItem + ".indicator__item--active").target[0];
                    b !== c && b && (c = parseInt(b.getAttribute("clickid"), 10), h.indicator.move(h.el.indicatorEl, c))
                },
                paginationRenderHandler: function() {
                    h.handler.renderIndicator();
                    h.handler.setupBullet()
                },
                setupBullet: function() {
                    h.headlineArr = [];
                    h.el.containerEl.find(".swiper-slide:not(.swiper-slide-duplicate)").target.forEach(function(a) {
                        var b = a.getAttribute("headline");
                        b || (b = a.getAttribute("an-tr"));
                        h.headlineArr.push(b)
                    });
                    h.headlineArr = h.headlineArr.concat(h.headlineArr);
                    a(h.option.pagination.el).find(".swiper-pagination-bullet").target.forEach(function(b, c) {
                        var d = null;
                        d = c * h.group;
                        h.group !== h.getNowPerView() && (d = c);
                        d = h.option.loop ? h.el.containerEl.find(h.selector.swiperWrapper).find('.swiper-slide[data-swiper-slide-index\x3d"' +
                            d + '"]') : a(h.sw.slides[d]);
                        var e = a(b);
                        d.target.forEach(function(a) {
                            a.setAttribute("aria-describedby", e.attr("id"))
                        });
                        b = d.attr("an-tr");
                        var g = d.attr("headline");
                        g || (g = b);
                        e.attr("an-tr", b);
                        e.attr("an-ca", d.attr("an-ca"));
                        e.attr("an-ac", d.attr("an-ac"));
                        e.attr("an-la", d.attr("an-la"));
                        e.attr("slide-index", c);
                        e.find(".hidden").innerHTML("Slide " + (c + 1) + ": " + g)
                    });
                    var b = h.getNowPerView();
                    if (1 < b) {
                        var c = 0;
                        a(h.option.pagination.el).find(".swiper-pagination-bullet").target.forEach(function(d, e) {
                            for (var g = "",
                                    m = c; m < c + b; m++) g += " " + h.headlineArr[m];
                            c += b;
                            a(d).find(".hidden").innerHTML("Slide " + (e + 1) + ":" + g)
                        })
                    }
                },
                resize: function() {
                    "pc" === h.option.viewMode ? h.resizePc() : "mobile" === h.option.viewMode ? h.resizeMobile() : h.resize()
                }
            };
            this.handler.setImageCheck();
            this.bindEvents();
            this.reInit = function() {
                h.el.containerEl.find(h.selector.swiperSlide).removeClass("swiper-slide-active");
                h.remove();
                h.handler.setImageCheck();
                h.bindEvents()
            };
            c.instances.set(this.el.containerEl.target[0], {
                swiper: this
            })
        };
    c.createCount = function() {
        return this.count +=
            1
    };
    c.prototype.customFocus = function() {};
    c.prototype.getSwiper = function() {
        return this.sw
    };
    c.prototype.init = function() {
        var d = this;
        if (!1 === this.sw) {
            this.activeSlide = 0;
            var e = this.el.containerEl.find(this.selector.swiperSlide);
            this.el.autoPlayBtnEl = this.el.componentEl.find(this.selector.indicatorControls);
            this.el.indicatorEl = this.el.componentEl.find(this.selector.indicator).target[0];
            this.el.prevEl = this.el.componentEl.find(this.selector.swiperButtonPrev);
            this.el.nextEl = this.el.componentEl.find(this.selector.swiperButtonNext);
            if (this.getNowPerView() > e.target.length) this.el.prevEl.hide(), this.el.nextEl.hide();
            else {
                this.el.containerEl.find(this.selector.swiperSlide).target.forEach(function(b, c) {
                    a(b).hasClass("swiper-slide-active") && (d.activeSlide = c)
                });
                if (0 === this.el.containerEl.find(this.selector.swiperWrapper).target.length) {
                    var g = this.el.containerEl.find(this.selector.swiperSlide);
                    this.slideAccessibility();
                    e = g.clone();
                    g.remove();
                    g = this.el.containerEl.find(".indicator");
                    var p = this.el.containerEl.children();
                    0 === p.target.length ?
                        this.el.containerEl.append(this.wrapperStr) : g.target.length && !this.el.containerEl.find(this.selector.swiperButtonPrev).target.length ? g.prepend(this.wrapperStr) : p.eq(0).after(this.wrapperStr);
                    this.el.containerEl.find(this.selector.swiperWrapper).append(e);
                    window.sg.common.image.initAll();
                    b.initAll()
                }
                this.el.containerEl.find(this.selector.hiddenButton).off().remove();
                this.option.autoplay && this.el.containerEl.target[0].insertAdjacentHTML("afterbegin", this.hiddenButton);
                this.option.navigation ? "string" ===
                    (typeof this.option.navigation.prevEl).toLowerCase() && (this.el.prevEl = this.el.componentEl.find(this.option.navigation.prevEl), this.el.nextEl = this.el.componentEl.find(this.option.navigation.nextEl)) : (this.option.navigation = {}, this.option.navigation.prevEl = this.el.prevEl.target[0], this.option.navigation.nextEl = this.el.nextEl.target[0]);
                this.slideChangeHandler && (this.option.on.slideChange = function() {
                    d.slideChangeHandler(d.sw, d.sw.realIndex)
                });
                this.option.pagination && 0 < this.el.containerEl.height() && (this.option.pagination = {}, this.el.componentEl.find(this.selector.indicatorList + " \x3e button").remove(), this.option.pagination.el = this.el.componentEl.find(this.selector.indicatorList).target[0], this.option.pagination.renderBullet = function(a, b) {
                    return '\x3cbutton class\x3d"indicator__item ' + b + '" role\x3d"tab" clickid\x3d"' + a + '" id\x3d"swiper' + c.createCount() + '"\x3e\x3cspan class\x3d"indicator__dot-wrap"\x3e\x3cspan class\x3d"indicator__dot"\x3e \x3cspan class\x3d"indicator__dot-inner"\x3e\x3c/span\x3e\x3c/span\x3e\x3cspan class\x3d"hidden"\x3eIndicator 10\x3c/span\x3e\x3c/span\x3e\x3c/button\x3e'
                });
                e = this.getNowPerView();
                this.group = this.option.slidesPerGroup;
                this.group || (this.group = 1);
                e = e !== this.group && "number" === (typeof this.group).toLowerCase() && "auto" !== e ? !0 : !1;
                var n = [];
                e ? (this.option.slidesPerGroup = 1, this.timer = null, this.option.on = {
                    slideNextTransitionStart: function() {
                        var a = this;
                        0 === (this.realIndex - 1) % this.group && this.slideTo(this.activeIndex + (this.group - 1));
                        var b = !1;
                        n.forEach(function(c) {
                            a.realIndex === c && (b = !0)
                        });
                        b && this.slideNext();
                        this.slideChangeHandler && (this.timer && clearTimeout(this.timer),
                            this.timer = setTimeout(function() {
                                a.slideChangeHandler(a.sw, a.sw.realIndex)
                            }, 200))
                    },
                    slidePrevTransitionStart: function() {
                        var a = this;
                        0 === (this.realIndex + 1) % this.group && this.slideTo(this.activeIndex - (this.group - 1));
                        var b = !1;
                        n.forEach(function(c) {
                            a.realIndex === c && (b = !0)
                        });
                        b && this.slidePrev();
                        this.slideChangeHandler && (this.timer && clearTimeout(this.timer), this.timer = setTimeout(function() {
                            a.slideChangeHandler(a.sw, a.sw.realIndex)
                        }, 200))
                    }
                }) : this.option.pagination && (this.option.pagination.clickable = !0);
                this.option.autoHeight &&
                    (this.el.containerEl.find(this.selector.swiperWrapper).css({
                        transition: "all ease-out",
                        "-o-transition": "all ease-out",
                        "-ms-transition": "all ease-out",
                        "-moz-transition": "all ease-out",
                        "-webkit-transition": "all ease-out"
                    }), this.option.on.touchStart = function() {
                        d.slideResize()
                    });
                var t = !1;
                this.option.freeMode && (this.option.on.touchEnd = function() {
                    t = !0
                });
                this.option.on.slideChangeTransitionEnd = function() {
                    d.slideChangeTransitionEndHandler && d.slideChangeTransitionEndHandler(d.sw, d.sw.realIndex);
                    d.slideAccessibility();
                    t || d.customFocus();
                    t = !1
                };
                this.sw = new l(this.el.containerEl.target[0], this.option);
                this.sw.init();
                this.option.autoplay ? (this.el.autoPlayBtnEl.attr("an-tr", this.option.autoplay["an-tr"]), this.el.autoPlayBtnEl.attr("an-ca", this.option.autoplay["an-ca"]), this.el.autoPlayBtnEl.attr("an-ac", this.option.autoplay["an-ac"]), this.el.autoPlayBtnEl.attr("an-la", this.option.autoplay["an-la"]), !this.el.indicatorEl && this.el.autoPlayBtnEl && this.handler.renderIndicator()) : this.el.autoPlayBtnEl.hide();
                if (this.option.pagination) {
                    this.handler.setupBullet();
                    if (e) {
                        var y = 0,
                            v = a(this.option.pagination.el).find(".swiper-pagination-bullet");
                        v.target.forEach(function(a, b) {
                            0 === b % d.group || b === v.target.length - 1 ? (a.setAttribute("index", b), a.setAttribute("clickid", y), y++) : (n.push(b), a.setAttribute("disabled", "false"))
                        });
                        this.el.componentEl.find(this.selector.indicatorItem + '[disabled\x3d"false"]').remove();
                        this.el.componentEl.find(this.selector.indicatorItem).on("click", function(b) {
                            b = parseInt(a(b.target).closest(d.selector.indicatorItem).attr("index"), 10);
                            d.sw.slideToLoop(b)
                        });
                        var L = this.getNowPerView();
                        a(this.option.pagination.el).find(".swiper-pagination-bullet").target.forEach(function(b, c) {
                            for (var e = "", h = parseInt(b.getAttribute("slide-index"), 10), g = h; g < h + L; g++) e += " " + d.headlineArr[g];
                            a(b).find(".hidden").innerHTML("Slide " + (c + 1) + ":" + e)
                        })
                    }
                    this.option.pagination && setTimeout(function() {
                            d.sw.pagination && d.sw.pagination.bullets && (d.handler.renderIndicator(), d.sw.on("paginationUpdate", d.handler.paginationUpdateHandler), d.sw.on("paginationRender", d.handler.paginationRenderHandler))
                        },
                        100)
                }
                this.option.autoplay && (this.autoPlayCheck = this.sw.autoplay.running, e = null, e = this.el.componentEl.target.length ? this.el.componentEl.find(this.swiperStopEle) : this.el.containerEl, this.focusInCheck = !1, e.off("mouseover", this.handler.focusInHandler).on("mouseover", this.handler.focusInHandler), e.off("mouseleave", this.handler.focusOutHandler).on("mouseleave", this.handler.focusOutHandler), e.off("focusin", this.handler.focusInHandler).on("focusin", this.handler.focusInHandler), e.off("focusout", this.handler.focusOutHandler).on("focusout",
                    function(b) {
                        setTimeout(function() {
                            a(document.activeElement).target[0] !== d.el.autoPlayBtnEl.target[0] && d.handler.focusOutHandler(b)
                        }, 300)
                    }));
                if (this.option.loop) this.sw.slideToLoop(this.activeSlide, 0);
                else if (this.sw.slideTo(this.activeSlide, 0), this.el.indicatorEl && "none" !== this.el.autoPlayBtnEl.css("display")) this.sw.on("slideChange", function() {
                    d.sw.isEnd && !d.el.autoPlayBtnEl.hasClass("indicator__controls--play") && (d.clickCheck = !0, d.handler.autoPlayHandler())
                });
                this.slideAccessibility();
                this.el.nextEl.off("click").on("click",
                    function() {
                        d.sw.isEnd && !d.option.loop && d.el.prevEl.focus()
                    });
                this.el.prevEl.off("click").on("click", function() {
                    d.sw.isBeginning && !d.option.loop && d.el.nextEl.focus()
                });
                this.sw.on("slideChange", function() {
                    b.setLazyLoad()
                });
                this.sw.on("transitionEnd", function() {
                    b.setLazyLoad()
                });
                this.sw.on("init", function() {
                    d.slideInitEndHandler && d.slideInitEndHandler()
                })
            }
        }
    };
    c.prototype.slideStart = function() {
        this.sw && (this.autoPlayCheck = !0, this.sw.autoplay.start(), this.handler.autoPlayBtnSetup(!1))
    };
    c.prototype.slideStop =
        function() {
            this.sw && (this.autoPlayCheck = !1, this.sw.autoplay.stop(), this.handler.autoPlayBtnSetup(!0))
        };
    c.prototype.getNowPerView = function() {
        var a = 0,
            b = this.option.breakpoints;
        b && Object.keys(b).forEach(function(b) {
            b = parseInt(b, 0);
            g.getViewPort().width > b && a < b && (a = b)
        });
        b = 0 !== a ? b[a].slidesPerView : this.option.slidesPerView;
        this.option.realSlidesPerView && (b = parseInt(this.option.realSlidesPerView, 0));
        return b
    };
    c.prototype.slideAccessibility = function() {
        var b = this;
        if (this.sw && !this.option.offSlideAccessibility) {
            var c =
                this.getNowPerView();
            this.el.containerEl.find(this.focusClass).removeAttr("tabindex");
            var d = [];
            [].concat($jscomp.arrayFromIterable(this.sw.slides)).forEach(function(c) {
                c = a(c);
                c.find(b.focusElementStr).attr("tabindex", "-1");
                c.attr("aria-hidden", !0);
                d.push(c)
            });
            if ("auto" !== c && 1 < c)
                for (var e = this.sw.activeIndex; e < this.sw.activeIndex + c; e++) {
                    var g = d[e];
                    g && (g.find(this.focusElementStr).removeAttr("tabindex"), g.attr("aria-hidden", !1), 0 < g.find(this.focusClass).target.length ? g.find(this.focusClass).attr("tabindex",
                        "0") : g.find(this.focusElementStr).attr("tabindex", "0"))
                }
            var n = this.el.containerEl.find(".swiper-slide-active");
            n.find(this.focusClass).target.length ? n.find(this.focusClass).attr("tabindex", "0") : n.find(this.focusElementStr).attr("tabindex", "0");
            n.attr("aria-hidden", !1);
            if (this.option.pagination) {
                var l = !0;
                this.textColorArr.forEach(function(a, c) {
                    n.find(a).target.length && (b.bulletColorArr.forEach(function(a) {
                        b.el.containerEl.removeClass(a)
                    }), l = !1, b.el.containerEl.addClass(b.bulletColorArr[c]))
                });
                l && this.bulletColorArr.forEach(function(a) {
                    b.el.containerEl.removeClass(a)
                })
            }
        }
    };
    c.prototype.update = function() {
        if (this.sw) {
            var a = this.el.containerEl.find(".swiper-slide-active").index();
            this.option.loop || (this.sw.activeIndex = a);
            this.slideResize();
            this.sw.update();
            this.slideAccessibility()
        }
    };
    c.prototype.slideChange = function(a) {
        this.slideChangeHandler = a
    };
    c.prototype.slideChangeTransitionEnd = function(a) {
        this.slideChangeTransitionEndHandler = a
    };
    c.prototype.slideInitEnd = function(a) {
        this.sw.initialized ? a() : this.slideInitEndHandler = a
    };
    c.prototype.slideResize = function() {
        if (!1 !== this.sw &&
            this.option.autoHeight) {
            var b = this.el.containerEl.find(this.selector.swiperWrapper),
                c = b.find(this.selector.swiperSlide);
            b.css({
                height: ""
            });
            c.css({
                height: ""
            });
            c.target.forEach(function(b) {
                b = a(b);
                var c = b.outerHeight();
                b.css({
                    height: c + "px"
                })
            });
            c = b.find(".swiper-slide.swiper-slide-active").height();
            b.css({
                height: c + "px"
            })
        }
    };
    c.prototype.remove = function() {
        if (!1 !== this.sw) {
            this.el.containerEl.find(".swiper-pagination-bullet").off();
            this.el.componentEl.find(this.selector.indicatorControls).off();
            var a = this.el.containerEl.find(this.selector.swiperSlide);
            a.find(this.focusElementStr).removeAttr("tabindex");
            a.css({
                width: "",
                height: "",
                visibility: ""
            });
            a.removeAttr("aria-hidden");
            a.removeAttr("aria-describedby");
            a.removeClass("swiper-slide-prev");
            a.removeClass("swiper-slide-next");
            this.option.keepWrapper || (a = a.clone(), this.el.containerEl.find(this.selector.swiperWrapper).remove(), this.el.containerEl.append(a));
            this.el.containerEl.find(".swiper-slide-duplicate").remove();
            this.sw.destroy();
            this.sw = !1
        }
    };
    c.prototype.slideSwiperDestory = function() {
        this.sw.destroy();
        this.sw = !1
    };
    c.prototype.resizePc = function() {
        e.MOBILE < g.getViewPort().width ? (this.resize(), this.init()) : this.remove();
        this.slideAccessibility()
    };
    c.prototype.resize = function() {
        this.el.containerEl.find(this.selector.swiperWrapper).css({
            height: ""
        });
        this.el.containerEl.find(this.selector.swiperWrapper + " " + this.selector.swiperSlide).css({
            height: ""
        });
        this.slideResize();
        this.slideAccessibility()
    };
    c.prototype.resizeMobile = function() {
        e.MOBILE >= g.getViewPort().width ? (this.resize(), this.init()) : this.remove();
        this.slideAccessibility()
    };
    c.prototype.bindEvents = function() {
        this.$qwindow.off("resize", this.handler.resize).on("resize", this.handler.resize);
        this.option.viewMode || this.init();
        this.handler.resize()
    };
    c.prototype.slideUpdate = function(a) {
        void 0 !== a && (this.option = g.extend(this.option, a));
        this.update()
    };
    c.count = 0;
    c.instances = new WeakMap;
    window.sg.common.swiperManager = n;
    a.ready(n.init);
    a.load(n.update)
})();
(function() {
    var a = 0,
        l = function() {
            var a = window.document.createEvent("UIEvents");
            a.initUIEvent("resize", !0, !1, window, 0);
            window.dispatchEvent(a)
        },
        e = function(b) {
            b ? 60 < a || 768 === window.innerWidth ? l() : (a++, requestAnimationFrame(function() {
                return e(b)
            })) : 60 < a || 768 !== window.innerWidth ? l() : (a++, requestAnimationFrame(function() {
                return e(b)
            }))
        },
        g = function() {
            var b = document.querySelector('meta[name\x3d"viewport"]'),
                g = b.getAttribute("content");
            768 > window.outerWidth && 534 < window.outerWidth ? "width\x3d768,maximum-scale\x3d1.0" !==
                g && (b.setAttribute("content", "width\x3d768,maximum-scale\x3d1.0"), a = 0, requestAnimationFrame(function() {
                    return e(!0)
                })) : "width\x3ddevice-width,initial-scale\x3d1.0,minimum-scale\x3d1.0,maximum-scale\x3d1.0" !== g && (b.setAttribute("content", "width\x3ddevice-width,initial-scale\x3d1.0,minimum-scale\x3d1.0,maximum-scale\x3d1.0"), a = 0, requestAnimationFrame(function() {
                    return e(!1)
                }))
        },
        b = function(d) {
            window.outerWidth !== d || 120 <= a ? g() : (a++, d = window.outerWidth, requestAnimationFrame(function() {
                return b(d)
            }))
        };
    window.addEventListener("resize", g);
    window.addEventListener("orientationchange", function() {
        a = 0;
        b(window.outerWidth)
    });
    "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", g) : g()
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.utils.closest,
        e = function(a, d) {
            this.el = a;
            this.src = d;
            this.init()
        };
    e.prototype.init = function() {
        this.loadSvgSprite(this.src);
        this.setSvgs(this.el)
    };
    e.prototype.loadSvgSprite = function(a) {
        var b = new XMLHttpRequest;
        b.open("GET", a);
        b.send();
        a = function() {
            if (4 === b.readyState) {
                var a = document.createElement("div");
                a.innerHTML = b.responseText;
                if (a = a.querySelector("svg")) a.setAttribute("aria-hidden", "true"), a.style.position = "absolute", a.style.width = "0", a.style.height =
                    "0", document.body.insertBefore(a, document.body.firstChild)
            }
        };
        b.onreadystatechange = a;
        a()
    };
    e.prototype.setSvgs = function(a) {
        a = a.querySelectorAll("use");
        [].concat($jscomp.arrayFromIterable(a)).forEach(function(a) {
            var b = a.getAttribute("xlink:href") || a.getAttribute("href"),
                c = l(a, "svg");
            b && c && (b = "#" + b.split("#")[1], a.setAttribute("xlink:href", b), a.setAttribute("href", b))
        })
    };
    e.instance = null;
    var g = {
        init: function() {
            e.instance = new e(document, "/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/images/svg-sprite.svg")
        },
        setSvgs: function(a) {
            a = void 0 === a ? document : a;
            e.instance && e.instance.setSvgs(a)
        },
        redrawSvg: function(a) {
            var b = a.parentElement;
            if (b) {
                var e = [].concat($jscomp.arrayFromIterable(b.childNodes)).indexOf(a);
                b.removeChild(a);
                var c = document.createElement("div");
                c.appendChild(a);
                c.innerHTML = c.innerHTML;
                a = c.firstChild;
                b.childNodes[e] ? b.insertBefore(a, b.childNodes[e]) : b.appendChild(a)
            }
        },
        redrawSvgs: function(a) {
            a = void 0 === a ? document : a;
            a = a.querySelectorAll("svg");
            [].concat($jscomp.arrayFromIterable(a)).forEach(function(a) {
                g.redrawSvg(a)
            })
        },
        redrawAbnormalSvgs: function(a) {
            a = void 0 === a ? document : a;
            var b = a.querySelectorAll("svg");
            [].concat($jscomp.arrayFromIterable(b)).forEach(function(b) {
                "http://www.w3.org/2000/svg" !== a.namespaceURI && g.redrawSvg(b)
            })
        },
        update: function(a) {
            a = void 0 === a ? document : a;
            g.setSvgs(a);
            g.redrawSvgs(a)
        },
        updateAbnormalSvgs: function(a) {
            a = void 0 === a ? document : a;
            g.setSvgs(a);
            g.redrawAbnormalSvgs(a)
        }
    };
    window.sg.common.icon = g;
    a.ready(g.init)
})();
(function() {
    window.sg = window.sg || {};
    window.sg.authoring = window.sg.authoring || {};
    window.sg.authoring.raiseEvent = {
        domContentLoaded: function() {
            var a = document.createEvent("Event");
            a.initEvent("DOMContentLoaded", !0, !0);
            return window.document.dispatchEvent(a)
        }
    }
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.constants.KEY_CODE,
        e = window.sg.common.scrollbar,
        g = function(b, e) {
            var c = this;
            e = void 0 === e ? -1 : e;
            this.els = {
                el: a(b),
                selectEl: null,
                btnEl: null,
                btnTextEl: null,
                listWrapEl: null,
                listEl: null,
                itemEls: null,
                docEl: a(document)
            };
            this.els.selectEl = this.els.el.find("select");
            this.els.selectEl.hide();
            this.options = [].concat($jscomp.arrayFromIterable(this.els.selectEl.target[0].options));
            this.selectedIndex = e;
            this.isDisabled = this.isOpen = !1;
            this.itemMappedIndices = [];
            this.itemMappedIndicesExclDisabled = [];
            this.eventHandler = {
                docEl: {
                    click: function(a) {
                        a.preventDefault();
                        a.target.hasClass("dropdown__option") || c.close()
                    }
                },
                el: {
                    keydown: function(a) {
                        if (!c.isDisabled) switch (a.keyCode) {
                            case l.TAB:
                                c.els.el.removeClass("selected");
                                break;
                            case l.ENTER:
                            case l.SPACE:
                                -1 === c.selectedIndex && (c.selectedIndex = 0, c.selectItem(c.selectedIndex));
                                c.keydown(a);
                                break;
                            case l.PAGE_UP:
                            case l.HOME:
                                c.selectedIndex = 0;
                                c.selectItem(c.selectedIndex, a);
                                break;
                            case l.PAGE_DOWN:
                            case l.END:
                                c.selectedIndex =
                                    c.els.itemEls.target.length - 1;
                                c.selectItem(c.selectedIndex, a);
                                break;
                            case l.LEFT:
                            case l.UP:
                                -1 !== c.selectedIndex && c.selectNext(-1, a);
                                break;
                            case l.RIGHT:
                            case l.DOWN:
                                -1 !== c.selectedIndex ? c.selectNext(1, a) : c.selectItem(0, a);
                                break;
                            default:
                                c.selectItem(c.getSelectedItemIndex(a.keyCode), a)
                        }
                    }
                },
                btnEl: {
                    click: function(a) {
                        a.preventDefault();
                        a.stopPropagation();
                        c.isDisabled || (c.els.el.toggleClass("selected"), c.els.el.hasClass("selected") ? (c.els.docEl.off("click", c.eventHandler.docEl.click), c.els.docEl.on("click",
                            c.eventHandler.docEl.click), c.open()) : c.close())
                    }
                },
                selectEl: {
                    change: function(a) {
                        c.selectedIndex = a.target.selectedIndex;
                        c.els.btnTextEl.text(a.target.options[c.selectedIndex].text);
                        c.select()
                    }
                },
                itemEls: {
                    click: function(b) {
                        b.preventDefault();
                        b = a(b.target);
                        b.hasClass("disabled") || (b = b.closest("li").index(), c.change(b), c.close(), c.els.btnEl.focus())
                    }
                }
            };
            this.init()
        };
    g.prototype.init = function() {
        g.instances.has(this.els.el.target[0]) || (g.instances.set(this.els.el.target[0], this), this.setElements(), this.bindEvents(),
            this.update(), -1 < this.selectedIndex && this.selectItem(this.selectedIndex))
    };
    g.prototype.reInit = function(a) {
        this.els.selectEl = this.els.el.find("select");
        this.els.btnEl = this.els.el.find(".dropdown__cta");
        this.els.listWrapEl = this.els.el.find(".dropdown__list-wrap");
        this.options = [].concat($jscomp.arrayFromIterable(this.els.selectEl.target[0].options));
        this.removeElements();
        this.setElements();
        this.bindEvents();
        this.update(); - 1 < a && this.selectItem(a)
    };
    g.prototype.removeElements = function() {
        this.els.btnEl.remove();
        this.els.listWrapEl.remove()
    };
    g.prototype.setElements = function() {
        var a = this,
            b = this.els.selectEl.target[0],
            c = b.dataset.defaultMessage;
        c ? b.selectedIndex = -1 : c = b.options[b.selectedIndex].text;
        this.selectedIndex = b.selectedIndex;
        this.els.el.append('\x3ca class\x3d"dropdown__cta" title\x3d"' + b.title + '" href\x3d"#" role\x3d"combobox" aria-haspopup\x3d"listbox" aria-expanded\x3d"false"\x3e\x3cspan\x3e' + c + "\x3c/span\x3e\x3c/a\x3e");
        this.els.btnEl = this.els.el.find(".dropdown__cta");
        this.els.btnTextEl = this.els.btnEl.find("span");
        this.els.el.append('\x3cdiv class\x3d"dropdown__list-wrap scrollbar"\x3e\x3c/div\x3e');
        this.els.listWrapEl = this.els.el.find(".dropdown__list-wrap");
        this.els.listWrapEl.append('\x3cul class\x3d"dropdown__option-list scrollbar__contents" role\x3d"listbox" tabindex\x3d"0"\x3e');
        this.els.listEl = this.els.listWrapEl.find(".dropdown__option-list");
        this.options.forEach(function(b) {
            a.els.listEl.append('\x3cli class\x3d"dropdown__option"\x3e\x3ca href\x3d"#" role\x3d"option"\x3e\x3cspan\x3e' + b.text + "\x3c/span\x3e\x3c/a\x3e\x3c/li\x3e")
        });
        this.els.itemEls = this.els.listEl.find("li\x3ea");
        e.init(this.els.listWrapEl.target[0]);
        this.select()
    };
    g.prototype.select = function() {
        this.els.itemEls.removeAttr("aria-selected");
        this.els.itemEls.removeClass("active");
        var a = this.els.itemEls.eq(this.selectedIndex);
        a.addClass("active");
        a.attr("aria-selected", !0)
    };
    g.prototype.bindEvents = function() {
        this.els.btnEl.off("click").on("click", this.eventHandler.btnEl.click);
        this.els.itemEls.off("click").on("click", this.eventHandler.itemEls.click);
        this.els.selectEl.off("change").on("change",
            this.eventHandler.selectEl.change);
        this.els.el.off("keydown").on("keydown", this.eventHandler.el.keydown)
    };
    g.prototype.update = function() {
        var a = this;
        this.els.el.hasClass("selected") && (this.els.el.removeClass("selected"), this.els.btnEl.trigger("click"));
        (this.isDisabled = this.els.el.hasClass("disabled")) ? (this.els.btnEl.attr("tabindex", "-1"), this.els.btnEl.attr("aria-disabled", "true")) : (this.els.btnEl.removeAttr("tabindex"), this.els.btnEl.attr("aria-disabled", "false"));
        this.els.itemEls.removeClass("disabled");
        this.els.itemEls.removeAttr("tabindex");
        this.els.itemEls.attr("aria-disabled", "false");
        this.itemMappedIndices = [];
        this.itemMappedIndicesExclDisabled = [];
        var b = 0;
        this.options.forEach(function(c, d) {
            a.itemMappedIndices.push(-1);
            c.disabled ? (c = a.els.itemEls.eq(d), c.addClass("disabled"), c.attr("tabindex", "-1"), c.attr("aria-disabled", "true")) : (a.itemMappedIndices[d] = b++, a.itemMappedIndicesExclDisabled.push(d))
        })
    };
    g.prototype.open = function() {
        this.els.el.css({
            "z-index": 1
        }); - 1 !== this.els.selectEl.target[0].selectedIndex &&
            this.els.itemEls.eq(this.els.selectEl.target[0].selectedIndex).focus();
        this.els.btnEl.attr("aria-expanded", !0);
        this.isOpen = !0;
        this.resize()
    };
    g.prototype.close = function() {
        this.els.el.css({
            "z-index": ""
        });
        this.els.el.removeAttr("z-index");
        this.els.el.removeClass("selected");
        this.isOpen = !1;
        this.els.btnEl.attr("aria-expanded", !1);
        this.els.docEl.off("click", this.eventHandler.docEl.click);
        this.els.btnEl.focus()
    };
    g.prototype.resize = function() {
        e.resize(this.els.listWrapEl.target[0])
    };
    g.prototype.change = function(a) {
        var b =
            this.els.selectEl.target[0];
        b.selectedIndex !== a && (this.selectedIndex = b.selectedIndex = a, this.els.selectEl.trigger("change"))
    };
    g.prototype.keydown = function(a) {
        this.els.btnEl.trigger("click");
        a.preventDefault()
    };
    g.prototype.selectNext = function(a, b) {
        var c = -1 === this.itemMappedIndices[this.selectedIndex] ? 0 : this.itemMappedIndices[this.selectedIndex];
        c += a;
        a = 0 > c ? this.itemMappedIndicesExclDisabled[0] : c > this.itemMappedIndicesExclDisabled.length - 1 ? this.itemMappedIndicesExclDisabled[this.itemMappedIndicesExclDisabled.length -
            1] : this.itemMappedIndicesExclDisabled[c]; - 1 !== a && (this.els.itemEls.target[a].focus(), this.change(a));
        b && b.preventDefault()
    };
    g.prototype.selectItem = function(a, b) {
        if (!(0 > a)) {
            var c = -1;
            0 === a ? c = this.itemMappedIndicesExclDisabled[0] : a === this.itemMappedIndices.length - 1 ? c = this.itemMappedIndicesExclDisabled[this.itemMappedIndicesExclDisabled.length - 1] : -1 !== this.itemMappedIndices[a] && (c = a); - 1 !== c && (this.els.itemEls.target[c].focus(), this.change(c));
            b && b.preventDefault()
        }
    };
    g.prototype.getSelectedItemIndex = function(b) {
        var d =
            this,
            c = /[A-Z]/,
            e = b - 48 * Math.floor(b / 48),
            g = String.fromCharCode(96 <= b ? e : b),
            m = !0,
            p = -1;
        b = this.selectedIndex;
        this.els.itemEls.target.forEach(function(b, e) {
            var h = b.textContent.substring(0, 1).toUpperCase();
            b = a(b).hasClass("disabled");
            c.test(h) && h === g && !b && -1 === p && (p = e);
            c.test(h) && h === g && d.selectedIndex < e && m && !b && (d.selectedIndex = e, m = !1)
        });
        b === this.selectedIndex && -1 !== p && (this.selectedIndex = p);
        return this.selectedIndex
    };
    g.instances = new WeakMap;
    var b = {
        initAll: function() {
            a(".dropdown").target.forEach(function(a) {
                g.instances.has(a) ||
                    new g(a)
            })
        },
        init: function(a) {
            g.instances.has(a) || new g(a)
        },
        reInit: function(a, b) {
            b = void 0 === b ? -1 : b;
            g.instances.has(a) ? g.instances.get(a).reInit(b) : new g(a, b)
        }
    };
    window.sg.common.dropdown = b;
    a.ready(b.initAll)
})();
(function() {
    var a = window.sg.common.$q,
        l = window.BezierEasing,
        e = window.sg.common.lazyLoad,
        g = function(a) {
            this.el = a;
            this.init()
        };
    g.prototype.init = function() {
        this.scrollPos = document.body.scrollTop || document.documentElement.scrollTop;
        this.isAnim = !1;
        this.duration = 600;
        this.easing = l(.4, 0, .2, 1);
        this.bindEvent()
    };
    g.prototype.bindEvent = function() {
        this.handleScroll = this.handleScroll.bind(this);
        window.addEventListener("scroll", this.handleScroll);
        this.scrollToTop = this.scrollToTop.bind(this);
        this.el.addEventListener("click",
            this.scrollToTop)
    };
    g.prototype.handleScroll = function() {
        var a = document.body.scrollTop || document.documentElement.scrollTop;
        0 <= a && a !== this.scrollPos && (0 === a || a > this.scrollPos || this.isAnim ? this.el.classList.remove("show") : this.el.classList.add("show"), this.scrollPos = a)
    };
    g.prototype.scrollToTop = function() {
        var a = document.body.scrollTop || document.documentElement.scrollTop,
            d = function(b) {
                window.scrollTo(0, a - a * b);
                1 === b && e.setDisabled(!1)
            };
        this.isAnim || (e.setDisabled(), this.animate(d))
    };
    g.prototype.animate =
        function(a) {
            var b = this,
                e = Date.now();
            this.isAnim = !0;
            var c = function() {
                var d = (Date.now() - e) / b.duration;
                1 < d ? (a(1), b.isAnim = !1) : (requestAnimationFrame(c), a(b.easing(d)))
            };
            requestAnimationFrame(c)
        };
    g.instance = null;
    (0, a.ready)(function() {
        var a = document.querySelector(".fab");
        a && !g.instance && (g.instance = new g(a))
    })
})();
(function() {
    var a = window.sg.common.$q,
        l = function(a) {
            this.els = {
                el: a,
                inputEl: a.querySelector("input, textArea"),
                clearButtonEl: a.querySelector(".icon"),
                assistiveMsgEl: a.querySelector(".assistive-message"),
                errorMsgEl: a.querySelector(".error-message"),
                successMsgEl: a.querySelector(".success-message")
            };
            this.init()
        };
    l.prototype.init = function() {
        l.instances.has(this.els.el) || (l.instances.set(this.els.el, this), this.bindEvents())
    };
    l.prototype.setAssistiveMessage = function(a) {
        this.els.assistiveMsgEl.innerText =
            a
    };
    l.prototype.setErrorMessage = function(a) {
        this.els.errorMsgEl.innerText = a
    };
    l.prototype.setSuccessMessage = function(a) {
        this.els.errorMsgEl.innerText = a
    };
    l.prototype.setValue = function(a) {
        this.els.inputEl.value = a;
        this.els.inputEl !== document.activeElement && ("" !== a.replace(/^\s+$/, "") ? this.els.el.classList.add("text-field--active") : this.els.el.classList.remove("text-field--active"))
    };
    l.prototype.focusIn = function() {
        this.els.el.classList.add("text-field--focus")
    };
    l.prototype.focusOut = function(a) {
        this.els.el.classList.remove("text-field--focus");
        "" !== a.target.value.replace(/^\s+$/, "") ? this.els.el.classList.add("text-field--active") : this.els.el.classList.remove("text-field--active")
    };
    l.prototype.bindEvents = function() {
        var a = this;
        this.focusIn = this.focusIn.bind(this);
        this.focusOut = this.focusOut.bind(this);
        this.els.inputEl.addEventListener("focus", this.focusIn);
        this.els.inputEl.addEventListener("blur", this.focusOut);
        this.els.clearButtonEl && this.els.clearButtonEl.addEventListener("click", function() {
            a.els.inputEl.value = "";
            a.els.el.classList.remove("text-field--active")
        })
    };
    l.instances = new WeakMap;
    var e = {
        initAll: function() {
            [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".text-field"))).forEach(function(a) {
                l.instances.has(a) || new l(a)
            })
        },
        init: function(a) {
            return l.instances.has(a) ? l.instances.get(a) : new l(a)
        },
        setAssistiveMessage: function(a, b) {
            l.instances.has(a) && l.instances.get(a).setAssistiveMessage(b)
        },
        setErrorMessage: function(a, b) {
            l.instances.has(a) && l.instances.get(a).setErrorMessage(b)
        },
        setSuccessMessage: function(a, b) {
            l.instances.has(a) && l.instances.get(a).setSuccessMessage(b)
        },
        setValue: function(a, b) {
            l.instances.has(a) && l.instances.get(a).setValue(b)
        }
    };
    window.sg.common.textField = e;
    a.ready(function() {
        return e.initAll()
    })
})();
(function() {
    var a = window.sg.common.$q,
        l = function(a) {
            this.els = {
                el: a,
                inputEl: null,
                voiceInputBtnEl: null,
                deleteBtnEl: null,
                errorIconEl: null,
                openDownBtnEl: null,
                iconEls: [],
                assistiveMsgEl: null,
                errorMsgEl: null,
                successMsgEl: null
            };
            this.disabled = !1;
            this.init()
        };
    l.prototype.init = function() {
        l.instances.has(this.els.el) || (l.instances.set(this.els.el, this), this.setElement(), this.bindEvents())
    };
    l.prototype.reInit = function() {
        this.unBindEvents();
        this.setElement();
        this.bindEvents()
    };
    l.prototype.setElement = function() {
        this.els.inputEl =
            this.els.el.querySelector(".text-field-v2__input");
        this.els.iconEls.push(this.els.voiceInputBtnEl = this.els.el.querySelector(".text-field-v2__input-icon.voice-input"));
        this.els.iconEls.push(this.els.deleteBtnEl = this.els.el.querySelector(".text-field-v2__input-icon.delete"));
        this.els.iconEls.push(this.els.errorIconEl = this.els.el.querySelector(".text-field-v2__input-icon.error"));
        this.els.iconEls.push(this.els.openDownBtnEl = this.els.el.querySelector(".text-field-v2__input-icon.open-down"));
        this.els.assistiveMsgEl =
            this.els.el.querySelector(".text-field-v2__text.assistive");
        this.els.errorMsgEl = this.els.el.querySelector(".text-field-v2__text.error");
        this.els.successMsgEl = this.els.el.querySelector(".text-field-v2__text.success");
        this.disabled = this.els.el.classList.contains("disabled");
        this.checkActive()
    };
    l.prototype.handleFocus = function() {
        this.els.el.classList.add("active");
        this.els.el.classList.add("focus")
    };
    l.prototype.handleBlur = function() {
        this.els.el.classList.remove("focus");
        this.checkActive()
    };
    l.prototype.handleInput =
        function() {
            "" !== this.els.inputEl.value.replace(/^\s+$/, "") ? this.els.el.classList.add("delete") : (this.els.el.classList.remove("delete"), this.els.el.classList.remove("error"), this.els.el.classList.remove("success"))
        };
    l.prototype.handleDeleteBtnClick = function() {
        this.els.inputEl.value = "";
        this.els.el.classList.remove("delete");
        this.els.el.classList.remove("error");
        this.els.el.classList.remove("success")
    };
    l.prototype.checkActive = function() {
        "" !== this.els.inputEl.value.replace(/^\s+$/, "") ? this.els.el.classList.add("active") :
            this.els.el.classList.remove("active")
    };
    l.prototype.bindEvents = function() {
        this.handleFocus = this.handleFocus.bind(this);
        this.els.inputEl.addEventListener("focus", this.handleFocus);
        this.handleBlur = this.handleBlur.bind(this);
        this.els.inputEl.addEventListener("blur", this.handleBlur);
        this.handleInput = this.handleInput.bind(this);
        this.els.inputEl.addEventListener("input", this.handleInput);
        this.els.deleteBtnEl && (this.handleDeleteBtnClick = this.handleDeleteBtnClick.bind(this), this.els.deleteBtnEl.addEventListener("click",
            this.handleDeleteBtnClick))
    };
    l.prototype.unBindEvents = function() {
        this.els.inputEl.removeEventListener("focus", this.handleFocus);
        this.els.inputEl.removeEventListener("blur", this.handleBlur);
        this.els.inputEl.removeEventListener("input", this.handleInput);
        this.els.deleteBtnEl && this.els.deleteBtnEl.removeEventListener("click", this.handleDeleteBtnClick)
    };
    l.prototype.setDisabled = function(a) {
        (this.disabled = void 0 === a ? !0 : a) ? (this.els.el.classList.add("disabled"), [].concat($jscomp.arrayFromIterable(this.els.iconEls)).forEach(function(a) {
            a &&
                "BUTTON" === a.tagName.toUpperCase() && (a.disabled = !0)
        })) : (this.els.el.classList.remove("disabled"), [].concat($jscomp.arrayFromIterable(this.els.iconEls)).forEach(function(a) {
            a && "BUTTON" === a.tagName.toUpperCase() && (a.disabled = !1)
        }))
    };
    l.prototype.setState = function(a) {
        switch (a) {
            case "error":
                this.els.errorIconEl && this.els.el.classList.remove("delete");
                this.els.el.classList.remove("success");
                this.els.el.classList.add("error");
                break;
            case "success":
                this.els.el.classList.remove("delete");
                this.els.el.classList.remove("error");
                this.els.el.classList.add("success");
                break;
            default:
                this.els.el.classList.remove("success"), this.els.el.classList.remove("error")
        }
    };
    l.prototype.setMsg = function(a, b) {
        switch (a) {
            case "error":
                this.els.errorMsgEl && (this.els.errorMsgEl.innerText = b);
                break;
            case "success":
                this.els.successMsgEl && (this.els.successMsgEl.innerText = b);
                break;
            default:
                this.els.assistiveMsgEl && (this.els.assistiveMsgEl.innerText = b)
        }
    };
    l.instances = new WeakMap;
    var e = {
        initAll: function() {
            [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".text-field-v2"))).forEach(function(a) {
                l.instances.has(a) ||
                    new l(a)
            })
        },
        reInit: function(a) {
            l.instances.has(a) ? l.instances.get(a).reInit() : new l(a)
        },
        setDisabled: function(a, b) {
            b = void 0 === b ? !0 : b;
            l.instances.has(a) && l.instances.get(a).setDisabled(b)
        },
        setState: function(a, b) {
            l.instances.has(a) && l.instances.get(a).setState(b)
        },
        setMsg: function(a, b, d) {
            l.instances.has(a) && l.instances.get(a).setMsg(b, d)
        }
    };
    window.sg.common.textFieldv2 = e;
    a.ready(e.initAll)
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.utils.getCurrentDevice,
        e = window.sg.common.utils.extend,
        g = window.sg.common.utils.closest,
        b = window.sg.common.utils.addEventListener,
        d = window.sg.common.utils.removeAllEventListeners,
        n = window.sg.common.utils.triggerEvent,
        c = window.sg.common.utils.isRtl,
        h = function(a) {
            this.els = {
                el: a,
                wrap: null,
                controlEl: null,
                controlHiddenEl: null,
                indicatorListWrapEl: null,
                indicatorListEl: null,
                indicatorEls: [],
                indicatorDotEls: [],
                indicatorLineEls: [],
                indicatorPageEls: [],
                videoWrapEls: [],
                videoEls: []
            };
            this.defaultOption = {
                type: "label-indicator",
                play: !1,
                control: !1,
                autoRolling: !1,
                infiniteRolling: !1,
                indicators: []
            };
            this.dotSizeSmall = .5;
            this.dotSizeMedium = .75;
            this.dotSizeLarge = 1;
            this.transitionDuration = 400;
            this.transitionTimer = null;
            this.init()
        };
    h.prototype.init = function() {
        this.initValues();
        this.setElements();
        this.bindEvents();
        this.option.control || this.option.play || this.select(0);
        h.instances.has(this.els.el) || h.instances.set(this.els.el, this)
    };
    h.prototype.reInit = function() {
        this.select(-1);
        this.unBindEvents();
        this.initValues();
        this.setElements();
        this.bindEvents();
        clearTimeout(this.transitionTimer);
        this.option.control || this.option.play || this.select(0)
    };
    h.prototype.initValues = function() {
        this.option = {};
        this.playing = !1;
        this.selectedIndex = -1;
        this.elapseTime = 0;
        this.device = l();
        this.type = "";
        this.firstIndex = this.translateX = 0;
        this.lastIndex = 6;
        this.maxDotNum = 7;
        this.inTransition = !1;
        this.control = "stop";
        this.animReqId && (cancelAnimationFrame(this.animReqId), this.animReqId = null);
        this.videosLoaded = [];
        this.isRtl = c()
    };
    h.prototype.setElements = function() {
        var a = this,
            b = g(this.els.el, ".indicator-container");
        b ? (this.els.wrap = b, [].concat($jscomp.arrayFromIterable(this.els.wrap.querySelectorAll(".indicator-page"))).forEach(function(b) {
            b.classList.contains("swiper-slide-duplicate") || a.els.indicatorPageEls.push(b)
        })) : this.els.wrap = null;
        this.els.controlEl = this.els.el.querySelector(".indicator__controls");
        this.els.controlHiddenEl = this.els.el.querySelector(".indicator__controls \x3e .hidden");
        this.els.indicatorEls =
            this.els.el.querySelectorAll(".indicator__item");
        this.els.indicatorListWrapEl = this.els.el.querySelector(".indicator__list-wrap");
        this.els.indicatorListEl = this.els.el.querySelector(".indicator__list");
        this.els.indicatorDotEls = this.els.el.querySelectorAll(".indicator__dot-inner");
        this.els.indicatorLineEls = this.els.el.querySelectorAll(".indicator__label-line-filled");
        var c = JSON.parse(JSON.stringify(this.defaultOption));
        [].concat($jscomp.arrayFromIterable(this.els.indicatorEls)).forEach(function(a) {
            a.setAttribute("aria-selected",
                "false");
            c.indicators.push(parseInt(a.dataset.indicatorDelay))
        });
        b = JSON.parse(this.els.el.dataset.indicatorData);
        this.option = e(c, b);
        this.els.controlEl && (this.option.control = !0);
        this.option.autoRolling && (this.option.play = !1);
        this.setType();
        this.setDots()
    };
    h.prototype.setType = function() {
        if ("desktop" === l()) switch (this.option.type) {
            case "dot-indicator":
                this.els.el.classList.remove("label-indicator");
                this.els.el.classList.add("dot-indicator");
                this.type = "dot-indicator";
                break;
            case "dot-indicator-mobile-only":
                this.els.el.classList.remove("label-indicator");
                this.els.el.classList.add("dot-indicator");
                this.els.el.classList.add("dot-indicator-mobile-only");
                this.type = "dot-indicator";
                break;
            default:
                this.els.el.classList.remove("dot-indicator"), this.els.el.classList.remove("dot-indicator-mobile-only"), this.els.el.classList.add("label-indicator"), this.type = "label-indicator"
        } else "dot-indicator-mobile-only" === this.option.type && this.els.el.classList.add("dot-indicator-mobile-only"), this.els.el.classList.remove("label-indicator"), this.els.el.classList.add("dot-indicator"),
            this.type = "dot-indicator";
        "dot-indicator" === this.type && this.option.indicators.length > this.maxDotNum && this.els.indicatorListWrapEl.classList.add("dot-more")
    };
    h.prototype.bindEvents = function() {
        var a = this;
        [].concat($jscomp.arrayFromIterable(this.els.indicatorEls)).forEach(function(c, d) {
            b(c, "click", function() {
                return a.select(d)
            });
            b(c, "mouseenter", function() {
                return a.handleMouseEnter(d)
            });
            b(c, "mouseleave", function() {
                return a.handleMouseLeave(d)
            });
            b(c, "focusin", function() {
                return a.handleMouseEnter(d)
            });
            b(c, "focusout", function() {
                return a.handleMouseLeave(d)
            })
        });
        this.option.control && b(this.els.controlEl, "click", function() {
            a.handleControl()
        });
        this.resize = this.resize.bind(this);
        window.addEventListener("resize", this.resize)
    };
    h.prototype.unBindEvents = function() {
        [].concat($jscomp.arrayFromIterable(this.els.indicatorEls)).forEach(function(a) {
            d(a, "click");
            d(a, "mouseenter");
            d(a, "mouseleave");
            d(a, "focusin");
            d(a, "focusout")
        });
        this.option.control && d(this.els.controlEl, "click");
        window.removeEventListener("resize",
            this.resize)
    };
    h.prototype.resize = function() {
        var a = l();
        this.device !== a && (this.device = a, this.setType(), "label-indicator" === this.type && (this.els.indicatorListEl.style.transform = "", [].concat($jscomp.arrayFromIterable(this.els.indicatorEls)).forEach(function(a) {
            a.removeAttribute("tabindex");
            a.removeAttribute("aria-hidden");
            a.style.visibility = ""
        })), this.select(this.selectedIndex, !0));
        this.setDots()
    };
    h.prototype.handleMouseEnter = function(a) {
        a = this.els.indicatorEls[a];
        a.classList.add("indicator__item--hover");
        a.classList.remove("indicator__item--not-hover")
    };
    h.prototype.handleMouseLeave = function(a) {
        a = this.els.indicatorEls[a];
        var b = a.matches ? a.matches(":hover") : a.msMatchesSelector(":hover"),
            c = a.matches ? a.matches(":focus") : a.msMatchesSelector(":focus");
        b || c || (a.classList.remove("indicator__item--hover"), a.classList.add("indicator__item--not-hover"))
    };
    h.prototype.handleControl = function(a) {
        a = void 0 === a ? null : a;
        var b = "";
        if (a ? !this.playing && "play" === a : !this.playing) this.control = "play", -1 < this.selectedIndex ? this.play() :
            this.select(0), b = "stop";
        else if (a ? this.playing && "pause" === a : this.playing) this.control = "stop", this.pause(), b = "play";
        if ("" !== b && this.option.control) {
            var c = this.els.controlEl.getAttribute("an-la");
            c && (c = "" + c.substring(0, c.length - 4) + b, this.els.controlEl.setAttribute("an-la", c));
            a || n(this.els.el, "controlChange", {
                index: this.selectedIndex,
                playing: this.playing
            })
        }
    };
    h.prototype.select = function(a, b, c) {
        var d = this;
        c = void 0 === c ? !1 : c;
        var e = this.selectedIndex;
        if (e !== a || (void 0 === b ? 0 : b))
            if (this.animReqId && (cancelAnimationFrame(this.animReqId),
                    this.animReqId = null), -1 < e && (this.els.indicatorEls[e].classList.contains("indicator__item--active") && this.els.indicatorEls[e].classList.remove("indicator__item--active"), this.els.indicatorEls[e].setAttribute("aria-selected", "false"), "label-indicator" === this.type && this.els.indicatorLineEls[e] && (this.els.indicatorLineEls[e].style.transform = "")), 0 > a) this.option.control && this.pause(), this.selectedIndex = a;
            else {
                this.selectedIndex = a;
                this.els.indicatorEls[this.selectedIndex].classList.contains("indicator__item--active") ||
                    this.els.indicatorEls[this.selectedIndex].classList.add("indicator__item--active");
                this.els.indicatorEls[this.selectedIndex].setAttribute("aria-selected", "true");
                c && n(this.els.el, "indicatorReiterate");
                n(this.els.el, "indicatorMove", this.selectedIndex);
                this.inTransition = !0;
                var h = function(b) {
                        b = void 0 === b ? d.transitionDuration : b;
                        d.transitionTimer = setTimeout(function() {
                            d.elapseTime = 0;
                            d.inTransition = !1;
                            d.selectedIndex === a && ("play" === d.control || !d.option.autoRolling && d.option.play) && d.play()
                        }, 0 < b ? b : 0)
                    },
                    g =
                    0,
                    m = function(a) {
                        var b = d.els.videoEls[d.selectedIndex] ? d.els.videoEls[d.selectedIndex] : d.els.videoEls[d.selectedIndex] = a.querySelector(".indicator-background video");
                        if (b)
                            if (4 > b.readyState && !d.videosLoaded[d.selectedIndex]) {
                                var c = Date.now(),
                                    e = function() {
                                        b.removeEventListener("canplaythrough", e);
                                        b.currentTime = 0;
                                        d.option.indicators[d.selectedIndex] === parseInt(d.els.indicatorEls[d.selectedIndex].dataset.indicatorDelay) && (d.option.indicators[d.selectedIndex] = 1E3 * b.duration);
                                        d.videosLoaded[d.selectedIndex] = !0;
                                        h(d.transitionDuration - (Date.now() - c + 200 * g))
                                    };
                                b.addEventListener("canplaythrough", e)
                            } else b.currentTime = 0, d.option.indicators[d.selectedIndex] === parseInt(d.els.indicatorEls[d.selectedIndex].dataset.indicatorDelay) && (d.option.indicators[d.selectedIndex] = 1E3 * b.duration), d.videosLoaded[d.selectedIndex] = !0, h();
                        else 5 > g && setTimeout(function() {
                            m(a);
                            g++
                        }, 200)
                    };
                this.els.indicatorPageEls[this.selectedIndex] ? (b = this.els.videoWrapEls[this.selectedIndex] ? this.els.videoWrapEls[this.selectedIndex] : this.els.videoWrapEls[this.selectedIndex] =
                    this.els.indicatorPageEls[this.selectedIndex].querySelector(".indicator-background .video")) ? "TRUE" === b.dataset.videoEmbed.toUpperCase() && "FALSE" === b.dataset.imageDefault.toUpperCase() ? m(b) : h() : h() : h(); - 1 < e && this.els.videoEls[e] && this.els.videoEls[e].pause();
                this.setDots()
            }
    };
    h.prototype.setDots = function() {
        if ("dot-indicator" === this.type && this.option.indicators.length > this.maxDotNum) {
            var a = this.els.indicatorEls[0].getBoundingClientRect().width + parseFloat(this.isRtl ? getComputedStyle(this.els.indicatorEls[0]).marginLeft :
                    getComputedStyle(this.els.indicatorEls[0]).marginRight),
                b = 0 > this.selectedIndex ? 0 : this.selectedIndex;
            b > this.lastIndex ? (this.firstIndex = b - 6, this.lastIndex = b) : b < this.firstIndex && (this.firstIndex = b, this.lastIndex = b + 6);
            if (b > this.lastIndex - 2) {
                var c = 2 - (this.lastIndex - b),
                    d = this.option.indicators.length - this.lastIndex - 1;
                this.firstIndex += d >= c ? c : d;
                this.lastIndex += d >= c ? c : d
            } else b < this.firstIndex + 2 && (c = 2 - (b - this.firstIndex), d = this.firstIndex, this.firstIndex -= d >= c ? c : d, this.lastIndex -= d >= c ? c : d);
            this.els.indicatorListEl.style.transform =
                "translate3d(" + (this.isRtl ? this.firstIndex * a : -(this.firstIndex * a)) + "px,0,0)";
            for (a = 0; a < this.els.indicatorEls.length; a++) a < this.firstIndex || a > this.lastIndex ? (this.els.indicatorDotEls[a].style.transform = "scale(" + this.dotSizeSmall + ")", this.els.indicatorEls[a].setAttribute("tabindex", -1), this.els.indicatorEls[a].setAttribute("aria-hidden", !0), this.els.indicatorEls[a].style.visibility = "hidden") : a >= this.firstIndex && a <= this.lastIndex && (this.els.indicatorEls[a].removeAttribute("tabindex"), this.els.indicatorEls[a].setAttribute("aria-hidden", !1), this.els.indicatorEls[a].style.visibility = "");
            this.els.indicatorDotEls[b].style.transform = "scale(" + this.dotSizeLarge + ")";
            if (b > this.lastIndex - 3) {
                for (a = this.firstIndex + 2; a < b; a++) this.els.indicatorDotEls[a].style.transform = "scale(" + this.dotSizeLarge + ")";
                1 < this.firstIndex ? (this.els.indicatorDotEls[this.firstIndex].style.transform = "scale(" + this.dotSizeSmall + ")", this.els.indicatorDotEls[this.firstIndex + 1].style.transform = "scale(" + this.dotSizeMedium + ")") : 0 < this.firstIndex && (this.els.indicatorDotEls[this.firstIndex].style.transform =
                    "scale(" + this.dotSizeMedium + ")");
                this.els.indicatorDotEls[b + 1] && (a = parseFloat(this.els.indicatorDotEls[b + 1].style.transform.replace(/[^\d.]/g, "")), this.dotSizeMedium >= a && (this.els.indicatorDotEls[b + 1].style.transform = "scale(" + this.dotSizeMedium + ")"));
                this.els.indicatorDotEls[b + 2] && (a = parseFloat(this.els.indicatorDotEls[b + 2].style.transform.replace(/[^\d.]/g, "")), this.dotSizeSmall >= a && (this.els.indicatorDotEls[b + 2].style.transform = "scale(" + this.dotSizeSmall + ")"))
            }
            if (b < this.firstIndex + 3) {
                for (a = b + 1; a <
                    this.lastIndex - 1; a++) this.els.indicatorDotEls[a].style.transform = "scale(" + this.dotSizeLarge + ")";
                this.lastIndex < this.option.indicators.length - 2 ? (this.els.indicatorDotEls[this.lastIndex].style.transform = "scale(" + this.dotSizeSmall + ")", this.els.indicatorDotEls[this.lastIndex - 1].style.transform = "scale(" + this.dotSizeMedium + ")") : this.lastIndex < this.option.indicators.length - 1 && (this.els.indicatorDotEls[this.lastIndex].style.transform = "scale(" + this.dotSizeMedium + ")");
                this.els.indicatorDotEls[b - 1] && (a = parseFloat(this.els.indicatorDotEls[b -
                    1].style.transform.replace(/[^\d.]/g, "")), this.dotSizeMedium >= a && (this.els.indicatorDotEls[b - 1].style.transform = "scale(" + this.dotSizeMedium + ")"));
                this.els.indicatorDotEls[b - 2] && (a = parseFloat(this.els.indicatorDotEls[b - 2].style.transform.replace(/[^\d.]/g, "")), this.dotSizeSmall >= a && (this.els.indicatorDotEls[b - 2].style.transform = "scale(" + this.dotSizeSmall + ")"))
            }
        }
    };
    h.prototype.setIndicatorDelay = function(a, b) {
        this.option.indicators[a] = b
    };
    h.prototype.play = function() {
        var a = this;
        this.inTransition || (this.option.control &&
            (this.els.controlEl.classList.remove("indicator__controls--play"), this.els.controlHiddenEl.innerHTML = "stop"), this.playing = !0, this.els.videoEls[this.selectedIndex] && !this.els.videoEls[this.selectedIndex].ended && this.els.videoEls[this.selectedIndex].play(), this.delay = this.option.indicators[this.selectedIndex] - this.elapseTime, 0 < this.delay && (this.start = Date.now(), this.animReqId = requestAnimationFrame(function() {
                return a.updateProgress(a.selectedIndex)
            })))
    };
    h.prototype.pause = function() {
        this.option.control &&
            (this.els.controlEl.classList.add("indicator__controls--play"), this.els.controlHiddenEl.innerHTML = "play");
        this.playing = !1;
        this.els.videoEls[this.selectedIndex] && this.els.videoEls[this.selectedIndex].pause();
        this.animReqId && (this.elapseTime += Date.now() - this.start, cancelAnimationFrame(this.animReqId), this.animReqId = null)
    };
    h.prototype.updateProgress = function(a) {
        var b = this;
        if (this.selectedIndex === a) {
            var c = Date.now() - this.start;
            c >= this.delay ? this.option.autoRolling && (a === this.option.indicators.length -
                1 ? this.option.infiniteRolling ? this.select(0, !1, !0) : this.select(-1) : this.select(a + 1)) : ("label-indicator" === this.type && (c = (this.elapseTime + c) / this.option.indicators[a], 1 < c && (c = 100), this.els.indicatorLineEls[a].style.transform = "scaleX(" + c + ")"), this.animReqId = requestAnimationFrame(function() {
                return b.updateProgress(a)
            }))
        }
    };
    h.instances = new WeakMap;
    var q = {
        initAll: function() {
            [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".indicator"))).forEach(function(a) {
                h.instances.has(a) || new h(a)
            })
        },
        init: function(a) {
            return h.instances.has(a) ? h.instances.get(a) : new h(a)
        },
        reInit: function(a) {
            h.instances.has(a) && h.instances.get(a).reInit()
        },
        move: function(a, b) {
            h.instances.has(a) && h.instances.get(a).select(b)
        },
        play: function(a) {
            h.instances.has(a) && h.instances.get(a).handleControl("play")
        },
        pause: function(a) {
            h.instances.has(a) && h.instances.get(a).handleControl("pause")
        },
        setIndicatorDelay: function(a, b, c) {
            h.instances.has(a) && h.instances.get(a).setIndicatorDelay(b, c)
        }
    };
    window.sg.common.indicator = q;
    a.ready(q.initAll)
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.constants.KEY_CODE,
        e = window.sg.common.scrollbar,
        g = window.sg.common.utils.getCurrentDevice,
        b = window.sg.common.utils.detectTransitionEndEvent,
        d = window.sg.common.utils.closest,
        n = window.sg.common.icon,
        c = function(b, c) {
            var e = this;
            c = void 0 === c ? -1 : c;
            this.els = {
                el: a(b),
                selectEl: null,
                fieldEl: null,
                fieldTextEl: null,
                listWrapEl: null,
                listEl: null,
                scrollWrapEl: null,
                itemWrapEls: null,
                itemEls: null,
                docEl: a(document),
                winEl: a(window)
            };
            this.handler = {
                docEl: {
                    click: function(a) {
                        e.isDisabled ||
                            (a.preventDefault(), d(a.target, ".menu") !== e.els.el.target[0] && e.close())
                    }
                },
                el: {
                    keydown: function(a) {
                        if (!e.isDisabled) switch (a.keyCode) {
                            case l.TAB:
                                e.isOpen && e.close();
                                break;
                            case l.ENTER:
                            case l.SPACE:
                                -1 === e.index && (e.index = 0, e.selectItem(e.index));
                                break;
                            case l.PAGE_UP:
                            case l.HOME:
                                e.index = 0;
                                e.selectItem(e.index, a);
                                break;
                            case l.PAGE_DOWN:
                            case l.END:
                                e.index = e.els.itemEls.target.length - 1;
                                e.selectItem(e.index, a);
                                break;
                            case l.LEFT:
                            case l.UP:
                                -1 !== e.index && e.selectNext(-1, a);
                                break;
                            case l.RIGHT:
                            case l.DOWN:
                                -1 !==
                                    e.index ? e.selectNext(1, a) : e.selectItem(0, a);
                                break;
                            default:
                                e.selectItem(e.getSelectedItemIndex(a.keyCode), a)
                        }
                    }
                },
                fieldEl: {
                    click: function(a) {
                        a.preventDefault();
                        e.isDisabled || (e.isOpen ? e.close() : e.open())
                    }
                },
                selectEl: {
                    change: function(a) {
                        var b = e.els.selectEl.find("option"),
                            c = a.target.dataset.useLink,
                            d = a.target.selectedOptions[0],
                            h = d.text,
                            g = d.value,
                            m = c ? d.dataset.openAction : "";
                        b.target.forEach(function(a) {
                            a.removeAttribute("selected")
                        });
                        e.index = a.target.selectedIndex; - 1 < e.index && d.setAttribute("selected",
                            "true");
                        e.els.fieldTextEl.text(h);
                        e.select();
                        c && ("current-window" === m ? window.location.href = g : "new-window" === m && window.open(g, "_blank"))
                    },
                    click: function() {
                        "mobile" === g() && (e.isOpen ? e.close() : e.open())
                    },
                    keyup: function(a) {
                        e.isDisabled || "mobile" === g() && e.isOpen && a.keyCode === l.ESC && e.close()
                    }
                },
                itemWrapEls: {
                    click: function(b) {
                        b.preventDefault();
                        b = a(b.target);
                        b.hasClass("disabled") || (b = b.closest("li").index(), e.change(b), e.close())
                    }
                },
                winEl: {
                    resize: this.resize.bind(this)
                }
            };
            this.init();
            this.selectItem(c)
        };
    c.prototype.init = function() {
        c.instances.has(this.els.el.target[0]) || (c.instances.set(this.els.el.target[0], this), this.initValues(), this.setElements(), this.bindEvents(), this.update())
    };
    c.prototype.reInit = function(a) {
        this.els.listWrapEl.remove();
        this.initValues();
        this.setElements();
        this.bindEvents();
        this.update();
        this.selectItem(a)
    };
    c.prototype.initValues = function() {
        this.options = {};
        this.index = -1;
        this.isDisabled = this.isOpen = !1;
        this.itemMappedIndices = [];
        this.itemMappedIndicesExclDisabled = [];
        this.maxHeight =
            0;
        this.maxItemNum = 11;
        this.device = g();
        this.openDir = ""
    };
    c.prototype.setElements = function() {
        var a = this;
        this.els.selectEl = this.els.el.find(".menu__select");
        var b = this.els.selectEl.target[0],
            c = this.els.selectEl.find("option[selected]");
        c.target[0] && (b.selectedIndex = c.index());
        c = b.dataset.defaultMessage;
        !c && b.options[b.selectedIndex] ? c = b.options[b.selectedIndex].text : b.selectedIndex = -1;
        this.index = b.selectedIndex;
        this.options = [].concat($jscomp.arrayFromIterable(b.options)); - 1 === this.index && this.options.forEach(function(a) {
            a.removeAttribute("selected")
        });
        this.els.fieldEl = this.els.el.find(".menu__select-field");
        this.els.fieldTextEl = this.els.fieldEl.find("span");
        this.els.fieldTextEl.text(c);
        this.els.el.append('\x3cdiv class\x3d"menu__list-wrap scrollbar"\x3e\x3c/div\x3e');
        this.els.listWrapEl = this.els.el.find(".menu__list-wrap");
        this.els.listWrapEl.append('\x3cul class\x3d"menu__list scrollbar__contents" role\x3d"listbox"\x3e');
        this.els.listEl = this.els.listWrapEl.find(".menu__list");
        this.options.forEach(function(c) {
            var d = "",
                e = "";
            ["an-tr", "an-ca", "an-ac",
                "an-la"
            ].forEach(function(a) {
                c.hasAttribute(a) && (d += " " + a + '\x3d"' + c.getAttribute(a).replace('"', "") + '" ')
            });
            b.dataset.useLink && c.title && "" !== c.title && (e = ' title\x3d"' + c.title + '"');
            a.els.listEl.append('\x3cli class\x3d"menu__list-option-wrap" role\x3d"presentation"' + d + '\x3e\x3cbutton class\x3d"menu__list-option" role\x3d"option"' + e + '\x3e\x3cspan class\x3d"menu__list-option-text"\x3e' + c.text + '\x3c/span\x3e\x3csvg class\x3d"menu__list-option-icon" focusable\x3d"false"\x3e\x3cuse xlink:href\x3d"#done-bold" href\x3d"#done-bold"\x3e\x3c/use\x3e\x3c/svg\x3e\x3c/button\x3e\x3c/li\x3e')
        });
        this.els.itemWrapEls = this.els.listEl.find(".menu__list-option-wrap");
        this.els.itemEls = this.els.listEl.find(".menu__list-option");
        e.init(this.els.listWrapEl.target[0]);
        this.els.scrollWrapEl = this.els.listWrapEl.find(".scrollbar__wrap");
        this.els.scrollWrapEl.css({
            "max-height": 0
        });
        this.els.listWrapEl.css({
            visibility: "hidden"
        });
        n.update(this.els.el.target[0]);
        this.select()
    };
    c.prototype.select = function() {
        if ("desktop" === g()) {
            if (this.isOpen) {
                var a = this.els.el.hasClass("filled"),
                    b = this.els.el.offset();
                a = a ?
                    "0" : b.height + "px";
                "up" === this.openDir ? this.els.listWrapEl.css({
                    bottom: a,
                    top: "auto"
                }) : "down" === this.openDir && this.els.listWrapEl.css({
                    bottom: "auto",
                    top: a
                })
            }
            this.els.el.removeClass("selected");
            this.els.itemEls.removeAttr("aria-selected");
            this.els.itemWrapEls.removeClass("active"); - 1 < this.index && (this.els.el.addClass("selected"), this.els.itemWrapEls.eq(this.index).addClass("active"), this.els.itemEls.eq(this.index).attr("aria-selected", !0))
        }
    };
    c.prototype.bindEvents = function() {
        var a = this;
        this.els.fieldEl.off("click").on("click",
            this.handler.fieldEl.click);
        this.els.itemWrapEls.off("click").on("click", this.handler.itemWrapEls.click);
        this.els.selectEl.off("change").on("change", this.handler.selectEl.change);
        this.els.selectEl.off("click").on("click", this.handler.selectEl.click);
        this.els.selectEl.off("keyup").on("keyup", this.handler.selectEl.keyup);
        this.els.selectEl.off("focus").on("focus", function() {
            a.els.el.addClass("focus")
        });
        this.els.selectEl.off("blur").on("blur", function() {
            a.els.el.removeClass("focus")
        });
        this.els.el.off("keydown").on("keydown",
            this.handler.el.keydown);
        this.els.winEl.off("resize", this.handler.winEl.resize).on("resize", this.handler.winEl.resize)
    };
    c.prototype.update = function() {
        var a = this;
        this.isOpen && this.close(!1);
        (this.isDisabled = this.els.el.hasClass("disabled")) ? (this.els.selectEl.attr("disabled", !0), this.els.fieldEl.attr("disabled", !0)) : (this.els.selectEl.removeAttr("disabled"), this.els.fieldEl.removeAttr("disabled"));
        this.els.itemWrapEls.removeClass("disabled");
        "desktop" === this.device ? (this.els.selectEl.attr("tabindex",
            "-1"), this.els.selectEl.attr("aria-hidden", !0), this.els.fieldEl.removeAttr("tabindex"), this.els.fieldEl.removeAttr("aria-hidden")) : (this.els.selectEl.removeAttr("tabindex"), this.els.selectEl.removeAttr("aria-hidden"), this.els.fieldEl.attr("tabindex", "-1"), this.els.fieldEl.attr("aria-hidden", !0), this.els.fieldEl.removeAttr("aria-expanded"));
        this.itemMappedIndices = [];
        this.itemMappedIndicesExclDisabled = [];
        var b = 0;
        this.options.forEach(function(c, d) {
            var e = a.els.itemWrapEls.eq(d);
            c.disabled ? ("desktop" ===
                g() && e.addClass("disabled"), a.itemMappedIndices[d] = -1) : (a.itemMappedIndices[d] = b++, a.itemMappedIndicesExclDisabled.push(d))
        })
    };
    c.prototype.open = function(a) {
        var c = this;
        a = void 0 === a ? !0 : a;
        var d = function() {
            c.els.docEl.on("click", c.handler.docEl.click);
            "desktop" === g() && (c.els.itemEls.eq(c.els.selectEl.target[0].selectedIndex).focus(), e.resize(c.els.listWrapEl.target[0]))
        };
        requestAnimationFrame(function() {
            c.els.el.addClass("open");
            c.isOpen = !0;
            if ("desktop" === g()) {
                c.els.scrollWrapEl.css({
                    "max-height": ""
                });
                var e = c.els.itemWrapEls.target.length;
                c.maxHeight = 0;
                if (e > c.maxItemNum) {
                    for (var h = 0; h < c.maxItemNum; h++) {
                        var p = c.els.itemWrapEls.eq(h);
                        c.maxHeight += p.offset().height
                    }
                    c.maxHeight += parseFloat(getComputedStyle(c.els.itemWrapEls.target[0]).marginTop) + parseFloat(getComputedStyle(c.els.itemWrapEls.target[e - 1]).marginBottom)
                } else c.maxHeight = c.els.scrollWrapEl.offset().height;
                c.els.scrollWrapEl.css({
                    "max-height": "0"
                });
                var m = c.els.el.hasClass("filled");
                e = c.els.el.offset();
                h = e.top;
                p = m ? c.maxHeight - e.height : c.maxHeight;
                m = m ? "0" : e.height + "px";
                p > window.innerHeight - e.bottom && p < h ? (c.openDir = "up", c.els.listWrapEl.css({
                    bottom: m,
                    top: "auto"
                })) : (c.openDir = "down", c.els.listWrapEl.css({
                    bottom: "auto",
                    top: m
                }));
                if (a) {
                    c.els.scrollWrapEl.css({
                        transition: "max-height .2s cubic-bezier(.4,0,.2,1)"
                    });
                    var n = b(c.els.scrollWrapEl.target[0]);
                    if (n) {
                        var l = function() {
                            d();
                            c.els.scrollWrapEl.off(n, l)
                        };
                        c.els.scrollWrapEl.on(n, l)
                    } else setTimeout(d, 200)
                } else c.els.scrollWrapEl.css({
                    transition: ""
                }), d();
                requestAnimationFrame(function() {
                    c.els.fieldEl.attr("aria-expanded", !0);
                    c.els.listWrapEl.css({
                        visibility: "visible"
                    });
                    c.els.scrollWrapEl.css({
                        "max-height": c.maxHeight + "px"
                    })
                })
            } else d()
        })
    };
    c.prototype.close = function(a) {
        var c = this;
        a = void 0 === a ? !0 : a;
        var d = function() {
            c.els.listWrapEl.css({
                visibility: "hidden"
            })
        };
        requestAnimationFrame(function() {
            c.els.docEl.off("click", c.handler.docEl.click);
            c.els.el.removeClass("open");
            c.isOpen = !1;
            if ("desktop" === g()) {
                if (a) {
                    c.els.scrollWrapEl.css({
                        transition: "max-height .2s cubic-bezier(.4,0,.2,1)"
                    });
                    var e = b(c.els.scrollWrapEl.target[0]);
                    if (e) {
                        var h = function() {
                            d();
                            c.els.scrollWrapEl.off(e, h)
                        };
                        c.els.scrollWrapEl.on(e, h)
                    } else setTimeout(d, 200)
                } else c.els.scrollWrapEl.css({
                    transition: ""
                }), d();
                requestAnimationFrame(function() {
                    c.els.fieldEl.attr("aria-expanded", !1);
                    c.els.scrollWrapEl.css({
                        "max-height": "0"
                    });
                    c.els.fieldEl.focus()
                })
            } else d()
        })
    };
    c.prototype.resize = function() {
        var a = g();
        this.device !== a && (this.device = a, this.update(), "desktop" === this.device && this.selectItem(this.index));
        "desktop" === this.device && this.isOpen && this.close(!1)
    };
    c.prototype.change =
        function(a) {
            var b = this.els.selectEl.target[0];
            b.selectedIndex !== a && (this.index = b.selectedIndex = a, this.els.selectEl.trigger("change"))
        };
    c.prototype.keydown = function(a) {
        this.els.fieldEl.trigger("click");
        a.preventDefault()
    };
    c.prototype.selectNext = function(a, b) {
        var c = this.itemMappedIndices[this.index];
        c += a;
        a = 0 > c ? this.itemMappedIndicesExclDisabled[0] : c > this.itemMappedIndicesExclDisabled.length - 1 ? this.itemMappedIndicesExclDisabled[this.itemMappedIndicesExclDisabled.length - 1] : this.itemMappedIndicesExclDisabled[c]; -
        1 !== a && ("desktop" === g() && this.els.itemEls.target[a].focus(), this.change(a));
        b && b.preventDefault()
    };
    c.prototype.selectItem = function(a, b) {
        if (!(0 > a)) {
            var c = -1;
            0 === a ? c = this.itemMappedIndicesExclDisabled[0] : a === this.itemMappedIndices.length - 1 ? c = this.itemMappedIndicesExclDisabled[this.itemMappedIndicesExclDisabled.length - 1] : -1 !== this.itemMappedIndices[a] && (c = a); - 1 !== c && ("desktop" === g() && this.els.itemEls.target[c].focus(), this.change(c));
            b && b.preventDefault()
        }
    };
    c.prototype.getSelectedItemIndex = function(b) {
        var c =
            this,
            d = /[A-Z]/,
            e = b - 48 * Math.floor(b / 48),
            h = String.fromCharCode(96 <= b ? e : b),
            g = !0,
            n = -1;
        b = this.index;
        this.els.itemEls.target.forEach(function(b, e) {
            var p = b.textContent.substring(0, 1).toUpperCase();
            b = a(b).closest(".menu__list-option-wrap").hasClass("disabled");
            d.test(p) && p === h && !b && -1 === n && (n = e);
            d.test(p) && p === h && c.index < e && g && !b && (c.index = e, g = !1)
        });
        b === this.index && -1 !== n && (this.index = n);
        return this.index
    };
    c.instances = new WeakMap;
    var h = {
        initAll: function() {
            a(".menu").target.forEach(function(a) {
                c.instances.has(a) ||
                    new c(a)
            })
        },
        init: function(a) {
            c.instances.has(a) || new c(a)
        },
        reInit: function(a, b) {
            b = void 0 === b ? -1 : b;
            c.instances.has(a) ? c.instances.get(a).reInit(b) : new c(a, b)
        }
    };
    window.sg.common.menu = h;
    a.ready(h.initAll)
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.constants.BREAKPOINTS,
        e = window.sg.common.utils,
        g = window.sg.common.icon,
        b = function(d) {
            var c = this;
            this.selector = {
                swiperSlide: ".option-selector__swiper-slide",
                swiperWrap: ".option-selector__swiper",
                swiperPrev: ".option-selector__button-prev",
                swiperNext: ".option-selector__button-next",
                btnDisabledCls: "option-selector__button--disabled",
                capaContainer: ".option-selector__swiper-container",
                capaItemInner: ".option-selector__size",
                capaItemRadio: ".option-selector__size input",
                flotingBox: ".option-selector__floating-bar",
                moveWapper: ".option-selector__swiper-wrapper",
                optionRadio: 'input[type\x3d"radio"]'
            };
            this.el = {
                window: a(window),
                component: a(d)
            };
            this.handler = {
                timeHandler: function() {
                    c.el.moveWapper.css({
                        transition: "none"
                    });
                    c.resize();
                    c.resizeTimer && clearTimeout(c.resizeTimer);
                    c.resizeTimer = setTimeout(function() {
                        c.el.moveWapper.css({
                            transition: ""
                        })
                    }, 400)
                },
                changeCapacity: this.changeCapacity.bind(this),
                setHalfSlide: this.setHalfSlide.bind(this)
            };
            this.moveLength = null;
            b.instances.set(d,
                this);
            this.setElements();
            this.init()
        };
    b.prototype.setElements = function() {
        var b = this;
        this.el.swiperPrev = this.el.component.find(this.selector.swiperPrev);
        this.el.swiperNext = this.el.component.find(this.selector.swiperNext);
        this.el.swiperSlide = this.el.component.find(this.selector.swiperSlide);
        this.el.moveWapper = this.el.component.find(this.selector.moveWapper);
        this.el.capaContainer = this.el.component.find(this.selector.capaContainer);
        this.el.capaItemInner = this.el.component.find(this.selector.capaItemInner);
        this.el.capaItemRadio = this.el.component.find(this.selector.capaItemRadio);
        this.el.capaItemRadioActive = this.el.component.find(this.selector.capaItemRadio + ":checked").closest(this.selector.swiperSlide);
        this.el.flotingBox = this.el.component.find(this.selector.flotingBox);
        this.el.optionRadio = this.el.component.find(this.selector.optionRadio);
        this.desktopPerView = this.el.component.attr("data-desktop-view");
        this.mobilePerView = this.el.component.attr("data-mobile-view");
        this.maxCnt = Number(l.MOBILE < e.getViewPort().width ?
            this.desktopPerView : this.mobilePerView);
        this.mobileFlg = this.desktopFlg = !1;
        this.slideCnt = this.el.swiperSlide.target.length;
        this.lastCnt = this.slideCnt <= this.maxCnt ? 1 : this.slideCnt - this.maxCnt;
        this.activeCnt = this.slideCnt <= this.maxCnt && this.el.moveWapper.target[0].scrollWidth - 8 > this.el.capaContainer.outerWidth() && this.el.capaItemRadioActive.index() === this.slideCnt - 1 ? this.lastCnt : 0;
        this.maxPos = this.el.moveWapper.target[0].scrollWidth - 8 <= this.el.capaContainer.outerWidth() ? 0 : this.el.moveWapper.target[0].scrollWidth -
            this.el.capaContainer.outerWidth();
        this.resizeTimer = this.timer = null;
        this.initFlag = this.activeCheck = !1;
        this.direction = (this.rtlFlag = "rtl" === a("body").css("direction") ? !0 : !1) ? "" : "-";
        this.startActiveIdx = null;
        "none" !== this.el.moveWapper.css("transform") ? this.moveLength = Math.abs(Number(this.el.moveWapper.css("transform").match(/-?[\d\\.]+/g)[4])) : this.moveLength = 0;
        this.el.swiperSlide.target.forEach(function(c, d) {
            a(c).hasClass("active-slide") && (b.startActiveIdx = d)
        })
    };
    b.prototype.init = function() {
        this.initFlag = !0;
        this.bindEvents();
        this.optionSlide();
        this.resize(!0)
    };
    b.prototype.reInit = function() {
        this.setElements();
        this.init()
    };
    b.prototype.setBtnDisable = function() {
        this.el.capaItemRadioActive = this.el.component.find(this.selector.capaItemRadio + ":checked").closest(this.selector.swiperSlide);
        this.el.moveWapper.target[0].scrollWidth - 8 > this.el.capaContainer.outerWidth() ? (this.el.swiperNext.show(), this.el.swiperPrev.show(), 0 < this.moveLength ? (this.el.swiperPrev.removeClass(this.selector.btnDisabledCls), this.el.swiperPrev.attr("aria-disabled",
            "false"), this.el.swiperPrev.attr("tabindex", "0"), this.moveLength >= this.el.moveWapper.target[0].scrollWidth - this.el.capaContainer.outerWidth() - 8 ? (this.el.swiperNext.addClass(this.selector.btnDisabledCls), this.el.swiperNext.attr("aria-disabled", "true"), this.el.swiperNext.attr("tabindex", "-1")) : (this.el.swiperNext.removeClass(this.selector.btnDisabledCls), this.el.swiperNext.attr("aria-disabled", "false"), this.el.swiperNext.attr("tabindex", "0"))) : (this.el.swiperNext.removeClass(this.selector.btnDisabledCls),
            this.el.swiperNext.attr("aria-disabled", "false"), this.el.swiperNext.attr("tabindex", "0"), this.el.swiperPrev.addClass(this.selector.btnDisabledCls), this.el.swiperPrev.attr("aria-disabled", "true"), this.el.swiperPrev.attr("tabindex", "-1"))) : (this.el.swiperNext.hide(), this.el.swiperNext.attr("aria-disabled", "true"), this.el.swiperNext.attr("tabindex", "-1"), this.el.swiperPrev.hide(), this.el.swiperPrev.attr("aria-disabled", "true"), this.el.swiperPrev.attr("tabindex", "-1"))
    };
    b.prototype.setActiveCnt = function() {
        !0 ===
            this.initFlag && ("none" === this.el.moveWapper.css("transform") ? this.activeCnt = this.el.component.find("input:checked").closest(this.selector.swiperSlide).index() : this.activeCnt = null);
        this.initFlag = !1
    };
    b.prototype.setSlidePos = function(a) {
        a = void 0 === a ? null : a;
        this.maxPos = this.el.moveWapper.target[0].scrollWidth - 8 <= this.el.capaContainer.outerWidth() ? 0 : this.el.moveWapper.target[0].scrollWidth - this.el.capaContainer.outerWidth();
        this.setSlideMove(a)
    };
    b.prototype.setSlideMove = function(a) {
        var b = this;
        a = void 0 ===
            a ? null : a;
        var d = this.el.component.find("input:checked").closest(this.selector.swiperSlide).index(),
            e = this.el.component.find(this.selector.swiperSlide).outerWidth();
        null !== a ? null !== this.activeCnt ? this.moveLength = e * this.activeCnt > this.maxPos ? this.maxPos : e * this.activeCnt : this.activeCnt = Math.ceil(this.moveLength / e) : "none" === this.el.moveWapper.css("transform") && 0 === this.moveLength && 0 < d && (this.moveLength = e * d > this.maxPos ? this.maxPos : e * d);
        this.el.moveWapper.css({
            transform: "translateX(" + this.direction + this.moveLength +
                "px)"
        });
        setTimeout(function() {
            b.setBtnDisable()
        }, 300)
    };
    b.prototype.setSwiperWidth = function() {
        var b = this;
        this.el.component.target.forEach(function(c) {
            c = a(c);
            var d = [];
            c.find(b.selector.swiperSlide).css({
                width: ""
            });
            c.find(b.selector.swiperSlide).target.forEach(function(b) {
                d.push(a(b).width())
            });
            var g = Math.max.apply(null, d),
                m = l.MOBILE < e.getViewPort().width ? b.desktopPerView : b.mobilePerView,
                p = 0;
            0 < c.closest(".pf-product-compare").target.length ? p = l.MOBILE < e.getViewPort().width ? 4 : 8 : 1 > c.closest(".hubble-item-card__option-memory").target.length &&
                (p = 16);
            c.find(b.selector.swiperSlide).css({
                width: g + "px"
            });
            c.find(b.selector.swiperWrap).css({
                width: g * m + 2 + "px"
            });
            0 !== c.find(b.selector.flotingBox).target.length && c.find(b.selector.flotingBox).css({
                transition: "none",
                width: g - p + "px"
            })
        })
    };
    b.prototype.setHalfSlide = function(b) {
        var c = a(b.target).closest(this.selector.swiperSlide);
        b = Math.ceil(c.offset().left);
        c = Math.ceil(b + c.width());
        var d = Math.ceil(this.el.capaContainer.offset().left),
            e = Math.ceil(d + this.el.capaContainer.width());
        b > d + 10 && c > e + 10 ? this.rtlFlag ?
            this.el.swiperPrev.trigger("click") : this.el.swiperNext.trigger("click") : b < d - 10 && c < e - 10 && (this.rtlFlag ? this.el.swiperNext.trigger("click") : this.el.swiperPrev.trigger("click"))
    };
    b.prototype.optionSlide = function() {
        var b = this;
        this.el.swiperNext.target.forEach(function(c) {
            a(c).off("click").on("click", function() {
                var a = b.el.swiperSlide.outerWidth();
                b.activeCnt += 1;
                b.moveLength >= b.el.moveWapper.target[0].scrollWidth - b.el.capaContainer.outerWidth() && (b.activeCnt = b.lastCnt);
                b.moveLength = b.moveLength + a > b.maxPos ?
                    b.maxPos : b.moveLength + a;
                b.el.moveWapper.css({
                    transform: "translateX(" + b.direction + b.moveLength + "px)"
                });
                b.setBtnDisable()
            })
        });
        this.el.swiperPrev.target.forEach(function(c) {
            a(c).off("click").on("click", function() {
                var a = b.el.swiperSlide.outerWidth();
                --b.activeCnt;
                0 > b.activeCnt && (b.activeCnt = 0);
                a = 0 < b.moveLength % a ? b.moveLength - Math.floor(b.moveLength / a) * a : a;
                b.moveLength = 0 >= b.moveLength - a ? 0 : b.moveLength - a;
                b.el.moveWapper.css({
                    transform: "translateX(" + b.direction + b.moveLength + "px)"
                });
                b.setBtnDisable()
            })
        })
    };
    b.prototype.moveFloting = function(a) {
        if (!(0 >= a.target.length)) {
            var b = 0;
            0 < this.el.flotingBox.closest(".pf-product-compare").target.length ? b = l.MOBILE < e.getViewPort().width ? 2 : 4 : 1 > this.el.flotingBox.closest(".hubble-item-card__option-memory").target.length && (b = 7.5);
            this.el.flotingBox.css({
                display: "block",
                transition: "",
                left: a.target[0].offsetLeft + b + "px"
            });
            this.flotingActive = a.closest(this.selector.swiperSlide)
        }
    };
    b.prototype.resize = function(a) {
        a = void 0 === a ? null : a;
        this.setSwiperWidth();
        this.moveFloting(this.el.component.find(this.selector.capaItemRadio +
            ":checked").closest(this.selector.swiperSlide));
        l.MOBILE < e.getViewPort().width ? !1 === this.desktopFlg && (this.desktopFlg = !0, this.mobileFlg = !1, !0 === a ? (this.setActiveCnt(), this.setBtnDisable(), this.setSlidePos()) : this.desktopPerView !== this.mobilePerView && (this.setActiveCnt(), this.setBtnDisable())) : !1 === this.mobileFlg && (this.mobileFlg = !0, this.desktopFlg = !1, !0 === a ? (this.setActiveCnt(), this.setBtnDisable(), this.setSlidePos()) : this.desktopPerView !== this.mobilePerView && (this.setActiveCnt(), this.setBtnDisable()));
        this.setSlidePos(!0)
    };
    b.prototype.changeCapacity = function(b) {
        b = a(b.currentTarget);
        this.moveFloting(b.closest(this.selector.swiperSlide))
    };
    b.prototype.bindEvents = function() {
        this.el.window.off("resize", this.handler.timeHandler).on("resize", this.handler.timeHandler);
        this.el.optionRadio.off("change", this.handler.setHalfSlide).on("change", this.handler.setHalfSlide);
        this.el.capaItemRadio.off("change", this.handler.changeCapacity).on("change", this.handler.changeCapacity)
    };
    var d = function() {
        a(".option-selector__wrap").target.forEach(function(d) {
            a(d).closest(".unbind-option").target.length ||
                b.instances.has(d) || new b(d)
        })
    };
    b.instances = new WeakMap;
    a.ready(d);
    window.sg.common.OptionSelector = {
        init: d,
        reInit: function(d) {
            var c = a(".option-selector__wrap");
            void 0 !== d && (c = d.hasClass("option-selector__wrap") ? d : d.find(".option-selector__wrap"));
            c.target.forEach(function(a) {
                b.instances.has(a) ? b.instances.get(a).reInit() : new b(a);
                g.update(a)
            })
        }
    }
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.utils,
        e = window.sg.common.constants.KEY_CODE,
        g = window.sg.common.swiperManager,
        b = function(d) {
            var c = this;
            this.isTouchEvent = this.keypress = this.motioning = this.dragging = !1;
            this.containerPadding = this.timer = this.percent = 0;
            this.offset = {
                startX: 0,
                wrapperX: 0,
                x_origine: 0,
                y_origine: 0,
                x_new: 0,
                y_new: 0
            };
            this.touchEvents = {};
            this.ele = {
                window: a(window),
                document: a(document),
                section: a(d),
                component: null,
                slideContainer: null,
                slideWrap: null,
                slideButtonList: null,
                slideList: null
            };
            this.selector = {
                component: ".option-selector-v2__swiper",
                slideContainer: ".option-selector-v2__swiper-container",
                slideWrap: ".option-selector-v2__swiper-wrapper",
                slideButtonList: ".option-selector-v2__swiper-slide button",
                slideList: ".option-selector-v2__swiper-slide",
                slideSelected: ".option-selector-v2__swiper-slide .is-checked"
            };
            this.handler = {
                touchsupport: function() {
                    return "ontouchstart" in window || window.DocumentTouch && document instanceof window.DocumentTouch || 0 < navigator.maxTouchPoints || 0 < window.navigator.msMaxTouchPoints
                },
                heightLimit: function() {
                    return c.isTouchEvent ? 10 : 100
                },
                clickHandler: function(b) {
                    c.dragging || c.handler.slideTo(a(b.target).closest(".option-selector-v2__swiper-slide"));
                    c.dragging = !1
                },
                slideTo: function(a) {
                    var d = c.ele.slideWrap.offset();
                    a = a.offset();
                    var e = d.left - a.left;
                    "ltr" !== b.direction && (e = d.right - a.right);
                    c.handler.setWrapperPos(e, !0)
                },
                eventClick: function(a) {
                    a.preventDefault();
                    a.preventDefault ? a.preventDefault() : a.returnValue = !1
                },
                touchStart: function(a) {
                    a = c.isTouchEvent ? a.touches[0] || a.changedTouches[0] :
                        a;
                    c.offset.x_new = 0;
                    c.offset.y_new = 0;
                    c.offset.x_origine = a.pageX;
                    c.offset.y_origine = a.pageY;
                    c.offset.wrapperX = c.offset.startX;
                    c.ele.slideWrap.on(c.touchEvents.touchMove, c.handler.touchMove);
                    c.ele.document.on(c.touchEvents.touchMove, c.handler.touchMove);
                    c.ele.document.on(c.touchEvents.touchEnd, c.handler.touchEnd);
                    c.ele.document.on("mouseleave", c.handler.touchEnd);
                    if (a = g.getSwiper(c.ele.slideContainer.closest(".swiper-container").target[0])) a.allowTouchMove = !1
                },
                touchMove: function(a) {
                    var b = c.isTouchEvent ?
                        a.touches[0] || a.changedTouches[0] : a;
                    c.offset.x_new = c.offset.x_origine - b.pageX;
                    c.offset.y_new = c.offset.y_origine - b.pageY;
                    a.preventDefault();
                    Math.abs(c.offset.y_new) > c.handler.heightLimit() ? (c.handler.touchEnd(), c.handler.eventClick(a), c.dragging = !1) : 0 !== c.offset.x_new && (c.dragging = !0, c.handler.setWrapperPos(c.offset.wrapperX - c.offset.x_new))
                },
                touchEnd: function() {
                    c.ele.slideWrap.off(c.touchEvents.touchMove, c.handler.touchMove);
                    c.ele.document.off(c.touchEvents.touchMove, c.handler.touchMove);
                    c.ele.document.off(c.touchEvents.touchEnd,
                        c.handler.touchEnd);
                    c.ele.document.off("mouseleave", c.handler.touchEnd);
                    setTimeout(function() {
                        c.dragging = !1
                    }, 1);
                    var a = g.getSwiper(c.ele.slideContainer.closest(".swiper-container").target[0]);
                    a && (a.allowTouchMove = !0)
                },
                resetPos: function() {
                    c.ele.slideWrap.css({
                        transform: ""
                    })
                },
                changeHandler: function(b) {
                    c.ele.slideList.removeClass("is-checked");
                    c.ele.slideList.find(".blind").remove();
                    b = a(b.target).closest(c.selector.slideList);
                    b.addClass("is-checked");
                    b.find("span").after('\x3cspan class\x3d"blind"\x3e' +
                        c.globalText + "\x3c/span\x3e")
                },
                keyDownHandler: function(a) {
                    a.keyCode === e.TAB && c.ele.component.hasClass("bindCheck") && c.handler.clickHandler(a)
                },
                setWrapperPos: function(a, d) {
                    d = void 0 === d ? !1 : d;
                    if (!isNaN(a)) {
                        "ltr" === b.direction ? 0 < a ? a = 0 : c.ele.slideWrap.outerWidth() + a <= c.ele.slideContainer.outerWidth() - c.containerPadding && (a = c.ele.slideContainer.outerWidth() - c.containerPadding - c.ele.slideWrap.outerWidth()) : 0 > a ? a = 0 : c.ele.slideWrap.outerWidth() - a <= c.ele.slideContainer.outerWidth() - c.containerPadding && (a = -1 *
                            (c.ele.slideContainer.outerWidth() - c.containerPadding - c.ele.slideWrap.outerWidth()));
                        var e = {
                            transform: "translateX(" + a + "px)"
                        };
                        e.transition = d ? "" : "none";
                        c.ele.slideWrap.css(e);
                        c.offset.startX = a;
                        a = Math.abs(a) / (c.ele.slideContainer.outerWidth() - c.containerPadding - c.ele.slideWrap.outerWidth()) * 100;
                        a = isNaN(a) ? 0 : a;
                        c.percent = Math.abs(Math.floor(a));
                        c.ele.component.removeClass("next");
                        c.ele.component.removeClass("prev");
                        2 >= c.percent ? c.ele.component.addClass("next") : 98 >= c.percent ? (c.ele.component.addClass("prev"),
                            c.ele.component.addClass("next")) : c.ele.component.addClass("prev")
                    }
                },
                resize: function() {
                    clearTimeout(c.timer);
                    c.timer = setTimeout(function() {
                        c.handler.timeResize()
                    }, 10)
                },
                timeResize: function() {
                    if (c.ele.slideContainer.width() < c.ele.slideWrap.width()) {
                        c.ele.component.hasClass("bindCheck") || (c.ele.component.addClass("bindCheck"), c.ele.slideWrap.on(c.touchEvents.touchStart, c.handler.touchStart), c.ele.slideWrap.on(c.touchEvents.touchEnd, c.handler.touchEnd), c.ele.slideButtonList.on("click", c.handler.clickHandler));
                        c.containerPadding = 2 * parseInt(c.ele.slideContainer.css("padding-right"), 10);
                        var a = (c.ele.slideContainer.outerWidth() - c.containerPadding - c.ele.slideWrap.outerWidth()) * (c.percent / 100);
                        "ltr" !== b.direction && (a *= -1);
                        c.handler.setWrapperPos(a)
                    } else c.ele.component.removeClass("bindCheck"), c.ele.component.removeClass("next"), c.ele.component.removeClass("prev"), c.ele.component.addClass("option-selector-v2__swiper--min"), c.ele.slideWrap.off(c.touchEvents.touchStart, c.handler.touchStart), c.ele.slideWrap.off(c.touchEvents.touchEnd,
                        c.handler.touchEnd), c.ele.slideButtonList.off("click", c.handler.clickHandler), c.handler.resetPos()
                }
            };
            this.startX = 0;
            this.globalText = null;
            b.instances.set(d, this);
            this.init()
        };
    b.prototype.init = function() {
        this.setProperty();
        this.bindEvents()
    };
    b.prototype.scrollX = function() {
        var a = window.getComputedStyle(this.ele.slideWrap.target[0]).getPropertyValue("transform").match(/(-?[0-9\\.]+)/g),
            b = 0;
        a && (b = parseInt(a[4], 10));
        return b
    };
    b.prototype.reInit = function() {
        this.isTouchEvent = this.handler.touchsupport();
        this.unBindEvents();
        this.setProperty();
        this.bindEvents()
    };
    b.prototype.setProperty = function() {
        "rtl" === l.getDirection() && (b.direction = "rtl");
        this.ele.component = this.ele.section.find(this.selector.component);
        this.ele.slideWrap = this.ele.component.find(this.selector.slideWrap);
        this.ele.slideContainer = this.ele.component.find(this.selector.slideContainer);
        this.ele.slideButtonList = this.ele.component.find(this.selector.slideButtonList);
        this.ele.slideList = this.ele.component.find(this.selector.slideList);
        this.ele.component.removeClass("bindCheck");
        this.isTouchEvent = this.handler.touchsupport();
        this.touchEvents = {
            touchStart: this.isTouchEvent ? "touchstart" : "mousedown",
            touchMove: this.isTouchEvent ? "touchmove" : "mousemove",
            touchEnd: this.isTouchEvent ? "touchend" : "mouseup"
        };
        this.globalText = JSON.parse(this.ele.section.target[0].dataset.globalText).selected;
        this.startX = Math.abs(this.scrollX());
        if (0 < this.startX) {
            var a = scrollX / (this.ele.slideContainer.outerWidth() - 2 * parseInt(this.ele.slideContainer.css("padding-right"), 10) - this.ele.slideWrap.outerWidth()) *
                100;
            this.percent = Math.abs(a)
        }
    };
    b.prototype.bindEvents = function() {
        this.ele.window.on("resize", this.handler.timeResize);
        this.ele.slideButtonList.on("click", this.handler.changeHandler);
        this.ele.slideButtonList.on("keyup", this.handler.keyDownHandler);
        this.handler.timeResize();
        var a = this.ele.slideContainer.find(".is-checked button");
        0 === this.startX && a.target.length && this.ele.component.hasClass("bindCheck") && this.handler.slideTo(a)
    };
    b.prototype.unBindEvents = function() {
        this.ele.window.off("resize", this.handler.timeResize);
        this.ele.slideButtonList.off("click", this.handler.clickHandler);
        this.ele.slideButtonList.off("keyup", this.handler.keyDownHandler);
        this.ele.slideButtonList.off("click", this.handler.changeHandler);
        this.ele.slideWrap.off(this.touchEvents.touchStart, this.handler.touchStart);
        this.ele.slideWrap.off(this.touchEvents.touchEnd, this.handler.touchEnd)
    };
    b.direction = "ltr";
    var d = function() {
        a(".option-selector-v2 .option-selector-v2__wrap").target.forEach(function(a) {
            new b(a)
        })
    };
    b.instances = new WeakMap;
    a.ready(d);
    window.sg.common.optionSelectorV2 = {
        init: d,
        reInit: function(d) {
            a(d).find(".option-selector-v2 .option-selector-v2__wrap").target.forEach(function(a) {
                b.instances.has(a) ? b.instances.get(a).reInit() : new b(a)
            })
        }
    }
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.utils.getCurrentDevice,
        e = window.sg.common.video,
        g = window.sg.common.utils.triggerEvent,
        b = window.sg.common.utils.setMobileFocusLoop,
        d = window.sg.common.utils.removeMobileFocusLoop,
        n = function(a) {
            this.els = {
                el: a,
                videoWrapEl: a.querySelector(".popup-video__video-wrap"),
                videoEls: a.querySelectorAll(".popup-video__video-wrap .video"),
                videoCloseButtonEl: a.querySelector(".popup-video__btn-video-close"),
                popupVideoLoopingStartEl: a.querySelector(".popup-video__looping--start"),
                popupVideoLoopingEndEl: a.querySelector(".popup-video__looping--end")
            };
            this.currentPlayingVideoEl = {};
            this.focusTargetEl = {};
            this.init()
        };
    n.prototype.init = function() {
        n.instances.get(this.els.el) || (n.instances.set(this.els.el, this), this.bindEvents())
    };
    n.prototype.setVideoSize = function() {
        "desktop" === l() ? .9 * window.innerHeight < 8.1 * window.innerWidth / 16 ? (this.els.videoWrapEl.style.width = 14.4 * window.innerHeight / 9 + "px", this.els.videoWrapEl.style.height = .9 * window.innerHeight + "px") : (this.els.videoWrapEl.style.width =
            .9 * window.innerWidth + "px", this.els.videoWrapEl.style.height = 8.1 * window.innerWidth / 16 + "px") : (this.els.videoWrapEl.style.width = window.innerWidth + "px", this.els.videoWrapEl.style.height = 9 * window.innerWidth / 16 + "px")
    };
    n.prototype.bindEvents = function() {
        var a = this;
        this.els.videoCloseButtonEl.addEventListener("click", this.close.bind(this));
        this.els.popupVideoLoopingStartEl.addEventListener("focus", function() {
            a.els.videoCloseButtonEl.focus()
        });
        this.els.popupVideoLoopingEndEl.addEventListener("focus", function() {
            a.els.videoWrapEl.focus()
        });
        window.addEventListener("resize", this.setVideoSize.bind(this))
    };
    n.prototype.open = function(a, c) {
        a = void 0 === a ? 0 : a;
        c = void 0 === c ? null : c;
        document.body.style.overflow = "hidden";
        this.els.el.classList.add("popup-video--show");
        this.els.videoWrapEl.focus();
        this.els.videoEls[a].style.display = "block";
        this.setVideoSize();
        e.init(this.els.videoEls[a]);
        this.currentPlayingVideoEl = this.els.videoEls[a];
        this.focusTargetEl = c;
        "mobile" === l() && b(this.els.el)
    };
    n.prototype.close = function() {
        e.dispose(this.currentPlayingVideoEl);
        this.currentPlayingVideoEl.removeAttribute("style");
        this.els.el.classList.remove("popup-video--show");
        document.body.removeAttribute("style");
        this.currentPlayingVideoEl = {};
        this.focusTargetEl instanceof Element && this.focusTargetEl.focus();
        "mobile" === l() && d();
        g(this.els.el, "popupVideoClose")
    };
    n.instances = new WeakMap;
    var c = {
        initAll: function() {
            [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".popup-video"))).forEach(function(a) {
                n.instances.has(a) || new n(a)
            })
        },
        open: function(a, b, c) {
            n.instances.has(a) ?
                n.instances.get(a).open(b, c) : (new n(a)).open(b, c)
        },
        close: function(a) {
            n.instances.has(a) ? n.instances.get(a).close() : (new n(a)).close()
        }
    };
    window.sg.common.popupVideo = c;
    a.ready(c.initAll)
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.utils.getCurrentDevice,
        e = window.BezierEasing,
        g = window.sg.common.utils.triggerEvent,
        b = window.sg.common.utils.addEventListener,
        d = window.sg.common.utils.removeAllEventListeners,
        n = window.sg.common.utils.getNormalizedScrollLeft,
        c = window.sg.common.utils.setNormalizedScrollLeft,
        h = function(a, b) {
            this.els = {
                el: a,
                tabListEl: null,
                tabItemTitleEls: []
            };
            this.init(void 0 === b ? 0 : b)
        };
    h.prototype.init = function(a) {
        a = void 0 === a ? 0 : a;
        h.instances.has(this.els.el) || (h.instances.set(this.els.el,
            this), this.initValues(), this.setElements(), this.bindEvents(), this.select(a, !0))
    };
    h.prototype.reInit = function(a) {
        a = void 0 === a ? 0 : a;
        this.unBindEvents();
        this.initValues();
        this.setElements();
        this.bindEvents();
        this.select(a)
    };
    h.prototype.initValues = function() {
        this.index = -1;
        this.startX = 0;
        this.isAnim = this.isContentsDragging = !1;
        this.diffX = 0;
        this.device = "";
        this.selectDisabled = !1
    };
    h.prototype.setElements = function() {
        this.els.tabListEl = this.els.el.querySelector(".tab__list");
        this.els.tabItemTitleEls = this.els.el.querySelectorAll(".tab__item-title")
    };
    h.prototype.select = function(a, b) {
        b = void 0 === b ? !1 : b;
        a === this.index || this.isAnim || (this.index = a, [].concat($jscomp.arrayFromIterable(this.els.tabItemTitleEls)).forEach(function(a) {
            a.parentElement.classList.remove("tab__item--active");
            a.setAttribute("aria-selected", "false")
        }), this.els.tabItemTitleEls[a].parentElement.classList.add("tab__item--active"), this.els.tabItemTitleEls[a].setAttribute("aria-selected", "true"), b ? this.setPosition(a, !1) : this.setPosition(a), b || g(this.els.el, "tabSelect", this.index))
    };
    h.prototype.selectTab = function(a) {
        this.selectDisabled || (this.select(a), this.setPosition(a))
    };
    h.prototype.setPosition = function(a, b) {
        var d = this;
        b = void 0 === b ? !0 : b;
        if ("mobile" === l()) {
            var h = this.els.el.getBoundingClientRect();
            a = this.els.tabItemTitleEls[a].getBoundingClientRect();
            var g = Math.max(document.documentElement.clientWidth, window.innerWidth || 0),
                p = b ? 300 : 0,
                m = e(.4, 0, .2, 1);
            b = function(a) {
                var b = n(d.els.tabListEl),
                    e = d.els.tabListEl.scrollWidth - d.els.el.getBoundingClientRect().width;
                b + a > e && (a = e - b);
                0 > b +
                    a && (a = -b);
                e = function(e) {
                    c(d.els.tabListEl, b + a * e)
                };
                0 < p ? d.isAnim || d.animate(e, p, m) : e(1)
            };
            g = 56 * g / 360;
            a.right + g > h.right ? b(a.right - h.right + g) : a.left - g < h.left && b(-(h.left - a.left + g))
        }
    };
    h.prototype.animate = function(a, b, c) {
        var d = this,
            e = Date.now();
        this.isAnim = !0;
        this.isContentsDragging = !1;
        var h = function() {
            var g = (Date.now() - e) / b;
            1 < g ? (a(1), d.isAnim = !1) : (requestAnimationFrame(h), a(c(g)))
        };
        requestAnimationFrame(h)
    };
    h.prototype.bindEvents = function() {
        var a = this;
        [].concat($jscomp.arrayFromIterable(this.els.tabItemTitleEls)).forEach(function(c,
            d) {
            b(c, "click", function() {
                a.selectDisabled || a.select(d)
            })
        });
        this.handleContentsDragStart = this.handleContentsDragStart.bind(this);
        this.handleContentsDrag = this.handleContentsDrag.bind(this);
        this.handleContentsDragEnd = this.handleContentsDragEnd.bind(this);
        this.els.el.addEventListener("mousedown", this.handleContentsDragStart);
        this.resize = this.resize.bind(this);
        window.addEventListener("resize", this.resize)
    };
    h.prototype.unBindEvents = function() {
        [].concat($jscomp.arrayFromIterable(this.els.tabItemTitleEls)).forEach(function(a) {
            d(a,
                "click")
        });
        this.els.el.removeEventListener("mousedown", this.handleContentsDragStart);
        window.removeEventListener("resize", this.resize)
    };
    h.prototype.resize = function() {
        var a = l();
        this.device !== a && (this.device = a, this.setPosition(this.index))
    };
    h.prototype.handleContentsDragStart = function(a) {
        "mobile" === l() && (this.startX = a.clientX + n(this.els.tabListEl), this.isContentsDragging = !0, this.diffX = 0, document.addEventListener("mousemove", this.handleContentsDrag), document.addEventListener("mouseup", this.handleContentsDragEnd))
    };
    h.prototype.handleContentsDrag = function(a) {
        if (!this.isAnim && this.isContentsDragging) {
            this.diffX = this.startX - (a.clientX + n(this.els.tabListEl));
            a = n(this.els.tabListEl) + this.diffX;
            var b = this.els.tabListEl.scrollWidth - this.els.el.getBoundingClientRect().width;
            0 > a ? a = 0 : a > b && (a = b);
            c(this.els.tabListEl, a)
        }
    };
    h.prototype.handleContentsDragEnd = function() {
        this.isContentsDragging = !1;
        document.removeEventListener("mousemove", this.handleContentsDrag);
        document.removeEventListener("mouseup", this.handleContentsDragEnd)
    };
    h.prototype.setSelectDisabled = function(a) {
        this.selectDisabled = a
    };
    h.instances = new WeakMap;
    var q = {
        initAll: function() {
            for (var a = [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".tab"))), b = [].concat($jscomp.arrayFromIterable(document.querySelectorAll(".static-content .tab"))), c = 0; c < a.length; c++) {
                for (var d = a[c], e = !1, g = 0; g < b.length; g++)
                    if (d === b[g]) {
                        e = !0;
                        break
                    }
                e || h.instances.has(d) || new h(d)
            }
        },
        init: function(a, b) {
            h.instances.has(a) ? (a = h.instances.get(a), a.reInit(b)) : a = new h(a, b);
            return a
        },
        reInit: function(a,
            b) {
            h.instances.has(a) && h.instances.get(a).reInit(b)
        },
        selectTab: function(a, b) {
            h.instances.has(a) && h.instances.get(a).selectTab(b)
        },
        setSelectDisabled: function(a, b) {
            h.instances.has(a) && h.instances.get(a).setSelectDisabled(b)
        }
    };
    window.sg.common.tab = q;
    a.ready(q.initAll)
})();
(function() {
    var a, l;

    function e(c) {
        c = h(c.currentTarget);
        var d = h(c.attr("data-div-id") || "");
        if (!(0 >= d.target.length)) {
            var e = d.find(q.closeBtn);
            a = d.target[0];
            l = e.target[0];
            p = c;
            d.show();
            m.window.off("keydown", b).on("keydown", b);
            n.hiddenScroll();
            d.focus();
            e.off("click", g).on("click", g)
        }
    }

    function g(c) {
        c = void 0 === c ? null : c;
        h(a || ".wishlist-popup").hide();
        m.window.off("keydown", b);
        n.visibleScroll();
        c instanceof Element ? c.focus() : p.focus();
        p = l = a = null
    }

    function b(b) {
        b.keyCode === c.KEY_CODE.TAB && (l === document.activeElement &&
            !1 === b.shiftKey ? (b.preventDefault(), a.focus()) : a === document.activeElement && !0 === b.shiftKey && (b.preventDefault(), l.focus()))
    }

    function d() {
        m.component.off("click", e).on("click", e);
        m.component.target.forEach(function(a) {
            a.classList.contains("pd-wishlist-cta--on") ? a.setAttribute("aria-label", a.getAttribute("data-added-text")) : a.setAttribute("aria-label", a.getAttribute("data-add-text"))
        })
    }
    var n = window.sg.common.utils,
        c = window.sg.common.constants,
        h = window.sg.common.$q,
        q = {
            component: ".pd-wishlist-cta",
            active: "pd-wishlist-cta--on",
            closeBtn: ".wishlist-popup__close"
        },
        m = {
            component: null,
            window: h(window)
        };
    var p = l = a = null;
    window.sg.components.wishlistIcon = {
        reInit: function() {
            m.component = h(q.component);
            d()
        },
        closeWishlistPop: g
    };
    h.ready(function() {
        m.component = h(q.component);
        d()
    })
})();
(function() {
    var a, l, e, g, b, d, n, c, h, q, m, p;

    function u() {
        a = document.querySelector(".gnb-search");
        l = document.querySelector(".gnb-search__form");
        e = document.querySelector(".gnb-search__input");
        g = document.querySelector(".gnb-search__placeholder");
        b = document.querySelector(".gnb-search__input-btn--cancel");
        d = document.querySelector(".gnb-search__result-wrap");
        n = document.querySelector(".gnb-search__history");
        c = document.querySelector(".gnb-search__suggested");
        h = document.querySelector(".gnb-search__related");
        q =
            document.querySelector(".gnb-search__matched");
        m = document.querySelector(".gnb-search__no-suggestions");
        p = document.querySelector(".gnb-search__input-btn--close");
        E = document.querySelector(".gnb-search__btn--close");
        a && (t(), y())
    }

    function t() {
        l.addEventListener("submit", function() {
            var a = e;
            var b = e.value.replace(/[\{\}\[\]/?,;:|\)*~`!^_<>@#$%&\\=\('"]/gi, "");
            a.value = b;
            e.focus()
        });
        b.addEventListener("click", function() {
            v()
        });
        p.addEventListener("click", function() {
            L()
        });
        E.addEventListener("click", function() {
            L()
        });
        window.addEventListener("resize", function() {
            y()
        })
    }

    function y() {
        d.style.maxHeight = window.innerHeight - l.getBoundingClientRect().bottom + "px"
    }

    function v() {
        e.value = "";
        b.classList.remove("gnb-search__input-btn--cancel--show");
        g.classList.remove("gnb-search__placeholder--hide");
        n.classList.add("gnb-search__history--hide");
        c.classList.add("gnb-search__suggested--hide");
        h.classList.add("gnb-search__related--hide");
        q.classList.add("gnb-search__matched--hide");
        m.classList.add("gnb-search__no-suggestions--hide")
    }

    function L() {
        v();
        a.style.display = "none";
        document.body.removeAttribute("style")
    }
    var J = window.sg.common.$q;
    var E = p = m = q = h = c = n = d = b = g = e = l = a = void 0;
    window.sg.components.gnbSearch = {
        init: u,
        reInit: function() {
            y()
        }
    };
    J.ready(function() {
        return u()
    })
})();
(function(a) {
    function l() {
        if (0 < H.length) {
            var b = "";
            a.each(H, function(a) {
                b += '\x3cli class\x3d"gnb-search__result-item"\x3e';
                b += '\x3ca href\x3d"javascript:;" an-tr\x3d"search layer--text-link" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"search history:' + h(H[a]) + '"\x3e';
                b += H[a];
                b += "\x3c/a\x3e";
                b += "\x3c/li\x3e"
            });
            B.gnbSearchHistory.find("ul").html(b)
        }
    }

    function e() {
        l();
        B.gnbSearchSuggested.addClass("gnb-search__suggested--hide");
        B.gnbSearchHistory.removeClass("gnb-search__history--hide");
        B.gnbSearchRelated.addClass("gnb-search__related--hide");
        B.gnbSearchMatched.addClass("gnb-search__matched--hide");
        B.gnbSearchNoSuggestions.addClass("gnb-search__no-suggestions--hide")
    }

    function g() {
        "us" != W && (B.gnbSearchSuggested.removeClass("gnb-search__suggested--hide"), B.gnbSearchHistory.addClass("gnb-search__history--hide"), B.gnbSearchRelated.addClass("gnb-search__related--hide"), B.gnbSearchMatched.addClass("gnb-search__matched--hide"));
        B.gnbSearchNoSuggestions.addClass("gnb-search__no-suggestions--hide")
    }

    function b() {
        B.gnbSearchSuggested.addClass("gnb-search__suggested--hide");
        B.gnbSearchHistory.addClass("gnb-search__history--hide");
        B.gnbSearchRelated.addClass("gnb-search__related--hide");
        B.gnbSearchMatched.addClass("gnb-search__matched--hide");
        B.gnbSearchNoSuggestions.removeClass("gnb-search__no-suggestions--hide")
    }

    function d() {
        B.gnbSearchResultWrap.removeClass("gnb-search__result-wrap--hide");
        B.gnbSearchChipWrap.addClass("gnb-search__chip-wrap--hide")
    }

    function n() {
        B.gnbSearchResultWrap.addClass("gnb-search__result-wrap--hide");
        B.gnbSearchChipWrap.removeClass("gnb-search__chip-wrap--hide")
    }

    function c(a) {
        return a = a.split("\x3c").join("").split("\x3e").join("").split("\x26lt").join("").split("\x26gt").join("")
    }

    function h(a) {
        var b = /[\{\}\[\]?,;:|\)*~`!^_<>@#$%&\\=\('"]/gi;
        b.test(a) && (a = a.replace(b, ""));
        return a
    }

    function q(a, b) {
        return a.split(b).join("\x3cb\x3e" + b + "\x3c/b\x3e")
    }

    function m(a) {
        return a.split('"').join("\x26quot;").split("\x3cb\x3e").join("").split("\x3c/b\x3e").join("")
    }

    function p(a) {
        a = m(a);
        return Granite.I18n.get("search.common.labels.searchBy.a1", [a])
    }

    function u(a) {
        var b =
            a;
        a.lastIndexOf("/") === a.length - 1 && (b = a.substr(0, a.length - 1));
        return b
    }

    function t(a) {
        /(?:\/\/)([\/a-z0-9-%#?&=\w])+(\.[a-z0-9]{2,4}(\?[\/a-z0-9-%#?&=\w]+)*)*/gi.test(a) || (a = Q + a);
        return a
    }

    function y() {
        var d = "";
        0 < F.length ? (a.each(F, function(a) {
            var b = F[a];
            7 > a && (d += '\x3cli class\x3d"gnb-search__result-item"\x3e\x3ca href\x3d"' + K + encodeURIComponent(c(b)) + '" title\x3d"' + p(b) + '" an-tr\x3d"search layer--text-suggested" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"suggested searches:' + m(b) + '"\x3e' +
                F[a] + "\x3c/a\x3e\x3c/li\x3e")
        }), B.gnbSearchSuggested.find("ul").html(d), g()) : 0 < H.length ? e() : b()
    }

    function v() {
        "us" !== W && a.ajax({
            type: "GET",
            crossDomain: !0,
            data: {
                siteCd: W,
                stage: z.stage,
                searchValue: ""
            },
            dataType: "json",
            jsonCallback: "samsungcallback",
            url: u(z.domain) + "/search/suggest/v6",
            error: function() {
                b()
            },
            success: function(a) {
                if ((a = a.response.resultData) && a.common)
                    if (a.common.suggestedKeywords) {
                        a = a.common.suggestedKeywords;
                        for (var c = 0; c < a.length; c++) {
                            var d = a[c];
                            0 > F.indexOf(d) && 7 > F.length && F.push(d)
                        }
                        y()
                    } else b()
            }
        })
    }

    function L(a, b) {
        var d = "";
        if (0 < a.length) {
            for (var e = 0; e < a.length; e++) {
                var h = a[e];
                4 > e && (d += '\x3cli class\x3d"gnb-search__result-item"\x3e\x3ca href\x3d"' + K + encodeURIComponent(c(h)) + '" title\x3d"' + p(h) + '" an-tr\x3d"search layer--text-related" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"related searches:' + m(h) + '"\x3e' + q(h, b) + "\x3c/a\x3e\x3c/li\x3e")
            }
            B.gnbSearchRelated.find("ul").html(d);
            B.gnbSearchRelated.removeClass("gnb-search__related--hide");
            return "Y"
        }
        B.gnbSearchRelated.addClass("gnb-search__related--hide");
        return "N"
    }

    function J(a, b) {
        var c = "",
            d = parseFloat(a.reviewsCount || "0");
        if (0 < d) {
            for (var e = parseInt(a.ratings), h = "", g = 0; g < Math.floor(e); g++) h += '\x3cspan class\x3d"gnb-search__result-product-rating-star gnb-search__result-product-rating-star--active"\x3e\x3csvg class\x3d"icon" focusable\x3d"false"\x3e\x3cuse xlink:href\x3d"#star-rating-full-bold" href\x3d"#star-rating-full-bold"\x3e\x3c/use\x3e\x3c/svg\x3e\x3c/span\x3e';
            for (g = 0; g < 5 - Math.floor(e); g++) h += '\x3cspan class\x3d"gnb-search__result-product-rating-star"\x3e\x3csvg class\x3d"icon" focusable\x3d"false"\x3e\x3cuse xlink:href\x3d"#star-rating-full-bold" href\x3d"#star-rating-full-bold"\x3e\x3c/use\x3e\x3c/svg\x3e\x3c/span\x3e';
            c += '\x3ca class\x3d"gnb-search__result-product-rating" href\x3d"' + a.linkUrlReview + '" title\x3d"' + Granite.I18n.get("{0} Reviews", [m(b)]) + '" data-modelcode\x3d"' + a.modelCode + '" data-modelname\x3d"' + a.modelName + '" an-tr\x3d"search layer--product-link" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"matched contents:product:review"\x3e' + h + '\x3cspan class\x3d"gnb-search__result-product-rating-star-count"\x3e' + e + '\x3c/span\x3e\x3cspan class\x3d"gnb-search__result-product-rating-review-count"\x3e(' +
                d + ")\x3c/span\x3e\x3c/a\x3e"
        }
        return c
    }

    function E(a, b) {
        var c = "";
        !a || "" === a.supportLinkUrl && "" === a.supportLinkUrlManuals && "" === a.regLinkUrl || (c += '\x3cdiv class\x3d"gnb-search__result-product-cta-wrap"\x3e', "" !== a.supportLinkUrlManuals && (c += '\x3ca href\x3d"' + a.supportLinkUrlManuals + '" class\x3d"gnb-search__result-product-cta" title\x3d"' + m(b) + ":" + Granite.I18n.get("search.comp.gnbSearch.product.cta.ownersManual") + '" data-modelcode\x3d"' + a.modelCode + '" data-modelname\x3d"' + a.modelName + '" an-tr\x3d"search layer--product-link" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"matched contents:product:manual"\x3e' +
            Granite.I18n.get("search.comp.gnbSearch.product.cta.ownersManual") + '\x3csvg class\x3d"icon" focusable\x3d"false"\x3e\x3cuse xlink:href\x3d"#next-bold" href\x3d"#next-bold"\x3e\x3c/use\x3e\x3c/svg\x3e\x3c/a\x3e'), "" !== a.supportLinkUrl && (c += '\x3ca href\x3d"' + a.supportLinkUrl + '" class\x3d"gnb-search__result-product-cta" title\x3d"' + m(b) + ":" + Granite.I18n.get("search.comp.gnbSearch.product.cta.support") + '" data-modelcode\x3d"' + a.modelCode + '" data-modelname\x3d"' + a.modelName + '" an-tr\x3d"search layer--product-link" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"matched contents:product:support"\x3e' +
            Granite.I18n.get("search.comp.gnbSearch.product.cta.support") + '\x3csvg class\x3d"icon" focusable\x3d"false"\x3e\x3cuse xlink:href\x3d"#next-bold" href\x3d"#next-bold"\x3e\x3c/use\x3e\x3c/svg\x3e\x3c/a\x3e'), "" !== a.regLinkUrl && (c += '\x3ca href\x3d"' + a.regLinkUrl + '" class\x3d"gnb-search__result-product-cta" title\x3d"' + m(b) + ":" + Granite.I18n.get("search.comp.gnbSearch.product.cta.register") + '" data-modelcode\x3d"' + a.modelCode + '" data-modelname\x3d"' + a.modelName + '" an-tr\x3d"search layer--product-link" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"matched contents:product:register"\x3e' +
            Granite.I18n.get("search.comp.gnbSearch.product.cta.register") + '\x3csvg class\x3d"icon" focusable\x3d"false"\x3e\x3cuse xlink:href\x3d"#next-bold" href\x3d"#next-bold"\x3e\x3c/use\x3e\x3c/svg\x3e\x3c/a\x3e'), c += "\x3c/div\x3e");
        return c
    }

    function la(a) {
        var c = "N",
            d = "N";
        if ("us" !== W) {
            if ("Y" === Z.related && a.common.relatedKeywords && (c = L(a.common.relatedKeywords, a.q)), "Y" === Z.matched && a.resultList && 0 < a.resultList.length && a.resultList[0].contentList && 0 < a.resultList[0].contentList.length) {
                var h = a.resultList[0].contentList;
                a = a.q;
                var l = "",
                    n = "";
                if (0 < h.length) {
                    for (var u = d = 0, v = 0; v < h.length; v++)
                        if (4 > d && "Products" !== h[v].contentSource) {
                            var A = h[v],
                                z = a,
                                w = "",
                                y = A.title;
                            if (-1 < A.contentSource.indexOf("Support")) {
                                var G = A.scmsContentSource.toUpperCase();
                                y = A.scTitle;
                                "PRODUCT" === G && (y = A.dispNm)
                            }
                            G = "ConnectedLiving" === A.contentSource ? "search.common.category.mde" : "AppsServices" === A.contentSource ? "search.common.category.appServices" : "search.common.category." + A.contentSource.toLowerCase();
                            w += '\x3cli class\x3d"gnb-search__result-item"\x3e\x3ca href\x3d"' +
                                A.linkUrl + '" title\x3d"' + p(y) + '" data-search-data\x3d"' + encodeURIComponent(y) + '" an-tr\x3d"search layer--text-matched" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"matched contents:support:' + m(y) + '"\x3e\x3cspan class\x3d"gnb-search__result-item-anchor"\x3e[' + Granite.I18n.get(G) + ']\x3c/span\x3e\x3cspan class\x3d"gnb-search__result-item-title"\x3e' + q(y, z) + "\x3c/span\x3e\x3c/a\x3e\x3c/li\x3e";
                            l += w;
                            d++
                        } else if (1 > u && "Products" === h[v].contentSource) {
                        var K = h[v];
                        A = a;
                        z = "";
                        w = {};
                        G = y = "";
                        var Q = K.thumbnailUrl,
                            V = K.thumbnailUrlAlt || "",
                            T = K.displaySortTitle;
                        if (K.modelList) {
                            for (var x = 0; x < K.modelList.length; x++) "M" === K.modelList[x].mdlRegTypeCd && (w = K.modelList[x]);
                            "Y" === w.shopYN && (G = J(w, T))
                        }
                        Q && (y += '\x3cimg src\x3d"' + t(Q) + '?$SRP_PRD_THUM_GRID_PNG$" alt\x3d"' + V + '" class\x3d"gnb-search__result-item-img"\x3e');
                        K = E(w, T);
                        z += '\x3cli class\x3d"gnb-search__result-item gnb-search__result-item--products"\x3e' + y + '\x3cdiv class\x3d"gnb-search__result-product-wrap"\x3e\x3ca href\x3d"' + w.pdpURL + '" title\x3d"' + p(T) + '" data-modelcode\x3d"' +
                            w.modelCode + '" data-modelname\x3d"' + w.modelName + '" an-tr\x3d"search layer--product-link" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"matched contents:product:product click"\x3e\x3cspan class\x3d"gnb-search__result-item-anchor"\x3e[' + Granite.I18n.get("search.common.category.product") + ']\x3c/span\x3e\x3cspan class\x3d"gnb-search__result-item-title"\x3e' + q(T, A) + "\x3c/span\x3e\x3c/a\x3e" + G + K + "\x3c/div\x3e\x3c/li\x3e";
                        n += z;
                        u++
                    }
                    l += n;
                    B.gnbSearchMatched.find("ul").html(l);
                    "" !== l ? (B.gnbSearchMatched.removeClass("gnb-search__matched--hide"),
                        d = "Y") : (B.gnbSearchMatched.addClass("gnb-search__matched--hide"), d = "N")
                } else B.gnbSearchMatched.addClass("gnb-search__matched--hide"), d = "N"
            }
        } else if (a.Suggestions && a.Suggestions.Suggestion && ("Y" === Z.related && (c = L(a.Suggestions.Suggestion, a.q)), "Y" === Z.matched && a.Recommend)) {
            v = "";
            u = a.Suggestions.Suggestion;
            d = a.Recommend;
            a = a.q;
            if (u.length && (u = u[0], d[u]))
                for (h in d = d[u][0], u = 0, d)
                    if (d[h] && "N" === d[h][0].IsHidden[0] && (y = d[h][0], l = a, n = "", A = {}, z = "", G = y.MediumImage ? y.MediumImage[0] : "", w = y.Title ? y.Title[0] :
                            "", A.reviewsCount = y.ReviewsCount ? y.ReviewsCount[0] : "", A.ratings = y.Ratings_display ? y.Ratings_display[0] : "", A.linkUrlReview = y.LinkUrl ? y.LinkUrl[0] + "/#reviews" : "", A.modelName = "", A.modelCode = y.ModelCode ? y.ModelCode[0] : "", A.regLinkUrl = "/us/support/register/", A.supportLinkUrl = y["Support.LinkUrl"] ? y["Support.LinkUrl"][0] : "", A.supportLinkUrlManuals = y["Support.LinkUrl"] ? y["Support.LinkUrl"][0] + "#manuals" : "", A.linkUrl = y.LinkUrl ? y.LinkUrl[0] : "", y = J(A, w), G && (z += '\x3cimg src\x3d"' + t(G) + '?$SRP_PRD_THUM_GRID_PNG$" class\x3d"gnb-search__result-item-img"\x3e'),
                            G = E(A, w), n += '\x3cli class\x3d"gnb-search__result-item gnb-search__result-item--products"\x3e' + z + '\x3cdiv class\x3d"gnb-search__result-product-wrap"\x3e\x3ca href\x3d"' + A.linkUrl + '" title\x3d"' + p(w) + '" an-tr\x3d"search layer--product-link" an-ca\x3d"search" an-ac\x3d"search layer" an-la\x3d"matched contents:product:product click"\x3e\x3cspan class\x3d"gnb-search__result-item-anchor"\x3e[' + Granite.I18n.get("search.common.category.product") + ']\x3c/span\x3e\x3cspan class\x3d"gnb-search__result-item-title"\x3e' +
                            q(w, l) + "\x3c/span\x3e\x3c/a\x3e" + y + G + "\x3c/div\x3e\x3c/li\x3e", v += n, u++, 1 < u)) break;
            B.gnbSearchMatched.find("ul").html(v);
            "" !== v ? (B.gnbSearchMatched.removeClass("gnb-search__matched--hide"), d = "Y") : (B.gnbSearchMatched.addClass("gnb-search__matched--hide"), d = "N")
        }
        B.gnbSearchSuggested.addClass("gnb-search__suggested--hide");
        B.gnbSearchHistory.addClass("gnb-search__history--hide");
        B.gnbSearchRelated.removeClass("gnb-search__related--hide");
        B.gnbSearchMatched.removeClass("gnb-search__matched--hide");
        B.gnbSearchNoSuggestions.addClass("gnb-search__no-suggestions--hide");
        "N" === c && B.gnbSearchRelated.addClass("gnb-search__related--hide");
        "N" === d && B.gnbSearchMatched.addClass("gnb-search__matched--hide");
        "N" === c && "N" === d && (0 < H.length ? e() : 0 < F.length ? g() : b())
    }

    function ma(c) {
        "us" === W ? ia(c) : a.ajax({
            type: "GET",
            crossDomain: !0,
            data: {
                siteCd: W,
                stage: z.stage,
                searchValue: c
            },
            dataType: "json",
            jsonCallback: "samsungcallback",
            url: u(z.domain) + "/search/suggest/v6",
            error: function() {
                b()
            },
            success: function(a) {
                a = a.response.resultData;
                a.q = c;
                a && 0 < a.common.searchCount ? la(a) : b()
            }
        })
    }

    function ia(c) {
        a.ajax({
            type: "GET",
            data: {
                searchTerm: c
            },
            url: u(z.domain),
            error: function() {
                b()
            },
            success: function(a) {
                a.q = c;
                "object" === typeof a.Recommend ? la(a) : b()
            }
        })
    }

    function V(b) {
        var c = new Date;
        c.setTime(c.getTime() + 72576E5);
        a.cookies.setSearchKeyword(decodeURIComponent(b), c)
    }

    function ja() {
        z.domain = a.trim(a("#esapiSearchDomain").val());
        "us" === W && (da = "listType\x3dg\x26searchTerm", z.domain = "/us/search/global/es/typeahead");
        z.stage = a.trim(a("#apiStageInfo").val());
        B.gnbSearchSuggested.find("li").each(function() {
            var b = a.trim(a(this).text());
            0 > F.indexOf(b) && F.push(b)
        });
        K = -1 < K.indexOf(".html") ? K + ("?" + da + "\x3d") : K + ("/?" + da + "\x3d")
    }
    var G = a("section.gnb-search");
    if (G) {
        var W = a("#siteCode").val(),
            da = "searchvalue",
            Q = a("#scene7domain").val(),
            K = a("#sc_gnb_searchURL").val();
        "us" === W && (K = "/us/search/searchMain");
        var w = a("#sc_gnb_placeholder").val(),
            H = a.cookies.getSearchKeyword(),
            F = [];
        Granite.I18n.setLocale(a("#language").val());
        var z = {
                domain: null,
                stage: "qa"
            },
            Z = {
                suggest: "Y",
                related: "Y",
                matched: a("#sc_gnb_matchedcontentsusable").val() || "Y"
            },
            B = {
                gnbSearchForm: G.find(".gnb-search__form"),
                gnbSearchInputWrap: G.find(".gnb-search__input-wrap"),
                gnbSearchInput: G.find(".gnb-search__input"),
                gnbSearchPlaceholder: G.find(".gnb-search__placeholder"),
                gnbSearchInputCancelButton: G.find(".gnb-search__input-btn--cancel"),
                gnbSearchInputSubmitButton: G.find(".gnb-search__input-btn--search"),
                gnbSearchResultWrap: G.find(".gnb-search__result-wrap"),
                gnbSearchHistory: G.find(".gnb-search__history"),
                gnbSearchHistoryClearButton: G.find(".gnb-search__btn--history-clear"),
                gnbSearchSuggested: G.find(".gnb-search__suggested"),
                gnbSearchRelated: G.find(".gnb-search__related"),
                gnbSearchMatched: G.find(".gnb-search__matched"),
                gnbSearchNoSuggestions: G.find(".gnb-search__no-suggestions"),
                gnbSearchChipWrap: G.find(".gnb-search__chip-wrap"),
                gnbSearchCloseBtn: G.find(".gnb-search__btn--close")
            };
        G.on("focus", ".gnb-search__input", function() {
            var b = c(a.trim(a(this).val()));
            H = a.cookies.getSearchKeyword();
            b && 0 < b.length ? ma(b) : 0 < H.length ? e() : (g(), 7 > F.length && v());
            ("us" != W || b && 0 < b.length) && d();
            window.sg.components.gnbSearch.reInit()
        });
        G.on("click",
            ".gnb-search__contents",
            function(b) {
                0 === a(".gnb-search__search-wrap").has(b.target).length && n()
            });
        G.on("click", ".gnb-search__input-btn--cancel", function() {
            n()
        });
        G.on("input", ".gnb-search__input", function() {
            var b = a(this).val();
            a(this).val(h(b));
            b = a.trim(b);
            H = a.cookies.getSearchKeyword();
            b && 0 < b.length ? ("us" === W && d(), B.gnbSearchPlaceholder.addClass("gnb-search__placeholder--hide"), B.gnbSearchInputCancelButton.addClass("gnb-search__input-btn--cancel--show"), ma(b)) : (B.gnbSearchPlaceholder.removeClass("gnb-search__placeholder--hide"),
                B.gnbSearchInputCancelButton.removeClass("gnb-search__input-btn--cancel--show"), 0 < H.length ? e() : v(), B.gnbSearchRelated.find("ul").empty(), B.gnbSearchMatched.find("ul").empty())
        });
        G.on("click", ".gnb-search__related a, .gnb-search__suggested a", function() {
            var b = a(this).text();
            V(b)
        });
        G.on("click", ".gnb-search__history a", function() {
            var b = c(a(this).html());
            window.location.href = K + encodeURIComponent(b)
        });
        G.on("click", ".gnb-search__btn--history-clear", function() {
            B.gnbSearchSuggested.addClass("gnb-search__suggested--hide");
            B.gnbSearchHistory.addClass("gnb-search__history--hide");
            B.gnbSearchRelated.addClass("gnb-search__related--hide");
            B.gnbSearchMatched.addClass("gnb-search__matched--hide");
            B.gnbSearchNoSuggestions.addClass("gnb-search__no-suggestions--hide");
            g();
            a.cookies.clearSearchKeyword();
            H = [];
            7 > F.length && v()
        });
        G.on("click", ".gnb-search__input-btn--search", function(b) {
            b.preventDefault();
            (b = c(a.trim(B.gnbSearchInput.val()))) || (b = w);
            b && (V(b), window.location.href = K + encodeURIComponent(b), window.gmap = null)
        });
        a(document).on("click",
            ".gnb-search__chip",
            function() {
                var b = a(this).text();
                V(b);
                window.location.href = K + b
            });
        a(document).on("click", ".gnb__search-btn-js", function() {
            G.show();
            B.gnbSearchInput.focus();
            document.body.style.overflow = "hidden"
        });
        a(function() {
            K && "" !== K && ja()
        })
    }
})(window.jQuery);
var SITE_CD = "";
SITE_CD = "" !== $("#siteCode").val() && void 0 !== $("#siteCode").val() ? $("#siteCode").val() : "sec";
var USE_ESTORE = !0,
    DOMAIN = "";
DOMAIN = "" !== $("#domain").val() && void 0 !== $("#domain").val() ? $("#domain").val() : "www.samsung.com";
var STORE_DOMAIN = "";
"N" === $("#useStore").val() && (USE_ESTORE = !1);
STORE_DOMAIN = "" !== $("#storeDomain").val() ? $("#storeDomain").val() : location.protocol + "shop.samsung.com";
var SEC_LOCAL_URL_CHECKMEMBERSTATE = "http://local.sec.samsung.com/comLocal/checkMemberStateAjax.do",
    SEC_LOCAL_URL_SIGNIN = "http://local.sec.samsung.com/comLocal/loginCheck.do";
$("#signInForm input[name\x3ddomain]").val(DOMAIN);
$("#joinForm input[name\x3ddomain]").val(DOMAIN);
$("#findAccountForm input[name\x3ddomain]").val(DOMAIN);
(function(a, l) {
    a(function() {
        a(".layer_popup .close, .layer_popup .icon-close-x, .layer_popup .alert-ok-button").click(function() {
            "close" === a(this).data("popup") && a(".accesseFocusTarget").trigger("focus");
            a(".layer_popup").hide();
            a(".lightbox-skrim").hide();
            return !1
        })
    })
})(jQuery, window);
$.cookies.data = {
    SEARCH_NAME: "sk",
    NAVIGATION_NAME: "nh",
    PRIVATECODE_NAME: "pv",
    COMPARELIST_NAME: "cl",
    WISHLIST_NAME: "wl",
    INSTORE_PRIVATECODE_NAME: "ipv",
    STORE_REGION_NUM: "cnregionnum",
    STORE_REGION_CODE: "cnregion",
    STORE_REGION_NAME: "cnregionname",
    STORE_CITY_NUM: "cncitynamenum",
    STORE_CITY_CODE: "cncity",
    STORE_CITY_NAME: "cncityname",
    SEARCH_MAX_SIZE: 4,
    PRIVATECODE_MAX_SIZE: 5,
    WISHLIST_MAX_SIZE: 6,
    STORE_REGION_MAX_SIZE: 1,
    STORE_CITY_MAX_SIZE: 1
};
var CONTENT = "/content/samsung";
$.cookies.getDefaultOption = function(a, l) {
    a && a instanceof Date || (a = new Date, a.setTime(a.getTime() + 864E5));
    l ? -1 < window.location.pathname.indexOf(CONTENT) && (l = CONTENT + l) : l = "/";
    return {
        expiresAt: a,
        path: l,
        domain: ".samsung.com",
        secure: !1
    }
};
$.cookies.setWishList = function(a, l) {
    var e = this.data.WISHLIST_NAME,
        g = this.get(e);
    if (g) {
        if (0 <= $.inArray(a, g)) return;
        g.length >= this.data.WISHLIST_MAX_SIZE && g.splice(0, 1);
        g.push(a)
    } else g = [a];
    this.set(e, g, this.getDefaultOption(l))
};
$.cookies.getWishListCnt = function() {
    var a = this.get(this.data.WISHLIST_NAME);
    return a && $.isArray(a) ? a.length : 0
};
$.cookies.getWishList = function() {
    var a = this.get(this.data.WISHLIST_NAME);
    return a && $.isArray(a) ? a : []
};
$.cookies.isAddedWishList = function(a) {
    var l = this.get(this.data.WISHLIST_NAME);
    if (l && $.isArray(l))
        for (var e = 0, g = l.length; e < g; e++)
            if (l[e] === a) return !0;
    return !1
};
$.cookies.deleteWishProduct = function(a, l) {
    var e = this.data.WISHLIST_NAME,
        g = this.get(e);
    return g && $.isArray(g) && (a = $.inArray(a, g), 0 <= a) ? (g.splice(a, 1), 0 >= g.length ? this.del(e, this.getDefaultOption(l)) : this.set(e, g, this.getDefaultOption(l)), !0) : !1
};
$.cookies.deleteWishList = function(a) {
    this.del(this.data.WISHLIST_NAME, this.getDefaultOption(a))
};
try {
    if (!$.cookies.get("cookie_country") || "" === $.cookies.get("cookie_country")) $.cookies.set("cookie_country", SITE_CD, $.cookies.getDefaultOption());
    else if (SITE_CD !== $.cookies.get("cookie_country")) {
        var deleteOption = $.cookies.getDefaultOption();
        $.cookies.del($.cookies.data.NAVIGATION_NAME, deleteOption);
        $.cookies.del($.cookies.data.PRIVATECODE_NAME, deleteOption);
        $.cookies.del($.cookies.data.COMPARELIST_NAME, deleteOption);
        $.cookies.del($.cookies.data.WISHLIST_NAME, deleteOption);
        $.cookies.del($.cookies.data.INSTORE_PRIVATECODE_NAME,
            deleteOption);
        $.cookies.set("cookie_country", SITE_CD, $.cookies.getDefaultOption())
    }
} catch (a) {}
var ss = $;
(function(a) {
    ss.EstoreIfQueue = {
        setQueue: function(l) {
            var e = a.cookies.get("iPlanetDirectoryPro", {
                    domain: ".samsung.com"
                }),
                g = a.cookies.get("snsSessionId", {
                    domain: ".samsung.com"
                });
            e || g ? USE_ESTORE ? this.getIsSignReady() ? this.callFunction(l, arguments) : this.queue.push(arguments) : this.callFunction(l, arguments) : this.callFunction(l, arguments)
        },
        callFunction: function(a, e) {
            if (a && "function" == typeof a) {
                for (var g = [], b = 1; b < e.length; b++) g.push(e[b]);
                a.apply(null, g)
            }
        },
        setIsSignReady: function(a) {
            this.isSignReady = a;
            if (!0 ===
                a || "true" === a)
                for (a = 0; a < this.queue.length; a++) this.queue[a].length && this.callFunction(this.queue[a][0], this.queue[a])
        },
        getIsSignReady: function() {
            return this.isSignReady
        },
        setProperties: function() {
            this.isSignReady = !1;
            this.queue = []
        },
        init: function() {
            this.setProperties()
        }
    };
    ss.EstoreIfQueue.init()
})(jQuery);
var estore = function() {
    var a = function(a) {
            var b = "?",
                e = 0,
                c;
            for (c in a) {
                0 != e && (b += "\x26");
                var h = a[c];
                $.isArray(h) ? $.each(h, function(a, d) {
                    b += c + "\x3d" + d;
                    a < h.length - 1 && (b += "\x26")
                }) : b += c + "\x3d" + h;
                e++
            }
            return b
        },
        l = function(a) {
            var b = $("#popup_alert");
            b.find(".msg-text").html(a);
            "sec" === SITE_CD && b.find(".pop-btn").find(".button").text("\ud655\uc778");
            $(".layer_popup").hide();
            b.parent().show();
            "sec" === SITE_CD ? $(".lightbox-skrim").show() : $(".lightbox-skrim").hide();
            a = parseInt(($("body").width() - b.width()) / 2);
            var e = parseInt($(window).scrollTop() + ($(window).height() - b.height()) / 2);
            $(window).height() < b.height() && (e = $(window).scrollTop() + 10);
            b.css({
                top: e + "px",
                left: a + "px"
            });
            $("#popup_alert .popup_wrap .pop-btn").find("a").focus()
        },
        e = function(b, d, e) {
            var c = !1; - 1 < location.href.indexOf("/consumer") && (c = !0);
            var h = $("#hybrisApiJson").val(),
                g = "";
            "ae" == SITE_CD || "ae_ar" == SITE_CD ? (g = $.cookies.get("dotcom_multistore") ? $.cookies.get("dotcom_multistore").toString() : "", g = fnIsNull(g) ? SITE_CD : g) : "levant" == SITE_CD ? g = "jo" :
                "levant_ar" == SITE_CD ? g = "jo_ar" : "n_africa" == SITE_CD && (g = "ma");
            var m = "";
            if ("addCart" === b)
                if ("co" === SITE_CD || "pe" === SITE_CD || "ar" === SITE_CD || "br" === SITE_CD) m = STORE_DOMAIN + "/" + SITE_CD + "/getServicesProduct" + (d ? a(d) : ""), window.location.href = m;
                else if ("py" === SITE_CD || "mx" === SITE_CD || "cl" === SITE_CD) m = "cl" == SITE_CD ? STORE_DOMAIN.replace("/api/io", "") + "/getServicesProduct" + (d ? a(d) : "") : STORE_DOMAIN + "/getServicesProduct" + (d ? a(d) : ""), window.location.href = m;
            m = "ar" !== SITE_CD && "co" !== SITE_CD && "pe" !== SITE_CD && "br" !==
                SITE_CD || "getCartCount" !== b ? "py" === SITE_CD || "mx" === SITE_CD || "cl" === SITE_CD ? "getCartCount" === b ? STORE_DOMAIN + "/_v/private/ng/p4v1/" + b + (d ? a(d) : "") : STORE_DOMAIN + "/ng/p4v1/" + b + (d ? a(d) : "") : "" != g ? STORE_DOMAIN + "/" + g + "/ng/p4v1/" + b + (d ? a(d) : "") : STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/" + b + (d ? a(d) : "") : STORE_DOMAIN + "/" + SITE_CD + "/_v/private/ng/p4v1/" + b + (d ? a(d) : "");
            "getRealTimeProductSimpleInfo" === b && c && "br" !== SITE_CD && "Y" !== h ? $.ajax({
                url: m,
                type: "GET",
                dataType: "jsonp",
                jsonpCallback: "jQuery1910499421933433041_1385598221584",
                jsonp: "callback",
                success: function(a) {
                    "2100" === a.resultCode || 2100 === a.resultCode ? d && d.hasOwnProperty("returnUrl") && "" !== d.returnUrl ? $.Auth.signOut(d.returnUrl) : $.Auth.signOut() : "cn" !== SITE_CD || "0000" === a.resultCode || "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "sec" !== SITE_CD || "0000" === a.resultCode ||
                        "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || "2002" === a.resultCode || 2002 === a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "cn" !== SITE_CD && "sec" !== SITE_CD && "0000" !== a.resultCode && "9000" !== a.resultCode && "9001" !== a.resultCode && "9002" !== a.resultCode && 9E3 !== a.resultCode && 9001 !== a.resultCode && 9002 !== a.resultCode && "2110" !== a.resultCode &&
                        2110 !== a.resultCode && l(a.resultMessage) : l(a.resultMessage) : l(a.resultMessage);
                    $.isFunction(e) && e(a)
                },
                error: function(a, b, c) {}
            }) : "getRealTimeProductSimpleInfo" === b && "sec" === SITE_CD ? $.ajax({
                url: m,
                type: "GET",
                dataType: "jsonp",
                jsonpCallback: "jQuery1910499421933433041_1385598221584",
                jsonp: "callback",
                timeout: 1E4,
                success: function(a) {
                    "2100" === a.resultCode || 2100 === a.resultCode ? d && d.hasOwnProperty("returnUrl") && "" !== d.returnUrl ? $.Auth.signOut(d.returnUrl) : $.Auth.signOut() : "cn" !== SITE_CD || "0000" === a.resultCode ||
                        "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "sec" !== SITE_CD || "0000" === a.resultCode || "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || "2002" === a.resultCode || 2002 ===
                        a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "cn" !== SITE_CD && "sec" !== SITE_CD && "0000" !== a.resultCode && "9000" !== a.resultCode && "9001" !== a.resultCode && "9002" !== a.resultCode && 9E3 !== a.resultCode && 9001 !== a.resultCode && 9002 !== a.resultCode && "2110" !== a.resultCode && 2110 !== a.resultCode && l(a.resultMessage) : (-1 !== a.resultMessage.indexOf("\uad6c\ub9e4 \ud55c\ub3c4\ub97c \ucd08\uacfc\ud558\uc5ec \uad6c\ub9e4\uac00 \ubd88\uac00\ub2a5\ud569\ub2c8\ub2e4.\x3cbr /\x3e") &&
                            (a.resultMessage = "\uad6c\ub9e4 \ud55c\ub3c4" + a.resultMessage.split("\uad6c\ub9e4 \ud55c\ub3c4")[1].replace("\x3cbr /\x3e", "\n")), l(a.resultMessage)) : l(a.resultMessage);
                    $.isFunction(e) && e(a)
                },
                error: function(a, b, c) {
                    "au" !== SITE_CD && "nz" !== SITE_CD && "sec" !== SITE_CD || window.location.pathname !== "/" + SITE_CD + "/wishlist" || e();
                    "sec" === SITE_CD && "timeout" === c && $("#product-detail-current-modelcode").val() && ($("#BT_shop .BT_txt").html("\ud574\ub2f9 \uc0c1\ud488\uc744 \ud310\ub9e4 \uc900\ube44\ud558\uace0 \uc788\uc2b5\ub2c8\ub2e4. \uad6c\ub9e4 \uac00\ub2a5 \uc5ec\ubd80\ub294\x3cbr /\x3e\uac00\uae4c\uc6b4 \ub9e4\uc7a5\uc774\ub098 \uc0bc\uc131\uc804\uc790 \uacf5\uc2dd \ud310\ub9e4\ucc98\uc5d0 \ubb38\uc758\ud558\uc2dc\uae30 \ubc14\ub78d\ub2c8\ub2e4."),
                        $("#BT_shop").show(), $("#BT_shop .product-details__link.s-cta-retailer.js-cta-buy-sec").hide(), $("#BT_shop .BT_help").hide(), $("#BT_shop .BT_help-content").hide(), $("#BT_shop .BT_txt").show(), $("#find-store-shopmain").show(), $("#store-reservation").hide())
                }
            }) : "getRealTimeProductSimpleInfo" === b && c && "Y" === h ? $.ajax({
                url: m,
                type: "GET",
                dataType: "json",
                xhrFields: {
                    withCredentials: !0
                },
                contentType: "application/x-www-form-urlencoded",
                crossDomain: !0,
                success: function(a) {
                    "2100" === a.resultCode || 2100 === a.resultCode ?
                        d && d.hasOwnProperty("returnUrl") && "" !== d.returnUrl ? $.Auth.signOut(d.returnUrl) : $.Auth.signOut() : "cn" !== SITE_CD || "0000" === a.resultCode || "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "sec" !== SITE_CD || "0000" === a.resultCode || "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode ||
                        9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || "2002" === a.resultCode || 2002 === a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "cn" !== SITE_CD && "sec" !== SITE_CD && "0000" !== a.resultCode && "9000" !== a.resultCode && "9001" !== a.resultCode && "9002" !== a.resultCode && 9E3 !== a.resultCode && 9001 !== a.resultCode && 9002 !== a.resultCode && "2110" !== a.resultCode && 2110 !== a.resultCode && l(a.resultMessage) : l(a.resultMessage) :
                        l(a.resultMessage);
                    $.isFunction(e) && e(a)
                },
                error: function(a, b, c) {}
            }) : "getRealTimeProductSimpleInfo" === b || c || "Y" !== h ? $.ajax({
                url: m,
                type: "GET",
                dataType: "jsonp",
                jsonp: "callback",
                success: function(a) {
                    "2100" === a.resultCode ? d && d.hasOwnProperty("returnUrl") && "" !== d.returnUrl ? $.Auth.signOut(d.returnUrl) : $.Auth.signOut() : "cn" !== SITE_CD || "0000" === a.resultCode || "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode ||
                        2110 === a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "sec" !== SITE_CD || "0000" === a.resultCode || "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || "2002" === a.resultCode || 2002 === a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "cn" !== SITE_CD && "sec" !== SITE_CD && "0000" !== a.resultCode &&
                        "9000" !== a.resultCode && "9001" !== a.resultCode && "9002" !== a.resultCode && 9E3 !== a.resultCode && 9001 !== a.resultCode && 9002 !== a.resultCode && "2110" !== a.resultCode && 2110 !== a.resultCode && l(a.resultMessage) : (-1 !== a.resultMessage.indexOf("\uad6c\ub9e4 \ud55c\ub3c4\ub97c \ucd08\uacfc\ud558\uc5ec \uad6c\ub9e4\uac00 \ubd88\uac00\ub2a5\ud569\ub2c8\ub2e4.\x3cbr /\x3e") && (a.resultMessage = "\uad6c\ub9e4 \ud55c\ub3c4" + a.resultMessage.split("\uad6c\ub9e4 \ud55c\ub3c4")[1].replace("\x3cbr /\x3e", "\n")), l(a.resultMessage)) :
                        l(a.resultMessage);
                    $.isFunction(e) && e(a)
                },
                error: function(a, b, c) {
                    "au" !== SITE_CD && "nz" !== SITE_CD && "sec" !== SITE_CD || window.location.pathname !== "/" + SITE_CD + "/wishlist" || e()
                }
            }) : $.ajax({
                url: m,
                type: "GET",
                dataType: "json",
                xhrFields: {
                    withCredentials: !0
                },
                contentType: "application/x-www-form-urlencoded",
                crossDomain: !0,
                success: function(a) {
                    "2100" === a.resultCode || 2100 === a.resultCode ? d && d.hasOwnProperty("returnUrl") && "" !== d.returnUrl ? $.Auth.signOut(d.returnUrl) : $.Auth.signOut() : "cn" !== SITE_CD || "0000" === a.resultCode ||
                        "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "sec" !== SITE_CD || "0000" === a.resultCode || "9000" === a.resultCode || "9001" === a.resultCode || "9002" === a.resultCode || 9E3 === a.resultCode || 9001 === a.resultCode || 9002 === a.resultCode || "2110" === a.resultCode || 2110 === a.resultCode || "2002" === a.resultCode || 2002 ===
                        a.resultCode || 4 !== a.resultCode.length || "2" !== a.resultCode.charAt(0) && "3" !== a.resultCode.charAt(0) ? "cn" !== SITE_CD && "sec" !== SITE_CD && "0000" !== a.resultCode && "9000" !== a.resultCode && "9001" !== a.resultCode && "9002" !== a.resultCode && 9E3 !== a.resultCode && 9001 !== a.resultCode && 9002 !== a.resultCode && "2110" !== a.resultCode && 2110 !== a.resultCode && l(a.resultMessage) : (-1 !== a.resultMessage.indexOf("\uad6c\ub9e4 \ud55c\ub3c4\ub97c \ucd08\uacfc\ud558\uc5ec \uad6c\ub9e4\uac00 \ubd88\uac00\ub2a5\ud569\ub2c8\ub2e4.\x3cbr /\x3e") &&
                            (a.resultMessage = "\uad6c\ub9e4 \ud55c\ub3c4" + a.resultMessage.split("\uad6c\ub9e4 \ud55c\ub3c4")[1].replace("\x3cbr /\x3e", "\n")), l(a.resultMessage)) : l(a.resultMessage);
                    $.isFunction(e) && e(a)
                },
                error: function(a, b, c) {
                    "au" !== SITE_CD && "nz" !== SITE_CD && "sec" !== SITE_CD || window.location.pathname !== "/" + SITE_CD + "/wishlist" || e()
                }
            })
        },
        g = function() {};
    g.prototype.makeBuyNowCookie = function(a) {
        $.EstoreIfQueue.setQueue(e, "makeBuyNowCookie", null, a)
    };
    g.prototype.addCart = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "addCart",
            a, d)
    };
    g.prototype.getCartCount = function(a) {
        $.EstoreIfQueue.setQueue(e, "getCartCount", null, a)
    };
    g.prototype.getRealTimeProductSimpleInfo = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getRealTimeProductSimpleInfo", a, d)
    };
    g.prototype.getRealTimeProductListInfo = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getRealTimeProductListInfo", a, d)
    };
    g.prototype.addWishListItem = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "addWishListItem", a, d)
    };
    g.prototype.addWishListItemForce = function(a, d) {
        e("addWishListItem", a, d)
    };
    g.prototype.delWishListItem =
        function(a, d) {
            $.EstoreIfQueue.setQueue(e, "delWishListItem", a, d)
        };
    g.prototype.getWishList = function(a, d) {
        var b = {
            page: 1,
            pageSize: 5
        };
        a && !$.isFunction(a) && (b = $.extend(b, a));
        $.EstoreIfQueue.setQueue(e, "getWishList", b, d)
    };
    g.prototype.login = function(a) {
        $.EstoreIfQueue.setQueue(e, "login", null, a)
    };
    g.prototype.logout = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "logout", a, d)
    };
    g.prototype.getRealTimeWishProductListInfo = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getRealTimeWishProductListInfo", a, d)
    };
    g.prototype.getGuestOrderExistYn =
        function(a, d) {
            $.EstoreIfQueue.setQueue(e, "getGuestOrderExistYn", a, d)
        };
    g.prototype.getSnsUserInfo = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getSnsUserInfo", a, d)
    };
    g.prototype.setAgreeStorePolicy = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "setAgreeStorePolicy", a, d)
    };
    g.prototype.getSessionCheck = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getSessionCheck", a, d)
    };
    g.prototype.getEstoreCategoryList = function(a) {
        $.EstoreIfQueue.setQueue(e, "getEstoreCategoryList", null, a)
    };
    g.prototype.getCurrentUserInfo = function(a,
        d) {
        $.EstoreIfQueue.setQueue(e, "getCurrentUserInfo", a, d)
    };
    g.prototype.buyNow = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "buyNow", a, d)
    };
    g.prototype.getReviews = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getReviewList", a, d)
    };
    g.prototype.getMyReview = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getMyReview", a, d)
    };
    g.prototype.addReview = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "addReview", a, d)
    };
    g.prototype.updateReview = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "updateReview", a, d)
    };
    g.prototype.deleteReview = function(a,
        d) {
        $.EstoreIfQueue.setQueue(e, "deleteReview", a, d)
    };
    g.prototype.addReviewHelpful = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "setReviewHelpful", a, d)
    };
    g.prototype.addReviewHelpful = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "setReviewHelpful", a, d)
    };
    g.prototype.addReviewUnHelpful = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "setReviewUnHelpful", a, d)
    };
    g.prototype.addReviewAbuse = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "setReviewAbuse", a, d)
    };
    g.prototype.getExpertReviewList = function(a, d) {
        $.EstoreIfQueue.setQueue(e,
            "getExpertReviewList", a, d)
    };
    g.prototype.getProductDetailRegion = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getProductDetailRegion", a, d)
    };
    g.prototype.getProductDetailCity = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getProductDetailCity", a, d)
    };
    g.prototype.showProductOpenphoneOption = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "showProductOpenphoneOption", a, d)
    };
    g.prototype.preCalc = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "preCalc", a, d)
    };
    g.prototype.preCalcApply = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "preCalcApply",
            a, d)
    };
    g.prototype.stores = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "stores", a, d)
    };
    g.prototype.getReviewStatus = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "getReviewStatus", a, d)
    };
    g.prototype.addViewCount = function(a, d) {
        $.EstoreIfQueue.setQueue(e, "addViewCount", a, d)
    };
    return new g
}();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.utils,
        e = window.sg.common.constants.KEY_CODE,
        g = window.sg.common.lazyLoad,
        b = null,
        d = function(b) {
            this.selector = {
                gnbMenuWrap: ".gnb__menu-wrap",
                depth1: ".gnb__depth1",
                depth1Menu: ".gnb__depth1-menu",
                depth1Link: ".gnb__depth1-link",
                depth2: ".gnb__depth2",
                depth2Wrap: ".gnb__depth2-wrap",
                depth2Inner: ".gnb__depth2-inner",
                depth2Menu: ".gnb__depth2-menu",
                depth2Link: ".gnb__depth2-link",
                depth2Close: ".gnb__depth2-close",
                depth3Wrap: ".gnb__depth3-wrap",
                depth3Inner: ".gnb__depth3-inner",
                depth3Menu: ".gnb__depth3-menu",
                depth3Link: ".gnb__depth3-link",
                featureContainer: ".gnb__feature-container",
                loginBtn: ".gnb__logout-btn, .gnb__login-btn",
                loginLayer: ".gnb__login-layer",
                cartBtn: ".gnb__cart-btn",
                layerOpenBtn: ".js-layer-open",
                layerCloseBtn: ".layer-popup__close, .gnb-js-layer-close",
                layerWrap: ".layer-popup",
                layerDim: ".layer-popup-dim",
                hasDepthMenu: "has-depth-menu",
                gnbDim: ".gnb__dimmed",
                countryBtn: ".gnb__country-cta",
                countryLayer: ".gnb__country-layer",
                countrySelect: ".gnb__country-select",
                searchBtn: ".gnb__search-btn",
                desktopUtilLink: ".gnb__login-layer .gnb__utility-link"
            };
            this.mobileSelector = {
                gnbContainer: ".gnb__depth1-container",
                gnbMenuBtn: ".gnb__menu-btn",
                gnbMenuClose: ".gnb__menu-close",
                gnbDepthBack: ".gnb__depth-back",
                utilLink: ".gnb__utility-mobile .gnb__utility-link"
            };
            this.el = {
                body: null,
                window: null,
                component: a(b)
            };
            this.mobileEl = {
                gnbMenuBtn: null
            };
            this.handler = {
                resize: this.resize.bind(this)
            };
            d.instances.set(b, this);
            this.setElement();
            this.init()
        };
    d.prototype.setElement = function() {
        this.el.body =
            a("body");
        this.el.window = a(window);
        this.el.depth1 = this.el.component.find(this.selector.depth1);
        this.el.gnbMenuWrap = this.el.component.find(this.selector.gnbMenuWrap);
        this.el.depth1Menu = this.el.component.find(this.selector.depth1Menu);
        this.el.depth1Link = this.el.component.find(this.selector.depth1Link);
        this.el.depth2Wrap = this.el.component.find(this.selector.depth2Wrap);
        this.el.depth2Inner = this.el.component.find(this.selector.depth2Inner);
        this.el.depth2Menu = this.el.component.find(this.selector.depth2Menu);
        this.el.depth2Link = this.el.component.find(this.selector.depth2Link);
        this.el.depth2Close = this.el.component.find(this.selector.depth2Close);
        this.el.depth3Wrap = this.el.component.find(this.selector.depth3Wrap);
        this.el.loginBtn = this.el.component.find(this.selector.loginBtn);
        this.el.loginLayer = this.el.component.find(this.selector.loginLayer);
        this.el.cartBtn = this.el.component.find(this.selector.cartBtn);
        this.el.layerOpenBtn = this.el.component.find(this.selector.layerOpenBtn);
        this.el.layerCloseBtn = this.el.component.find(this.selector.layerCloseBtn);
        this.el.layerDim = this.el.component.find(this.selector.layerDim);
        this.el.gnbDim = this.el.component.find(this.selector.gnbDim);
        this.el.depth1First = this.el.depth1Menu.eq(0).find(this.selector.depth1Link);
        this.el.featureContainer = this.el.component.find(this.selector.featureContainer);
        this.el.countryBtn = this.el.component.find(this.selector.countryBtn);
        this.el.countryLayer = this.el.component.find(this.selector.countryLayer);
        this.el.countrySelect = this.el.countryLayer.find(this.selector.countrySelect);
        this.el.searchBtn =
            this.el.countryLayer.find(this.selector.searchBtn);
        this.el.desktopUtilLink = this.el.component.find(this.selector.desktopUtilLink);
        this.mobileEl.gnbContainer = this.el.component.find(this.mobileSelector.gnbContainer);
        this.mobileEl.gnbMenuBtn = this.el.component.find(this.mobileSelector.gnbMenuBtn);
        this.mobileEl.gnbMenuClose = this.el.component.find(this.mobileSelector.gnbMenuClose);
        this.mobileEl.gnbDepthBack = this.el.component.find(this.mobileSelector.gnbDepthBack);
        this.mobileEl.utilLink = this.el.component.find(this.mobileSelector.utilLink);
        this.breakpoint = 1279;
        this.viewPortSize = 1440;
        this.mobileFlag = this.desktopFlag = this.depth2Flag = !1;
        this.loginFlag = this.dimHideFlag = this.dimShowFlag = null;
        this.dimEventFlag = !1;
        this.animateTime = null;
        this.subOpenFlag = !1;
        this.countryFlag = null
    };
    d.prototype.init = function() {
        this.bindEvents()
    };
    d.prototype.reInit = function() {
        this.setElement();
        this.bindEvents()
    };
    d.prototype.resize = function() {
        var a = this;
        this.breakpoint < l.getViewPort().width ? !1 === this.desktopFlag && (this.desktopFlag = !0, this.mobileFlag = !1, this.el.gnbMenuWrap.css({
                transition: "none"
            }),
            this.deactiveMobileGnb(), this.resetGnb(), this.unbindEvents(), this.bindEvents(), setTimeout(function() {
                a.el.gnbMenuWrap.css({
                    transition: ""
                })
            }, 50)) : !1 === this.mobileFlag && (this.desktopFlag = !1, this.mobileFlag = !0, this.el.gnbMenuWrap.css({
            transition: "none"
        }), this.deactiveGnb(), this.deactiveSnb(), this.resetGnb(), this.unbindEvents(), this.bindEvents(), setTimeout(function() {
            a.el.gnbMenuWrap.css({
                transition: ""
            })
        }, 50))
    };
    d.prototype.toggleGnb = function(a) {
        a.parent().hasClass("active") || (this.deactiveGnb(a), a.closest(".gnb__depth1-menu").hasClass("has-depth-menu") &&
            this.activeGnb(a))
    };
    d.prototype.deactiveGnb = function(b) {
        var c = this,
            d = void 0 !== b ? !b.parent().hasClass(this.selector.hasDepthMenu) : !1;
        this.subOpenFlag = !1;
        null !== this.dimShowFlag && (clearTimeout(this.dimShowFlag), this.dimShowFlag = null);
        null !== this.animateTime && (clearTimeout(this.animateTime), this.animateTime = null);
        this.el.depth1Link.target.forEach(function(b) {
            var e = a(b).parent(),
                h = e.find(c.selector.depth2Inner);
            b = h.find(c.selector.depth2);
            var g = e.find(c.selector.depth2Close),
                l = function() {
                    h.removeAttr("style");
                    h.removeClass("active");
                    e.find(c.selector.depth2Wrap).css({
                        visibility: "hidden"
                    });
                    e.find(c.selector.depth2Menu).removeClass("active");
                    "visible" === g.css("visibility") && g.css({
                        visibility: "hidden"
                    })
                },
                m = function() {
                    g.finish().animate({
                        opacity: 0
                    }, 400, "cubic-bezier(.4,0,.2,1)", function() {
                        g.css({
                            visibility: "hidden"
                        })
                    })
                };
            e.hasClass("active") && (b.removeClass("active"), e.find(c.selector.depth1Link).removeClass("active"), c.el.gnbMenuWrap.removeClass("active"), d ? (c.setHeight(h, 0, "animate", l), m(), e.removeClass("active"),
                c.el.gnbDim.hasClass("open") ? (c.el.gnbDim.removeClass("open"), c.dimHideFlag = setTimeout(function() {
                    c.el.gnbDim.hide()
                }, 600)) : c.el.gnbDim.hasClass("open") || "block" !== c.el.gnbDim.css("display") || (c.el.gnbDim.hide(), l()), c.depth2Flag = !1) : (l(), m(), e.removeClass("active"), setTimeout(function() {
                c.setHeight(h, 0, "css")
            }, 30)))
        });
        a(this.selector.depth2Link + " \x3e svg.icon--next").css({
            "transition-delay": ".2s, .2s"
        });
        this.dimEventFlag = !1
    };
    d.prototype.activeGnb = function(b) {
        var c = this;
        null !== this.dimHideFlag &&
            (clearTimeout(this.dimHideFlag), this.dimHideFlag = null);
        var d = b.parent(),
            e = d.find(this.selector.depth2Inner),
            l = e.find(this.selector.depth2),
            n = null;
        !1 === this.openFlag && a(".gnb__depth2-link \x3e svg.icon").css({
            "transition-delay": ".2s, .2s"
        });
        n = 0 < d.find(this.selector.depth2Menu).target.length && 1 > d.find(this.selector.depth2Menu + ":not(.gnb-api--mobile-only)").target.length ? d.find(this.selector.depth2Menu).eq(0).find(this.selector.depth2Link) : d.find(this.selector.depth2Menu + ":not(.gnb-api--mobile-only)").eq(0).find(this.selector.depth2Link);
        this.activeSnb(n);
        this.el.depth2Close.target.forEach(function(b) {
            b = a(b);
            "0" === b.css("opacity") && "visible" === b.css("visibility") && b.css({
                visibility: "hidden"
            })
        });
        b.addClass("active");
        d.addClass("active");
        e.addClass("active");
        l.addClass("active");
        d.find(this.selector.depth2Close).finish().css({
            visibility: "visible"
        });
        d.find(this.selector.depth2Close).animate({
            opacity: 1
        }, 400, "cubic-bezier(.4,0,.2,1)");
        this.el.gnbMenuWrap.addClass("active");
        d.find(this.selector.depth2Wrap).css({
            visibility: "visible"
        });
        a(this.selector.depth2Link +
            " \x3e svg.icon--next").css({
            "transition-delay": ""
        });
        g.setLazyLoadManually(d.target[0]);
        this.el.gnbDim.hasClass("open") || (this.el.gnbDim.show(), this.dimShowFlag = setTimeout(function() {
            c.el.gnbDim.addClass("open")
        }, 50));
        this.depth2Flag = !0
    };
    d.prototype.deactiveSnb = function() {
        var b = this;
        this.el.depth2Link.target.forEach(function(c) {
            c = a(c).parent();
            c.hasClass("active") && c.removeClass("active");
            "us" === siteCode && (c.closest(b.selector.depth2Wrap).addClass("one-col"), c.closest(b.selector.depth2Wrap).removeClass("all"),
                a(".gnb__feature-container").removeClass("active"), a(".gnb__feature-container").target.forEach(function(a) {
                    a.innerHTML = ""
                }))
        })
    };
    d.prototype.activeSnb = function(a) {
        var b = this,
            c = 672,
            d = a.parent(),
            e = d.closest(this.selector.depth2Inner),
            g = d.find(this.selector.depth3Wrap),
            l = a.closest(this.selector.depth2Inner).find(this.selector.depth2Menu);
        this.deactiveSnb();
        d.hasClass("active") || (d.addClass("active"), "us" === siteCode && d.closest(this.selector.depth2Wrap).removeClass("one-col"), "us" === siteCode && d.closest(this.selector.depth2Wrap).addClass("all"),
            d = a.closest(this.selector.depth2Inner).find(".gnb__depth2-title-wrap").outerHeight() + 24, l = l.parent().outerHeight() + d, g = g.target.length ? g.outerHeight() + 6 + d : 0, c = l > g ? l > c ? l : c : g > c ? g : c, !1 === this.depth2Flag || !0 === this.subOpenFlag ? (this.setHeight(e, c, "animate"), this.animateTime = setTimeout(function() {
                b.dimEventFlag = !0
            }, 500)) : (this.setHeight(e, c, "css"), this.dimEventFlag = !0), "us" === siteCode && this.activeDepth2Img(a))
    };
    d.prototype.activeDepth2Img = function(a, b) {
        !b && a.closest(this.selector.depth2Inner).find(".gnb__feature-container").addClass("active");
        var c = a.closest(this.selector.depth2Inner).find(".gnb__depth2-title-text").target[0].textContent || "",
            d = document.createElement("div");
        d.setAttribute("class", "hybrid-class");
        var e = function(a) {
            a = (a || "").replace(/\+/gi, "plus").replace(/&/gi, "and").replace(/\$/gi, "dollar").replace(/%/gi, "percentage").replace(/"/gi, "inches");
            a = a.replace(/\||\-|~|,|\.|!|\?|@|=|#|\*|'/gi, "");
            return a.toLowerCase()
        };
        d.innerHTML = a.attr("data-flyout-img") ? '\n      \x3cdiv class\x3d"glide"\x3e\n        \x3cdiv class\x3d"glide__track" data-glide-el\x3d"track"\x3e\n          \x3cul class\x3d"glide__slides"\x3e\n            \x3cli class\x3d"glide__slide"\x3e\n              \x3ca class\x3d"gnb__feature-container-link" href\x3d"' +
            a.attr("data-flyout-url") + '" an-tr\x3d"nv00_gnb--cta-feature" an-ca\x3d"navigation" an-ac\x3d"gnb" an-la\x3d"feature image:' + e(c) + ": " + e(a.target[0].text) + ":" + e(a.attr("data-flyout-text")) + '" data-link_cat\x3d"navigation" data-link_id\x3d"' + a.target[0].text + '" data-link_meta\x3d"link_name:' + a.target[0].text + '" data-link_position\x3d"navigation\x3egnb\x3e' + c + "\x3e" + a.target[0].text + '" data-event_name\x3d"select_' + a.target[0].text + '_click"\x3e\n            \x3cdiv class\x3d"image"\x3e\n              \x3cimg class\x3d"image__main image--loaded" src\x3d"' +
            a.attr("data-flyout-img") + '"/\x3e\n            \x3c/div\x3e\n            \x3cdiv class\x3d"gnb__feature-container-contents"\x3e\n              \x3cp class\x3d"gnb__feature-container-description ' + a.attr("data-flyout-theme") + '"\x3e' + a.attr("data-flyout-text") + '\x3c/p\x3e\n              \x3cspan class\x3d"cta cta--contained hidden cta--black"\x3e' + a.target[0].text + "\x3c/span\x3e\n            \x3c/div\x3e\n          \x3c/a\x3e\n            \x3c/li\x3e\n          \x3c/ul\x3e\n        \x3c/div\x3e\n      \x3c/div\x3e" :
            "";
        b ? document.querySelector(".gnb__depth2-menu.has-depth-menu.open .gnb__depth3 .hybrid-class") || document.querySelector(".gnb__depth2-menu.has-depth-menu.open .gnb__depth3").appendChild(d) : document.querySelector(".gnb__feature-container.active") && (document.querySelector(".gnb__feature-container.active").innerHTML = "", document.querySelector(".gnb__feature-container.active").appendChild(d));
        g.setLazyLoad()
    };
    d.prototype.setHeight = function(a, b, d, e) {
        var c = 0;
        0 !== b && (c = b + "px");
        "css" === d ? a.css({
            transition: "none",
            height: c
        }) : (a.css({
            transition: ""
        }), a.stop().animate({
            height: c
        }, 500, "Cubic-bezier (0.4, 0, 0.2, 1)", e))
    };
    d.prototype.deactiveLoginMenu = function() {
        this.el.loginLayer.removeClass("active");
        this.loginFlag = null
    };
    d.prototype.activeLoginMenu = function() {
        g.setLazyLoadManually(this.el.component.find(".gnb__user-image").target[0]);
        this.el.loginLayer.addClass("active")
    };
    d.prototype.deactiveCountry = function() {
        this.el.countryBtn.removeClass("active");
        this.el.countryLayer.removeClass("active");
        this.countryFlag =
            null
    };
    d.prototype.activeCountry = function() {
        g.setLazyLoadManually(this.el.countryLayer.target[0]);
        this.el.countryBtn.addClass("active");
        this.el.countryLayer.addClass("active")
    };
    d.prototype.moveActiveMenu = function() {
        var b = this,
            d = [];
        this.el.depth1Menu.target.forEach(function(c) {
            c = a(c);
            c.hasClass("active-first") && (d.push(c.find(b.selector.depth1Link)), c.find(b.selector.depth2Menu).target.forEach(function(c) {
                c = a(c);
                c.hasClass("active-second") && d.push(c.find(b.selector.depth2Link))
            }))
        });
        0 < d.length && this.activeMobileFirstMenu(d[0],
            d[1])
    };
    d.prototype.activeMobileGnb = function() {
        this.el.component.css({
            position: "fixed",
            width: "100%"
        });
        a("#content").css({
            "padding-top": "56px"
        });
        this.el.gnbMenuWrap.addClass("open");
        this.el.depth1.addClass("open");
        this.mobileEl.gnbDepthBack.attr("tabindex", "-1");
        this.el.component.hasClass("js-mobile-open") && this.moveActiveMenu();
        l.hiddenScroll()
    };
    d.prototype.deactiveMobileGnb = function(b) {
        var c = this;
        this.mobileEl.gnbContainer.removeClass("slide");
        this.el.gnbMenuWrap.removeClass("open");
        this.el.depth1.removeClass("open");
        this.el.component.css({
            position: "",
            width: ""
        });
        a("#content").css({
            "padding-top": ""
        });
        this.el.depth1Menu.target.forEach(function(b, d) {
            b = a(b);
            b.hasClass("open") && (c.activeFirst = d, b.removeClass("open"), b.find(c.selector.depth2Wrap).hide(), b.find(c.selector.depth2Wrap).removeClass("open"), b.find(c.selector.depth2Menu).target.forEach(function(b, d) {
                b = a(b);
                b.hasClass("open") && (c.activeSecond = d, b.removeClass("open"))
            }))
        });
        this.el.depth1Link.removeAttr("tabindex");
        this.mobileEl.utilLink.removeAttr("tabindex");
        l.visibleScroll();
        b && this.mobileEl.gnbMenuBtn.focus()
    };
    d.prototype.activeMobileFirstMenu = function(b, d) {
        var c = this;
        b = b.parent();
        this.mobileEl.gnbDepthBack.removeAttr("tabindex");
        b.hasClass(this.selector.hasDepthMenu) && (b.addClass("open"), this.mobileEl.gnbContainer.addClass("slide"), b.find(this.selector.depth2Wrap).css({
            display: "block"
        }), this.el.depth2Menu.target.forEach(function(b) {
            b = a(b);
            if (b.hasClass(c.selector.hasDepthMenu)) {
                var d = b.find(c.selector.depth3Inner).height();
                "us" === siteCode && 0 == b.find(".hybrid-class .gnb__feature-container-link").target.length &&
                    (d += 400);
                b.find(c.selector.depth3Inner).attr("data-height", d);
                b.hasClass("open") || b.find(c.selector.depth3Wrap).css({
                    height: "0"
                })
            }
        }), b.find(this.selector.depth2Wrap).addClass("open"), this.el.depth1Link.attr("tabindex", "-1"), this.mobileEl.utilLink.attr("tabindex", "-1"), b.find(this.selector.depth2Inner).scrollTop(0));
        void 0 !== d && setTimeout(function() {
            c.activeMobileSecondMenu(d)
        }, 600);
        g.setLazyLoadManually(b.target[0])
    };
    d.prototype.activeMobileSecondMenu = function(b) {
        var c = this,
            d = b.parent();
        if (0 < d.find(".icon--dropdown").target.length) {
            var e =
                56 * d.index();
            if (d.hasClass("open")) d.hasClass(this.selector.hasDepthMenu) && (d.find(this.selector.depth3Wrap).css({
                height: "0"
            }), setTimeout(function() {
                d.closest(c.selector.depth2Inner).moveScroll(0, 100)
            }, 200), setTimeout(function() {
                d.find(c.selector.depth3Wrap).css({
                    visibility: "hidden"
                })
            }, 300)), d.removeClass("open");
            else {
                var g = null;
                this.el.depth2Menu.target.forEach(function(b) {
                    b = a(b);
                    b.hasClass("open") && (g = b.find(c.selector.depth3Wrap), g.css({
                            "transition-duration": ".2s",
                            visibility: "hidden",
                            height: "0"
                        }),
                        b.removeClass("open"))
                });
                d.addClass("open");
                "us" === siteCode && this.activeDepth2Img(b, !0);
                d.hasClass(this.selector.hasDepthMenu) && (b = parseInt(d.find(this.selector.depth3Inner).attr("data-height")), d.find(this.selector.depth3Wrap).css({
                    visibility: "visible",
                    height: b + 17 + "px"
                }), setTimeout(function() {
                    null !== g && (g.css({
                        "transition-duration": ""
                    }), g = null);
                    d.closest(c.selector.depth2Inner).moveScroll(e, 100)
                }, 200))
            }
        }
    };
    d.prototype.backDepthMobile = function() {
        var b = this,
            d = 0;
        this.el.depth1Link.removeAttr("tabindex");
        this.mobileEl.utilLink.removeAttr("tabindex");
        this.el.depth1Menu.target.forEach(function(c, e) {
            var g = a(c);
            g.hasClass("open") && (d = e, b.mobileEl.gnbContainer.removeClass("slide"), g.removeClass("open"), g.find(b.selector.depth2Link).removeClass("open"), g.find(b.selector.depth2Menu).removeClass("open"), g.find(b.selector.depth2Wrap).removeClass("open"), g.find(b.selector.depth2Inner).scrollTop(0), setTimeout(function() {
                g.find(b.selector.depth2Wrap).css({
                    display: "none"
                })
            }, 200), g.find(b.selector.depth3Wrap).target.forEach(function(b) {
                a(b).css({
                    height: ""
                })
            }))
        });
        this.el.depth1Menu.eq(d).find(this.selector.depth1Link).focus();
        this.mobileEl.gnbContainer.trigger("scroll")
    };
    d.prototype.setFocusFoward = function(b) {
        var c = this,
            d = !1;
        b.keyCode === e.TAB && !1 === b.shiftKey && (this.el.depth1Menu.target.forEach(function(b) {
            b = a(b);
            b.hasClass("open") && (b.find(c.mobileSelector.gnbDepthBack).focus(), d = !0)
        }), !1 === d && this.el.depth1First.focus());
        b.preventDefault()
    };
    d.prototype.setFocusReverse = function(a) {
        a.keyCode === e.TAB && !0 === a.shiftKey && (this.mobileEl.gnbMenuClose.focus(), a.preventDefault())
    };
    d.prototype.setCloseFocus = function(b) {
        var c = this,
            d = !1;
        b.keyCode === e.TAB && !1 === b.shiftKey ? (this.el.depth1Menu.target.forEach(function(b) {
            b = a(b);
            b.hasClass("open") && (b.find(c.mobileSelector.gnbDepthBack).focus(), d = !0)
        }), !1 === d && this.el.depth1First.focus(), b.preventDefault()) : b.keyCode === e.ENTER && (this.deactiveMobileGnb(!0), b.preventDefault())
    };
    d.prototype.openPopup = function(b) {
        b = a("" + b.dataset.divId);
        "none" === b.css("display") ? (this.el.layerDim.show(), b.attr("tabindex", "0"), b.show(), b.focus()) : this.closePopup()
    };
    d.prototype.closePopup = function(b) {
        b = a(b.closest(this.selector.layerWrap));
        var c = b.attr("id");
        this.el.layerDim.hide();
        b.hide();
        b.removeAttr("tabindex");
        this.el.layerOpenBtn.target.forEach(function(a) {
            a.dataset.divId === "#" + c && a.focus()
        })
    };
    d.prototype.unbindEvents = function() {
        this.el.depth1Link.off("mouseenter");
        this.el.depth1Link.off("keydown");
        this.el.depth1Link.off("click");
        this.el.depth2Close.off("click");
        this.el.depth2Link.off("mouseenter");
        this.el.depth2Link.off("keydown");
        this.el.depth2Link.off("focus");
        this.el.depth2Link.off("click");
        this.el.loginBtn.off("focus");
        this.el.loginBtn.off("mouseenter");
        this.el.loginBtn.off("mouseleave");
        this.el.loginBtn.off("keydown");
        this.el.loginLayer.off("mouseenter");
        this.el.loginLayer.off("mouseleave");
        this.el.countryBtn.off("focus");
        this.el.countryBtn.off("mouseenter");
        this.el.countryBtn.off("mouseleave");
        this.el.countryBtn.off("keydown");
        this.el.countryLayer.off("mouseenter");
        this.el.countryLayer.off("mouseleave");
        this.el.gnbDim.off("mouseenter");
        this.el.countrySelect.eq(this.el.countrySelect.target.length -
            1).off("keydown");
        this.el.desktopUtilLink.eq(this.el.desktopUtilLink.target.length - 1).off("keydown");
        this.mobileEl.gnbMenuBtn.off("click");
        this.mobileEl.gnbMenuClose.off("click");
        this.mobileEl.gnbMenuClose.off("keydown");
        this.mobileEl.gnbDepthBack.off("click");
        this.mobileEl.gnbDepthBack.off("keydown");
        this.el.depth1First.off("keydown");
        this.el.featureContainer.off("keydown")
    };
    d.prototype.resetGnb = function() {
        var a = this;
        this.el.depth2Wrap.removeAttr("style");
        this.el.depth3Wrap.css({
            visibility: "",
            height: ""
        });
        this.el.depth2Close.css({
            visibility: "hidden"
        });
        this.el.gnbDim.removeClass("open");
        this.el.gnbDim.hide();
        setTimeout(function() {
            a.el.depth2Inner.removeAttr("style")
        }, 500)
    };
    d.prototype.bindEvents = function() {
        var b = this;
        this.breakpoint < l.getViewPort().width ? this.desktopEvents() : this.mobileEvents();
        this.el.window.off("resize", this.handler.resize).on("resize", this.handler.resize);
        this.el.layerOpenBtn.target.forEach(function(c) {
            a(c).off("click").on("click", function() {
                b.openPopup(c)
            })
        });
        this.el.layerCloseBtn.target.forEach(function(c) {
            a(c).off("click").on("click",
                function() {
                    b.closePopup(c)
                })
        })
    };
    d.prototype.mobileEvents = function() {
        var b = this;
        this.mobileEl.gnbMenuBtn.target.forEach(function(c) {
            a(c).off("click").on("click", function() {
                g.setLazyLoadManually(b.el.component.find(".gnb__utility-mobile .gnb__user-name").target[0]);
                b.el.gnbMenuWrap.hasClass("use-country-selector") && g.setLazyLoadManually(b.el.component.find(".gnb__country-mobile").target[0]);
                b.activeMobileGnb()
            })
        });
        this.mobileEl.gnbMenuClose.target.forEach(function(c) {
            c = a(c);
            c.off("click").on("click",
                function() {
                    b.deactiveMobileGnb(!0)
                });
            c.off("keydown").on("keydown", function(a) {
                b.setCloseFocus(a)
            })
        });
        this.el.depth1Link.target.forEach(function(c) {
            var d = a(c);
            d.off("click").on("click", function() {
                b.activeMobileFirstMenu(d)
            })
        });
        this.mobileEl.gnbDepthBack.target.forEach(function(c) {
            c = a(c);
            c.off("click").on("click", function() {
                b.backDepthMobile()
            });
            c.off("keydown").on("keydown", function(a) {
                b.setFocusReverse(a)
            })
        });
        this.el.depth2Link.target.forEach(function(c) {
            var d = a(c);
            d.off("click").on("click", function() {
                b.activeMobileSecondMenu(d)
            })
        });
        this.el.depth1First.off("keydown").on("keydown", function(a) {
            b.setFocusReverse(a)
        })
    };
    d.prototype.desktopEvents = function() {
        var b = this;
        g.setLazyLoadManually(this.el.loginBtn.target[0]);
        this.el.gnbMenuWrap.hasClass("use-country-selector") && g.setLazyLoadManually(this.el.countryBtn.target[0]);
        this.el.depth1Link.target.forEach(function(c) {
            var d = a(c);
            d.off("mouseenter").on("mouseenter", function() {
                b.toggleGnb(d)
            });
            d.off("keydown").on("keydown", function(a) {
                a.keyCode === e.ENTER && (b.toggleGnb(d), d.parent().hasClass("has-depth-menu") &&
                    a.preventDefault())
            })
        });
        this.el.depth2Close.target.forEach(function(c) {
            var d = a(c);
            d.off("click").on("click", function() {
                b.deactiveGnb(d)
            })
        });
        this.el.gnbDim.off("mouseenter").on("mouseenter", function() {
            !0 === b.dimEventFlag && b.deactiveGnb(b.el.gnbDim)
        });
        this.el.depth2Link.target.forEach(function(c) {
            var d = a(c);
            "us" !== siteCode ? (d.off("mouseenter").on("mouseenter", function() {
                b.subOpenFlag = !0;
                b.activeSnb(d)
            }), d.off("focus").on("focus", function() {
                b.subOpenFlag = !0;
                b.activeSnb(d)
            }), d.off("click").on("click",
                function(a) {
                    d.parent().hasClass("has-depth-menu") && a.preventDefault()
                })) : (d.find(".gnb__depth2-link-text, .icon--next").off("mouseenter").on("mouseenter", function() {
                b.subOpenFlag = !0;
                b.activeSnb(d);
                b.activeDepth2Img(d)
            }), d.find(".gnb__depth2-link-text, .icon--next").off("focus").on("focus", function() {
                b.subOpenFlag = !0;
                b.activeSnb(d);
                b.activeDepth2Img(d)
            }), d.find(".gnb__depth2-link-text, .icon--next").off("click").on("click", function(a) {
                d.parent().hasClass("has-depth-menu") && a.preventDefault()
            }))
        });
        this.el.loginBtn.target.forEach(function(c) {
            c = a(c);
            c.off("focus").on("focus", function() {
                b.activeLoginMenu()
            });
            c.off("mouseenter").on("mouseenter", function() {
                null === b.loginFlag ? b.activeLoginMenu() : (clearTimeout(b.loginFlag), b.loginFlag = null)
            });
            c.off("mouseleave").on("mouseleave", function() {
                null !== b.loginFlag && (clearTimeout(b.loginFlag), b.loginFlag = null);
                b.loginFlag = setTimeout(function() {
                    b.deactiveLoginMenu()
                }, 200)
            });
            c.off("keydown").on("keydown", function(a) {
                a.keyCode === e.TAB && !0 === a.shiftKey && b.deactiveLoginMenu()
            })
        });
        this.el.desktopUtilLink.eq(this.el.desktopUtilLink.target.length - 1).off("keydown").on("keydown", function(a) {
            a.keyCode === e.TAB && !1 === a.shiftKey && b.deactiveLoginMenu()
        });
        this.el.loginLayer.target.forEach(function(c) {
            c = a(c);
            c.off("mouseenter").on("mouseenter", function() {
                null !== b.loginFlag && clearTimeout(b.loginFlag)
            });
            c.off("mouseleave").on("mouseleave", function() {
                null !== b.loginFlag && clearTimeout(b.loginFlag);
                b.loginFlag = setTimeout(function() {
                    b.deactiveLoginMenu()
                }, 200)
            })
        });
        this.el.countryBtn.target.forEach(function(c) {
            c =
                a(c);
            c.off("focus").on("focus", function() {
                b.activeCountry()
            });
            c.off("mouseenter").on("mouseenter", function() {
                null === b.countryFlag ? b.activeCountry() : (clearTimeout(b.countryFlag), b.countryFlag = null)
            });
            c.off("mouseleave").on("mouseleave", function() {
                null !== b.countryFlag && (clearTimeout(b.countryFlag), b.countryFlag = null);
                b.countryFlag = setTimeout(function() {
                    b.deactiveCountry()
                }, 200)
            });
            c.off("keydown").on("keydown", function(a) {
                a.keyCode === e.TAB && !0 === a.shiftKey && b.deactiveCountry()
            })
        });
        this.el.countryLayer.target.forEach(function(c) {
            c =
                a(c);
            c.off("mouseenter").on("mouseenter", function() {
                null !== b.countryFlag && clearTimeout(b.countryFlag)
            });
            c.off("mouseleave").on("mouseleave", function() {
                null !== b.countryFlag && clearTimeout(b.countryFlag);
                b.countryFlag = setTimeout(function() {
                    b.deactiveCountry()
                }, 200)
            })
        });
        this.el.countrySelect.eq(this.el.countrySelect.target.length - 1).off("keydown").on("keydown", function(a) {
            a.keyCode === e.TAB && !1 === a.shiftKey && b.deactiveCountry()
        })
    };
    var n = function() {
        b = a(".gnb");
        b.target.length && b.target.forEach(function(a) {
            d.instances.has(a) ||
                new d(a)
        })
    };
    d.instances = new WeakMap;
    "us" !== siteCode && a.ready(n);
    window.sg.components.gnb = {
        init: n,
        reInit: function() {
            "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", n) : (b = a(".gnb"), b.target.forEach(function(a) {
                d.instances.has(a) ? d.instances.get(a).reInit() : new d(a)
            }))
        }
    }
})();
ss = $;
var reservationUserData = null;

function nextGenLoginResult(a) {}
(function(a) {
    ss.Sign = function() {
        function l(a) {
            a = a.split("+").join(" ");
            for (var b = {}, c, d = /[?&]?([^=]+)=([^&]*)/g; c = d.exec(a);) b[decodeURIComponent(c[1])] = decodeURIComponent(c[2]);
            return b
        }

        function e() {
            a.cookies.del("estoreLoginRequesting");
            a.cookies.del("estoreLoginRequesting", {
                domain: ".samsung.com"
            })
        }

        function g() {
            a.cookies.del("snsSessionId");
            a.cookies.del("snsSessionId", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("isStoreLogedIn");
            a.cookies.del("sa_em");
            a.cookies.del("sa_em", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("eVar67");
            a.cookies.del("eVar67", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("lastName", {
                domain: ".samsung.com"
            });
            a.cookies.del("firstName", {
                domain: ".samsung.com"
            });
            a.cookies.del("guid", {
                domain: ".samsung.com"
            });
            a.cookies.del("ReD", {
                domain: ".samsung.com"
            });
            a.cookies.del("directCallFl", {
                expires: null,
                domain: ".samsung.com"
            });
            a.cookies.del("directCallFlv2", {
                expires: null,
                domain: ".samsung.com"
            });
            a.cookies.del("returnURL", {
                domain: ".samsung.com"
            });
            a.cookies.del("mVal10", {
                domain: ".samsung.com"
            });
            a.cookies.del("mVal11", {
                domain: ".samsung.com"
            });
            e();
            a.cookies.del("prof_id", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("prof_lname", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("prof_bpno", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("prof_bpno_s", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("rew_enr", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("prof_fname", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("tppid", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("tmktid", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("tmktname", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("tlgimg", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("taccessrtype", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("remoteId", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("tsgmt", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("epp_verified", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("store_id", {
                path: "/",
                domain: ".samsung.com"
            })
        }

        function b() {
            a.cookies.del("xsdcxyn");
            a.cookies.del("xsdcxyn", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("xsdcbxyn");
            a.cookies.del("xsdcbxyn", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("iPlanetDirectoryPro");
            a.cookies.del("iPlanetDirectoryPro", {
                path: "/",
                domain: ".samsung.com"
            });
            a.cookies.del("iPlanetDirectoryProOptVal");
            a.cookies.del("iPlanetDirectoryProOptVal", {
                path: "/",
                domain: ".samsung.com"
            })
        }

        function d() {
            g();
            b();
            Q = null;
            (USE_ESTORE || S) && c(!1);
            return !1
        }

        function n(b, c, d) {
            var e = Z.find(".gnb__user-image"),
                g = B.find(".gnb__user-image"),
                h = a(".js-gnb-afterlogin-image"),
                k = a(".js-gnb-afterlogin-no-image");
            if ("" != N && null != N && c) {
                c = N;
                var l = "?$LazyLoad_Home",
                    n = N.toLowerCase();
                l = -1 < n.indexOf(".jpg") ? l + "_JPG$" : -1 < n.indexOf(".jpeg") ? l + "_JPG$" : -1 < n.indexOf(".png") ? l + "_PNG$" : -1 < n.indexOf(".gif") ? l + "_GIF$" : l + "_PNG$";
                c += l;
                l = N;
                h.find(".image__preview").attr("data-src", c);
                h.find(".image__main").attr("data-src", l);
                h.show();
                k.remove()
            } else h.remove();
            e = '\x3cspan class\x3d"gnb__user-image"\x3e' + e.html() + "\x3c/span\x3e";
            g = '\x3cspan class\x3d"gnb__user-image"\x3e' + g.html() + "\x3c/span\x3e";
            d && (d = "/" + SITE_CD + "/web/mypage/profile-settings", Z.attr("href", d), B.attr("href", d));
            Z.html(b + e);
            B.html(b + g);
            window.sg.components.gnb.reInit();
            window.sg.common.lazyLoad.setLazyLoadManually(h[0])
        }

        function c(b) {
            b = a.cookies.get("firstName");
            var c = a.cookies.get("lastName");
            null == b || null == c ? n("", !1) : "vn" === SITE_CD ? n(c, !1) : n(b, !1)
        }

        function h(a, b) {
            var c = new Date;
            c.setDate(c.getDate() + b);
            document.cookie = "_common_saveEmail\x3d" + encodeURIComponent(a) + "; path\x3d/; domain\x3d.samsung.com; expires\x3d" + c.toGMTString() +
                ";"
        }

        function q() {
            var a = document.cookie + ";",
                b = a.indexOf("_common_saveEmail", 0),
                c = ""; - 1 != b && (a = a.substring(b, a.length), b = a.indexOf("\x3d", 0) + 1, c = a.indexOf(";", b), c = decodeURIComponent(a.substring(b, c)));
            "" !== c && (Ba.next().css({
                visibility: "hidden"
            }), Ba.val(c), D.attr("checked", "checked"), D.prop("checked", !0), D.next().addClass(D.next().attr("data-acc-onclass")))
        }

        function m() {
            "N" === a.cookies.get("directCallFlv2") && ("undefined" != typeof dataLayer && "object" == typeof dataLayer && dataLayer.push({
                event: "login",
                eventNonInteraction: !0
            }), a.cookies.set("directCallFlv2", "Y", {
                expires: null,
                domain: ".samsung.com"
            }))
        }

        function p(a) {
            a ? (ss.Auth.getUserProfile(function(a) {
                null != a && "" !== a ? "vn" === SITE_CD ? n(a.lastName, !0) : n(a.firstName + " " + a.lastName, !0) : n("", !0)
            }), A.hide(), X.show()) : (A.show(), X.hide())
        }

        function u() {
            function b(e) {
                d < c.length ? (estore.addWishListItemForce({
                    productCode: c[d]
                }, b), d++) : (a.cookies.deleteWishList(), a.EstoreIfQueue && a.EstoreIfQueue.setIsSignReady(!0))
            }
            var c = a.cookies.getWishList(),
                d = 0;
            0 < c.length ?
                b() : a.EstoreIfQueue && a.EstoreIfQueue.setIsSignReady(!0)
        }

        function t() {
            a(".gnb-layer_popup-js").hide();
            sa.hide()
        }

        function y(b) {
            if (b) {
                var c = LOGIN.msg.errorTitleText,
                    d = "";
                switch (b) {
                    case "DW":
                    case "AW":
                    case "WP":
                        d = LOGIN.msg.errorText1;
                        break;
                    case "BA":
                        d = LOGIN.msg.errorText2;
                        break;
                    case "UK":
                        d = LOGIN.msg.errorText3;
                        break;
                    case "ES":
                        d = LOGIN.msg.errorText4
                }
                pa = ya; - 1 == "pop-tit".indexOf(a("#confirmPopup \x3ediv\x3e div.popup_wrap").find("h2").attr("class")) && (ya.append('\x3ch2 class\x3d"pop-tit"\x3e'), ya.append('\x3cp class\x3d"msg-text tc"\x3e'));
                a(".pop-tit", ya).text(c);
                a(".msg-text", ya).text(d)
            }
            a(".gnb-layer_popup-js").hide();
            if (aa && "in" !== SITE_CD) {
                a("#privacy-terms").parent().find(".check_text").empty();
                a("#privacy-terms2").parent().find(".check_text").remove();
                a("#privacy-terms2").parent().find(".check_txt").remove();
                if (0 < ka.length) {
                    var e = ka[0].data.content;
                    if (null != ka[1]) {
                        var g = ka[1].data.content;
                        g = g.replace("check_text", "checkbox-radio__label-text check_text")
                    }
                }
                a("#privacy-terms").parent().find(".check_text").append(e);
                null != g && a("#privacy-terms2").parent().append(g)
            }
            pa &&
                (sa.show(), pa.show())
        }

        function v(b) {
            var c = "",
                d = a.cookies.get("jwt_" + ea, {
                    domain: ".samsung.com"
                });
            aa && (c = STORE_DOMAIN + "/v4/identity/preferences");
            var e = b;
            "in" === SITE_CD && (e = JSON.stringify(b));
            a.ajax({
                headers: {
                    "Cache-Control": "no-cache",
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                    "x-ecom-app-id": "identity-store",
                    "x-ecom-jwt": d
                },
                url: c,
                type: "PUT",
                dataType: "json",
                data: e,
                xhrFields: {
                    withCredentials: !0
                },
                beforeSend: function(a) {
                    "Y" === O && a.setRequestHeader("x-ecom-locale", R)
                },
                success: function(a) {
                    t();
                    pa = "Y" === ja ? null : Ca;
                    y()
                },
                error: function(a, b, c) {
                    console.error(b)
                }
            })
        }

        function L() {
            var b = "",
                c = a.cookies.get("guid", {
                    domain: ".samsung.com"
                });
            b = "au" === SITE_CD || "latin" === SITE_CD || "tw" === SITE_CD || "uk" === SITE_CD || "ru" === SITE_CD || "ae" === SITE_CD || "ae_ar" === SITE_CD || "vn" === SITE_CD || "th" === SITE_CD || "sa" === SITE_CD || "sa_en" === SITE_CD || "nz" === SITE_CD || "ca" === SITE_CD || "ca_fr" === SITE_CD || "se" === SITE_CD || "dk" === SITE_CD || "fi" === SITE_CD || "no" === SITE_CD || "at" === SITE_CD || "my" === SITE_CD || "pt" === SITE_CD || "sg" === SITE_CD ||
                "eg" == SITE_CD || "za" == SITE_CD || "hk" == SITE_CD || "hk_en" == SITE_CD || "pk" === SITE_CD || "ch" == SITE_CD || "ch_fr" == SITE_CD || "il" == SITE_CD || "ar" === SITE_CD || "cl" === SITE_CD || "co" === SITE_CD || "mx" === SITE_CD || "pe" === SITE_CD ? STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/agreeStorePolicy?receiveEmail\x3d" + da : "es" === SITE_CD || "it" === SITE_CD ? -1 < STORE_DOMAIN.indexOf("https://") ? STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/agreeStorePolicy?receiveEmail\x3d" + da : STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/setAgreeStorePolicy?receiveEmail\x3d" + da : "levant" ===
                SITE_CD ? STORE_DOMAIN + "/jo/ng/p4v1/agreeStorePolicy?receiveEmail\x3d" + da : "levant_ar" === SITE_CD ? STORE_DOMAIN + "/jo_ar/ng/p4v1/agreeStorePolicy?receiveEmail\x3d" + da : "n_africa" === SITE_CD ? STORE_DOMAIN + "/ma/ng/p4v1/agreeStorePolicy?receiveEmail\x3d" + da : STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/setAgreeStorePolicy?receiveEmail\x3d" + da;
            wa ? a.ajax({
                url: b,
                type: "GET",
                data: {
                    ssoID: c
                },
                dataType: "json",
                xhrFields: {
                    withCredentials: !0
                },
                contentType: "application/x-www-form-urlencoded",
                crossDomain: !0,
                beforeSend: function() {},
                success: function(a) {
                    t();
                    "0000" === a.resultCode && (pa = "Y" === ja ? null : Ca, y())
                },
                error: function(a, b, c) {
                    console.error(b)
                }
            }) : a.ajax({
                url: b,
                type: "GET",
                dataType: "jsonp",
                data: {
                    ssoID: c
                },
                jsonp: "callback",
                beforeSend: function() {},
                success: function(a) {
                    t();
                    "0000" === a.resultCode && (pa = "Y" === ja ? null : Ca, y())
                },
                error: function(a, b, c) {
                    console.error(b)
                }
            })
        }

        function J() {
            a("#signInForm").attr("action", H);
            w = window.location.href;
            var b = a("#redirect_uri", x).val();
            var c = window.location.port;
            c = null == c || "" === c || "80" === c || "8080" === c ? "https://" + window.location.host :
                "http://" + window.location.host;
            0 > b.indexOf(window.location.hostname) && (b = c + b, a("#redirect_uri", x).val(b));
            b = "GLB" + Math.random().toString(36).substr(2, 11);
            a.cookies.set("glbState", b, {
                domain: ".samsung.com"
            });
            a("#response_type", x).val("code");
            a("#countryCode", x).val(a("#countryCode", x).val());
            a("#redirect_uri", x).val(a("#redirect_uri", x).val());
            a("#signInState", x).val(b);
            a("#signInGoBackURL", x).val(w);
            a(".goBackURL").val(w);
            a("#scope", x).val("");
            (b = a("#loginAccountServiceId").val()) && a("#client_id",
                x).val(b);
            b = a("#languageCode").val();
            c = a("#countryCode").val();
            b && c && (b = b + "_" + c, a("#locale", x).val(b));
            a.cookies.set("returnURL", w, {
                domain: ".samsung.com"
            });
            x.submit();
            D.is(":checked") ? h(a.trim(Ba.val()), 7) : h(null, -1);
            w = void 0
        }

        function E() {
            a("#signOutForm").attr("action", F);
            w = window.location.href;
            !a("#tempTitle").val() || "page-my-samsung" !== a("#tempTitle").val() && "page-my-products" !== a("#tempTitle").val() && "page-my-rewards" !== a("#tempTitle").val() || (w = window.location.protocol + "//" + window.location.host +
                "/" + SITE_CD + "/");
            a.cookies.set("returnURL", w, {
                domain: ".samsung.com"
            });
            var b = a("#signOutURL", za).val();
            var c = window.location.port;
            c = null == c || "" === c || "80" === c || "8080" === c ? "https://" + window.location.host : "http://" + window.location.host;
            0 > b.indexOf(window.location.hostname) && (b = c + b, a("#signOutURL", za).val(b));
            b = "GLB" + Math.random().toString(36).substr(2, 11);
            a.cookies.set("glbState", b, {
                domain: ".samsung.com"
            });
            a("#signOutState", za).val(b);
            (b = a("#loginAccountServiceId").val()) && a("#client_id", za).val(b);
            za.submit();
            w = void 0
        }

        function la(b) {
            var c = !0;
            a.ajax({
                headers: {
                    "Cache-Control": "no-cache",
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                    "x-ecom-app-id": "identity-store",
                    "x-ecom-jwt": b
                },
                url: "in" !== SITE_CD ? STORE_DOMAIN + "/v4/identity/preferences?display_context\x3dpre_purchase" : STORE_DOMAIN + "/v4/identity/preferences",
                type: "GET",
                dataType: "json",
                cache: !0,
                xhrFields: {
                    withCredentials: !0
                },
                beforeSend: function(a) {
                    "Y" === O && a.setRequestHeader("x-ecom-locale", R)
                },
                success: function(a) {
                    if (null != a && "" !== a) {
                        if ("pl" ===
                            SITE_CD) c = !0;
                        else if ("in" === SITE_CD) !0 !== a.terms_and_conditions.is_accepted && (c = !1);
                        else if (null != a.consents && "" !== a.consents) {
                            ka = Array(a.consents.length);
                            for (var b = 0; b < a.consents.length; b++) {
                                var d = a.consents[b];
                                ka[b] = d;
                                !0 === d.data.is_required && !0 !== d.is_accepted && (c = !1)
                            }
                        }!1 === c && (t(), pa = "Y" === ja ? null : U, y())
                    }
                },
                error: function(a, b, c) {
                    console.error(b)
                }
            })
        }

        function ma(c) {
            var d = a.cookies.get("jwt_" + ea, {
                    domain: ".samsung.com"
                }),
                h = function() {
                    g();
                    b();
                    Da.val("N")
                },
                k = function(b) {
                    var c = {
                        jwt: b
                    };
                    if ("us" === siteCode) {
                        var d =
                            a.cookies.get("epp_verified", {
                                domain: ".samsung.com"
                            }),
                            e = a.cookies.get("tmktid", {
                                domain: ".samsung.com"
                            }),
                            g = a.cookies.get("store_id", {
                                domain: ".samsung.com"
                            });
                        null != d && (d = d.toString(), "true" == d && null != e && "" != e ? c.store_id = e.toString() : null != g && "" != g && (c.store_id = g.toString()))
                    }
                    a.ajax({
                        headers: {
                            "Cache-Control": "no-cache",
                            "Content-Type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        },
                        url: STORE_DOMAIN + "/v1/sso/user/validate",
                        type: "POST",
                        dataType: "json",
                        data: JSON.stringify(c),
                        xhrFields: {
                            withCredentials: !0
                        },
                        beforeSend: function(a) {
                            "Y" === O && a.setRequestHeader("x-ecom-locale", R)
                        },
                        success: function(c) {
                            if (200 === c.statusCode || "200" === c.statusCode) {
                                var d = a.cookies.get("jwt_" + ea, {
                                    domain: ".samsung.com"
                                });
                                Da.val("Y");
                                var e = function() {
                                    if (a.cookies.get("remoteId")) {
                                        if (a.cookies.get("tppid") && a.cookies.get("tmktname")) {
                                            var b = a('\x3cimg src\x3d"' + a.cookies.get("tlgimg") + '"\x3e');
                                            a(".epp-bar-logo").append(b);
                                            b = a.cookies.get("tmktname") + " Store";
                                            a(".epp-bar-username").text(b);
                                            "16568500" === a.cookies.get("tppid") && a(".gnb__utility-link.sea").removeClass("hidden");
                                            a(".epp-bar-wrap").show()
                                        }
                                    } else if (a.cookies.get("tppid")) {
                                        a.cookies.get("remoteId");
                                        b = a.cookies.get("tlgimg");
                                        var c = a.cookies.get("tmktname");
                                        if (a.cookies.get("remoteId")) {
                                            var d = a.cookies.get("prof_fname") && a.cookies.get("prof_fname") ? a.cookies.get("prof_fname") : a.cookies.get("tmktname");
                                            a(".epp-bar-logo img").remove();
                                            a(".epp-bar-logo").append('\x3cimg src\x3d"' + b + '"/\x3e');
                                            "null" != d ? a(".epp-bar-msg").html('Welcome to the \x3cdiv class\x3d"epp-bar-username"\x3e' + c + " Store.\x3c/div\x3e Please enjoy our special offers for you") :
                                                a(".epp-bar-msg").html('Welcome \x3cdiv class\x3d"epp-bar-username"\x3e' + c + '!\x3c/div\x3e Please \x3cdiv class\x3d"epp-bar-username"\x3e\x3ca href\x3d"#" id\x3d"openLogin"\x3elogin\x3c/a\x3e\x3c/div\x3e to enjoy our special offers for you')
                                        } else a.cookies.get("remoteId") && "4145500" === a.cookies.get("tmktid") && "17593200" === a.cookies.get("tppid") ? (a(".epp-bar-logo img").remove(), a(".epp-bar-logo").append('\x3cimg src\x3d"' + b + '"/\x3e'), a(".epp-bar-msg").html("Welcome to Samsung's Friends and Family Store! Enjoy special pricing. Please \x3cdiv class\x3d'epp-bar-username'\x3e\x3ca href\x3d'#' id\x3d'openLogin' style\x3d'font-size:12px;'\x3elogin/signup\x3c/a\x3e\x3c/div\x3e to make a purchase.")) :
                                            (a(".epp-bar-logo img").remove(), a(".epp-bar-logo").append('\x3cimg src\x3d"' + b + '"/\x3e'), a(".epp-bar-msg").html('Welcome to the \x3cdiv class\x3d"epp-bar-username" style\x3d"color:#1428a0;"\x3e' + c + " Store!\x3c/div\x3e Please \x3cdiv class\x3d'epp-bar-username' style\x3d'color:#1428a0;'\x3e\x3ca href\x3d'#' id\x3d'openLogin' style\x3d'color:#1428a0;'\x3elogin\x3c/a\x3e\x3c/div\x3e to enjoy our special pricing."));
                                        a(".epp-bar-wrap").slideDown()
                                    } else a(".epp-bar-wrap").hide()
                                }; - 1 < window.location.href.indexOf("/us/") &&
                                    e();
                                a.ajax({
                                    headers: {
                                        "Cache-Control": "no-cache",
                                        "Content-Type": "application/json",
                                        "Access-Control-Allow-Origin": "*",
                                        "x-ecom-jwt": d
                                    },
                                    url: STORE_DOMAIN + "/v4/shopping-carts/",
                                    type: "POST",
                                    dataType: "json",
                                    data: JSON.stringify({}),
                                    xhrFields: {
                                        withCredentials: !0
                                    },
                                    beforeSend: function(a) {
                                        "Y" === O && a.setRequestHeader("x-ecom-locale", R)
                                    },
                                    success: function() {
                                        var b = a.cookies.get("s_ecom_sc_cnt", {
                                            domain: ".samsung.com"
                                        });
                                        null != b && "" !== b && (0 === b ? z.hide() : z.show(), z.html('\x3cspan class\x3d"hidden"\x3e' + a("#productCountText").val() +
                                            " : \x3c/span\x3e" + b))
                                    }
                                });
                                null != c.user_info.firstname && "" !== c.user_info.firstname ? (A.hide(), X.show(), n(c.user_info.firstname + " " + c.user_info.lastname, !0)) : a.ajax({
                                    headers: {
                                        "Cache-Control": "no-cache",
                                        "Content-Type": "application/json",
                                        "Access-Control-Allow-Origin": "*"
                                    },
                                    url: STORE_DOMAIN + "/v1/sso/jwt/details",
                                    type: "POST",
                                    dataType: "json",
                                    data: JSON.stringify({
                                        jwt: d
                                    }),
                                    xhrFields: {
                                        withCredentials: !0
                                    },
                                    beforeSend: function(a) {
                                        "Y" === O && a.setRequestHeader("x-ecom-locale", R)
                                    },
                                    success: function(a) {
                                        null != a && "" !== a &&
                                            (null != a.user_info.firstname && "" !== a.user_info.firstname ? (A.hide(), X.show(), n(a.user_info.firstname + " " + a.user_info.lastname, !0)) : (A.hide(), X.show(), n("User", !0)))
                                    }
                                });
                                la(b)
                            } else a.cookies.del("jwt_" + ea, {
                                domain: ".samsung.com"
                            }), a(".epp-bar-wrap").hide(), h()
                        },
                        error: function(b, c, d) {
                            console.error(c);
                            a.cookies.del("jwt_" + ea, {
                                domain: ".samsung.com"
                            });
                            h()
                        }
                    })
                },
                l = function() {
                    a.ajax({
                        url: "/aemapi/v6/data-login/callSALogin." + siteCode + ".json",
                        type: "GET",
                        dataType: "json",
                        success: function(d) {
                            var e = a.cookies.get("jwt_" +
                                ea, {
                                    domain: ".samsung.com"
                                });
                            m();
                            200 === d.statusCode && "Y" === d.redCookieChk ? e ? k(e) : h() : "N" === d.redCookieChk && c ? (g(), b(), J()) : h()
                        },
                        error: function(a, b, c) {
                            console.error(b);
                            h()
                        }
                    })
                };
            if (d) {
                var p = {
                        jwt: d
                    },
                    q = !1;
                if ("us" === siteCode) {
                    var t = a.cookies.get("epp_verified", {
                            domain: ".samsung.com"
                        }),
                        u = a.cookies.get("tmktid", {
                            domain: ".samsung.com"
                        }),
                        v = a.cookies.get("store_id", {
                            domain: ".samsung.com"
                        });
                    null != t && (t = t.toString(), "true" == t && null != u && "" != u ? p.store_id = u.toString() : null != v && "" != v && (p.store_id = v.toString()));
                    a.ajax({
                        headers: {
                            "Cache-Control": "no-cache",
                            "Content-Type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        },
                        url: STORE_DOMAIN + "/v1/sso/jwt/details",
                        type: "POST",
                        async: !1,
                        dataType: "json",
                        data: JSON.stringify({
                            jwt: d
                        }),
                        xhrFields: {
                            withCredentials: !0
                        },
                        success: function(c) {
                            null == c || "" === c || null == c.login_type || "guest_epp_store" !== c.login_type && "referral_url" !== c.login_type ? a.cookies.set("isUSGuestUser", "N") : (q = !0, a.cookies.set("isUSGuestUser", "Y"), a.cookies.del("snsSessionId"), a.cookies.del("snsSessionId", {
                                    path: "/",
                                    domain: ".samsung.com"
                                }), a.cookies.del("isStoreLogedIn"),
                                a.cookies.del("sa_em"), a.cookies.del("sa_em", {
                                    path: "/",
                                    domain: ".samsung.com"
                                }), a.cookies.del("eVar67"), a.cookies.del("eVar67", {
                                    path: "/",
                                    domain: ".samsung.com"
                                }), a.cookies.del("lastName", {
                                    domain: ".samsung.com"
                                }), a.cookies.del("firstName", {
                                    domain: ".samsung.com"
                                }), a.cookies.del("guid", {
                                    domain: ".samsung.com"
                                }), a.cookies.del("ReD", {
                                    domain: ".samsung.com"
                                }), a.cookies.del("directCallFl", {
                                    expires: null,
                                    domain: ".samsung.com"
                                }), a.cookies.del("directCallFlv2", {
                                    expires: null,
                                    domain: ".samsung.com"
                                }), a.cookies.del("returnURL", {
                                    domain: ".samsung.com"
                                }), a.cookies.del("mVal10", {
                                    domain: ".samsung.com"
                                }), a.cookies.del("mVal11", {
                                    domain: ".samsung.com"
                                }), e(), b(), Da.val("N"))
                        }
                    })
                }
                q || a.ajax({
                    headers: {
                        "Cache-Control": "no-cache",
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    },
                    url: STORE_DOMAIN + "/v1/sso/user/validate",
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify(p),
                    xhrFields: {
                        withCredentials: !0
                    },
                    beforeSend: function(a) {
                        "Y" === O && a.setRequestHeader("x-ecom-locale", R)
                    },
                    success: function(b) {
                        if (200 === b.statusCode || "200" ===
                            b.statusCode) {
                            var c = a.cookies.get("jwt_" + ea, {
                                domain: ".samsung.com"
                            });
                            Da.val("Y");
                            m();
                            null != b.user_info.firstname && "" !== b.user_info.firstname ? (A.hide(), X.show(), c = a.cookies.get("guid", {
                                domain: ".samsung.com"
                            }), fnIsNull(c) ? n(b.user_info.firstname + " " + b.user_info.lastname, !0, !0) : n(b.user_info.firstname + " " + b.user_info.lastname, !0)) : a.ajax({
                                headers: {
                                    "Cache-Control": "no-cache",
                                    "Content-Type": "application/json",
                                    "Access-Control-Allow-Origin": "*"
                                },
                                url: STORE_DOMAIN + "/v1/sso/jwt/details",
                                type: "POST",
                                dataType: "json",
                                data: JSON.stringify({
                                    jwt: c
                                }),
                                xhrFields: {
                                    withCredentials: !0
                                },
                                beforeSend: function(a) {
                                    "Y" === O && a.setRequestHeader("x-ecom-locale", R)
                                },
                                success: function(a) {
                                    null != a && "" !== a && (null != a.user_info.firstname && "" !== a.user_info.firstname ? (A.hide(), X.show(), n(a.user_info.firstname + " " + a.user_info.lastname, !0, !0)) : (A.hide(), X.show(), n("User", !0, !0)))
                                }
                            });
                            la(d)
                        } else l()
                    },
                    error: function(a, b, c) {
                        console.error(b);
                        console.log(a);
                        void 0 == a.responseJSON || "StoreIdNotPresent" !== a.responseJSON.error ? l() : Da.val("N")
                    }
                })
            } else c ?
                l() : Da.val("N")
        }

        function ia() {
            var c = a.cookies.get("snsSessionId", {
                    domain: ".samsung.com"
                }),
                d = a.cookies.get("xsdcxyn", {
                    domain: ".samsung.com"
                }),
                g = a.cookies.get("firstName", {
                    domain: ".samsung.com"
                }),
                h = a.cookies.get("lastName", {
                    domain: ".samsung.com"
                }),
                k = a.cookies.get("guid", {
                    domain: ".samsung.com"
                }),
                n = "Y" === a.cookies.get("estoreLoginRequesting", {
                    domain: ".samsung.com"
                }) ? !0 : !1;
            q();
            m();
            A.show();
            X.hide();
            if (("YG" === d || "YH" === d) && g && h)
                if (USE_ESTORE || S) {
                    c = !1;
                    if (!n) {
                        n = [".samsung.com"];
                        for (d = 0; d < n.length; d++)
                            if (-1 <
                                document.referrer.indexOf(n[d])) {
                                c = !0;
                                break
                            }
                        if (c)
                            for (n = "www.samsung.com dev.samsung.com p4.samsung.com stgweb4.samsung.com ptcweb4.samsung.com local.dev.my.eu.samsung.com dev.my.eu.samsung.com stg.my.eu.samsung.com my.eu.samsung.com www.eumysamsung.com stg-account.samsung.com account.samsung.com local.sec.samsung.com dev-aem.samsung.com stg-aem.samsung.com itg-aem.samsung.com aem.samsung.com org-aem.samsung.com qaweb.samsung.com org-qaweb.samsung.com org-ap.samsung.com org-eu.samsung.com org-aem-eu.samsung.com aem-eu.samsung.com org-qashop.samsung.com qashop.samsung.com pre-qa.samsung.com pre-qa2.samsung.com".split(" "),
                                d = document.referrer.replace(/http(s)?:\/\//, ""), g = "", h = 0; h < n.length; h++)
                                if ("es" === SITE_CD || "latin" === SITE_CD || "tw" === SITE_CD || "ru" === SITE_CD || "ae" === SITE_CD || "ae_ar" === SITE_CD || "vn" === SITE_CD || "th" === SITE_CD || "sa" === SITE_CD || "sa_en" === SITE_CD || "nz" === SITE_CD || "it" === SITE_CD || "au" === SITE_CD || "cn" === SITE_CD || "ca" === SITE_CD || "ca_fr" === SITE_CD || "se" === SITE_CD || "dk" === SITE_CD || "fi" === SITE_CD || "no" === SITE_CD || "at" === SITE_CD || "my" === SITE_CD || "pt" === SITE_CD || "sg" === SITE_CD || "eg" == SITE_CD || "levant" == SITE_CD ||
                                    "levant_ar" == SITE_CD || "za" == SITE_CD || "hk" == SITE_CD || "hk_en" == SITE_CD || "n_africa" == SITE_CD || "pk" == SITE_CD || "ch" == SITE_CD || "ch_fr" == SITE_CD || "il" == SITE_CD || "ar" === SITE_CD || "cl" === SITE_CD || "co" === SITE_CD || "mx" === SITE_CD || "pe" === SITE_CD) {
                                    if (g = "account.samsung.com" === n[h] || "stg-account.samsung.com" === n[h] ? n[h] + "/" : n[h] + "/" + SITE_CD + "/", -1 < d.indexOf(g) && "Y" !== a.cookies.get("isStoreLogedIn")) {
                                        c = !1;
                                        break
                                    }
                                } else if (g = n[h] + "/" + SITE_CD + "/", -1 < g.indexOf(d) && "Y" !== a.cookies.get("isStoreLogedIn")) {
                            c = !1;
                            break
                        }
                    }
                    if (c) "es" ===
                        SITE_CD && t(), p(!0), a.EstoreIfQueue && a.EstoreIfQueue.setIsSignReady(!0);
                    else {
                        nextGenLoginResult = function(b) {
                            if ("0000" !== b.resultCode) "903" === b.resultCode || 903 === b.resultCode ? y("BA") : b.customerStatus ? y(b.customerStatus) : y("UK"), e();
                            else {
                                if (!b.hasAddInfo && ("au" === SITE_CD || "latin" === SITE_CD || "tw" === SITE_CD || "ru" === SITE_CD || "ae" === SITE_CD || "ae_ar" === SITE_CD || "vn" === SITE_CD || "th" === SITE_CD || "sa" === SITE_CD || "sa_en" === SITE_CD || "nz" === SITE_CD || "ca" === SITE_CD || "ca_fr" === SITE_CD || "se" === SITE_CD || "dk" === SITE_CD ||
                                        "fi" === SITE_CD || "no" === SITE_CD || "at" === SITE_CD || "my" === SITE_CD || "pt" === SITE_CD || "sg" === SITE_CD || "eg" == SITE_CD || "levant" == SITE_CD || "levant_ar" == SITE_CD || "za" == SITE_CD || "hk" == SITE_CD || "hk_en" == SITE_CD || "n_africa" == SITE_CD || "pk" == SITE_CD || "ch" == SITE_CD || "ch_fr" == SITE_CD || "il" == SITE_CD || "ar" === SITE_CD || "cl" === SITE_CD || "co" === SITE_CD || "mx" === SITE_CD || "pe" === SITE_CD || ("es" === SITE_CD || "it" === SITE_CD) && -1 < STORE_DOMAIN.indexOf("https://")) || !b.hasAddInfo && "cn" !== SITE_CD) W ? L() : (pa = "Y" === ja ? null : U, y());
                                p(!0);
                                "Y" === a.cookies.get("estoreLoginRequesting", {
                                    domain: ".samsung.com"
                                }) && (e(), ss.Auth.getGlobalCartCount());
                                u();
                                a.cookies.set("isStoreLogedIn", "Y")
                            }
                        };
                        a.cookies.set("estoreLoginRequesting", "Y", {
                            domain: ".samsung.com"
                        });
                        var v = "";
                        c = "";
                        v = STORE_DOMAIN.split("/")[2];
                        c = "https://" + v + "/" + SITE_CD + "/ng/p4v1/sessionCheck";
                        "levant" == SITE_CD ? c = "https://" + v + "/jo/ng/p4v1/sessionCheck" : "levant_ar" == SITE_CD ? c = "https://" + v + "/jo_ar/ng/p4v1/sessionCheck" : "n_africa" == SITE_CD && (c = "https://" + v + "/ma/ng/p4v1/sessionCheck");
                        if (wa) try {
                            a.ajax({
                                url: c,
                                type: "GET",
                                data: {
                                    ssoID: k
                                },
                                dataType: "json",
                                xhrFields: {
                                    withCredentials: !0
                                },
                                contentType: "application/x-www-form-urlencoded",
                                crossDomain: !0,
                                success: function(a) {
                                    "0000" !== a.resultCode ? ss.Auth.signOut() : nextGenLoginResult(a)
                                },
                                error: function(a, b, c) {
                                    K = !1
                                }
                            }), K || ss.Auth.signOut()
                        } catch (C) {
                            K = !1
                        } else if ("es" === SITE_CD || "latin" === SITE_CD || "tw" === SITE_CD || "ru" === SITE_CD || "ae" === SITE_CD || "ae_ar" === SITE_CD || "vn" === SITE_CD || "th" === SITE_CD || "sa" === SITE_CD || "sa_en" === SITE_CD || "nz" === SITE_CD || "it" === SITE_CD || "au" === SITE_CD ||
                            "se" === SITE_CD || "dk" === SITE_CD || "fi" === SITE_CD || "no" === SITE_CD || "at" === SITE_CD || "my" === SITE_CD || "pt" === SITE_CD || "sg" === SITE_CD || "us" === SITE_CD || "eg" === SITE_CD || "levant" == SITE_CD || "levant_ar" == SITE_CD || "za" == SITE_CD || "hk" == SITE_CD || "hk_en" == SITE_CD || "n_africa" == SITE_CD || "pk" == SITE_CD || "ch" == SITE_CD || "ch_fr" == SITE_CD || "il" == SITE_CD || "ar" === SITE_CD || "cl" === SITE_CD || "co" === SITE_CD || "mx" === SITE_CD || "pe" === SITE_CD) try {
                            a.ajax({
                                url: c,
                                type: "GET",
                                dataType: "jsonp",
                                data: {
                                    ssoID: k
                                },
                                jsonp: "callback",
                                success: function(a) {
                                    var b =
                                        "0000" === a.resultCode ? !0 : !1;
                                    "latin" === SITE_CD && (b = !0, a.hasAddInfo = !0);
                                    b ? nextGenLoginResult(a) : ss.Auth.signOut()
                                },
                                error: function(a, b, c) {
                                    K = !1
                                }
                            }), K || ss.Auth.signOut()
                        } catch (C) {
                            K = !1
                        } else "cn" === SITE_CD ? (a("body").append("\x3ciframe id\x3d'storeLoginIframe' src\x3d'" + STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/login' style\x3d'display:block;width:0px;height:0px;border:none;'\x3e\x3c/iframe\x3e"), a("#storeLoginIframe").load(function() {
                            a("#storeLoginIframe").unbind("load");
                            try {
                                document.getElementById("storeLoginIframe").contentWindow.postMessage("",
                                    "*");
                                var b = 0;
                                v = STORE_DOMAIN.split("/")[2];
                                a.ajax({
                                    url: "https://" + v + "/" + SITE_CD + "/ng/p4v1/getSessionCheck",
                                    type: "GET",
                                    dataType: "jsonp",
                                    jsonp: "callback",
                                    success: function(c) {
                                        var d = "0000" === c.resultCode ? !0 : !1,
                                            e = "N";
                                        b++;
                                        if (d) b = 0, nextGenLoginResult(c);
                                        else {
                                            var g = function(c) {
                                                b++;
                                                a.ajax({
                                                    url: "https://" + v + "/" + SITE_CD + "/ng/p4v1/getSessionCheck",
                                                    type: "GET",
                                                    dataType: "jsonp",
                                                    jsonp: "callback",
                                                    success: function(a) {
                                                        var c = "0000" === a.resultCode ? !0 : !1;
                                                        e = "N";
                                                        c ? (b = 0, nextGenLoginResult(a)) : (b = "Y" === e) ? (e = "N", setTimeout(function(a) {
                                                            b =
                                                                2;
                                                            return function() {
                                                                g(a)
                                                            }
                                                        }(a), 5E3)) : ss.Auth.signOut()
                                                    },
                                                    error: function(a, b, c) {
                                                        K = !1
                                                    }
                                                })
                                            };
                                            setTimeout(function(a) {
                                                return function() {
                                                    g(a)
                                                }
                                            }(c), 6E3)
                                        }
                                    },
                                    error: function(a, b, c) {
                                        K = !1
                                    }
                                });
                                K || ss.Auth.signOut()
                            } catch (ca) {
                                K = !1, ss.Auth.signOut()
                            }
                        })) : S && p(!0)
                    }
                } else p(!0);
            else d ? "br" === SITE_CD ? (w = window.location.href, b(), a.cookies.set("returnURL", w, {
                domain: ".samsung.com"
            }), window.location.href = H) : J() : c && (p(!0), USE_ESTORE && u());
            ss.Auth.getGlobalCartCount();
            k = l(document.location.search);
            if (null != k.customerStatus || null !=
                k.isblock) k.isblock && "true" === k.isblock ? y("BA") : data.customerStatus ? y(data.customerStatus) : y("UK")
        }
        var V = navigator.userAgent,
            ja = "N";
        "in" === SITE_CD && (-1 < V.indexOf("MyGalaxy") || -1 < V.indexOf("SamsungShopSDK")) && (ja = "Y");
        Granite.I18n.setLocale(a("#language").val());
        var G = a("#runmodeInfo").val(),
            W = "es" === SITE_CD ? !0 : !1,
            da = !1,
            Q = null,
            K = !0,
            w = "",
            H = a("#loginLinkURL").val(),
            F = a("#logoutURL").val(),
            z = a(".gnb-cart-count"),
            Z = a(".gnb__utility").find(".gnb__user-name"),
            B = a(".gnb__utility-mobile").find(".gnb__user-name"),
            A = a(".before-login-context"),
            X = a(".after-login-context");
        a("#scene7domain").val();
        var N = a.cookies.get("mVal11", {
            domain: ".samsung.com"
        });
        null != N && "" != N && (N = decodeURI(N.toString()));
        var S = a("#isLoginWithNoStore").val();
        S = "Y" === S ? !0 : !1;
        var Ka = "GPv2" === a("#shopIntegrationFlag").val() || "Hybris-intg" === a("#shopIntegrationFlag").val() ? "Y" : "",
            Ma = a("#gnbMyAccountUrl").val(),
            aa = "GPv2" === a("#shopIntegrationFlag").val() ? !0 : !1,
            ea = a("#countryIsoCode").val();
        aa && (V = a.cookies.get("s_ecom_sc_cnt", {
                domain: ".samsung.com"
            }),
            null != V && "" !== V && (z.html('\x3cspan class\x3d"hidden"\x3e' + a("#productCountText").val() + " : \x3c/span\x3e" + V), 0 === V ? z.hide() : z.show()));
        var O = a("#multiLanguageYn").val(),
            R = a("#hreflang").val();
        null != R && (R = R.toLowerCase());
        var fa = "https://sso-stg.us.samsung.com/sso";
        "prod" === a("#serverType").val() && (fa = "https://sso-us.samsung.com/sso");
        var ka = [],
            wa = a("#hybrisApiJson").val(),
            pa = null,
            Ra = null,
            na = null,
            T = null,
            x = null,
            za = null,
            ta = null,
            Qa = null,
            Oa = null,
            Ja = null,
            Ha = null,
            Ia = null,
            Aa = null,
            Pa = null,
            Ba = null,
            M = null,
            D =
            null,
            ua = null,
            ab = null,
            k = null,
            gb = null,
            sa = null,
            U = null,
            Ca = null,
            ya = null,
            Sa = null,
            hb = null,
            ib = null,
            Da = a("#loginValidateYnForGPv2"),
            Ta = a("#updateProfileURL").val();
        ss.Auth = {};
        Date.prototype.format = function(a) {
            if (!this.valueOf()) return " ";
            var b = this;
            return a.replace(/(yyyy|MM|dd|HH|mm|ss)/gi, function(a) {
                switch (a) {
                    case "yyyy":
                        return b.getFullYear();
                    case "MM":
                        return (b.getMonth() + 1).zf(2);
                    case "dd":
                        return b.getDate().zf(2);
                    case "HH":
                        return b.getHours().zf(2);
                    case "mm":
                        return b.getMinutes().zf(2);
                    case "ss":
                        return b.getSeconds().zf(2);
                    default:
                        return a
                }
            })
        };
        String.prototype.string = function(a) {
            for (var b = "", c = 0; c++ < a;) b += this;
            return b
        };
        String.prototype.zf = function(a) {
            return "0".string(a - this.length) + this
        };
        Number.prototype.zf = function(a) {
            return this.toString().zf(a)
        };
        String.prototype.escapeHtml = function() {
            return this.replace(/</g, "\x26lt;").replace(/"/g, "\x26quot;").replace(/>/g, "\x26gt;").replace(/'/g, "\x26#039;")
        };
        ss.Auth.checkSignInUs = function() {
            var c = a.cookies.get("xsdcxyn", {
                    domain: ".samsung.com"
                }),
                d = a.cookies.get("jwt_" + ea, {
                    domain: ".samsung.com"
                }),
                e = a.cookies.get("guid", {
                    domain: ".samsung.com"
                }),
                h = function() {
                    a.ajax({
                        url: "/aemapi/v6/data-login/callSALogin." + siteCode + ".json",
                        type: "GET",
                        dataType: "json",
                        success: function(c) {
                            200 === c.statusCode ? "N" === c.redCookieChk ? (g(), b(), J()) : a.cookies.get("jwt_" + ea, {
                                domain: ".samsung.com"
                            }) ? location.reload(!0) : (g(), b(), J()) : (g(), b(), J())
                        },
                        error: function(a, c, d) {
                            console.error(c);
                            g();
                            b();
                            J()
                        }
                    })
                };
            if (d) {
                c = {
                    jwt: d
                };
                var k = !1;
                if ("us" === siteCode) {
                    var l = a.cookies.get("epp_verified", {
                            domain: ".samsung.com"
                        }),
                        m = a.cookies.get("tmktid", {
                            domain: ".samsung.com"
                        }),
                        p = a.cookies.get("store_id", {
                            domain: ".samsung.com"
                        });
                    null != l && (l = l.toString(), "true" == l && null != m && "" != m ? c.store_id = m.toString() : null != p && "" != p && (c.store_id = p.toString()));
                    a.ajax({
                        headers: {
                            "Cache-Control": "no-cache",
                            "Content-Type": "application/json",
                            "Access-Control-Allow-Origin": "*"
                        },
                        url: STORE_DOMAIN + "/v1/sso/jwt/details",
                        type: "POST",
                        async: !1,
                        dataType: "json",
                        data: JSON.stringify({
                            jwt: d
                        }),
                        xhrFields: {
                            withCredentials: !0
                        },
                        success: function(b) {
                            null == b || "" === b || null == b.login_type ||
                                "guest_epp_store" !== b.login_type && "referral_url" !== b.login_type ? a.cookies.set("isUSGuestUser", "N") : (k = !0, a.cookies.set("isUSGuestUser", "Y"))
                        }
                    })
                }
                k ? J() : a.ajax({
                    headers: {
                        "Cache-Control": "no-cache",
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    },
                    url: STORE_DOMAIN + "/v1/sso/user/validate",
                    type: "POST",
                    dataType: "json",
                    data: JSON.stringify(c),
                    xhrFields: {
                        withCredentials: !0
                    },
                    beforeSend: function(a) {
                        "Y" === O && a.setRequestHeader("x-ecom-locale", R)
                    },
                    success: function(a) {
                        200 !== a.statusCode && "200" !==
                            a.statusCode ? h() : null != a.user_info.firstname && "" !== a.user_info.firstname && (A.hide(), X.show(), fnIsNull(e) ? n(a.user_info.firstname + " " + a.user_info.lastname, !0, !0) : n(a.user_info.firstname + " " + a.user_info.lastname, !0))
                    },
                    error: function(a, b, c) {
                        console.error(b);
                        h()
                    }
                })
            } else c ? h() : J()
        };
        ss.Auth.checkSignIn = function(b, c, e) {
            var g = !1,
                h = a.cookies.get("xsdcxyn", {
                    domain: ".samsung.com"
                }),
                k = a.cookies.get("guid", {
                    domain: ".samsung.com"
                });
            h ? c ? USE_ESTORE && (c = "", c = STORE_DOMAIN.split("/")[2], c = "au" === SITE_CD || "latin" ===
                SITE_CD || "tw" === SITE_CD || "ru" === SITE_CD || "ae" === SITE_CD || "ae_ar" === SITE_CD || "vn" === SITE_CD || "th" === SITE_CD || "sa" === SITE_CD || "sa_en" === SITE_CD || "nz" === SITE_CD || "ca" === SITE_CD || "ca_fr" === SITE_CD || "se" === SITE_CD || "dk" === SITE_CD || "fi" === SITE_CD || "no" === SITE_CD || "at" === SITE_CD || "my" === SITE_CD || "es" === SITE_CD || "it" === SITE_CD || "pt" === SITE_CD || "sg" === SITE_CD || "eg" == SITE_CD || "za" == SITE_CD || "hk" == SITE_CD || "hk_en" == SITE_CD || "pk" == SITE_CD || "ch" == SITE_CD || "ch_fr" == SITE_CD || "il" == SITE_CD || "ar" === SITE_CD || "cl" ===
                SITE_CD || "co" === SITE_CD || "mx" === SITE_CD || "pe" === SITE_CD ? "https://" + c + "/" + SITE_CD + "/ng/p4v1/sessionCheck" : "levant" === SITE_CD ? "https://" + c + "/jo/ng/p4v1/sessionCheck" : "levant_ar" === SITE_CD ? "https://" + c + "/jo_ar/ng/p4v1/sessionCheck" : "n_africa" === SITE_CD ? "https://" + c + "/ma/ng/p4v1/sessionCheck" : "https://" + c + "/" + SITE_CD + "/ng/p4v1/getSessionCheck", wa ? a.ajax({
                    url: c,
                    type: "GET",
                    data: {
                        ssoID: k
                    },
                    dataType: "json",
                    xhrFields: {
                        withCredentials: !0
                    },
                    contentType: "application/x-www-form-urlencoded",
                    crossDomain: !0,
                    success: function(a) {
                        b &&
                            "function" == typeof b && (a = "0000" === a.resultCode ? !0 : !1, 0 == a && (d(), e && J()), b(a))
                    },
                    error: function(a, b, c) {}
                }) : a.ajax({
                    url: c,
                    type: "GET",
                    dataType: "jsonp",
                    data: {
                        ssoID: k
                    },
                    jsonp: "callback",
                    success: function(a) {
                        b && "function" == typeof b && (a = "0000" === a.resultCode ? !0 : !1, 0 == a && (d(), e && J()), b(a))
                    },
                    error: function(a, b, c) {}
                })) : (g = !0, b && "function" == typeof b && b(g)) : (b && "function" == typeof b && (b(g), e && J()), p(!1));
            return g
        };
        ss.Auth.callSaSignInGate = function() {
            J()
        };
        ss.Auth.getUserProfile = function(b) {
            if (Q) b && "function" == typeof b &&
                b(Q);
            else {
                var c = a.cookies.get("xsdcxyn", {
                        domain: ".samsung.com"
                    }),
                    d = a.cookies.get("snsSessionId", {
                        domain: ".samsung.com"
                    });
                !c && d ? wa ? a.ajax({
                        url: STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/getSnsUserInfo?snsSessionId\x3d" + d,
                        type: "GET",
                        dataType: "json",
                        xhrFields: {
                            withCredentials: !0
                        },
                        contentType: "application/x-www-form-urlencoded",
                        crossDomain: !0,
                        beforeSend: function() {},
                        success: function(a) {
                            Q = a ? {
                                firstName: a.familyName,
                                lastName: a.givenName
                            } : null;
                            b && "function" == typeof b && b(Q)
                        },
                        error: function(a, b, c) {
                            console.error(b)
                        }
                    }) :
                    a.ajax({
                        url: STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/getSnsUserInfo?snsSessionId\x3d" + d,
                        type: "GET",
                        dataType: "jsonp",
                        jsonp: "callback",
                        beforeSend: function() {},
                        success: function(a) {
                            Q = a ? {
                                firstName: a.familyName,
                                lastName: a.givenName
                            } : null;
                            b && "function" == typeof b && b(Q)
                        },
                        error: function(a, b, c) {
                            console.error(b)
                        }
                    }) : c ? (c = a.cookies.get("firstName", {
                        domain: ".samsung.com"
                    }), d = a.cookies.get("lastName", {
                        domain: ".samsung.com"
                    }), n(c + " " + d, !0), Q = {
                        firstName: c,
                        lastName: d
                    }, reservationUserData = {
                        firstName: c,
                        lastName: d
                    }) : (c = function() {
                        console.log("get user profile Success");
                        var c = a.cookies.get("firstName", {
                                domain: ".samsung.com"
                            }),
                            d = a.cookies.get("lastName", {
                                domain: ".samsung.com"
                            });
                        if (null != c || null != d) {
                            if (Q = {
                                    firstName: c,
                                    lastName: d
                                }, reservationUserData = {
                                    firstName: c,
                                    lastName: d
                                }, USE_ESTORE || S) "vn" === SITE_CD ? n(d, !0) : n(c + " " + d, !0)
                        } else Q = null, (USE_ESTORE || S) && n("", !0);
                        b && "function" == typeof b && b(Q)
                    }, "Y" === a("#useLogin").val() && (USE_ESTORE ? ss.EstoreIfQueue.setQueue(c) : c()))
            }
        };
        ss.Auth.signOutUs = function(b) {
            w = b ? b : window.location.href;
            w = w.escapeHtml();
            var c = a.cookies.get("jwt_" +
                ea, {
                    domain: ".samsung.com"
                });
            c ? (a.ajax({
                headers: {
                    "Cache-Control": "no-cache",
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                },
                url: STORE_DOMAIN + "/v1/sso/user/logout",
                type: "GET",
                dataType: "json",
                xhrFields: {
                    withCredentials: !0
                },
                crossDomain: !0,
                async: !1,
                beforeSend: function(a) {
                    "Y" === O && a.setRequestHeader("x-ecom-locale", R);
                    "us" === siteCode && a.setRequestHeader("x-ecom-jwt", c)
                },
                success: function(b) {
                    200 === b.statusCode || "200" === b.statusCode ? "us" === siteCode ? a.ajax({
                        headers: {
                            "Cache-Control": "no-cache",
                            "Content-Type": "application/json",
                            "Access-Control-Request-Headers": "access-control-allow-origin",
                            "Access-Control-Allow-Origin": "*"
                        },
                        url: fa + "/apiservices/logout",
                        type: "GET",
                        dataType: "jsonp",
                        async: !1,
                        crossDomain: !0,
                        xhrFields: {
                            withCredentials: !0
                        },
                        success: function(a) {
                            window.location.replace("/" + SITE_CD)
                        },
                        error: function(b, c, d) {
                            console.error(c);
                            a.cookies.del("jwt_" + ea, {
                                domain: ".samsung.com"
                            });
                            window.location.replace("/" + SITE_CD)
                        }
                    }) : window.location.replace("/" + SITE_CD) : a.cookies.del("jwt_" + ea, {
                        domain: ".samsung.com"
                    })
                },
                error: function(b, c, d) {
                    console.error(c);
                    a.cookies.del("jwt_" + ea, {
                        domain: ".samsung.com"
                    });
                    window.location.replace("/" + SITE_CD)
                },
                complete: function() {
                    E()
                }
            }), A.show(), X.hide(), n("", !1)) : location.href = w;
            w = void 0
        };
        ss.Auth.signOut = function(a) {
            w = a ? a : window.location.href;
            w = w.escapeHtml();
            (USE_ESTORE || S) && K ? "au" === SITE_CD || "latin" === SITE_CD || "tw" === SITE_CD || "ru" === SITE_CD || "ae" === SITE_CD || "ae_ar" === SITE_CD || "vn" === SITE_CD || "th" === SITE_CD || "sa" === SITE_CD || "sa_en" === SITE_CD || "nz" === SITE_CD || S || "ca" === SITE_CD ||
                "ca_fr" === SITE_CD || "se" === SITE_CD || "dk" === SITE_CD || "fi" === SITE_CD || "no" === SITE_CD || "at" === SITE_CD || "my" === SITE_CD || ("es" === SITE_CD || "it" === SITE_CD) && -1 < STORE_DOMAIN.indexOf("https://") || "pt" === SITE_CD || "sg" === SITE_CD || "za" == SITE_CD || "hk" == SITE_CD || "hk_en" == SITE_CD || "eg" == SITE_CD || "levant" == SITE_CD || "levant_ar" == SITE_CD || "n_africa" == SITE_CD || "pk" == SITE_CD || "ch" == SITE_CD || "ch_fr" == SITE_CD || "il" == SITE_CD || "ar" === SITE_CD || "cl" === SITE_CD || "co" === SITE_CD || "mx" === SITE_CD || "pe" === SITE_CD ? (E(), c(!1)) : location.href =
                STORE_DOMAIN + "/" + SITE_CD + "/ng/logout?goUrl\x3d" + encodeURIComponent(w) : location.href = w;
            w = void 0;
            Q = null
        };
        ss.Auth.setCartEl = function(b) {
            var c = a(".js-global-cart-btn");
            b ? (c.each(function() {
                a(this).hasClass(".js-has-carturl") && a(this).attr("an-tr", "nv00_gnb--cart-depth1")
            }), c.removeClass("js-layer-open"), c.removeAttr("data-div-id"), b = c.data("cart-url"), c.attr("href", b)) : (c.addClass("js-layer-open"), c.attr("data-div-id", "#layerEmptyCart"), c.attr("an-tr", "nv00_gnb--text-depth1"), c.attr("href", "javascript:;"));
            window.sg.components.gnb.reInit()
        };
        ss.Auth.getGlobalCartCount = function(b) {
            function c(c) {
                var d = !1;
                if (c)
                    if ("0000" === c.resultCode) {
                        var e = 99 < parseInt(c.cartCount) ? 99 : parseInt(c.cartCount);
                        z.html('\x3cspan class\x3d"hidden"\x3e' + a("#productCountText").val() + " : \x3c/span\x3e" + e);
                        0 < e && (z.show(), d = !0)
                    } else z.html('\x3cspan class\x3d"hidden"\x3e' + a("#productCountText").val() + " : \x3c/span\x3e0"), z.hide(), d = !1;
                else z.html('\x3cspan class\x3d"hidden"\x3e' + a("#productCountText").val() + " : \x3c/span\x3e0"), z.hide(),
                    d = !1;
                ss.Auth.setCartEl(d);
                b && "function" == typeof b && b(c)
            }
            USE_ESTORE && "Y" !== a.cookies.get("estoreLoginRequesting", {
                domain: ".samsung.com"
            }) && ss.Auth.checkSignIn(function(b) {
                if (b) estore.getCartCount(c);
                else {
                    b = ss.cookies.get("everAddCart", {
                        domain: ".samsung.com"
                    });
                    if ("br" === SITE_CD || "ar" === SITE_CD || "cl" === SITE_CD || "mx" === SITE_CD || "pe" === SITE_CD || "co" === SITE_CD) b = "Y";
                    "sec" !== SITE_CD || void 0 !== b && null !== b || (b = "N");
                    "Y" === b ? estore.getCartCount(c) : (z.html('\x3cspan class\x3d"hidden"\x3e' + a("#productCountText").val() +
                        " : \x3c/span\x3e0"), z.hide(), ss.Auth.setCartEl(!1))
                }
            })
        };
        ss.Auth.setReturnURL = function(a) {};
        na = a("#joinForm");
        T = a("#findAccountForm");
        x = a("#signInForm");
        za = a("#signOutForm");
        Ra = a("#loginLayerPopup");
        Ba = a("#email");
        M = a("#password");
        D = a("#save-mail");
        ua = a("label[for\x3d'save-mail']");
        ab = a("#errorId");
        k = a("#errorPw");
        ta = a("input[type\x3d'submit'].sign-in__btn-submit");
        Qa = a(".sign-in__btn-submit__black");
        Oa = a(".sign-in__form-forgot-password a");
        Ja = a("#signToggleArrow");
        gb = a("#loginLayerPopup .login-close-btn");
        Ha = a(".login-leave-btn");
        sa = a(".layer-popup-dim");
        U = a("#layerPrivacy");
        aa && (U = a("#layerPrivacyGPV2"));
        Ca = a("#layerPreference");
        ya = a("#confirmPopup");
        Sa = a("#privacyBtn", U);
        Ia = a("#privacy-terms", U);
        Aa = a("#privacy-terms2", U);
        Pa = a("#errorPrivacy", U);
        hb = a("#preferenceCheckBtn", Ca);
        ib = a("#privacyCloseBtn");
        (function() {
            function b(a) {
                a ? ss.Auth.signOut(w) : J()
            }
            ta.click(function() {
                signIn()
            });
            Qa.click(function() {
                w = "http://" + window.location.host + "/" + SITE_CD + "/";
                a("#joinReturnURL", na).val(w);
                a("#joinGoBackURL",
                    na).val(w);
                var b = a("#joinRegistURL", na).val();
                var c = window.location.port;
                c = null == c || "" === c || "80" === c || "8080" === c ? "https://" + window.location.host : "http://" + window.location.host;
                0 > b.indexOf(window.location.hostname) && (b = c + b, a("#joinRegistURL", na).val(b));
                b = a("#joinEmailActivationURL", na).val();
                0 > b.indexOf(window.location.hostname) && (b = window.location.protocol + "//" + window.location.host + b, a("#joinEmailActivationURL", na).val(b));
                na.submit()
            });
            Oa.click(function() {
                w = window.location.href;
                a("#findReturnURL",
                    T).val(w);
                a("#findGoBackURL", T).val(w);
                T.submit()
            });
            gb.click(function() {
                a(this).closest("#loginLayerPopup").is(":visible") && (a("body").removeClass("gb-login-open"), a("#loginLayerPopup .popAlign").trigger("clickoutside", "touchstartoutside"))
            });
            Ha.click(function() {
                "es" === SITE_CD && ss.Auth.signOut();
                t();
                return !1
            });
            a(document).on("click", ".loginBtn", function(c) {
                c.preventDefault();
                "br" === SITE_CD ? window.location.href = a(this).data("linkinfo") : aa ? ss.Auth.checkSignInUs() : ss.Auth.checkSignIn(b)
            });
            a(document).on("click",
                ".logoutBtn",
                function(c) {
                    c.preventDefault();
                    c = a(this).attr("data-return-url");
                    aa ? ("dev" === G ? w = window.location.protocol + "//" + window.location.host + "/content/samsung/" + SITE_CD + ".html" : "qa" === G ? w = window.location.protocol + "//" + window.location.host + "/" + SITE_CD + ".html" : "live" === G && (w = window.location.protocol + "//" + window.location.host + "/" + SITE_CD + "/"), ss.Auth.signOutUs()) : (null != c && "" !== c ? w = c : "dev" === G ? w = window.location.protocol + "//" + window.location.host + "/content/samsung/" + SITE_CD + ".html" : "qa" === G ? w = window.location.protocol +
                        "//" + window.location.host + "/" + SITE_CD + ".html" : "live" === G && (w = window.location.protocol + "//" + window.location.host + "/" + SITE_CD + "/"), ss.Auth.checkSignIn(b));
                    return !1
                });
            a(".sign_input").focusin(function() {
                switch (a(this).attr("id")) {
                    case Ba.attr("id"):
                        ab.hide();
                        break;
                    case M.attr("id"):
                        k.hide()
                }
            });
            a(".sign-in__form-text").unbind("keydown").bind("keydown", function(b) {
                if ("13" === b.keyCode) switch (b.preventDefault(), a(this).attr("id")) {
                    case Ba.attr("id"):
                    case M.attr("id"):
                        signIn()
                }
            });
            D.focusin(function(a) {
                a.preventDefault();
                ua.addClass("fs-boarder")
            });
            D.focusout(function(a) {
                a.preventDefault();
                ua.removeClass()
            });
            Sa.click(function() {
                if (!Ia.is(":checked")) return Pa.show(), !1;
                da = Aa.is(":checked");
                if (0 < ka.length) {
                    var b = ka[0].id;
                    if (null != ka[1]) var c = ka[1].id
                }
                if (W) return a.cookies.set("shopPrivacyPolicyAgreeYN", "Y", {
                    domain: ".samsung.com"
                }), ia();
                if (aa) {
                    var d = Ia.is(":checked") ? !0 : !1,
                        e = null != c ? Aa.is(":checked") ? !0 : !1 : !1;
                    "in" === SITE_CD ? b = {
                        terms_and_conditions: {
                            is_accepted: d
                        },
                        email_consent: e
                    } : (b = '{"consents": {"' + b + '" : {"is_accepted" : ' +
                        d + "}", null != c && (b += ',"' + c + '" : {"is_accepted" : ' + e + "}"), b += "}}");
                    return v(b)
                }
                return L()
            });
            Ia.change(function() {
                Pa.hide()
            });
            hb.click(function() {
                if ("Y" === Ka) aa ? (a("#accountModifyForm").attr("target", ""), a("#accountModifyForm").submit()) : window.location.href = Ma;
                else if (null != Ta && "" !== Ta)
                    if ("ca" === SITE_CD || "ca_fr" === SITE_CD) {
                        var b = a.cookies.get("prof_id", {
                                domain: ".samsung.com"
                            }),
                            c = a.cookies.get("prof_country", {
                                domain: ".samsung.com"
                            });
                        window.location.href = "https://support-ca.samsung.com/seca/myaccount/ap/premodify/go?prof_id\x3d" +
                            b + "\x26lang\x3d" + c + "\x26page\x3dmyaccount"
                    } else window.location.href = STORE_DOMAIN + Ta;
                else window.location.href = STORE_DOMAIN + "/" + SITE_CD + "/ng/my-samsung/updatemyprofile"
            });
            ib.click(function() {
                a(this).closest("#layerPreference").is(":visible") && (a(this).closest("#layerPreference").hide(), sa.hide())
            });
            Ja.click(function() {
                a(".icon-down-arrow", Ra).toggleClass("icon-up-arrow")
            })
        })();
        (function() {
            var b = a.cookies.get("xsdcxyn", {
                    domain: ".samsung.com"
                }),
                c = a.cookies.get("guid", {
                    domain: ".samsung.com"
                });
            aa ? b ? b ?
                ma(b) : ma() : ma() : b && W ? a.ajax({
                    url: STORE_DOMAIN + "/" + SITE_CD + "/ng/p4v1/getGuidCheckInfo",
                    type: "GET",
                    dataType: "jsonp",
                    data: {
                        ssoID: c
                    },
                    jsonp: "callback",
                    beforeSend: function() {},
                    success: function(a) {
                        "0000" === a.resultCode ? "N" === a.resultValue ? (t(), pa = "Y" === ja ? null : U, y()) : ia() : ss.Auth.signOut()
                    },
                    error: function(a, b, c) {
                        console.error(b)
                    }
                }) : ia()
        })()
    }
})(jQuery);
new ss.Sign;
(function() {
    window.AEMapp = window.AEMapp || {};
    window.AEMapp.eppStore = window.AEMapp.eppStore || {};
    window.AEMapp.eppStore.isRealEppUser = function() {
        var a = $.cookies.get("jwt_USA"),
            b = $.cookies.get("tmktid"),
            d = $.cookies.get("taccessrtype") || "";
        return !!a && !!b && ~d.toLowerCase().indexOf("email")
    };
    window.AEMapp.eppStore.isUnverifiedEppUser = function() {
        var a = $.cookies.get("tmktid"),
            b = $.cookies.get("taccessrtype") || "";
        return !!$.cookies.get("jwt_USA") && !!a && -1 == b.toLowerCase().indexOf("email")
    };
    window.AEMapp.eppStore.setEppStoreCookie =
        function(a) {
            var b = a && a.store_info,
                d = {
                    path: "/",
                    domain: ".samsung.com"
                };
            $.cookies.set("jwt_USA", a.jwt, d);
            $.cookies.set("epp_verified", a.epp_verified, d);
            $.cookies.set("tmktname", b.store_disp_name, d);
            $.cookies.set("tmktid", b.store_id, d);
            $.cookies.set("tlgimg", b.image_logo_url, d);
            $.cookies.set("tppid", b.legacy_plan_id, d);
            $.cookies.set("tsgmt", b.store_segment, d)
        };
    window.AEMapp.eppStore.clearEppStoreCookie = function() {
        var a = {
            path: "/",
            domain: ".samsung.com"
        };
        $.cookies.del("tmktname", a);
        $.cookies.del("tmktid",
            a);
        $.cookies.del("tlgimg", a);
        $.cookies.del("tppid", a);
        $.cookies.del("tsgmt", a);
        $.cookies.del("epp_verified", a)
    };
    window.AEMapp.eppStore.getEcomURL = function() {
        var a = "https://www.samsung.com/us/api/ecom";
        ~window.location.href.indexOf("stgwwwus") && (a = "https://us.ecom-qa.samsung.com");
        ~window.location.href.indexOf("stgwebus") && (a = "https://us.ecom-stg.samsung.com");
        return a
    };
    window.AEMapp.eppStore.getEppStore = function() {
        return new Promise(function(a, b) {
            $.ajax({
                url: "/us/smg/content/samsung/content-library/prepurchase/eppdiscount/epp-discount.json",
                method: "GET",
                success: function(b) {
                    a(b)
                },
                error: function(b) {
                    a({
                        eppDiscounts: [{
                            storeId: "4789741110",
                            label: "Education Discounts"
                        }, {
                            storeId: "654345",
                            label: "First Responders Discounts"
                        }, {
                            storeId: "4789760945",
                            label: "Government Discounts"
                        }, {
                            storeId: "3485000",
                            label: "Workplace Discounts"
                        }, {
                            storeId: "4789760940",
                            label: "Military Discounts"
                        }]
                    })
                }
            })
        })
    };
    window.AEMapp.eppStore.exitStore = function() {
        $.cookies.get("jwt_USA") && $.ajax({
            url: window.AEMapp.eppStore.getEcomURL() + "/v1/sso/user/private-store/exit-store",
            method: "GET",
            headers: {
                "x-ecom-jwt": $.cookies.get("jwt_USA")
            },
            success: function(a) {
                a && a.jwt ? $.cookies.set("jwt_USA", a.jwt, {
                    path: "/",
                    domain: ".samsung.com"
                }) : $.cookies.del("jwt_USA", {
                    path: "/",
                    domain: ".samsung.com"
                })
            },
            fail: function() {
                $.cookies.del("jwt_USA", {
                    path: "/",
                    domain: ".samsung.com"
                })
            }
        });
        window.AEMapp.eppStore.clearEppStoreCookie()
    };
    window.AEMapp.eppStore.updateGNBCartSaving = function() {
        function a(b, d) {
            _.each(b, function(b) {
                d = ((100 * b.line_item_cost.unit_list_price - 100 * b.line_item_cost.unit_price) / 100 * 1E5 * b.quantity /
                    1E3 + 100 * d) / 100;
                b.line_items && 0 < Object.keys(b.line_items).length && (d = a(b.line_items, d))
            });
            return d
        }($.cookies.get("remoteId") || $.cookies.get("xsdcxyn")) && $.cookies.get("tppid") && 1 <= $.cookies.get("s_ecom_sc_cnt") ? $.ajax({
            type: "POST",
            url: window.AEMapp.eppStore.getEcomURL() + "/v4/shopping-carts/fetch-cart",
            headers: {
                "x-ecom-jwt": $.cookies.get("jwt_USA"),
                "x-ecom-app-id": "temp"
            },
            contentType: "application/json",
            data: JSON.stringify({}),
            xhrFields: {
                withCredentials: !0,
                crossDomain: !0
            }
        }).then(function(b) {
            (b = a(b.line_items,
                0)) && (0 < $(".epp-bar-save").length ? $(".epp-bar-save").html("You will save \x3cb\x3e$" + b.toFixed(2) + "\x3c/b\x3e on this purchase.") : $(".epp-bar-msg").after('\x3cspan class\x3d"epp-bar-save"\x3eYou will save \x3cb\x3e$' + b.toFixed(2) + "\x3c/b\x3e on this purchase.\x3c/span\x3e"))
        }) : $(".epp-bar-save").remove()
    };
    window.AEMapp.eppStore.updateEppGNB = function(a, b) {
        var d = {
                education: "/us/shop/discount-program/education/",
                "first responder": "/us/shop/discount-program/first-responders/",
                government: "/us/shop/discount-program/government/",
                employee: "/us/shop/discount-program/workplace/",
                military: "/us/shop/discount-program/military/"
            }[($.cookies.get("tsgmt") || "").toLowerCase()] || "/us/shop/discount-program/",
            e = $(".epp-bar-wrap");
        e.show();
        e.addClass("gnb-edited");
        var c = e.find(".epp-bar-msg");
        c.empty();
        var g = e.find(".benfit-wrap");
        g.empty();
        var l = e.find(".epp-bar-logo");
        l.empty();
        $.cookies.get("tlgimg") && l.append("\x3cimg src\x3d" + $.cookies.get("tlgimg") + " /\x3e");
        $.cookies.get("remoteId") || $.cookies.get("xsdcxyn") ? c.append('Welcome to the \x3cdiv class\x3d"epp-bar-username"\x3e' +
            a + " Store!\x3c/div\x3e Please enjoy our special offers for you.") : c.append('Welcome to the \x3cdiv class\x3d"epp-bar-username"\x3e' + a + ' Store!\x3c/div\x3e Please \x3ca href\x3d"#" class\x3d"epp-login"\x3elogin\x3c/a\x3e to access your special pricing.');
        g.append('\x3ca class\x3d"benfit-wrap__offers" href\x3d"' + d + '"\x3eSPECIAL OFFERS\x3c/a\x3e\x3cspan class\x3d"benfit-wrap__gap"\x3e\x3c/span\x3e\x3ca class\x3d"benfit-wrap__exit"\x3eEXIT STORE\x3c/a\x3e');
        e.find(".epp-login").click(function(a) {
            a.preventDefault();
            $(".gnb__utility-link.loginBtn").trigger("click")
        });
        g.find(".benfit-wrap__exit").click(function() {
            window.AEMapp.eppStore.exitStore();
            $(document).trigger("exit__store")
        });
        ($.cookies.get("remoteId") || $.cookies.get("xsdcxyn")) && $.cookies.get("tppid") && 1 <= $.cookies.get("s_ecom_sc_cnt") && window.AEMapp.eppStore.updateGNBCartSaving();
        a = e.find(".benfit-wrap__exit");
        a.attr("an-tr", "epp discount-" + b + "-text-link");
        a.attr("an-ca", "content click");
        a.attr("an-ac", "feature");
        a.attr("an-la", "epp:bar:exit store");
        e = e.find(".benfit-wrap__offers");
        e.attr("an-tr", "epp discount-" + b + "-text-link");
        e.attr("an-ca", "content click");
        e.attr("an-ac", "feature");
        e.attr("an-la", "epp:bar:special offer")
    };
    if ("us" === siteCode)
        if ($.cookies.get("tmktid") || $.cookies.get("tppid")) {
            $.cookies.get("xsdcxyn") || $.cookies.get("remoteId");
            var a = $.cookies.get("tlgimg"),
                l = $.cookies.get("tmktname");
            if (window.AEMapp && window.AEMapp.eppStore && window.AEMapp.eppStore.isUnverifiedEppUser()) window.AEMapp.eppStore.updateEppGNB(l, window.digitalData &&
                window.digitalData.page && window.digitalData.page.pageInfo && window.digitalData.page.pageInfo.pageTrack || "");
            else {
                if ($.cookies.get("xsdcxyn") || $.cookies.get("remoteId")) {
                    var e = $.cookies.get("firstName") && $.cookies.get("firstName") ? $.cookies.get("firstName") : $.cookies.get("tmktname");
                    $(".epp-bar-logo img").remove();
                    $(".epp-bar-logo").append('\x3cimg src\x3d"' + a + '"/\x3e');
                    "null" != e ? $(".epp-bar-msg").html('Welcome to the \x3cdiv class\x3d"epp-bar-username"\x3e' + l + " Store.\x3c/div\x3e Please enjoy our special offers for you") :
                        $(".epp-bar-msg").html('Welcome \x3cdiv class\x3d"epp-bar-username"\x3e' + l + '!\x3c/div\x3e Please \x3ca href\x3d"#" id\x3d"openLogin" style\x3d"color:#1428a0;font-weight: bold"\x3elogin\x3c/a\x3e to enjoy our special offers for you')
                } else($.cookies.get("xsdcxyn") || $.cookies.get("remoteId")) && "4145500" === $.cookies.get("tmktid") && "17593200" === $.cookies.get("tppid") ? ($(".epp-bar-logo img").remove(), $(".epp-bar-logo").append('\x3cimg src\x3d"' + a + '"/\x3e'), $(".epp-bar-msg").html("Welcome to Samsung's Friends and Family Store! Enjoy special pricing. Please \x3ca href\x3d'#' id\x3d'openLogin' style\x3d'font-size:12px;font-weight: bold'\x3elogin/signup\x3c/a\x3e to make a purchase.")) :
                    ($(".epp-bar-logo img").remove(), $(".epp-bar-logo").append('\x3cimg src\x3d"' + a + '"/\x3e'), $(".epp-bar-msg").html('Welcome to the \x3cdiv class\x3d"epp-bar-username" style\x3d"color:#1428a0;"\x3e' + l + " Store!\x3c/div\x3e Please \x3ca href\x3d'#' id\x3d'openLogin' style\x3d'color:#1428a0;font-weight: bold'\x3elogin\x3c/a\x3e to enjoy our special pricing."), $("#openLogin").click(function(a) {
                        a.preventDefault();
                        $(".gnb-login").trigger("click")
                    }));
                $(".epp-bar-wrap").slideDown();
                window.AEMapp && window.AEMapp.eppStore &&
                    window.AEMapp.eppStore.updateGNBCartSaving()
            }
        } else $(".epp-bar-wrap").hide()
})();
(function(a, l) {
    var e = function() {
        var a = l("#typeCodeForGNB").val(),
            b = l("#groupCodeForGNB").val();
        l(".js-gnb-menu-btn");
        if (!fnIsNull(a) || !fnIsNull(b)) {
            var d = l(".gnb__depth2-menu").filter("[data-type-code\x3d'" + a + "']");
            fnIsNull(d) && (d = l(".gnb__depth2-menu").filter("[data-group-code\x3d'" + b + "']"));
            fnIsNull(d) || d.each(function(a) {
                0 === a && (d.closest(".gnb__depth1-menu").addClass("active-first"), d.addClass("active-second"))
            })
        }
    };
    l(function() {
        e()
    })
})(window, $);
var cookieCode = "",
    selectedCode = "";

function setCookie(a, l, e) {
    var g = new Date;
    g.setTime(g.getTime() + 864E5 * e);
    document.cookie = a + "\x3d" + l + ";expires\x3d" + g.toUTCString() + ";path\x3d/"
}

function getCookie(a) {
    return (a = document.cookie.match("(^|;) ?" + a + "\x3d([^;]*)(;|$)")) ? a[2] : null
}

function ajaxStore(a) {
    $.ajax({
        url: "https://shop.samsung.com/" + a + "/ng/p4v1/getEstoreCategoryListJsonP",
        type: "GET",
        dataType: "jsonp",
        success: function(a) {
            "0000" == a.resultCode && (a = createHTML(a.categoryData), $(".shopLayer").html(""), $(".shopLayer").html(a), window.sg.components.gnb.reInit())
        },
        error: function(a) {
            console.log(a)
        }
    })
}

function createHTML(a) {
    for (var l = "", e = 0; e < a.length; e++) {
        var g = a[e].subCategoryList;
        fnIsNull(a[e].enCategoryName) || (a[e].enCategoryName = a[e].enCategoryName.toLowerCase());
        if (0 < g.length) {
            l += '\x3cli class\x3d"gnb__depth2-menu has-depth-menu" role\x3d"presentation"\x3e\x3ca class\x3d"gnb__depth2-link" href\x3d"javascript:void(0)" role\x3d"menuitem"an-tr\x3d"nv00_gnb--hover-depth2" an-ca\x3d"navigation" an-ac\x3d"gnb" an-la\x3d"shop:' + a[e].enCategoryName + '"\x3e\x3cspan class\x3d"gnb__depth2-link-text"\x3e' +
                a[e].categoryName + '\x3c/span\x3e\x3csvg class\x3d"icon icon--next" xmlns\x3d"http://www.w3.org/2000/svg" viewBox\x3d"0 0 96 96" focusable\x3d"false"\x3e\x3cpath d\x3d"M31.828 16.306l3.457-3.612L72.172 48 35.285 83.306l-3.457-3.612L64.941 48z"\x3e\x3c/path\x3e\x3c/svg\x3e\x3csvg class\x3d"icon icon--dropdown" xmlns\x3d"http://www.w3.org/2000/svg" viewBox\x3d"0 0 96 96" focusable\x3d"false"\x3e\x3cpath d\x3d"M48 73.254L11.651 36.361l5.698-5.614L48 61.855l30.651-31.108 5.698 5.614z"\x3e\x3c/path\x3e\x3c/svg\x3e\x3c/a\x3e\x3cdiv class\x3d"gnb__depth3-wrap"\x3e\x3cdiv class\x3d"gnb__depth3-inner"\x3e\x3cul class\x3d"gnb__depth3" role\x3d"menu" data-sly-list.lv2model\x3d"${lv1model.level2List}"\x3e';
            for (var b = 0; b < g.length; b++) fnIsNull(g[b].enSubCategoryName) || (g[b].enSubCategoryName = g[b].enSubCategoryName.toLowerCase()), l += '\x3cli class\x3d"gnb__depth3-menu" role\x3d"presentation"\x3e\x3ca class\x3d"gnb__depth3-link" href\x3d"' + g[b].url + '" role\x3d"menuitem"an-tr\x3d"nv00_gnb--text-depth3" an-ca\x3d"navigation" an-ac\x3d"gnb" an-la\x3d"shop:' + a[e].enCategoryName + ":" + g[b].enSubCategoryName + '"\x3e\x3cspan class\x3d"gnb__depth3-link-text"\x3e' + g[b].subCategoryName + "\x3c/span\x3e\x3c/a\x3e\x3c/li\x3e";
            l += "\x3c/ul\x3e\x3c/div\x3e\x3c/div\x3e\x3c/li\x3e"
        } else l += '\x3cli class\x3d"gnb__depth2-menu" role\x3d"presentation"\x3e\x3ca class\x3d"gnb__depth2-link" href\x3d"' + a[e].url + '" role\x3d"menuitem"an-tr\x3d"nv00_gnb--click-depth2" an-ca\x3d"navigation" an-ac\x3d"gnb" an-la\x3d"shop:' + a[e].enCategoryName + '"\x3e\x3cspan class\x3d"gnb__depth2-link-text"\x3e' + a[e].categoryName + "\x3c/span\x3e\x3c/a\x3e\x3c/li\x3e"
    }
    return l
}
(function(a, l) {
    var e = a(".gnb__country").find("a.gnb__country-select");
    l = a(".gnb__country-mobile").find(".gnb__country-select");
    var g = l.find("option");
    e.click(function(b) {
        b.preventDefault();
        e.removeClass("is-selected");
        a(this).addClass("is-selected");
        b = a(this).attr("data-code");
        0 > cookieCode.indexOf("_ar") ? setCookie("dotcom_multistore", b, 7) : setCookie("dotcom_multistore", b + "_ar", 7);
        location.reload(!0)
    });
    l.change(function(b) {
        b.preventDefault();
        b = a(this).val();
        0 > cookieCode.indexOf("_ar") ? setCookie("dotcom_multistore",
            b, 7) : setCookie("dotcom_multistore", b + "_ar", 7);
        location.reload(!0)
    });
    a(function() {
        cookieCode = getCookie("dotcom_home");
        selectedCode = getCookie("dotcom_multistore");
        if ("ae" === SITE_CD || "ae_ar" === SITE_CD) {
            if ("" === selectedCode || null == selectedCode || cookieCode !== SITE_CD) setCookie("dotcom_home", SITE_CD, 7), setCookie("dotcom_multistore", SITE_CD, 7), selectedCode = cookieCode = SITE_CD;
            if (selectedCode != SITE_CD) {
                e.removeClass("is-selected");
                var b = "",
                    d = "";
                e.each(function() {
                    var e = a(this).attr("data-code"); - 1 < selectedCode.indexOf(e) &&
                        (a(this).addClass("is-selected"), b = a(this).find(".image__main").attr("data-src"), d = a(this).find("span").text(), a(".gnb__country-current .image__preview").attr("data-src", b + "?$LazyLoad_Home_PNG$"), a(".gnb__country-current .image__preview").attr("src", b + "?$LazyLoad_Home_PNG$"), a(".gnb__country-current .image__main").attr("data-src", b), a(".gnb__country-current .image__main").attr("src", b), a(".gnb__country-current \x3e span").text(d))
                });
                g.removeAttr("selected");
                g.each(function(b) {
                    a(this).val() == selectedCode &&
                        a(this).attr("selected", !0)
                });
                ajaxStore(selectedCode)
            }
        }
    })
})(jQuery, window);
$(function() {
    function a() {
        var a = -1 < window.location.href.indexOf("www.samsung.com") ? "/us/smg/content/samsung/content-library/gnb/gnb-header/json/pub/gnb-header-menu.json" : "/etc.clientlibs/samsung/clientlibs/consumer/global/clientlib-common/resources/json/gnb-header-menu.json";
        $.ajax({
            url: a,
            dataType: "json"
        }).then(function(a) {
            if (a && a.menuOptions && 0 < a.menuOptions.length) {
                $(".gnb__depth2-title-wrap, .gnb__depth2, .gnb__feature-container").remove();
                $(".gnb").addClass("isHybrid");
                var e = function(a) {
                    a = (a ||
                        "").replace(/\+/gi, "plus").replace(/&/gi, "and").replace(/\$/gi, "dollar").replace(/%/gi, "percentage").replace(/"/gi, "inches");
                    a = a.replace(/\||\-|~|,|\.|!|\?|@|=|#|\*|'/gi, "");
                    return a.toLowerCase()
                };
                $(".gnb__depth1-menu").each(function(b, d) {
                    $(d).find(".gnb__depth2-wrap").addClass("isHybrid one-col");
                    $(d).find(".gnb__depth2-wrap .gnb__depth-back").append('\x3cspan class\x3d"gnb__depth1-name"\x3e\x3c/span\x3e');
                    if ($(d).hasClass("has-depth-menu")) {
                        var g = a.menuOptions[b];
                        if (g) {
                            b = "";
                            b = g.titleTaburl ? '\x3ca class\x3d"gnb__depth2-title-link" href\x3d"' +
                                g.titleTaburl + '"\x3e' + (g.titleTabHeadline ? g.titleTabHeadline : "") + "\x3c/a\x3e" : '\x3cspan class\x3d"gnb__depth2-title-text"\x3e' + (g.titleTabHeadline ? g.titleTabHeadline : "") + "\x3c/span\x3e";
                            b = '\x3cdiv class\x3d"gnb__depth2-title-wrap"\x3e\x3cstrong class\x3d"gnb__depth2-title"\x3e' + b + "\x3c/strong\x3e\x3c/div\x3e";
                            var c = g.foImg ? '\x3cdiv class\x3d"gnb__feature-container"\x3e \x3ca class\x3d"gnb__feature-container-link" an-tr\x3d"nv00_gnb--cta-feature" an-ca\x3d"navigation" an-la\x3d"feature image:' + (g.titleTabHeadline ?
                                    e(g.titleTabHeadline) : "") + ":" + (g.fiHeadline ? e(g.fiHeadline) : "") + ":" + (g.fiCtaText ? e(g.fiCtaText) : "") + '" an-ac\x3d"gnb" data-link_cat\x3d"navigation hybrid-accordion" data-link_id\x3d"' + g.fiHeadline + '" data-link_meta\x3d"link_name:' + g.fiHeadline + '" data-link_position\x3d"navigation\x3egnb\x3e' + g.titleTabHeadline + '" data-event_name\x3d"select_' + g.titleTabHeadline + '_click" href\x3d"' + (g.foLinkUrl ? g.foLinkUrl : "javascript:void(0);") + '"\x3e\x3cdiv class\x3d"image"\x3e \x3cimg class\x3d"image__main responsive-img lazy-load image__main" data-src\x3d"' +
                                g.foImg + '" data-mobile-src\x3d"' + g.foImg + '" alt\x3d"' + (g.foImgAlt ? g.foImgAlt : "") + '"\x3e\x3c/div\x3e\x3cdiv class\x3d"gnb__feature-container-contents"\x3e\x3cp class\x3d"gnb__feature-container-description"\x3e' + (g.fiHeadline ? g.fiHeadline : "") + '\x3c/p\x3e \x3cspan class\x3d"cta cta--contained hidden cta--black"\x3e' + (g.fiCtaText ? g.fiCtaText : "") + "\x3c/span\x3e\x3c/div\x3e\x3c/a\x3e\x3c/div\x3e" : "",
                                h = "";
                            g.children && (h += '\x3cul class\x3d"gnb__depth2 isHybrid" role\x3d"menu"\x3e', $.each(g.children, function(a,
                                b) {
                                a = b.children ? "has-depth-menu" : "";
                                var c = b.flyOutSections ? b.flyOutSections[0].flyOutImage ? b.flyOutSections : void 0 : void 0,
                                    d = c ? c[0].flyOutBlackTextTheme ? "" : "text-color--white" : "",
                                    l = '\x3cli class\x3d"gnb__depth2-menu ' + a + '" role\x3d"presentation"\x3e';
                                l += '\x3ca class\x3d"gnb__depth2-link" target\x3d"' + ("B" == b.linkTarget ? "_blank" : "_self") + '" href\x3d"' + (b.linkUrl ? b.linkUrl : "javascript:void(0);") + '" role\x3d"menuitem" ' + (c ? 'data-flyout-url\x3d"' + c[0].flyOutLink + '" data-flyout-text\x3d"' + c[0].flyOutTitle +
                                    '" data-flyout-img\x3d"' + c[0].flyOutImage + '" data-flyout-theme\x3d"' + d + '"' : 'data-flyout-url\x3d"' + (g.foLinkUrl || "") + '" data-flyout-text\x3d"' + (g.fiHeadline || "") + '" data-flyout-img\x3d"' + (g.foImg || "") + '"') + '\x3e\x3cspan class\x3d"gnb__depth2-link-text"\x3e' + b.displayName + "\x3c/span\x3e" + (a ? '\x3csvg class\x3d"icon icon--next" id\x3d"next-regular" xmlns\x3d"http://www.w3.org/2000/svg" viewBox\x3d"0 0 96 96"\x3e\x3cpath d\x3d"M31.828 16.306l3.457-3.612L72.172 48 35.285 83.306l-3.457-3.612L64.941 48z"\x3e\x3c/path\x3e\x3c/svg\x3e' :
                                    "") + "\x3c/a\x3e";
                                l += a ? '\x3ca class\x3d"gnb__depth2-dropdown-cta" href\x3d"javascript:void(0)"\x3e\x3cspan class\x3d"hidden"\x3eOpen Menu\x3c/span\x3e\x3csvg class\x3d"icon icon--dropdown" id\x3d"open-down-bold" xmlns\x3d"http://www.w3.org/2000/svg" viewBox\x3d"0 0 96 96"\x3e\x3cpath d\x3d"M48 73.254L11.651 36.361l5.698-5.614L48 61.855l30.651-31.108 5.698 5.614z"\x3e\x3c/path\x3e\x3c/svg\x3e\x3c/a\x3e' : "";
                                a && (l += '\x3cdiv class\x3d"gnb__depth3-wrap "\x3e\x3cdiv class\x3d"gnb__depth3-inner"\x3e\x3cul class\x3d"gnb__depth3" role\x3d"menu"\x3e',
                                    $.each(b.children, function(a, c) {
                                        a = "B" == c.linkTarget ? "_blank" : "_self";
                                        var d = c.fimageL3url ? c.fimageL3url.replace(/ /g, "%20") : "",
                                            h = d ? "" : "no-img",
                                            m = "B" == c.linkTarget ? '\x3csvg class\x3d"icon" id\x3d"outlink-bold" xmlns\x3d"http://www.w3.org/2000/svg" viewBox\x3d"0 0 96 96"\x3e \x3cpath d\x3d"M81.436 14.564v54.285h-8V28.221L18.22 83.436l-5.656-5.656L67.78 22.563l-40.629.001v-8z"\x3e\x3c/path\x3e \x3c/svg\x3e' : "";
                                        d = d ? '\x3cimg class\x3d"lazy-load image__main" data-src\x3d"' + d + '" \x3e' : "";
                                        c = '\x3cli class\x3d"gnb__depth3-menu" role\x3d"presentation"\x3e\x3ca an-tr\x3d"nv00_gnb--text-depth3" an-ca\x3d"navigation" an-ac\x3d"gnb" an-la\x3d"' +
                                            (g.titleTabHeadline ? e(g.titleTabHeadline) : "") + ":" + e(b.displayName) + ":" + e(c.displayName) + '" class\x3d"gnb__depth3-link isHybrid " href\x3d"' + c.linkUrl + '" target\x3d"' + a + '"  role\x3d"menuitem"\x3e\x3cdiv class\x3d"gnb__depth3-link-text isHybrid ' + h + '"\x3e' + d + c.displayName + m + "\x3c/div\x3e\x3c/a\x3e\x3c/li\x3e";
                                        l += c
                                    }), a = b.shopAllLinkUrl, c = b.shopAllLinkTextDesktop, a = a ? '\x3cli class\x3d"gnb__depth3-menu" role\x3d"presentation"\x3e\x3ca class\x3d"gnb__depth3-link isHybrid shop-all" href\x3d"' + a + '" target\x3d"_self" role\x3d"menuitem" an-tr\x3d"nv00_gnb--text-depth3" an-ca\x3d"navigation" an-ac\x3d"gnb" an-la\x3d"' +
                                    (g.titleTabHeadline ? e(g.titleTabHeadline) : "") + ":" + e(b.displayName) + ":" + e(c) + '"\x3e\x3cdiv class\x3d"gnb__depth3-link-text isHybrid shop-all"\x3e' + c + '\x3csvg class\x3d"icon icon--next" id\x3d"next-regular" xmlns\x3d"http://www.w3.org/2000/svg" viewBox\x3d"0 0 96 96" style\x3d"width: 20px;"\x3e\x3cpath d\x3d"M31.828 16.306l3.457-3.612L72.172 48 35.285 83.306l-3.457-3.612L64.941 48z"\x3e\x3c/path\x3e\x3c/svg\x3e\x3c/div\x3e\x3c/a\x3e\x3c/li\x3e' : "", l += a, l += "\x3c/ul\x3e\x3c/div\x3e\x3c/div\x3e");
                                l += "\x3c/li\x3e";
                                h += l
                            }), h += "\x3c/ul\x3e");
                            $(b + h + c).appendTo($(d).find(".gnb__depth2-inner"))
                        }
                    }
                });
                window.sg.components.gnb.init();
                window.sg.common.lazyLoad.initAll();
                $(".gnb").on("click", ".gnb__depth2-dropdown-cta", function(a) {
                    $(this).siblings(".gnb__depth2-link").find(".gnb__depth2-link-text").click()
                });
                $(document).trigger("GNBInitialized")
            } else console.log("gnb json is invalid"), window.sg.components.gnb.init()
        }).fail(function(a) {
            console.log("error", a);
            window.sg.components.gnb.init()
        })
    }
    "us" === siteCode && a()
});

function getNextApiDomain() {
    return STORE_DOMAIN
}

function updateTotalCartCount(a) {
    /^[0-9]+$/.test(a) || (a = 0);
    99 < a && (a = 99);
    $(".gnb-cart-count").html('\x3cspan class\x3d"hidden"\x3e' + $("#productCountText").val() + " : \x3c/span\x3e" + a);
    0 < a ? ($(".gnb-cart-count").show(), ss.Auth.setCartEl(!0)) : ($(".gnb-cart-count").hide(), ss.Auth.setCartEl(!1))
}

function hideMiniCart() {
    navigation.miniCartHide()
}

function nextViewPopup(a) {
    a = $("#" + a.split("#")[1]);
    $(".layer_popup, .layer_popup_ng").hide();
    a.parent().show();
    $(".lightbox-skrim").show();
    var l = document.getElementById(a.attr("id"));
    setTimeout(function() {
        l.popAlign()
    }, 100);
    return !1
}

function hidePopup() {
    $(".layer_popup, .layer_popup_ng").hide();
    $(".lightbox-skrim").hide();
    return !1
}

function viewGlovalMessagePopup(a) {
    var l = $("#gloval_message_popup");
    l.find(".msg-text").text(a);
    l.find(".button").attr("tabindex", "1");
    l.find(".button").attr("data-focus-id", "shop-popover-ok");
    l.find(".button").attr("data-tab-next", "shop-popover-close");
    l.find(".icon-close-x").attr("data-tab-next", "shop-popover-ok");
    l.attr("data-tab-next", "nav-cart-link");
    l.find(".button").focus();
    nextViewPopup("#" + l.attr("id"));
    l.find(".button").focus();
    l.find(".pop-btn\x3e.button").click(function() {
        hidePopup();
        $(".cartbutton.item").focus();
        return !1
    })
}

function getProtocal() {
    return document.location.href.split("://")[0]
}
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.utils,
        e = function(b) {
            this.selector = {
                gnbMenu: ".gnb__depth1-menu.has-depth-menu .gnb__depth1-link, .gnb__depth2-menu.has-depth-menu .gnb__depth2-link"
            };
            this.el = {
                window: a(window),
                component: a(b)
            };
            this.handler = {
                resize: this.resize.bind(this)
            };
            e.instances.set(b, this);
            this.setElements();
            this.init()
        };
    e.prototype.setElements = function() {
        this.el.gnbMenu = this.el.component.find(this.selector.gnbMenu);
        this.breakpoint = 1279;
        this.mobileFlag = this.desktopFlag = !1
    };
    e.prototype.init = function() {
        this.bindEvents();
        this.resize()
    };
    e.prototype.reInit = function() {
        this.setElements();
        this.bindEvents();
        this.resize()
    };
    e.prototype.removeTagging = function() {
        this.el.gnbMenu.removeAttr("an-tr");
        this.el.gnbMenu.removeAttr("an-la");
        this.el.gnbMenu.removeAttr("an-ca");
        this.el.gnbMenu.removeAttr("an-ac")
    };
    e.prototype.setTagging = function() {
        this.el.gnbMenu.target.forEach(function(b) {
            var d = a(b);
            b = void 0 !== b.dataset.engname ? b.dataset.engname : "";
            var e = d.hasClass("gnb__depth1-link") ? "nv00_gnb--click-depth1" :
                "nv00_gnb--click-depth2";
            d.attr("an-tr", e);
            d.attr("an-la", b);
            d.attr("an-ca", "navigation");
            d.attr("an-ac", "gnb")
        })
    };
    e.prototype.resize = function() {
        this.breakpoint < l.getViewPort().width ? !1 === this.desktopFlag && (this.desktopFlag = !0, this.mobileFlag = !1, this.removeTagging()) : !1 === this.mobileFlag && (this.mobileFlag = !0, this.desktopFlag = !1, this.setTagging())
    };
    e.prototype.bindEvents = function() {
        this.el.window.off("resize", this.handler.resize).on("resize", this.handler.resize)
    };
    e.instances = new WeakMap;
    var g = function() {
        a(".gnb").target.forEach(function(a) {
            e.instances.has(a) ||
                new e(a)
        })
    };
    a.ready(g);
    window.sg.components.gnbTagging = {
        init: g,
        reInit: function() {
            a(".gnb").target.forEach(function(a) {
                e.instances.has(a) ? e.instances.get(a).reInit() : new e(a)
            })
        }
    }
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.libs,
        e = window.sg.common.constants.BREAKPOINTS,
        g = window.sg.common.utils,
        b = function(d) {
            this.selector = {
                section: ".footer",
                category: ".footer-category__anchor",
                categoryActive: "footer-category__anchor--active",
                categoryList: ".footer-category__list-wrap",
                categoryItem: ".footer-column__item",
                language: ".footer-language__anchor",
                languagePanel: ".footer-language__panel .footer-language__content",
                languageActive: "footer-language__anchor--active",
                languageTopTarget: ".footer-copyright-align",
                topBtn: ".footer-back-to-top__cta"
            };
            this.ele = {
                window: a(window),
                section: a(d),
                wrap2list: []
            };
            this.setProperty();
            this.isPCmode = e.MOBILE < g.getViewPort().width;
            this.handler = {
                resize: this.resize.bind(this),
                focusLock: this.focusLock.bind(this),
                outClick: this.outClick.bind(this)
            };
            b.instances.set(d, this);
            this.init()
        };
    b.prototype.setProperty = function() {
        var a = this;
        this.ele.topBtn = this.ele.section.find(this.selector.topBtn).eq(0);
        var b = this.ele.section.find("." + this.selector.categoryActive);
        this.ele.categoryActive =
            0 >= b.target.length ? null : b;
        this.ele.category = this.ele.section.find(this.selector.category);
        this.ele.language = this.ele.section.find(this.selector.language);
        this.ele.languagePanel = this.ele.section.find(this.selector.languagePanel);
        this.ele.languageTopTarget = this.ele.section.find(this.selector.languageTopTarget);
        this.ele.wrap2list = [];
        this.ele.section.find(this.selector.categoryList).target.forEach(function(b) {
            b = b.querySelectorAll(".footer-category__list");
            1 < b.length && a.ele.wrap2list.push([].concat($jscomp.arrayFromIterable(b)))
        })
    };
    b.prototype.focusLock = function(b) {
        var d = this;
        b.keyCode === l.keyCode.TAB_KEY && setTimeout(function() {
            var b = a(document.activeElement),
                e = !0;
            d.ele.languagePanel.target.forEach(function(a) {
                !0 === e && (e = 0 >= b.closest(a).target.length)
            });
            e && d.closeLanguage()
        }.bind(this), 30)
    };
    b.prototype.outClick = function(b) {
        (0 >= a(b.target).closest(this.ele.languagePanel.target[0]).target.length || b.target === document.documentElement) && this.closeLanguage()
    };
    b.prototype.init = function() {
        var a = this;
        this.setLengthTop();
        this.bindEvents();
        var b = this.ele.section.find(".image__preview");
        if (0 < b.target.length) b.eq(b.target.length - 1).on("load", function() {
            a.setLengthTop()
        })
    };
    b.prototype.reInit = function() {
        this.setProperty();
        this.bindEvents();
        this.resize()
    };
    b.prototype.resize = function() {
        this.isPCmode = e.MOBILE < g.getViewPort().width;
        this.setLengthTop();
        this.isPCmode && (null !== this.ele.categoryActive && this.closeCategory(this.ele.categoryActive, !0), this.ele.language.hasClass(this.selector.languageActive) && this.closeLanguage())
    };
    b.prototype.bindEvents =
        function() {
            var b = this;
            this.ele.topBtn.off("click").on("click", this.moveScroll.bind(this));
            this.ele.category.off("click").on("click", function(d) {
                d = a(d.currentTarget);
                d.hasClass(b.selector.categoryActive) ? b.closeCategory(d) : b.openCategory(d)
            });
            this.ele.language.off("click").on("click", function() {
                b.ele.language.hasClass(b.selector.languageActive) ? b.closeLanguage() : b.openLanguage()
            });
            this.ele.window.off("resize", this.handler.resize).on("resize", this.handler.resize)
        };
    b.prototype.moveScroll = function() {
        g.scrollTo(0)
    };
    b.prototype.openLanguage = function() {
        var a = this;
        this.isPCmode || g.hiddenScroll();
        this.ele.language.addClass(this.selector.languageActive);
        setTimeout(function() {
            a.ele.window.off("keydown", a.handler.focusLock).on("keydown", a.handler.focusLock);
            a.ele.window.off("click", a.handler.outClick).on("click", a.handler.outClick)
        }, 30)
    };
    b.prototype.closeLanguage = function() {
        g.visibleScroll();
        this.ele.language.removeClass(this.selector.languageActive);
        this.ele.window.off("keydown", this.handler.focusLock);
        this.ele.window.off("click",
            this.handler.outClick);
        this.ele.language.target.forEach(function(b) {
            "none" !== a(b).closest(".footer-language").css("display") && b.focus()
        })
    };
    b.prototype.openCategory = function(a) {
        if (null !== this.ele.categoryActive) {
            this.ele.categoryActive.removeClass(this.selector.categoryActive);
            a.addClass(this.selector.categoryActive);
            var b = a.closest(this.selector.categoryItem).target[0].getBoundingClientRect();
            b.top < -1 * a.height() && window.scrollTo(document.body.scrollLeft || document.documentElement.scrollLeft, (document.body.scrollTop ||
                document.documentElement.scrollTop) + b.top);
            this.ele.categoryActive.addClass(this.selector.categoryActive);
            a.removeClass(this.selector.categoryActive);
            this.closeCategory(this.ele.categoryActive)
        }
        a.addClass(this.selector.categoryActive);
        a.parent().find(this.selector.categoryList).slideDown(500);
        a.find(".hidden").target[0].innerHTML = "close";
        this.ele.categoryActive = a
    };
    b.prototype.closeCategory = function(a, b) {
        var c = this;
        b = void 0 === b ? !1 : b;
        var d = a.parent().find(this.selector.categoryList);
        if (b) a.removeClass(this.selector.categoryActive),
            a.find(".hidden").target[0].innerHTML = "open";
        else {
            var e = d.isAnimate();
            d.stop().slideUp(500, function() {
                a.removeClass(c.selector.categoryActive);
                a.find(".hidden").target[0].innerHTML = "open";
                e && d.css({
                    height: "",
                    display: "",
                    overflow: ""
                })
            })
        }
        this.ele.categoryActive = null
    };
    b.prototype.setLengthTop = function() {};
    b.instances = new WeakMap;
    window.sg.components.footer = {
        reInit: function() {
            a(".footer").target.forEach(function(a) {
                b.instances.has(a) && b.instances.get(a).reInit()
            })
        }
    };
    a.ready(function() {
        a(".footer").target.forEach(function(a) {
            b.instances.has(a) ||
                new b(a)
        })
    })
})();
(function() {
    var a = window.sg.common.$q,
        l = window.sg.common.menu,
        e = window.sg.common.utils.getCurrentDevice,
        g = function(a) {
            this.els = {
                el: a,
                cookieBarShopBanner: a.querySelector(".cookie-bar__app-banner"),
                cookieBarShopBannerCloseButton: a.querySelector(".cookie-bar__shop-app-close"),
                cookieBarMainArea: a.querySelector(".cookie-bar__wrap"),
                cookieBarDesc: a.querySelector(".cookie-bar__desc"),
                cookieBarDescReadMoreButton: a.querySelector(".cookie-bar__desc-read-more-btn"),
                settingButton: a.querySelector(".cookie-bar__setting"),
                settingConditionWrap: a.querySelector(".cookie-bar__setting-condition-wrap"),
                cookieBarMainCloseButton: a.querySelector(".cookie-bar__main-close")
            };
            this.isShowCookieBarDescFull = this.isShowSettingConditionWrap = !1;
            this.init()
        };
    g.prototype.init = function() {
        g.instances.get(this.els.el) || (g.instances.set(this.els.el, this), this.bindEvents(), this.checkCookieBarDescHeight())
    };
    g.prototype.reInitMobileAppBar = function() {
        this.init()
    };
    g.prototype.bindEvents = function() {
        var a = this;
        this.els.cookieBarMainCloseButton.addEventListener("click", this.closeMain.bind(this));
        this.els.cookieBarShopBannerCloseButton &&
            this.els.cookieBarShopBannerCloseButton.addEventListener("click", this.closeBanner.bind(this));
        this.els.settingButton && this.els.settingButton.addEventListener("click", function() {
            a.isShowSettingConditionWrap ? (a.els.settingConditionWrap.removeAttribute("style"), a.isShowSettingConditionWrap = !1) : (a.els.settingConditionWrap.style.display = "block", a.isShowSettingConditionWrap = !0)
        });
        this.els.cookieBarDescReadMoreButton.addEventListener("click", function() {
            a.els.cookieBarDesc.classList.remove("cookie-bar__desc--ellipsis");
            a.els.cookieBarDescReadMoreButton.style.display = "none";
            a.isShowCookieBarDescFull = !0
        });
        window.addEventListener("resize", function() {
            a.checkCookieBarDescHeight()
        })
    };
    g.prototype.checkCookieBarDescHeight = function() {
        if ("mobile" === e()) {
            if (!this.isShowCookieBarDescFull) {
                var a = parseFloat(window.getComputedStyle(this.els.cookieBarDesc).height),
                    b = parseFloat(window.getComputedStyle(this.els.cookieBarDesc).lineHeight);
                a > 2 * b && (this.els.cookieBarDesc.classList.add("cookie-bar__desc--ellipsis"), this.els.cookieBarDescReadMoreButton.style.display =
                    "block")
            }
        } else this.els.cookieBarDesc.classList.remove("cookie-bar__desc--ellipsis"), this.els.cookieBarDescReadMoreButton.style.display = "none"
    };
    g.prototype.closeBanner = function() {
        this.els.cookieBarShopBanner.classList.add("cookie-bar--hidden")
    };
    g.prototype.showBanner = function() {
        this.els.cookieBarShopBanner.classList.remove("cookie-bar--hidden")
    };
    g.prototype.closeMain = function() {
        this.els.cookieBarMainArea.classList.add("cookie-bar--hidden")
    };
    g.prototype.showMain = function() {
        this.els.cookieBarMainArea.classList.remove("cookie-bar--hidden")
    };
    g.instances = new WeakMap;
    var b = {
        init: function() {
            a(".cookie-bar").target.forEach(function(a) {
                g.instances.has(a) || new g(a)
            })
        },
        reInit: function() {
            a(".cookie-bar").find(".menu").target.forEach(function(a) {
                l.reInit(a)
            })
        },
        showCookieBar: function() {
            g.instances.get(document.querySelector(".cookie-bar")).showMain();
            g.instances.get(document.querySelector(".cookie-bar")).els.el.style.display = "block";
            g.instances.get(document.querySelector(".cookie-bar")).checkCookieBarDescHeight()
        },
        showMobileAppBanner: function() {
            this.showCookieBar();
            g.instances.get(document.querySelector(".cookie-bar")).closeMain();
            g.instances.get(document.querySelector(".cookie-bar")).els.cookieBarShopBanner.classList.add("cookie-bar__app-banner--visible");
            g.instances.get(document.querySelector(".cookie-bar")).reInitMobileAppBar()
        }
    };
    window.sg.components.cookieBar = b;
    a.ready(b.init)
})();
(function(a, l) {
    var e = [{
            site_code: "CA_FR",
            global: {
                country_name: "Canada",
                lang: "French"
            },
            local: {
                country_name: "Canada",
                lang: "Fran\u00e7ais"
            },
            country_codes: ["ca"]
        }, {
            site_code: "CA",
            global: {
                country_name: "Canada",
                lang: "English"
            },
            local: {
                country_name: "Canada",
                lang: "English"
            },
            country_codes: ["ca"]
        }, {
            site_code: "MX",
            global: {
                country_name: "Mexico",
                lang: "Spanish"
            },
            local: {
                country_name: "M\u00e9xico",
                lang: "Espa\u00f1o"
            },
            country_codes: ["mx"]
        }, {
            site_code: "BR",
            global: {
                country_name: "Brazil",
                lang: "Portuguese"
            },
            local: {
                country_name: "Brasil",
                lang: "Portugu\u00eas"
            },
            country_codes: ["br"]
        }, {
            site_code: "LATIN",
            global: {
                country_name: "Latin America",
                lang: "Spanish"
            },
            local: {
                country_name: "Latin",
                lang: "Espa\u00f1ol"
            },
            country_codes: "gt ni do bo ec sv cr pa hn".split(" ")
        }, {
            site_code: "LATIN_EN",
            global: {
                country_name: "Latin America",
                lang: "English"
            },
            local: {
                country_name: "Latin",
                lang: "English"
            },
            country_codes: "gy gp mq bb bm bz lc sr aw ht ag jm ky tt".split(" ")
        }, {
            site_code: "CO",
            global: {
                country_name: "Colombia",
                lang: "Spanish"
            },
            local: {
                country_name: "Colombia",
                lang: "Espa\u00f1ol"
            },
            country_codes: ["co"]
        }, {
            site_code: "AR",
            global: {
                country_name: "Argentina",
                lang: "Spanish"
            },
            local: {
                country_name: "Argentina",
                lang: "Espa\u00f1ol"
            },
            country_codes: ["ar"]
        }, {
            site_code: "UY",
            global: {
                country_name: "Uruguay",
                lang: "Spanish"
            },
            local: {
                country_name: "Uruguay",
                lang: "Espa\u00f1ol"
            },
            country_codes: ["uy"]
        }, {
            site_code: "PY",
            global: {
                country_name: "Paraguay",
                lang: "Spanish"
            },
            local: {
                country_name: "Paraguay",
                lang: "Espa\u00f1ol"
            },
            country_codes: ["py"]
        }, {
            site_code: "CL",
            global: {
                country_name: "Chile",
                lang: "Spanish"
            },
            local: {
                country_name: "Chile",
                lang: "Espa\u00f1ol"
            },
            country_codes: ["cl"]
        }, {
            site_code: "PE",
            global: {
                country_name: "Peru",
                lang: "Spanish"
            },
            local: {
                country_name: "Per\u00fa ",
                lang: "Espa\u00f1ol"
            },
            country_codes: ["pe"]
        }, {
            site_code: "SG",
            global: {
                country_name: "Singapore",
                lang: "English"
            },
            local: {
                country_name: "Singapore",
                lang: "English"
            },
            country_codes: ["sg"]
        }, {
            site_code: "AU",
            global: {
                country_name: "Australia",
                lang: "English"
            },
            local: {
                country_name: "Australia",
                lang: "English"
            },
            country_codes: ["au"]
        }, {
            site_code: "NZ",
            global: {
                country_name: "New Zealand",
                lang: "English"
            },
            local: {
                country_name: "New Zealand",
                lang: "English"
            },
            country_codes: ["nz"]
        }, {
            site_code: "ID",
            global: {
                country_name: "Indonesia",
                lang: "Indonesian"
            },
            local: {
                country_name: "Indonesia",
                lang: "Bahasa Indonesia"
            },
            country_codes: ["id"]
        }, {
            site_code: "TH",
            global: {
                country_name: "Thailand",
                lang: "Thai"
            },
            local: {
                country_name: "\u0e1b\u0e23\u0e30\u0e40\u0e17\u0e28\u0e44\u0e17\u0e22",
                lang: "\u0e44\u0e17\u0e22"
            },
            country_codes: ["th"]
        }, {
            site_code: "VN",
            global: {
                country_name: "Vietnam",
                lang: "Vietnamese"
            },
            local: {
                country_name: "Vi\u1ec7t Nam",
                lang: "Ti\u1ebfng Vi\u1ec7t"
            },
            country_codes: ["vn"]
        }, {
            site_code: "MY",
            global: {
                country_name: "Malaysia",
                lang: "English"
            },
            local: {
                country_name: "Malaysia",
                lang: "English"
            },
            country_codes: ["my"]
        }, {
            site_code: "MM",
            global: {
                country_name: "Myanmar",
                lang: "Burmese"
            },
            local: {
                country_name: "Myanmar",
                lang: "Burmese"
            },
            country_codes: ["mm"]
        }, {
            site_code: "JP",
            global: {
                country_name: "Japan",
                lang: "Japanese"
            },
            local: {
                country_name: "\u65e5\u672c",
                lang: "\u65e5\u672c\u8a9e"
            },
            country_codes: ["jp"]
        },
        {
            site_code: "IN",
            global: {
                country_name: "India",
                lang: "English"
            },
            local: {
                country_name: "India",
                lang: "English"
            },
            country_codes: ["in", "np", "bd", "lk"]
        }, {
            site_code: "UK",
            global: {
                country_name: "United Kingdom",
                lang: "English"
            },
            local: {
                country_name: "United Kingdom",
                lang: "English"
            },
            country_codes: ["gb", "uk"]
        }, {
            site_code: "IE",
            global: {
                country_name: "Ireland",
                lang: "English"
            },
            local: {
                country_name: "Ireland",
                lang: "English"
            },
            country_codes: ["ie"]
        }, {
            site_code: "IT",
            global: {
                country_name: "Italy",
                lang: "Italian"
            },
            local: {
                country_name: "Italia",
                lang: "Italiano"
            },
            country_codes: ["it", "mt"]
        }, {
            site_code: "ES",
            global: {
                country_name: "Spain",
                lang: "Spanish"
            },
            local: {
                country_name: "Espana",
                lang: "Espanol"
            },
            country_codes: ["es"]
        }, {
            site_code: "HU",
            global: {
                country_name: "Hungary",
                lang: "Hungarian"
            },
            local: {
                country_name: "Magyarorsz\u00e1g",
                lang: "Magyar"
            },
            country_codes: ["hu"]
        }, {
            site_code: "DE",
            global: {
                country_name: "Germany",
                lang: "German"
            },
            local: {
                country_name: "Deutschland",
                lang: "Deutsch"
            },
            country_codes: ["de"]
        }, {
            site_code: "SE",
            global: {
                country_name: "Sweden",
                lang: "Swedish"
            },
            local: {
                country_name: "Sverige",
                lang: "Svenska"
            },
            country_codes: ["se"]
        }, {
            site_code: "DK",
            global: {
                country_name: "Denmark",
                lang: "Danish"
            },
            local: {
                country_name: "Danmark",
                lang: "Dansk"
            },
            country_codes: ["dk"]
        }, {
            site_code: "FI",
            global: {
                country_name: "Finland",
                lang: "Finnish"
            },
            local: {
                country_name: "Suomi",
                lang: "Suomi"
            },
            country_codes: ["fi"]
        }, {
            site_code: "NO",
            global: {
                country_name: "Norway",
                lang: "Norwegian"
            },
            local: {
                country_name: "Norge",
                lang: "Norsk"
            },
            country_codes: ["no"]
        }, {
            site_code: "FR",
            global: {
                country_name: "France",
                lang: "French"
            },
            local: {
                country_name: "France",
                lang: "Fran\u00e7ais"
            },
            country_codes: ["fr"]
        }, {
            site_code: "PT",
            global: {
                country_name: "Portugal",
                lang: "Portuguese"
            },
            local: {
                country_name: "Portugal",
                lang: "Portugu\u00eas"
            },
            country_codes: ["pt"]
        }, {
            site_code: "PL",
            global: {
                country_name: "Poland",
                lang: "Polish"
            },
            local: {
                country_name: "Polska",
                lang: "Polski"
            },
            country_codes: ["pl"]
        }, {
            site_code: "GR",
            global: {
                country_name: "Greece",
                lang: "Greek"
            },
            local: {
                country_name: "\u0395\u03bb\u03bb\u03ac\u03b4\u03b1",
                lang: "\u0395\u03bb\u03bb\u03b7\u03bd\u03b9\u03ba\u03ac"
            },
            country_codes: ["gr"]
        }, {
            site_code: "CZ",
            global: {
                country_name: "Czech",
                lang: "Czech"
            },
            local: {
                country_name: "\u010cesk\u00e1 republika",
                lang: "\u010ce\u0161tina"
            },
            country_codes: ["cz"]
        }, {
            site_code: "SK",
            global: {
                country_name: "Slovakia",
                lang: "Slovakian"
            },
            local: {
                country_name: "Slovensko",
                lang: "Sloven\u010dina"
            },
            country_codes: ["sk"]
        }, {
            site_code: "RO",
            global: {
                country_name: "Romania",
                lang: "Romanian"
            },
            local: {
                country_name: "Romania",
                lang: "Romanian"
            },
            country_codes: ["ro"]
        }, {
            site_code: "BG",
            global: {
                country_name: "Bulgaria",
                lang: "Bulgarian"
            },
            local: {
                country_name: "\u0411\u044a\u043b\u0433\u0430\u0440\u0438\u044f",
                lang: "\u0411\u044a\u043b\u0433\u0430\u0440\u0441\u043a\u0438"
            },
            country_codes: ["bg"]
        }, {
            site_code: "AT",
            global: {
                country_name: "Austria",
                lang: "German"
            },
            local: {
                country_name: "\u00d6sterreich",
                lang: "Deutsch"
            },
            country_codes: ["at"]
        }, {
            site_code: "CH",
            global: {
                country_name: "Switzerland",
                lang: "German"
            },
            local: {
                country_name: "Schweiz",
                lang: "Deutsch"
            },
            country_codes: ["ch"]
        }, {
            site_code: "CH_FR",
            global: {
                country_name: "Switzerland",
                lang: "French"
            },
            local: {
                country_name: "Suisse",
                lang: "Francaise"
            },
            country_codes: ["ch"]
        }, {
            site_code: "BE",
            global: {
                country_name: "Belgium",
                lang: "Dutch"
            },
            local: {
                country_name: "Belgi\u00eb",
                lang: "Nederlands"
            },
            country_codes: ["be"]
        }, {
            site_code: "BE_FR",
            global: {
                country_name: "Belgium",
                lang: "French"
            },
            local: {
                country_name: "Belgium",
                lang: "French"
            },
            country_codes: ["lu"]
        }, {
            site_code: "NL",
            global: {
                country_name: "Netherlands",
                lang: "Dutch"
            },
            local: {
                country_name: "Nederland",
                lang: "Nederlands"
            },
            country_codes: ["nl"]
        }, {
            site_code: "LV",
            global: {
                country_name: "Latvia",
                lang: "Latvian"
            },
            local: {
                country_name: "Latvija",
                lang: "Latvie\u0161u"
            },
            country_codes: ["lv"]
        }, {
            site_code: "LT",
            global: {
                country_name: "Lithuania",
                lang: "Lithuanian"
            },
            local: {
                country_name: "Lietuva",
                lang: "Lietuvi\u0173"
            },
            country_codes: ["lt"]
        }, {
            site_code: "EE",
            global: {
                country_name: "Estonia",
                lang: "Estonian"
            },
            local: {
                country_name: "Eesti",
                lang: "Eesti"
            },
            country_codes: ["ee"]
        }, {
            site_code: "RS",
            global: {
                country_name: "Serbia",
                lang: "Serbian"
            },
            local: {
                country_name: "C\u0440\u0431\u0438\u0458\u0430",
                lang: "C\u0440\u043f\u0441\u043a\u0438"
            },
            country_codes: ["rs"]
        }, {
            site_code: "HR",
            global: {
                country_name: "Croatia",
                lang: "Croatian"
            },
            local: {
                country_name: "Hrvatska",
                lang: "Hrvatski"
            },
            country_codes: ["hr"]
        }, {
            site_code: "SI",
            global: {
                country_name: "Slovenia",
                lang: "Slovenijan"
            },
            local: {
                country_name: "Slovenija",
                lang: "Sloven\u0161\u010dina"
            },
            country_codes: ["sl"]
        }, {
            site_code: "AL",
            global: {
                country_name: "Albania",
                lang: "Albania"
            },
            local: {
                country_name: "Shqip\u00ebri",
                lang: "Shqi"
            },
            country_codes: ["al"]
        }, {
            site_code: "RU",
            global: {
                country_name: "Russia",
                lang: "Russian"
            },
            local: {
                country_name: "\u0420\u043e\u0441\u0441\u0438\u044f",
                lang: "\u0420\u0443\u0441\u0441\u043a\u0438\u0439"
            },
            country_codes: ["ru"]
        }, {
            site_code: "UA",
            global: {
                country_name: "Ukraine",
                lang: "Ukrainian"
            },
            local: {
                country_name: "\u0423\u043a\u0440\u0430\u0457\u043d\u0430",
                lang: "\u0423\u043a\u0440\u0430\u0457\u043d\u0441\u044c\u043a\u0430"
            },
            country_codes: ["ua"]
        }, {
            site_code: "UA_RU",
            global: {
                country_name: "Ukraine",
                lang: "Russian"
            },
            local: {
                country_name: "\u0423\u043a\u0440\u0430\u0438\u043d\u0430",
                lang: "P\u0443\u0441\u0441\u043a\u0438\u0439"
            },
            country_codes: ["ua"]
        }, {
            site_code: "KZ_RU",
            global: {
                country_name: "Kazakhstan",
                lang: "Russian"
            },
            local: {
                country_name: "\u041a\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043d",
                lang: "P\u0443\u0441\u0441\u043a\u0438\u0439"
            },
            country_codes: ["kz"]
        }, {
            site_code: "KZ_KZ",
            global: {
                country_name: "Kazakhstan",
                lang: "Kazakh"
            },
            local: {
                country_name: "\u049a\u0430\u0437\u0430\u049b\u0441\u0442\u0430\u043d",
                lang: "\u049a\u0430\u0437\u0430\u049b\u0448\u0430"
            },
            country_codes: ["kz"]
        }, {
            site_code: "UZ_RU",
            global: {
                country_name: "Uzbekistan",
                lang: "Russian"
            },
            local: {
                country_name: "\u0423\u0437\u0431\u0435\u043a\u0438\u0441\u0442\u0430\u043d",
                lang: "\u0420\u0443\u0441\u0441\u043a\u0438\u0439"
            },
            country_codes: ["uz"]
        }, {
            site_code: "UZ_UZ",
            global: {
                country_name: "Uzbekistan",
                lang: "Uzbek"
            },
            local: {
                country_name: "O'zbekiston",
                lang: "O'zbek"
            },
            country_codes: ["uz"]
        }, {
            site_code: "AE",
            global: {
                country_name: "UAE",
                lang: "English"
            },
            local: {
                country_name: "UAE",
                lang: "English"
            },
            country_codes: "bh ae ye om qa kw".split(" ")
        }, {
            site_code: "AE_AR",
            global: {
                country_name: "UAE",
                lang: "Arabic"
            },
            local: {
                country_name: "\u0627\u0644\u0625\u0645\u0627\u0631\u0627\u062a ",
                lang: "\u0627\u0644\u0639\u0631\u0628\u064a\u0629"
            },
            country_codes: ["ae"]
        }, {
            site_code: "IL",
            global: {
                country_name: "Israel",
                lang: "Hebrew"
            },
            local: {
                country_name: "\u05d9\u05e9\u05e8\u05d0\u05dc",
                lang: "\u05e2\u05d1\u05e8\u05d9\u05ea"
            },
            country_codes: ["il"]
        }, {
            site_code: "SA",
            global: {
                country_name: "Saudi Arabia",
                lang: "Arabic"
            },
            local: {
                country_name: "\u0627\u0644\u0645\u0645\u0644\u0643\u0629 \u0627\u0644\u0639\u0631\u0628\u064a\u0629 \u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629",
                lang: "\u0639\u0631\u0628\u064a"
            },
            country_codes: ["sa", "ly"]
        }, {
            site_code: "SA_EN",
            global: {
                country_name: "Saudi Arabia",
                lang: "English"
            },
            local: {
                country_name: "Saudi Arabia",
                lang: "English"
            },
            country_codes: ["sa"]
        }, {
            site_code: "TR",
            global: {
                country_name: "Turkey",
                lang: "Turkish"
            },
            local: {
                country_name: "T\u00fcrkiye",
                lang: "T\u00fcrk\u00e7e"
            },
            country_codes: ["tr"]
        }, {
            site_code: "IRAN",
            global: {
                country_name: "Iran",
                lang: "Persian"
            },
            local: {
                country_name: "\u0627\u06cc\u0631\u0627\u0646",
                lang: "\u0641\u0627\u0631\u0633\u064a"
            },
            country_codes: ["lr"]
        }, {
            site_code: "LEVANT",
            global: {
                country_name: "Levant",
                lang: "English"
            },
            local: {
                country_name: "Levant",
                lang: "English"
            },
            country_codes: ["lb", "jo", "iq", "ps"]
        }, {
            site_code: "LEVANT_AR",
            global: {
                country_name: "Levant",
                lang: "Arabic"
            },
            local: {
                country_name: "Levant",
                lang: "Arabic"
            },
            country_codes: ["lb", "jo", "iq", "ps"]
        }, {
            site_code: "PK",
            global: {
                country_name: "Pakistan",
                lang: "English"
            },
            local: {
                country_name: "Pakistan",
                lang: "English"
            },
            country_codes: ["pk", "af"]
        }, {
            site_code: "EG",
            global: {
                country_name: "Egypt",
                lang: "Arabic"
            },
            local: {
                country_name: "\u0627\u0644\u0628\u0644\u062f \u0645\u0635\u0631",
                lang: "\u0627\u0644\u0639\u0631\u0628\u064a\u0629"
            },
            country_codes: ["eg", "so", "er"]
        }, {
            site_code: "LB",
            global: {
                country_name: "Lebanon",
                lang: "Lebanon"
            },
            local: {
                country_name: "Lebanon",
                lang: "English"
            },
            country_codes: ["lb"]
        }, {
            site_code: "N_AFRICA",
            global: {
                country_name: "Africa",
                lang: "French"
            },
            local: {
                country_name: "Maroc",
                lang: "Fran\u00e7ais"
            },
            country_codes: ["ma", "dz", "tn"]
        }, {
            site_code: "AFRICA_EN",
            global: {
                country_name: "Africa Pan",
                lang: "English"
            },
            local: {
                country_name: "Africa",
                lang: "English"
            },
            country_codes: "gh gm na ng lr mw bw sz sl et ug zm zw ke tz".split(" ")
        }, {
            site_code: "AFRICA_FR",
            global: {
                country_name: "Africa Pan",
                lang: "French"
            },
            local: {
                country_name: "Afrique",
                lang: "Fran\u00e7ais"
            },
            country_codes: "ga gn ne rw re mg yt ml mu mr bj bi bf sn sc cf dj td cm km ci cg cd tg".split(" ")
        }, {
            site_code: "AFRICA_PT",
            global: {
                country_name: "Africa Pan",
                lang: "Portuguese"
            },
            local: {
                country_name: "\u00c1frica",
                lang: "Portugu\u00eas"
            },
            country_codes: ["gw",
                "mz", "ao", "cv"
            ]
        }, {
            site_code: "ZA",
            global: {
                country_name: "South Africa",
                lang: "English"
            },
            local: {
                country_name: "South Africa",
                lang: "English"
            },
            country_codes: ["za"]
        }, {
            site_code: "US",
            global: {
                country_name: "USA",
                lang: "English"
            },
            local: {
                country_name: "USA",
                lang: "English"
            },
            country_codes: ["us"]
        }, {
            site_code: "CN",
            global: {
                country_name: "China",
                lang: "Chinese"
            },
            local: {
                country_name: "\u4e2d\u56fd",
                lang: "\u4e2d\u6587"
            },
            country_codes: ["cn"]
        }, {
            site_code: "HK",
            global: {
                country_name: "Hong Kong",
                lang: "Chinese"
            },
            local: {
                country_name: "\u9999\u6e2f",
                lang: "\u7e41\u9ad4\u4e2d\u6587"
            },
            country_codes: ["hk"]
        }, {
            site_code: "HK_EN",
            global: {
                country_name: "Hong Kong",
                lang: "English"
            },
            local: {
                country_name: "Hong Kong",
                lang: "English"
            },
            country_codes: ["hk"]
        }, {
            site_code: "TW",
            global: {
                country_name: "Taiwan",
                lang: "Chinese"
            },
            local: {
                country_name: "\u53f0\u7063",
                lang: "\u7e41\u9ad4\u4e2d\u6587"
            },
            country_codes: ["tw"]
        }, {
            site_code: "SEC",
            global: {
                country_name: "Korea",
                lang: "Korean"
            },
            local: {
                country_name: "\ub300\ud55c\ubbfc\uad6d",
                lang: "\ud55c\uad6d\uc5b4"
            },
            country_codes: ["kr"]
        },
        {
            site_code: "PH",
            global: {
                country_name: "Philippines",
                lang: "English"
            },
            local: {
                country_name: "Philippines",
                lang: "English"
            },
            country_codes: ["ph"]
        }, {
            site_code: "VE",
            global: {
                country_name: "Venezuela",
                lang: "English"
            },
            local: {
                country_name: "Venezuela",
                lang: "English"
            },
            country_codes: ["sg", "ve"]
        }
    ];
    "undefined" === typeof a.smg && (a.smg = {});
    "undefined" === typeof a.smg.aem && (a.smg.aem = {});
    "undefined" === typeof a.smg.aem.common && (a.smg.aem.common = {});
    var g = function() {
        var a = l("#siteCode").val(),
            d = {
                closeBtn: ".cookie-bar__close",
                akkoordBtn: "#akkoord_btn",
                cookieAcceptBtn: ".cta--contained",
                geoSelectWrap: ".cookie-bar__select",
                visitBtnsWrap: ".cookie-bar__select-ctas .menu__select",
                geoMsgCookieWrap: ".cookie-bar__msg-wrap",
                typeManage: ".cookie-bar--type-manage",
                paramsCookie: {
                    commonaccepted: "cookiesaccepted",
                    accepted: "cookiesaccepted-geo",
                    acceptedCountries: "cookiesaccepted-countries",
                    banneraccepted: "cookiesaccepted_banner",
                    countryCodes: "country_codes",
                    siteCode: "site_cd"
                }
            };
        return {
            init: function(b, c) {
                if (!(1 > l(".cookie-bar").length)) {
                    var e =
                        "N",
                        g = navigator.userAgent;
                    if ("in" === a) {
                        if (-1 < g.indexOf("MyGalaxy") || -1 < g.indexOf("SamsungShopSDK")) e = "Y";
                        if ("Y" === e) {
                            l(".cookie-bar").remove();
                            return
                        }
                        window.sg.components.cookieBar.showMobileAppBanner()
                    }(this.$container = b).length && !this.$container.data("initialized") && a && (this.options = def(d, c || {}), this.assignedHTMLElements(), this.initProperties(), (this.isAcceptedGeo() || this.isLocalLanguageSite()) && this.$geoSelectWrap.remove(), this.isAcceptedCountries() && this.$geoMsgCookieWrap.remove(), this.isAcceptedBanner() &&
                        this.removebannerInner(), this.setCountryInfo(), !this.isAcceptedGeo() && !this.isLocalLanguageSite() && "" !== this.visitCountryCode && this.currentCountrySiteInfo[0] || !this.isAcceptedCountries() || null != this.$bannerInner) && (this.bindEvents(), this.append(), this.$container.attr("data-initialized", !0), window.sg.components.cookieBar.showCookieBar())
                }
            },
            assignedHTMLElements: function() {
                var a = this.$container,
                    b = this.options;
                this.$visitBtnsWrap = a.find(b.visitBtnsWrap);
                this.$cookieGeoClose = a.find(b.closeBtn);
                this.$akkoordBtn =
                    a.find(b.akkoordBtn);
                this.$cookieAcceptBtn = a.find(b.cookieAcceptBtn);
                this.$geoSelectWrap = a.find(b.geoSelectWrap);
                this.$selectListToggleBtn = a.find(b.selectListToggleBtn);
                this.$geoMsgCookieWrap = a.find(b.geoMsgCookieWrap);
                this.$bannerClose = l(".cookie-bar__shop-app-close");
                this.$bannerInner = l(".cookie-bar__app-banner")
            },
            initProperties: function() {
                var b = this.options.paramsCookie;
                this.testSiteCd = this.getParam(b.siteCode);
                this.currentSiteCode = a.toLowerCase();
                this.visitCountryCode = this.testSiteCd ? this.testSiteCd :
                    cookies.getCookie(b.countryCodes).toLowerCase();
                this.currentCountrySiteInfo = [];
                this.visitCountrySiteInfo = [];
                this.selectedSiteCode = "";
                this.acceptedCountries = [];
                cookies.getCookie(b.acceptedCountries) && (this.acceptedCountries = cookies.getCookie(b.acceptedCountries).split(","))
            },
            isLocalLanguageSite: function() {
                return this.currentSiteCode === this.visitCountryCode
            },
            isSameSiteGroup: function() {
                var a = this.visitCountrySiteInfo,
                    b = this.currentCountrySiteInfo[0],
                    d = !1;
                b && l.each(b.country_codes, function(b, c) {
                    l.each(a,
                        function(a, b) {
                            0 <= l.inArray(c, b.country_codes) && (d = !0)
                        })
                });
                return d
            },
            setCountryInfo: function() {
                l.each(e, l.proxy(function(a, b) {
                    a = b.country_codes;
                    var c = b.site_code.toLowerCase();
                    l.each(a, l.proxy(function(a, d) {
                        c === this.currentSiteCode && this.currentCountrySiteInfo.push(b);
                        d === this.visitCountryCode && this.visitCountrySiteInfo.push(b)
                    }, this))
                }, this))
            },
            append: function() {
                var a = this.visitCountrySiteInfo,
                    b = this.currentCountrySiteInfo[0];
                if (a.length && b) {
                    var d = "",
                        e = "",
                        g = 0;
                    this.isSameSiteGroup() || (g++, d += '\x3coption value\x3d"' +
                        g + '" site_cd\x3d"' + b.site_code.toLowerCase() + '" title\x3d"Visit ' + b.local.country_name + "/" + b.local.lang + ' site"\x3e' + b.local.country_name + " / " + b.local.lang + "\x3c/option\x3e", e = b.local.country_name + " / " + b.local.lang);
                    l.each(a, l.proxy(function(a, b) {
                            g++;
                            d += '\x3coption value\x3d"' + g + '" site_cd\x3d"' + b.site_code.toLowerCase() + '" title\x3d"Visit ' + b.local.country_name + "/" + b.local.lang + ' site"\x3e' + b.local.country_name + " / " + b.local.lang + "\x3c/option\x3e";
                            "" === e && (e = b.local.country_name + " / " + b.local.lang)
                        },
                        this));
                    this.$visitBtnsWrap.attr("data-default-message", e);
                    this.$visitBtnsWrap.html(d);
                    window.sg.components.cookieBar.reInit()
                } else this.$geoSelectWrap.remove()
            },
            bindEvents: function() {
                this.$visitBtnsWrap.on("change", l.proxy(this.onSelectBtnsClick, this));
                this.$cookieGeoClose.on("click", l.proxy(this.onCloseBtnClick, this));
                this.$akkoordBtn.on("click", l.proxy(this.onAkkoordBtnClick, this));
                this.$cookieAcceptBtn.on("click", l.proxy(this.onAcceptClick, this));
                this.$bannerClose.on("click", l.proxy(this.onBaanerCloseBtnClick,
                    this))
            },
            isTypeManage: function() {
                return this.$container.is(this.options.typeManage)
            },
            onCloseBtnClick: function() {
                this.isTypeManage() || (this.setCookieAccept(), this.setCookieGeo())
            },
            onAkkoordBtnClick: function() {
                this.isTypeManage() || (this.setCookieAccept(), this.setCookieGeo(), l(".cookie-bar").hide())
            },
            setCookieAccept: function() {
                var a = this.options.paramsCookie;
                0 > l.inArray(this.currentSiteCode, this.acceptedCountries) && this.acceptedCountries.push(this.currentSiteCode);
                cookies.setCookie(a.acceptedCountries,
                    this.acceptedCountries, 90);
                cookies.setCookie(a.commonaccepted, "true", 90)
            },
            setCookieGeo: function() {
                var a = this.options.paramsCookie;
                cookies.setCookie(a.accepted, "true", 90);
                cookies.setCookie(a.commonaccepted, "true", 90)
            },
            setBannerCookie: function() {
                cookies.setCookie(this.options.paramsCookie.banneraccepted, "true", 90)
            },
            onAcceptClick: function() {
                this.setCookieAccept();
                this.isTypeManage() ? (this.setCookieGeo(), l(".cookie-bar").hide()) : this.$geoMsgCookieWrap.remove()
            },
            onSelectBtnsClick: function(a) {
                a = this.options.paramsCookie;
                this.selectedSiteCode = l(".cookie-bar__select-ctas .menu__select option:selected").attr("site_cd");
                this.setParamsCookie(a.siteCode, this.selectedSiteCode, 999);
                this.setCookieGeo();
                this.isTypeManage() || this.setCookieAccept()
            },
            onBaanerCloseBtnClick: function() {
                this.setBannerCookie()
            },
            isAcceptedGeo: function() {
                return !!cookies.getCookie(this.options.paramsCookie.accepted)
            },
            isAcceptedBanner: function() {
                return !!cookies.getCookie(this.options.paramsCookie.banneraccepted)
            },
            isAcceptedCountries: function() {
                return 0 >
                    l.inArray(this.currentSiteCode, this.acceptedCountries) ? !1 : !0
            },
            removebannerInner: function() {
                null !== this.$bannerInner && (this.$bannerInner.remove(), this.$bannerInner = null)
            },
            setParamsCookie: function(a, b, d) {
                var c = new Date,
                    e = window.location.protocol + "//" + window.location.host + "/" + this.selectedSiteCode;
                c.setDate(c.getDate() + parseInt(d));
                document.cookie = a + "\x3d" + escape(b) + "; path\x3d/; expires\x3d" + c.toGMTString() + ";";
                window.location.href = e
            },
            getParam: function(a) {
                var b = {};
                document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g,
                    function(a, c, d) {
                        b[decodeURIComponent(c.split("+").join(" "))] = decodeURIComponent(d.split("+").join(" "))
                    });
                return b[a]
            }
        }
    }();
    l(function() {
        g.init(l(".cookie-bar__wrap"))
    })
})(window, jQuery);
(function() {
    function a() {
        l(e.section).target.forEach(function(a) {
            g.instances.has(a) || new g(a)
        })
    }
    var l = window.sg.common.$q,
        e = {
            section: ".notice"
        },
        g = function(a) {
            var b = this;
            this.selector = {
                section: e.section,
                btn: ".notice__toggle-btn",
                hidden: ".notice__toggle-btn .hidden",
                content: ".notice__inner",
                nomarl: ".notice__column notice__column--collapsed",
                expend: ".notice__column notice__column--expanded",
                close: ".notice__close"
            };
            this.timer = null;
            this.ele = {
                window: l(window),
                section: l(a),
                btn: null,
                content: null,
                nomarl: null,
                expand: null,
                close: null
            };
            this.toggleType = this.ele.section.hasClass("notice--toggle");
            this.handler = {
                resize: function() {
                    b.ele.section.css({
                        height: ""
                    });
                    b.timer && clearTimeout(b.timer);
                    setTimeout(function() {
                        b.setHeight()
                    }, 400)
                },
                clickClose: function(a) {
                    a.preventDefault();
                    b.ele.section.hide()
                }
            };
            this.init();
            g.instances.set(a, this)
        };
    g.prototype.setProperty = function() {
        this.ele.btn = this.ele.section.find(this.selector.btn);
        this.toggleType ? (this.ele.hidden = this.ele.section.find(this.selector.hidden), this.ele.content =
            this.ele.section.find(this.selector.content), this.ele.pdBanner = this.ele.section.find(this.selector.pdBanner), this.ele.nomarl = this.ele.section.find(this.selector.nomarl), this.ele.expand = this.ele.section.find(this.selector.expend)) : this.ele.close = this.ele.section.find(this.selector.close)
    };
    g.prototype.init = function() {
        this.setProperty();
        this.bindEvents()
    };
    g.prototype.reInit = function() {
        this.setProperty();
        this.bindEvents()
    };
    g.prototype.setHeight = function() {
        this.ele.section.css({
            height: this.ele.content.outerHeight() +
                "px"
        })
    };
    g.prototype.bindEvents = function() {
        var a = this;
        if (this.toggleType) this.ele.btn.off("click").on("click", function() {
            a.ele.section.hasClass("is-expanded") ? a.closeBanner() : a.openBanner()
        }), this.ele.window.off("resize", this.handler.resize).on("resize", this.handler.resize), this.setHeight();
        else this.ele.close.off("click").on("click", this.handler.clickClose)
    };
    g.prototype.openBanner = function() {
        this.ele.section.addClass("is-expanded");
        this.ele.section.attr("aria-expanded", !0);
        this.ele.nomarl.hide();
        this.ele.expand.show();
        this.ele.hidden.innerHTML("Click to Collapse");
        this.setHeight()
    };
    g.prototype.closeBanner = function() {
        this.ele.section.removeClass("is-expanded");
        this.ele.section.attr("aria-expanded", !1);
        this.ele.nomarl.show();
        this.ele.expand.hide();
        this.ele.hidden.innerHTML("Click to Expand");
        this.setHeight()
    };
    g.instances = new WeakMap;
    window.sg.components.notice = {
        init: a,
        reInit: function() {
            l(e.section).target.forEach(function(a) {
                g.instances.has(a) ? g.instances.get(a).reInit() : new g(a)
            })
        },
        closeBanner: function(a) {
            a =
                void 0 === a ? !0 : a;
            l(e.section).target.forEach(function(b) {
                g.instances.has(b) && g.instances.get(b).closeBanner(a)
            })
        }
    };
    l.ready(a)
})();